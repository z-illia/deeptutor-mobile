const { chromium } = require('playwright');
const fs=require('fs');
const root='/tmp/deeptutor-ui-audit';
(async()=>{
 const b=await chromium.launch({headless:true,executablePath:'/opt/google/chrome/chrome',args:['--no-sandbox']});
 const routeMap=JSON.parse(fs.readFileSync(root+'/route-map.json'));
 const inventory=JSON.parse(fs.readFileSync(root+'/screen-inventory.json'));
 const routes=[...new Set([...routeMap.map(x=>x.route),...inventory.map(x=>x.web_route).filter(x=>x.startsWith('/settings/'))])].filter(x=>x!='/settings/[section]');
 const results=[];fs.mkdirSync(root+'/screenshots',{recursive:true});
 for (const variant of [{theme:'snow',layout:'modern',width:1440,height:1000},{theme:'dark',layout:'modern',width:412,height:915}]) {
  const context=await b.newContext({viewport:{width:variant.width,height:variant.height},reducedMotion:'reduce'});
  await context.addInitScript(({theme,layout})=>{localStorage.setItem('deeptutor-theme',theme);localStorage.setItem('deeptutor.ui-layout',layout)},variant);
  const p=await context.newPage();
  for (let i=0;i<routes.length;i++){
   const template=routes[i];const path=template.replace(/\[surface\]/g,'chat').replace(/\[slot\]/g,'profile').replace(/\[[^\]]+\]/g,'audit-missing-record');
   const file=`screenshots/${variant.theme}-${variant.width}-${String(i+1).padStart(3,'0')}-${path.replace(/[^a-z0-9]+/gi,'-')||'root'}.png`;
   let result={template,path,...variant,file,backend:'NOT RUNNING; no API mocks or provider credentials',record:template.includes('[')?'Synthetic nonexistent ID; detail success UNVERIFIED':'No seeded data',source:routeMap.find(x=>x.route===template)?.path||'web/components/settings/SettingsPageContent.tsx'};
   try{
    const response=await p.goto('http://127.0.0.1:3137'+path,{waitUntil:'domcontentloaded',timeout:45000});
    await p.waitForTimeout(500);
    result.status=response?.status();result.finalUrl=p.url();result.body=(await p.locator('body').innerText()).slice(0,5000);
    result.tokens=await p.evaluate(()=>Object.fromEntries(['--background','--foreground','--primary','--muted','--border'].map(k=>[k,getComputedStyle(document.documentElement).getPropertyValue(k).trim()])));
    await p.screenshot({path:root+'/'+file,fullPage:false,timeout:12000});
    result.observation='VERIFIED capture of this frontend-only state; populated feature and backend-dependent interactions UNVERIFIED';
   }catch(e){result.error=String(e);result.observation='UNVERIFIED navigation/capture failure';}
   results.push(result);fs.writeFileSync(root+'/screenshot-catalog.json',JSON.stringify(results,null,2));
   if(i%12===0)console.log(`${variant.theme}: ${i+1}/${routes.length}: ${path}`);
  }
  // Additional shell interactions, kept separate from route coverage.
  await p.goto('http://127.0.0.1:3137/chat',{waitUntil:'domcontentloaded'});
  await p.waitForTimeout(500);
  if(variant.width<768){
   const toggle=p.getByRole('button',{name:'Open navigation',exact:true});
   if(await toggle.count()){
    await toggle.click();await p.waitForTimeout(250);
    const file='screenshots/dark-mobile-navigation-open.png';await p.screenshot({path:root+'/'+file});
    results.push({template:'/chat',path:'/chat',...variant,file,source:'web/components/layout/AppShell.tsx',observation:'VERIFIED navigation drawer opened; reduced motion enabled'});
   }
  }
  const search=p.getByRole('button',{name:'Search',exact:true}).first();
  if(await search.count()){
   try{await search.click({timeout:2000});await p.waitForTimeout(200);const file=`screenshots/${variant.theme}-search-open.png`;await p.screenshot({path:root+'/'+file});results.push({template:'/chat',...variant,file,source:'web/components/sidebar/CommandPalette.tsx',observation:'VERIFIED search control opened; no backend records'});}catch(e){}
  }
  await context.close();
 }
 fs.writeFileSync(root+'/screenshot-catalog.json',JSON.stringify(results,null,2));
 console.log('Captured entries: '+results.length);
 await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
