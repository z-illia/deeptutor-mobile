# Android adaptation and implementation sequence

Everything in this document is PROPOSED. Web behavior cited by inventory ID is VERIFIED in source unless the inventory explicitly marks it otherwise. No implementation was authorized or performed.

## Product scope and navigation

Preserve the current Modern product structure as the initial baseline because `lib/ui-layout.ts` defaults to Modern; do not blend Classic headings, Modern shell geometry and starter-app palette into an invented third identity. Keep Classic parity a separate presentation task if both layouts must ship. Preserve all existing terms in their context: Home/Chat, Learning, Resources, Favorites, Learning notebook/Co-Writer, Mastery Path, Practice, Question Bank, Mistakes, Partners and Personalization. Sources: S01–S03, S16, S39–S40, S45–S46, S62–S63.

Use Expo Router under `src/app/`, as required by mobile AGENTS.md. A phone drawer follows the source's existing responsive behavior. The drawer contains the same shelves and their permitted child pages, with workspace selection at the top and account utilities accessible from their source-equivalent menu. Do not install a permanent five-tab Home/Chat/Learn/Library/Profile structure from unused demo translations; it would replace actual product navigation and duplicate Home/Chat.

```mermaid
flowchart TD
    Shell[PROPOSED Android shell — source shelves] --> Home[Home: Chat / Calendar / Task Board / Learning notebook]
    Shell --> Learning[Learning dashboard and create chooser]
    Learning --> Books[Books: library → proposal/spine → reader]
    Learning --> Mastery[Mastery Path: atlas → path detail → study conversation]
    Learning --> Practice[Practice: daily review → question session]
    Learning --> Reading[Immersive Reading: collections/materials → reader]
    Shell --> Resources[Resources: history / Favorites / journal / Question Bank / Knowledge Center]
    Shell --> Partners[Account Partners: directory → partner/group conversation]
    Shell --> Personal[Account Personalization: agents / personas / skills / MCP / CLI / memory]
    Shell --> Account[Profile / Settings / authorized admin / handoff]
```

Nested mobile destinations may be introduced to replace desktop columns without inventing new capabilities. Examples: objective detail from the Mastery board, the reader's companion pane, a service provider editor, a session file viewer and a task's status chooser. Such destinations must cite their web host, carry the same record identifiers, and return to the same scroll/selection state.

## Mobile screen anatomy and interaction rules

| Surface | PROPOSED phone composition | Source link through inventory |
|---|---|---|
| Chat home | Safe-area header: navigation + workspace/location; flexible greeting/starters; composer above keyboard; compact model/capability/resource controls | S04/S06 |
| Conversation | Compact title/actions; message list; inline activity/results; persistent composer; resource context visible on demand; viewer opened as secondary screen | S05/S07/S08 |
| Learning dashboard | Source header; create action; stacked learning cards/items with source-specific counts; preserve unavailable/hidden differences | S16/S17 |
| Mastery atlas | Source goal cards with progress and next step; create goal action | S18/S19 |
| Mastery detail | Topic identity/sources; outline/board switch; single-column points; objective sheet/detail; sessions and due-review entry; edit/reset/delete actions | S20/S120 |
| Mastery conversation | Transcript plus explicit Outline/Study/Review switch; contextual question response; outline/session drawers; celebration overlay | S21/S22 |
| Practice | Today review summary and due count; start button; insights/import; question-at-a-time session with reveal, correctness, recall rating, completion | S23/S25/S26 |
| Question Bank | Bank/Mistakes tabs; query/filter/category control; card list; selection bar; import; practice selected questions | S24/S119 |
| Books | Library → creator → proposal/spine confirmation → reader; reader offers chapter navigation/chat/captures separately; generation/paused/error always tied to source book/page | S27–S30/S124 |
| Reading | Collections/materials navigation; collection contents → reader; one active document/media stage; source/outline and tutor via explicit controls; passage/timestamp remains attached to chat | S31–S38 |
| Knowledge Center | Knowledge bases/engines tabs; list cards; KB detail section selector; long create/link or engine forms full-screen; indexing summary with expandable logs | S41–S44/S125–S127 |
| Favorites | Collection list → original record list/detail; filters/source type; existing save/import-reference actions; independent from editable note pages | S45–S47 |
| Learning notebook | Hierarchical pages, pinned/recent grouping; page editor with tree/outline/companion accessible separately; save/recovery banner; due flashcards overlay | S62/S63/S121–S123 |
| Task Board | Source status columns as horizontal sections or status-filtered list; task editor; explicit status move and archive controls as drag equivalent | S64 |
| Calendar | Source Month/Agenda on phone; view selector includes parity work for Day/Week; date/layer/search controls; item sheet/editor; recurrence scope remains explicit | S65 |
| Partner | Directory → chat-first detail with tabs for source configuration/channels; session/continuity controls; five-step creation; source archive/link/export actions | S66–S69/S132 |
| Partner group | Attributed transcript/rounds; member/mode/session controls; side detail on demand; separate create/edit/delete confirmation | S70/S71 |
| Personalization | Account-resource lists; Markdown viewers/editors; connection forms; memory layer navigation; imported-history workflows | S49–S61/S117/S118 |
| Settings/admin | Source sections as navigation list; nested editor for wide master/detail pages; sticky staged draft actions; role/preset filtering; admin user details split from table | S76/S79/S81–S115/S130/S131 |

Screens shown in the current mobile starter are not retained as product features. Existing themed primitives may be adapted only if they can express the extracted roles; the starter branding and token values are not DeepTutor assets. This is future implementation guidance, not a request to remove existing files now.

## Overlay presentation policy

Short action menus, category/move/sort choices and a modest model selector are bottom-sheet candidates. Multi-select references, provider catalogs, creation wizards and editors require taller sheets or full-screen modals so keyboard and long lists remain usable. Generated document/interactive viewers and the note editor may need full screens. Small status/progress cards stay embedded. Destructive confirmations preserve the exact distinction between archive, remove-from-collection, delete-record, reset-progress and permanent delete.

Native Back should close the topmost dismissible overlay, then navigate within the feature. Preserve busy guards from the actual owner. Closing an overlay must restore accessibility focus to its trigger. Leaving a conversation does not imply canceling a durable server turn; source behavior and explicit cancel acknowledgment determine that. Source: shared Dialog/Modal/PickerShell, S05/S21/S34 and TurnRuntimeClient acknowledgment rules.

No hover-only actions: expose them with a labeled overflow control or persistent affordance. Preserve source tooltips as accessibility labels or explicit help, not long-press-only information. Drag interactions need an explicit equivalent: Move task, reorder field/action where editing is supported, source picker, or chapter controls. Source: S02/S06/S37/S64/S65 and component-catalog.md.

## Architecture boundaries

PROPOSED directories, not created application files:

```text
src/app/                 Expo Router route entry/layout files only
src/features/chat/       conversation controllers, projections and components
src/features/learning/   shared dashboard; separate mastery/practice/books/reading owners
src/features/resources/ history, Favorites, knowledge, journal
src/features/notes/      editable learning notebook and companion
src/features/partners/  partner/group views and configuration
src/features/calendar/  source calendar model and mobile views
src/features/tasks/     task board model and views
src/features/settings/  source sections, access, staged drafts
src/shared/ui/          extracted theme/layout typography and primitives
src/shared/contracts/   source-derived types with explicit version provenance
src/shared/transport/   deployment URL, session/workspace scope, durable events
src/shared/storage/     only source-supported persistence with account isolation
```

Preserve feature ownership even if initial folders are smaller. Do not put utilities, test fixtures, shared components or raw contracts in `src/app`, where files become routes. Existing Axios/Zustand installations are options, not evidence that either pattern is required. Keep feature state lifetimes explicit: account session, content workspace, current chat/turn, selected book/page, reading collection/material, and local presentation preference.

Web code is not directly portable: DOM elements, Next navigation, browser storage, CSS selectors, PDF.js/EPUB/BlockNote and iframe rendering require replacement/adaptation. Reuse pure contracts, identifiers, derived-state functions and proven protocol logic after dependency inspection; do not copy hooks that assume document/window without changing their lifecycle owner.

## Contract and lifecycle constraints needed for UI parity

This is an audit of existing UI consumption, not API design. Source owners to inspect during implementation: `web/contracts`, `shared/api/client.ts`, `lib/auth.ts`, `lib/workspace-scope.ts`, `lib/session-api.ts`, `features/chat/model/{protocol,start-turn}.ts`, `features/chat/transport/{UnifiedTurnClient,TurnRuntimeClient}.ts`, `packages/chat-engine`, and feature API/type modules referenced by each surface.

- Browser authentication uses credentialed requests and runtime `/api/auth/status`; no JWT/token scheme should be invented for the mobile app. Prove the supported mobile cookie/session behavior against an isolated backend. Wrong login credentials remain an inline form error; protected-operation 401 follows the auth boundary.
- Keep normalized return paths and handoff redemption separate from a chat-sharing feature. Source handoff codes are account/session utilities.
- Content-workspace scope is part of requests/navigation and cache identity. On switch, detail records may return to the owning index and workspace runtime stores remount; account Partners/Personalization remain account-wide. Never reuse old-workspace query results under a new ID.
- Durable turn admission, acknowledgments, event ordering, replay after sequence cursor and reconnect are state-machine concerns. Mobile background/foreground/network transitions must reconcile; reconnect must not blindly resend a user message and duplicate a turn.
- Stream projection needs text, thoughts/tools/activity, ask-user continuation, capability result, cancellation/retry, final response and usage states. Unknown or mismatched protocol cannot be rendered as a successful blank answer.
- Typed references differ: book/page/block, reading material/unit/locator/timestamp, notebook original record, question entry, memory surface/ref/focus, imported agent history and task link. Do not flatten all into a generic attachment string.
- Mutations use source identity/revision/idempotency semantics where present: Practice conflict reload, note expected_revision/recovery, question IDs and command acknowledgment. Preserve user input on a failed save rather than reset the screen to success.
- Module installed/enabled/ready, manifest capability availability, LLM access, learner policy, admin-only settings and record read_only are separate UI inputs. Pending probes must not briefly expose unauthorized functionality.

The existing mobile Axios file is insufficient to establish these guarantees. It should be reviewed during later implementation, including deployment path normalization and the assumption that every base URL needs `/api` appended. This audit does not change it or invent a replacement server contract.

## Rendering and native-integration decision gates

| Area | Source requirement | PROPOSED experiment and completion criterion |
|---|---|---|
| Markdown/math/code | GFM, tables, inline/block math, syntax themes, copy, citations | Compare a source-grounded fixture covering each feature on Android; preserve links/formulas/accessibility and large response performance |
| PDF/EPUB/document reading | Page/unit locators, selection anchors, annotation layers, display prefs, source jumps | Prove original document loading, persisted locators across reflow/rotation/font change, selection-to-tutor and annotation restore before choosing a renderer |
| Rich notes | BlockNote schema, nested pages, threads, AI suggestions/review, revision conflict, undo/selection | Evaluate isolated embedded editor against a native block implementation; choose only after proving serialization, selection, keyboard, undo and save recovery |
| SVG/charts/Mermaid/HTML | Source-generated visualizations with fullscreen/code/copy | Evaluate native SVG for static content and constrained embedded web runtime for interactive DOM outputs; preserve renderer identity and supported controls |
| GeoGebra/math animation/Video Lesson | Interactive board, rendered video or browser-live lesson | Verify actual output delivery format and playable artifact before committing to native video; browser-live Remotion output is not automatically an MP4 |
| Audio/video/voice | Mic recording/transcription, TTS playback/autoplay, synchronized media transcript | SDK 58 expo-audio/expo-video candidates; prove permission denial, interruption, headset/background transition and timestamp grounding against source providers |
| Import/export | Android file selection; source accepted types; blob/download alternatives | SDK 58 document-picker/file-system/sharing candidates; test file URI upload, cancellation, MIME/size validation and opening exported artifact |
| Calendar reminders | Web Notification permission and browser/runtime behavior | Establish whether backend and native scheduling can preserve current semantics; do not promise background notifications from browser-only source code |
| Memory graph | Source layer colors, visibility, pan/zoom/selected node | Accessible mobile node detail plus gesture rendering test; source graph is custom UI and must not be redesigned from installed Cytoscape defaults |

Current documentation anchors: [Expo SDK 58](https://docs.expo.dev/versions/v58.0.0/), [Router introduction](https://docs.expo.dev/router/introduction/), [DocumentPicker](https://docs.expo.dev/versions/v58.0.0/sdk/document-picker/), [Audio](https://docs.expo.dev/versions/v58.0.0/sdk/audio/), [Video](https://docs.expo.dev/versions/v58.0.0/sdk/video/). Recheck matching versioned APIs before writing code. Install compatible packages later with `npx expo install`, since this project has package-lock.json and no bun.lock. No dependency addition is part of this audit.

## Accessibility, performance and platform compatibility

Preserve content hierarchy and source control labels while adapting physical interaction: proposed minimum 48dp action regions, system font scaling, TalkBack headings/selected/expanded/busy announcements, focus restoration and reduced motion. Large font settings must not hide Send, rating controls, destructive-confirmation copy or staged settings Apply. Theme contrast must be checked on actual source palettes, including alpha surfaces in Glass, rather than substituting a generic Material palette.

Use one principal vertical scroller per phone screen; virtualize long histories, question banks and large file lists; keep editor/document scroll ownership explicit. Keep streaming canonical data separate from display batching, avoid re-parsing an entire transcript for every token, and lazily mount heavy result renderers. Cache by account/workspace/record/version and evict sensitive cross-account state on auth boundary. These are architectural proposals driven by source state lifetimes, not new user-facing features.

Avoid implementing offline write queues, local-only AI simulations, push notifications or background downloads without a source-supported behavior and tested server contract. On transient failure preserve current view/input and expose the owning source retry/error state. Android-specific keyboard, system Back, media permission and file-picker behavior need device tests; browser responsiveness is not proof of native compatibility.

## Proposed delivery sequence and parity scope

| Milestone | Concrete result | Required evidence before moving on |
|---|---|---|
| 0 — close runtime gaps | Isolated Python backend with synthetic authorized fixtures; successful source web flows and capture catalog for each meaningful state | No real learner data; record source SHA, auth modes, grants, modules and fixture identities; populated/empty/error/loading screenshots |
| 1 — fidelity foundation | Effective theme/layout tokens, original assets, typography, reusable buttons/fields/dialogs/statuses, source navigation tree and route mapping | Compare Default/Dark phone shell, readable text scaling, drawer and Back/focus behavior; lint/typecheck |
| 2 — connection and core chat | Source auth/session/workspace handling; Home/conversation/history; basic references/attachments; durable stream and ask-user | Reconnect without duplicate send; session restore; authorized/denied/expired states; stop/retry; workspace switch isolation |
| 3 — learner MVP | Four source learning entries; full Mastery goal/detail/study loop; Practice/import/Question Bank; Books proposal/spine/reader; Reading collections/materials/reader+companion; Favorites and journal | Each loop has loading/empty/error/success validation; document/renderer spikes passed; if a feature fails, explicitly defer it rather than show a fake success |
| 4 — content and collaboration parity | Learning notebook rich editing/review, full visualization/Video Lesson/GeoGebra, Partners/groups/channels, Task Board and Calendar | Editor conflict recovery; generated output fidelity; partner continuity; recurrence/reminder behavior; import/export device tests |
| 5 — expert/admin parity | Knowledge ingestion/engine/source/version/progress management; Memory workbenches/graph; agents/history import; Skills/Personas/MCP/CLI; advanced Settings and user admin | Admin/learner/grant matrix; read-only resources; server-folder semantics; configuration stage/save/apply; migration and destructive-action review |
| 6 — release verification | Android regression suite and full parity ledger for all inventory IDs; final deferred-feature list | Real-device performance/accessibility, full state screenshots, lint/typecheck, compatible dependencies; no unresolved critical cross-workspace/session data leakage |

This is a proposed sequence, not an approved restriction of final functionality. Phase 3 is a learner-oriented MVP; advanced settings remain inventoried in S81–S115, with Profile/General/Appearance and essential connection readiness needed earlier. Providers/model configuration may initially be managed through the existing web UI, but that limitation must be visible in delivery scope. Do not label incomplete mobile functionality as parity-complete.

No credible person-day estimate is available before the rich editor/document/interactive renderer and session-auth spikes. Those dominate scope more than route scaffolding. Estimate each feature after its runtime fixtures and decision gates are complete, with separate values for native view work, renderer adaptation, transport/state parity and device verification.

## Acceptance checklist by behavior

- New chat binds one persistent session; existing chat restores the correct transcript and context; errors are recoverable and no duplicate turns appear after foreground/reconnect.
- Every visible capability is runtime-available and policy-permitted; Quiz, Research and Visualize configs retain source fields and validation; outputs retain their original viewer/actions.
- Mastery creation hands off the goal/materials into Outline; mode switching obeys live-turn restrictions; objectives, due reviews and reset/delete semantics remain separate.
- Practice rates using original values, handles stale questions/conflict, preserves cross-workspace references and displays completion counts; generated quiz judgment is a separate flow.
- Books preserve proposal/spine confirmation, asynchronous generation, placeholder/paused/failure/rebuild state and page identity.
- Reading preserves source/collection/material/session identity, passage/timestamp context, annotations, display preferences and source jumps.
- Favorites preserve original content, while editable Learning notebook preserves blocks/revisions/AI-review links; journal remains mission/handoff/confirmed records.
- KB source sections follow engine eligibility/read-only status; indexing progress and version publication never become an invented local phone index.
- Settings preserves clean/unsaved/saved-draft/applied distinctions and access filtering; advanced user management is admin-only; learning policies restrict both navigation and operations.
- All 63 source page files have a routing decision; redirects and reused rendering routes do not inflate the mobile screen count; every proposed nested destination names its web host.

The remaining runtime observations must be completed before design sign-off claims full visual fidelity. Static inventory completion alone is not implementation readiness for the renderer and authenticated-streaming boundaries.
