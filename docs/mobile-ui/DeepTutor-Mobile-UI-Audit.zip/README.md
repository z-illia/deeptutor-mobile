# DeepTutor mobile: source audit and Android implementation plan

Research and specification only. No mobile application implementation or refactoring was performed. The mobile project and original web checkout were inspected read-only; all audit documents, scripts, dependencies and browser output are under this temporary directory.

The official `main` branch and the clean local `main` checkout both resolved to **`f7aed0744c36c5afef16a4261c31ebee1208cac2`**, tag **v1.7.1**, when checked on 2026-11-05. The commit is dated 2026-11-01 +08:00. Audit scope is that exact version, not a historical screenshot set. [Pinned official source](https://github.com/HKUDS/DeepTutor/tree/f7aed0744c36c5afef16a4261c31ebee1208cac2).

Read these documents in order:

1. [Audit findings and existing mobile architecture](audit-findings.md).
2. [Route accounting](route-map.md): all 63 page files, redirects and reused renderers.
3. [Screen and secondary-surface inventory](screen-inventory.md): 135 audit records covering navigable views, tabs, embedded capabilities, contextual controls and secondary overlays. **This is not a claim of 135 standalone screens.** Each record contains the requested identity, route, sources, layout, entry, purpose, sections, components, actions, overlays, four state fields, permissions, dependencies, mobile adaptation and evidence.
4. [Design system specification](design-system.md), with [exact CSS token extraction](design-tokens.json).
5. [Reusable component catalog](component-catalog.md).
6. [Android adaptation and implementation sequence](mobile-plan.md).
7. [Visual verification catalog and limits](screenshot-catalog.md).
8. [Validation record](validation.md).

Machine-readable companions: [screen inventory](screen-inventory.json), [CSV index](screen-index.csv), [route map](route-map.json), [asset manifest](asset-manifest.json), [source-file manifest](source-files.json), [source excerpts](source-evidence.md), [component evidence](component-evidence.json), [capture metadata](screenshot-catalog.json).

**Evidence labels:** VERIFIED means directly established in the pinned source, or explicitly identified as an actual capture observation. It never means that an unexecuted backend workflow succeeded. INFERRED means supported architectural interpretation. UNVERIFIED means a runtime check, permission outcome, data state or specific presentation remains unestablished. PROPOSED means a mobile design/engineering decision. The implementation plan is entirely proposed, with source evidence attached.

The request ends at the Phase Five heading. This report interprets that heading as a request for source-traceable Android adaptation and an implementation sequence; it does not assume additional unseen requirements.

The important product boundaries are preserved: Home is Chat; the four learning surfaces remain separate; Favorites and the editable Learning notebook are different systems; journal entries are structured tutor records; account resources and workspace content have different scopes; chat capabilities do not become invented top-level screens. Advanced configuration and administration are inventoried even when proposed for delivery after a learner MVP.

Runtime coverage is partial. An isolated Next frontend ran and browser captures were attempted, without API mocks, seeded records or a Python backend. The catalog identifies actual captures, redirects, missing-record IDs and failures. Successful chat, learning, indexing, auth and permission workflows remain unverified. No provider requests or production actions were made.
