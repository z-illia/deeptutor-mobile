# Design system extracted from source

VERIFIED source values; browser-computed precedence must include layout overrides below. All CSS values are web pixels, not pre-approved Android dp/sp conversions. PROPOSED mobile changes are explicitly separate.

## Exact base palettes

From `web/app/globals.css`, beginning at the Cream `:root`, Dark `.dark`, Default `.theme-snow`, Glass `.theme-glass` blocks. The complete extraction, including later overrides and feature tokens, is design-tokens.json.

| Token | Cream (light) | Dark | Default (snow) | Glass |
|---|---|---|---|---|
| --background | `#fdfcf9` | `#1a1918` | `#ffffff` | `#0e0d1a` |
| --foreground | `#1c1816` | `#e8e4de` | `#0d0d0d` | `#ffffff` |
| --card | `#ffffff` | `#242220` | `#ffffff` | `rgba(255, 255, 255, 0.06)` |
| --card-foreground | `#1c1816` | `#e8e4de` | `#0d0d0d` | `#ffffff` |
| --popover | `#ffffff` | `#242220` | `#ffffff` | `rgba(24, 22, 36, 0.92)` |
| --popover-foreground | `#1c1816` | `#e8e4de` | `#0d0d0d` | `#ffffff` |
| --primary | `#b0501e` | `#d4734b` | `#2563eb` | `#a855f7` |
| --primary-foreground | `#ffffff` | `#1a1918` | `#ffffff` | `#ffffff` |
| --secondary | `#f5f2ea` | `#2a2725` | `#f7f7f7` | `rgba(255, 255, 255, 0.04)` |
| --secondary-foreground | `#1c1816` | `#e8e4de` | `#0d0d0d` | `#eeeeee` |
| --muted | `#f1ede2` | `#2a2725` | `#f2f2f2` | `rgba(255, 255, 255, 0.06)` |
| --muted-foreground | `#6d645a` | `#9b9590` | `#6e6e6e` | `#b5b5c7` |
| --accent | `#ece7d8` | `#302d2a` | `#ececec` | `rgba(255, 255, 255, 0.12)` |
| --accent-foreground | `#1c1816` | `#e8e4de` | `#0d0d0d` | `#ffffff` |
| --destructive | `#c53a2c` | `#d44a3c` | `#d92d20` | `#f07178` |
| --destructive-foreground | `#ffffff` | `#ffffff` | `#ffffff` | `#ffffff` |
| --border | `#e6decc` | `#3a3634` | `#e5e5e5` | `rgba(255, 255, 255, 0.12)` |
| --input | `#e6decc` | `#3a3634` | `#e5e5e5` | `rgba(255, 255, 255, 0.06)` |
| --ring | `#b0501e` | `#d4734b` | `#2563eb` | `#a855f7` |
| --overlay | `rgba(28, 24, 22, 0.42)` | `rgba(0, 0, 0, 0.6)` | `rgba(0, 0, 0, 0.4)` | `rgba(0, 0, 0, 0.55)` |
| --success | `#237a4b` | `#5fd08a` | `#16794b` | `#68dfa0` |
| --success-foreground | `#14532d` | `#bbf7d0` | `#14532d` | `#bbf7d0` |
| --success-surface | `#ecf8f0` | `#173424` | `#ecfdf3` | `rgba(34, 197, 94, 0.14)` |
| --warning | `#a15c00` | `#f2b84b` | `#a15c00` | `#f7c65a` |
| --warning-foreground | `#713f12` | `#fde68a` | `#713f12` | `#fde68a` |
| --warning-surface | `#fff7df` | `#3a2c16` | `#fffaeb` | `rgba(245, 158, 11, 0.16)` |
| --info | `#2563eb` | `#7ba7ff` | `#2563eb` | `#9ab7ff` |
| --info-foreground | `#1e3a8a` | `#bfdbfe` | `#1e3a8a` | `#dbeafe` |
| --info-surface | `#eff6ff` | `#172641` | `#eff6ff` | `rgba(59, 130, 246, 0.16)` |
| --surface-raised | `#ffffff` | `#2a2826` | `#ffffff` | `rgba(35, 32, 51, 0.96)` |
| --shadow-raised | `0 16px 40px rgba(69, 49, 31, 0.12)` | `0 16px 44px rgba(0, 0, 0, 0.32)` | `0 16px 40px rgba(13, 13, 13, 0.12)` | `0 18px 48px rgba(0, 0, 0, 0.42)` |

## Effective Modern Default overrides

The default layout is Modern. Its CSS loads after the base palette and overrides Default, so using base snow text/borders directly would be inaccurate. `web/features/ui-layout/modern/modern.css:29` onward sets foreground/card/popover/secondary/accent foreground to `#37352f`, muted foreground `#787774`, secondary `#f8f8f7`, muted `#f1f1ef`, accent `rgb(55 53 47 / 0.06)`, border `rgb(55 53 47 / 0.09)`, input `rgb(55 53 47 / 0.16)`, and raised shadow to `var(--dt-shadow-md)`. Background remains `#ffffff` and primary remains `#2563eb`.

Theme initialization: stored `dark`, `glass`, `snow`, `light` map to CSS classes; `light` means Cream; missing/system/unrecognized preference follows OS and uses Default for light or Dark for dark. Glass also carries `.dark`. UI layout defaults to Modern independently of theme. Do not assume Cream is the startup light palette merely because its tokens use `:root`. Source: ThemeScript.tsx and lib/ui-layout.ts.

Modern neutral ink is `55 53 47` in light, `255 255 255` in dark/glass. Feature-specific annotation/folder colors and learning icon accents are not the global primary. Mastery status colors and memory graph layer mixtures remain source-specific; the graph derives L3/L2/L1 from primary/foreground rather than generic graph-library colors.

## Typography and hierarchy

| Role | VERIFIED source definition | Mobile specification |
|---|---|---|
| Sans | Geist, loaded through next/font/google into --font-sans | PROPOSED bundle original licensed face; establish Android fallback for unsupported scripts |
| Serif | Lora into --font-serif | PROPOSED retain for source serif roles, including Classic page headings and learning content where requested |
| CJK fallback | Sans: PingFang SC, Hiragino Sans GB, Microsoft YaHei, Noto Sans SC, system-ui; serif: Songti SC, STSong, Noto Serif SC, Source Han Serif SC, SimSun, Georgia | PROPOSED Android font coverage must be tested; platform-only desktop fonts cannot be copied by family name alone |
| Feature title base | 27px; 30px at 640px content-container width; semibold, normal leading, -0.02em tracking | Preserve hierarchy; scale for narrow layouts after device proof |
| Modern feature title | sans; weight 700; -0.025em; line-height 1.2; 32px at 640px content width | Source modern hierarchy is baseline |
| Classic feature title | serif via --dt-page-title-font | Keep a separate layout token if Classic parity is shipped |
| Description | base 12.5px relaxed; Modern 14px / 1.6 with 8px top margin | PROPOSED use readable scalable text without arbitrarily changing product hierarchy |
| Section label | FeaturePage 13.5px semibold | Keep distinct from page title |
| Field label/hint | shared Field text-sm medium; hint/error text-xs, 20px leading | Preserve hint and validation linkage |
| Modern navigation | 13px rows; 12.5px lists; 12px section labels | PROPOSED larger accessible hit area independent of glyph/text size |
| Learning prose | base 16px × --learning-font-scale; line-height 1.75 configurable | Preserve preference separate from shell text size |
| Learning h1–h6 | 24/20/18/16/14/14 × learning scale; baseline line heights 32/28/28/24/20/20 adjusted by preference | Native renderer must reproduce nesting without compounded scale |
| Learning tables | 14px × scale | Horizontal overflow or structured access, retain all cells |
| Reader text | default 17; min 12/max 28; serif true; line width 84 characters (48–104) | Preserve settings and locators; Android layout may clamp line width to available width |
| Code | ui-monospace/monospace roles; rich code styling and syntax theme modules; selected inline styles use --font-geist-mono fallback | Do not claim Geist Mono is loaded: root layout loads only Geist and Lora |

Source: web/app/layout.tsx; tailwind.config.js; components/layout/FeaturePage.tsx; globals.css learning-text rules; features/ui-layout/*/*.css; lib/reading-display-preferences.ts. Markdown uses ReactMarkdown with GFM/math and KaTeX integration in common renderers; raw HTML is supported in specific rich rendering paths. Native rendering must preserve formulas, citations, links, fenced code/copy behavior, tables and directionality rather than flatten output into plain text.

## Spacing, geometry and density

Tailwind spacing utilities are used alongside arbitrary pixel values; the repository does not publish one universal custom spacing token scale. Observed shared spacing includes 4/6/8/10/12/16/20/24/28/32/36/48/64px, with component-specific values. Treat these as source observations, not a fabricated design-token API.

FeaturePage: max width 1180; horizontal gutters 24, then 36 at viewport md; vertical base 28, then 36 at lg. Modern overrides top padding to 48, then 64 at 1024. Header-to-content margin 24. Grid gap 12. Content-container breakpoints 520 → two columns, 800 → three where enabled, 1040 → four/five. Header actions move beside title at content width 640; below this they wrap below. These differ from viewport breakpoints.

Sidebar resize hook: default/min 220, max 480 capped at 45% viewport; actual modern callers may supply their own default. A captured initial modern shell is about 272px wide; do not mistake the hook default for every rendered sidebar width. Phone shell top bar is h-11 (44px), menu button h-9 (36px); root shell h-dvh. Header/page bars use contextual slots rather than one global fixed header height. Source pane constraints include navigator min 184/max 400, companion min 300, reader min 360, divider 5 in reading layout logic; these desktop constraints cannot all fit side by side on a phone.

Modern radii: --dt-radius-sm 6px, md 8px, lg 12px; navigation radius 7px; page icon tile 14px. Shared Button sm rounded-lg (8), md/lg rounded-xl (12); dialog rounded-2xl (16); generic cards rounded-2xl; chips fully rounded. Feature CSS can override these defaults. Shared button heights 32/40/48; page actions min 44 below the container threshold and min 36 above. PROPOSED Android target minimum 48dp for actions, including small visual icons, with clear focus/pressed/disabled affordance.

Modern light shadows: xs `0 0 0 1px rgb(15 15 15 / 0.04), 0 1px 2px rgb(15 15 15 / 0.06)`; sm `0 0 0 1px rgb(15 15 15 / 0.05), 0 2px 4px rgb(15 15 15 / 0.06), 0 6px 16px -6px rgb(15 15 15 / 0.1)`; md `0 0 0 1px rgb(15 15 15 / 0.05), 0 3px 6px rgb(15 15 15 / 0.08), 0 9px 24px rgb(15 15 15 / 0.14)`. Exact dark overrides are in design-tokens.json. Base raised shadows are recorded in palette table. PROPOSED Android elevation/shadow implementation must be visually matched; arbitrary elevation numbers are not source tokens.

## Interaction states and motion

Shared primary button: primary/background + primary foreground, small shadow; hover brightness 95%, active 90%. Secondary: border + secondary surface, hover muted, active accent. Danger: destructive + destructive foreground. Ghost: muted foreground, hover muted + foreground. Disabled opacity 50% and noninteractive. IconButton disabled opacity 45%. Focus uses 2px ring and 2px offset, with component-specific rings. Modern selected navigation uses source accent/neutral fills; per-component hover opacity/color-mix must be preserved rather than replaced with a generic Android ripple palette.

Dialog backdrop uses --overlay; shared Dialog also applies 2px backdrop blur. Modal implementations differ: common Modal width classes 400/500/600/800 constrained by viewport; shared Dialog sm/md/lg/xl map Tailwind max widths and cap height to min(90vh,52rem). Both implement focus management; Dialog prevents Escape/backdrop dismissal while busy. A native dismissal policy must follow its owning component, not a blanket close-on-back rule.

Global motion tokens are 120/180/240ms. Modern ease is cubic-bezier(0.2,0,0,1). AppShell drawer transition is 200ms. Mastery has separate celebration/progress keyframes. Reduced-motion CSS removes effective animation and smooth scrolling; Framer components also inspect reduced motion. Captures made with reducedMotion=reduce do not prove live animations.

## Identity, assets and localization

Use original `web/public/brand/color-logo.png`, `color-word.png`, favicon and touch assets; consult assets/figs/logo/README.md for the canonical logo set and web/scripts/sync-logo-assets.mjs. Do not redraw the logo or promote Expo starter icons. asset-manifest.json preserves exact web asset paths/sizes, including brand, provider, agent and knowledge-engine assets. The package also has source-generated BrandIcon/provider mappings; use the owning map rather than assuming every filename is a visible choice. Some provider assets have dark variants and license notices.

Primary icons are lucide-react; mobile already has lucide-react-native but version/individual glyph parity must be checked. Custom ShelfIcons, ComposerIcons, agent/brand glyphs and selected SVG assets are product-owned. Preserve stroke/shape semantics; not every icon is an asset file. Modern shell uses compact line icons and source-specific activity/responder marks.

Selectable UI bundles: en, zh, fr, de, uk, pl, pt, vi, ja, tr, with English fallback per key. Model output languages are a larger separate set (including zh-tw, ko, es, ru, it, ar, ms). Keep interface language distinct from response language and partner reply language. Do not reduce locale parity to the unused mobile en/uk demo dictionary. Source i18n/languages.ts and i18n initialization are authoritative. Some agent/settings labels are inline English/Chinese objects rather than fully translated bundle keys; record this as existing behavior rather than inventing missing translations.

## PROPOSED Android token extraction policy

Create theme + layout + content-role layers, resolving selectors in source order. Keep raw source values and a tested effective token mapping. Begin with Modern + system/Default/Dark; retain Cream/Glass as explicit parity work. Preserve semantic success/warning/info/destructive surfaces and per-feature category colors. Allow system font scaling, preserve readable contrast and focus labels, and compare to source captures for the same actual state. No palette replacement or logo redesign is authorized by this audit.
