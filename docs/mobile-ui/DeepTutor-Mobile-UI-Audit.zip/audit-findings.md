# Audit findings

## Provenance and investigation boundaries

Primary checkout: `/home/zillia/Work/deeptutor-source`; official origin `https://github.com/HKUDS/DeepTutor.git`; clean worktree; local main/tag v1.7.1 at `f7aed0744c36c5afef16a4261c31ebee1208cac2`. `git ls-remote origin refs/heads/main` independently returned the same SHA. A commit archive was extracted to `source/` for runtime work. Only a per-command `safe.directory` option was needed to read Git metadata; no global Git configuration was changed.

Read before investigation: root `AGENTS.md`, `web/package.json`, developer handbook index, `docs-for-dev/DEVELOPMENT.md`, architecture ownership documentation, relevant contribution guidance and mobile `AGENTS.md`/package configuration. DeepTutor explicitly requires an isolated runtime home and identifies durable turn replay and account/workspace separation as architectural boundaries. [Agent instructions](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/AGENTS.md), [development guide](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/docs-for-dev/DEVELOPMENT.md), [architecture](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/docs-for-dev/ARCHITECTURE.md).

VERIFIED actual directories include `web/app`, `components`, `features`, `hooks`, `lib`, `shared`, `context`, `i18n`, `locales` and `public`; the target `web/styles` does not exist. Global CSS is `web/app/globals.css`; additional CSS is colocated with features and components. Tailwind 3.4.17 is configured in `web/tailwind.config.js`. `source-files.json` records paths, sizes and hashes across these investigation roots; it is coverage evidence, not a claim of line-by-line semantic review of every utility.

The web package uses Next 16.2.3, React 19, lucide-react, Framer Motion, i18next, Markdown/GFM/math/KaTeX rendering, BlockNote, PDF.js, epubjs, docx-preview, ExcelJS, Mermaid, Chart.js and Cytoscape dependencies. Dependency presence alone does not prove a user-facing feature or active renderer. [Package](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/package.json).

## Navigation hierarchy

VERIFIED modern is the default layout. Its page tree is driven by `sidebar/page-sections.ts`, while the classic layout retains its own navigation presentation. The modern hierarchy is:

- Home: Chat, Calendar, Task Board, Co-Writer/Learning notebook.
- Learning: Create learning, All learning, Books, Mastery Path, Practice, Immersive Reading.
- Resources: overview, Chat History, Favorites, Learning journal, Question Bank, Knowledge Center; optional Whisper under More Projects.
- Partners: account-level partner/group directory and conversations.
- Personalization: account-level My Agents, Personas, Skills, MCP Services, CLI Apps, Memory.
- Account/settings utilities: profile, settings, authorized administration and session handoff.

These are dynamic, policy-filtered shelves, not fixed always-visible options. Modern and Classic name some shared features differently: modern `Auto` corresponds to classic `Chat`; modern Resources/Learning correspond to classic Learning Space/Personalized Learning. [Page tree](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts), [classic entries](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts), [layout preference](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/ui-layout.ts).

Root `/` redirects to `/chat`. Both new and existing chat URLs render ChatWorkspace. Three reading conversation route patterns render ReadingWorkspacePage. Three book route patterns share BooksRoute. Watching index redirects to Reading, and an old watching session has a compatibility resolver. Settings uses one dynamic route, but its source registry defines multiple meaningful settings surfaces. All are accounted for in route-map.md.

The web shell is already responsive: below 768 px its sidebar becomes an off-canvas drawer with scrim, route-change dismissal, Escape dismissal and inactive focus blocking; at 768–1023 px compact behavior still applies to feature panes, with desktop behavior at 1024 px. This is evidence for preserving drawer navigation and single-pane work on Android. [AppShell](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx), [device thresholds](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useDevice.ts).

## Product boundaries that change the plan

| Question | Source finding | Consequence |
|---|---|---|
| Separate dashboard and chat? | `/` redirects; `/chat` renders greeting/composer or session content | Reuse a Home/Chat screen with new/persisted state |
| Deep Research/Deep Solve screens? | Composer registry labels them Research and Solve; results live in messages | Keep capabilities in chat, with configuration/results hosted there |
| Quiz versus Practice? | QuizViewer handles generated questions/judgments; PracticeSession handles scheduled recall and ratings | Preserve separate result and review models |
| Question Bank versus Mistakes? | Collection tabs share QuestionBankSection; Practice daily review has its own owner | Keep filters/tabs and daily review distinct |
| Mastery goals/waypoints/assessments? | Atlas → topic → outline/board/knowledge-point reports → outline/study/review conversations | Use actual knowledge-point/objective terminology; no separate invented Waypoints screen |
| Course Study? | No canonical Course Study route or separate navigation surface was established | Model the actual Mastery study experience; mark a distinct Course Study screen unsupported |
| Imported documents versus Books? | Immersive Reading owns imported document/media collections; Books generates chapter spines and blocks | Separate libraries, creation flows and locators |
| Favorites versus Notebooks? | Resource navigation calls `/notebooks` Favorites; component headings may still say Notebooks | Preserve context-specific copy; no silent product-wide renaming |
| Co-Writer versus editable notebook? | Current `/co-writer/[docId]` imports NoteWorkspace/NoteCompanion | Plan against routed rich notes, not old CoWriterWorkspace functionality |
| Learning Journal editor? | LearningJournalPanel reads mission, handoff and confirmed records | No freeform journal CRUD or invented reflection workflow |
| My Agents only connections? | AgentsHub renders ConnectedAgents and MyAgentsSection | Inventory live agents plus imported-history/replay/scope workflows |
| All tools always available? | Manifest/catalog plus auth/module/context gates filter the UI | Do not hardcode availability from AGENTS.md or presentation constants |
| Whisper bundled? | Resource tile explicitly requires an out-of-tree `whisper_visitor` capability | Conditional inventory; excluded from stock MVP |

Evidence: [capability presentation](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx), [Practice owner](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx), [resource definitions](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts), [AgentsHub](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/AgentsHub.tsx), [current editor route](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/%28workspace%29/co-writer/%5BdocId%5D/page.tsx).

No independently routed universal search screen, model-provider social login, password-reset flow, subscription/billing screen, generic notifications center or offline learning library was established. Do not create these based on familiar mobile patterns. Search is the actual shell command palette, list-specific search or feature search. Permissions include auth, user preset/learning policy, resource grants, module availability, LLM grants and read-only records; they cannot be reduced to a single `isLoggedIn` check.

## Existing React Native project — read-only findings

| Area | VERIFIED observation |
|---|---|
| Framework | Expo `~58.0.23`, React Native `0.88.1`, React `19.3.0`, TypeScript `~6.0.3` |
| Navigation | `main: expo-router/entry`; `src/app/_layout.tsx`; native `expo-router/native-tabs` in app-tabs.tsx, custom Expo Router web tabs in app-tabs.web.tsx |
| Actual screens | `/` Welcome to Expo; `/explore` starter educational content. No DeepTutor domain screen currently rendered |
| Theme | `src/constants/theme.ts`: black/white starter colors, spacing 2/4/8/16/24/32/64; maximum width 800; generic platform font families |
| Reusable components | ThemedText, ThemedView, HintRow, AnimatedIcon/splash overlay, Collapsible, ExternalLink, WebBadge; platform-specific web variants |
| API | Untracked `src/api/client.ts`: Axios instance requiring EXPO_PUBLIC_API_URL at import time, appends `/api`, JSON header and 30s timeout. No audited domain repository/stream adapter or authenticated session strategy is wired to screens |
| Localization | Untracked `src/i18n/translations.ts`: English/Ukrainian demo copy, some domain types for translations. Its entries are not evidence of implemented screens, mock repositories or authoritative web functionality |
| Contracts/mock data | No domain contracts, mock-data repository, application state store or feature repository implementation was found in the visible source tree; package installation alone is not use |
| Dependencies | AsyncStorage, Axios, Zustand, lucide-react-native, react-native-svg, safe-area/screens/gesture/Reanimated/worklets; Expo clipboard/font/image/linking/device/web-browser and @expo/ui present |
| Configuration | Portrait; automatic interface style; typed routes/react compiler enabled; predictiveBackGestureEnabled false; Expo starter icon/splash/branding; no manually authored ios/android directories found |
| Documentation | `docs/API_INTEGRATION.md` absent in this mobile checkout; README is Expo starter documentation |
| Existing changes | package.json and package-lock.json modified; .serena, src/api and src/i18n untracked at audit start. Preserved |

Local evidence: mobile `package.json`, `app.json`, `src/app/*`, `src/components/*`, `src/constants/theme.ts`, `src/hooks/*`, `src/api/client.ts`, `src/i18n/translations.ts`, `git status --short`. Existing files were not overwritten. The mobile translation file contains attractive but unsupported demo concepts, including local-only experiences and generic statistics; these must not drive parity scope.

Expo SDK 58 documentation and the Expo LLM index were checked before making API-related planning recommendations. Candidate module choices in mobile-plan.md remain proposals; no packages were installed in the mobile project. [SDK 58](https://docs.expo.dev/versions/v58.0.0/), [Expo index](https://docs.expo.dev/llms.txt).

## Evidence limitations

The inventory establishes all discovered page routes and significant feature/overlay families through direct source inspection, import tracing and indexed excerpts. Some secondary surface records intentionally leave states UNVERIFIED; their mere component presence does not establish a successful interaction. The component evidence index exposes state declarations for follow-up review rather than disguising them as runtime findings.

Successful backend-dependent workflows, actual learner/admin granted combinations, populated content, exact computed fonts on all Android devices, animations, media playback, document selection fidelity and long-session performance remain verification work. Current frontend captures use reduced motion, so they cannot verify animation timing. Product records were not fabricated to fill these gaps.
