# DeepTutor UI surface inventory

Pinned official source: `f7aed0744c36c5afef16a4261c31ebee1208cac2`. All paths relative to repository root. IDs identify audit records, not a count of independent product screens.

VERIFIED means source-confirmed wiring/behavior, never screenshot verification. INFERRED is reserved for architectural implications. UNVERIFIED identifies missing runtime evidence or unestablished states. Every mobile adaptation is PROPOSED. Empty/error/success behavior is not invented where the owner does not establish it. Reusable controls are grouped under their actual host. Route aliases are listed separately.

Layouts: workspace = `web/app/(workspace)/layout.tsx`; utility = `web/app/(utility)/layout.tsx`; settings = `web/app/(settings)/layout.tsx` plus `settings/layout.tsx`; auth = `web/app/(auth)/layout.tsx`; admin = `web/app/(admin)/layout.tsx`. All inherit root `web/app/layout.tsx`. Embedded records inherit the host layout.

Reusable components below are mechanically collected JSX references from source owners, including implementation helpers; they are not additional screens. Exact variant/state evidence is in component-catalog.md and source-evidence.md.

## S01 — Application shell / navigation

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Parent navigation or host control; see route and component wiring.

**Purpose:** Application frame

**Visible sections:** Application frame; workspace shelves Home, Learning, Resources; account shelves Partners and Personalization; page bar and breadcrumbs

**User actions:** Navigate; change shelf; new conversation; collapse/resize sidebar; customize navigation

**Modals / dialogs / drawers / sheets:** Mobile sidebar drawer; command palette; account menu

**Loading state:** VERIFIED — shell Suspense busy fallback

**Empty state:** Not applicable — shell surrounds content

**Error state:** UNVERIFIED — child/runtime gates own errors

**Success / completed state:** VERIFIED — selected destination and active shelf

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Use the source shelf hierarchy in an Android navigation drawer; keep account-level shelves distinct from workspace content. Do not make all shelves independent product screens.

**Source components:** [`web/components/layout/AppShell.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx), [`web/components/sidebar/SidebarShell.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx), [`web/components/sidebar/WorkspaceSidebar.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx), [`web/components/sidebar/UtilitySidebar.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/UtilitySidebar.tsx), [`web/components/sidebar/page-sections.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts)

**Reusable components:** AdminLink; CategoryBody; CategoryTabs; ChevronsLeft; ChevronsRight; CommandPalette; HTMLDivElement; Image; LayoutSidebarShell; Link; LogoutButton; MasteryTopicLabel; Menu; OrganizedSessionList; PageChromeProvider; PanelLeftClose; ProfileLink; RecordHeader; Search; SessionList; SessionSummary; SidebarDrawerContext; SquarePen; Suspense; Tooltip; WorkspaceMenu

**Source evidence:**

- [web/components/layout/AppShell.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L8) — `useState,`
- [web/components/layout/AppShell.tsx:26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L26) — `export function useSidebarDrawer() {`
- [web/components/layout/AppShell.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L55) — `export default function AppShell({ sidebar, pageBar, children, homeHref = "/" }: AppShellProps) {`
- [web/components/layout/AppShell.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L59) — `const [drawerOpen, setDrawerOpen] = useState(false);`
- [web/components/layout/AppShell.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L66) — `const [trackedPathname, setTrackedPathname] = useState(pathname);`
- [web/components/sidebar/SidebarShell.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L13) — `useState,`
- [web/components/sidebar/SidebarShell.tsx:104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L104) — `export function SidebarShell({`
- [web/components/sidebar/SidebarShell.tsx:132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L132) — `const [paletteOpen, setPaletteOpen] = useState(false);`
- [web/components/sidebar/SidebarShell.tsx:262](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L262) — `title={t("navigation.chatRecords")}`
- [web/components/sidebar/WorkspaceSidebar.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L5) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`


## S02 — Command palette / search

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Overlay

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Shell search / keyboard command

**Purpose:** Search pages, sessions, learning records, partners and groups

**Visible sections:** Search pages, sessions, learning records, partners and groups

**User actions:** Type query; select result; new chat; navigate

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** Not applicable — modal opens from shell

**Empty state:** VERIFIED — query filtering; exact no-result appearance needs runtime

**Error state:** UNVERIFIED — not a universal backend search/error screen

**Success / completed state:** VERIFIED — chosen action navigates

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Open a full-height search overlay from the header; preserve the indexed result types, without promising search across unindexed data.

**Source components:** [`web/components/sidebar/CommandPalette.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx)

**Reusable components:** CornerDownLeft; HTMLDivElement; HTMLElement; HTMLInputElement; Icon; PaletteGroup; PartnerAvatar; Search

**Source evidence:**

- [web/components/sidebar/CommandPalette.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L6) — `import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'`
- [web/components/sidebar/CommandPalette.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L42) — `export function CommandPalette({`
- [web/components/sidebar/CommandPalette.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L65) — `const [query, setQuery] = useState('')`
- [web/components/sidebar/CommandPalette.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L66) — `const [activeIndex, setActiveIndex] = useState(0)`
- [web/components/sidebar/CommandPalette.tsx:175](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L175) — `<div role="dialog" aria-modal="true" aria-label={t('navigation.searchEverything')} className="dt-palette">`


## S03 — Workspace and account menus

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Contextual menu

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Parent navigation or host control; see route and component wiring.

**Purpose:** Account utilities

**Visible sections:** Account utilities; workspace selection; scoped destinations

**User actions:** Switch workspace; profile/settings/admin/logout where exposed

**Modals / dialogs / drawers / sheets:** Workspace picker and menu

**Loading state:** VERIFIED — workspace choice fetch states in owner

**Empty state:** UNVERIFIED — depends on available workspace list

**Error state:** UNVERIFIED — runtime-dependent authentication and switch failure

**Success / completed state:** VERIFIED — workspace switch returns detail routes to their owning index

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Sheet for workspace choices; preserve switchDestination behavior and remount workspace stores. Account Partners and Personalization remain account-scoped.

**Source components:** [`web/components/sidebar/WorkspaceMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx), [`web/components/workspaces/WorkspacePill.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx), [`web/components/workspaces/WorkspaceNavigation.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceNavigation.tsx), [`web/components/sidebar/page-sections.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts)

**Reusable components:** ChatWorkspaceRegistration; Check; ChevronDown; Folder; FolderOpen; HTMLButtonElement; HTMLDivElement; Image; Link; Plus; ScopeCanonicalizer; ServerFolderPicker; Settings; Settings2; Suspense; ToolbarLabel; Tooltip; VersionBadge; WorkspaceChoiceList; WorkspaceGlyph

**Source evidence:**

- [web/components/sidebar/WorkspaceMenu.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L5) — `import { useId, useState, type ReactNode } from 'react'`
- [web/components/sidebar/WorkspaceMenu.tsx:17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L17) — `export function WorkspaceGlyph({ name, general, size = 22 }: { name: string; general: boolean; size?: number }) {`
- [web/components/sidebar/WorkspaceMenu.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L38) — `export function WorkspaceChoiceList({ onChoose }: { onChoose?: () => void }) {`
- [web/components/sidebar/WorkspaceMenu.tsx:73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L73) — `export function WorkspaceMenu({`
- [web/components/sidebar/WorkspaceMenu.tsx:85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L85) — `const [open, setOpen] = useState(false)`
- [web/components/sidebar/WorkspaceMenu.tsx:135](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L135) — `title={clientEditionLabel(process.env.NEXT_PUBLIC_APP_VERSION)}`
- [web/components/workspaces/WorkspacePill.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L4) — `import { useEffect, useRef, useState } from "react";`
- [web/components/workspaces/WorkspacePill.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L28) — `export function WorkspacePill({`
- [web/components/workspaces/WorkspacePill.tsx:45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L45) — `error?: string;`
- [web/components/workspaces/WorkspacePill.tsx:49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L49) — `const [creating, setCreating] = useState(false);`


## S04 — Home / Chat

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /chat

**Parent layout:** workspace

**Entry points:** Home shelf; new chat; / redirect

**Purpose:** New conversation

**Visible sections:** New conversation; greeting; starter suggestions; composer; resource and answer controls

**User actions:** Compose; attach; select model/capability/tools/resources; record voice; send

**Modals / dialogs / drawers / sheets:** Composer tray; model selector; reference pickers; capability config cards

**Loading state:** VERIFIED — model/resource probes and session loading

**Empty state:** VERIFIED — greeting and starters before messages

**Error state:** VERIFIED — attachment errors and resource/session load failure handling

**Success / completed state:** VERIFIED — first successful send binds a session route

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** S05–S09; S11 capability views

**Mobile adaptation:** PROPOSED — Keep a keyboard-aware composer above Android IME, a scrollable greeting/starter area, and compact resource chips. Preserve first-send session identity across navigation.

**Source components:** [`web/app/(workspace)/chat/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/chat/page.tsx), [`web/features/chat/components/ChatWorkspace.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx), [`web/components/chat/home/StarterSuggestions.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StarterSuggestions.tsx), [`web/components/chat/home/ChatComposer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx)

**Reusable components:** AbortController; AlertCircle; Archive; ArrowUp; AttachmentProcessingStatus; BookReferencePicker; CapIcon; CapMenuItem; CapabilityConfigCard; ChatComposer; ChatLocation; ChatMessageList; ChatSessionMenu; ChatSpaceMenu; ChatWorkspace; Check; ChevronDown; ChevronRight; ComposerInput; ComposerInputHandle; ComposerResources; ComposerTray; ContextBudgetChip; CornerDownLeft; CrumbRename; DeepQuestionFormConfig; DeepResearchFormConfig; ExploreNextMark; File; FilePreviewDrawer; FilePreviewSource; GeogebraTabBridge; GeogebraTabProvider; HTMLAnchorElement; HTMLButtonElement; HTMLDivElement; HTMLInputElement; HTMLTextAreaElement; HeaderActionButton; HistorySessionPicker; Icon; KnowledgeBase; KnowledgeSelector; Loader2; MemoryPicker; Mic; ModelSelector; MyAgentsPicker; NotebookRecordPicker; PageBarSlot; PageCustomizeButton; Paperclip; PenLine; PendingAttachment; Promise; QuestionBankPicker; QueuedMessages; QuizConfigPanel; QuizFollowupBridge; QuizFollowupProvider; QuotedPassage; ReadingReferencePicker; Record; RefreshCw; ResearchConfigPanel; ResourceReuseContext; ReturnType; RotateCcw; SaveToNotebookModal; SelectedResources; SelectionActions; SendState; SessionLoadingView; SessionViewerPanel; SessionViewerPanelHandle; Sparkles; Square; StarterSuggestions; SubagentTabWatcher; SuggestionPayload; TaskLinkSelector; Tooltip; TurnNavigator; View; VisualizeConfigPanel; VisualizeFormConfig; WorkspaceDraft; WorkspaceDraftLocation

**Source evidence:**

- [web/app/(workspace)/chat/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/chat/page.tsx#L3) — `export default function ChatPage() {`
- [web/features/chat/components/ChatWorkspace.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L21) — `useState,`
- [web/features/chat/components/ChatWorkspace.tsx:274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L274) — `export default function ChatWorkspace() {`
- [web/features/chat/components/ChatWorkspace.tsx:319](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L319) — `const [replyLanguageSavingKey, setReplyLanguageSavingKey] = useState<string | null>(null);`
- [web/features/chat/components/ChatWorkspace.tsx:340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L340) — `const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBase[]>([]);`
- [web/features/chat/components/ChatWorkspace.tsx:341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L341) — `const [knowledgeBasesLoaded, setKnowledgeBasesLoaded] = useState(false);`
- [web/features/chat/components/ChatWorkspace.tsx:371](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L371) — `const [draftTaskSelections, setDraftTaskSelections] = useState<Record<string, string[]>>({});`
- [web/features/chat/components/ChatWorkspace.tsx:388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L388) — `const [userEnabledTools, setUserEnabledTools] = useState<string[] | null>(`
- [web/features/chat/components/ChatWorkspace.tsx:391](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L391) — `const [attachments, setAttachments] = useState<PendingAttachment[]>([]);`
- [web/features/chat/components/ChatWorkspace.tsx:393](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L393) — `const [dragging, setDragging] = useState(false);`


## S05 — Conversation

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /chat/[sessionId]

**Parent layout:** workspace

**Entry points:** History; sidebar record; first send; deep link

**Purpose:** Persisted message stream

**Visible sections:** Persisted message stream; editable title; user messages; response activity; output previews; usage

**User actions:** Send/stop; retry; edit/discard message where allowed; copy; read aloud; rename/export/save/archive/delete via source menus

**Modals / dialogs / drawers / sheets:** Save to Favorites; viewer panel; session actions; delete/discard confirmation

**Loading state:** VERIFIED — SessionLoadingView and restore loading

**Empty state:** VERIFIED — same workspace handles empty session

**Error state:** VERIFIED — failed restore/retry/edit/copy and protocol mismatch surfaces

**Success / completed state:** VERIFIED — rendered completed response and usage footer

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** S04 composer; S06 selectors; S07 viewers; history and Favorites

**Mobile adaptation:** PROPOSED — Virtualize long threads while retaining chronological ordering, durable turn replay and action eligibility; throttled streaming paint must not mutate the canonical event stream.

**Source components:** [`web/app/(workspace)/chat/[sessionId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/chat/[sessionId]/page.tsx), [`web/features/chat/components/ChatWorkspace.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx), [`web/features/chat/messages/ChatMessageList.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx), [`web/features/chat/components/ChatSessionMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatSessionMenu.tsx), [`web/components/sessions/SessionActionsMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/SessionActionsMenu.tsx)

**Reusable components:** AbortController; ActivityFold; AlertCircle; AnswererMark; Archive; AskUserOptions; AssistantActivity; AssistantMessage; AssistantResponse; BookReferencePicker; BranchNavigator; CapabilityConfigCard; ChatComposer; ChatLocation; ChatMessageList; ChatSessionMenu; ChatWorkspace; Check; ChevronLeft; ChevronRight; ContextReferenceTree; Copy; CopyActionButton; CreationDraftCard; CrumbRename; DeepQuestionFormConfig; DeepResearchFormConfig; DeleteTurnButton; File; FilePreviewDrawer; FilePreviewSource; FloatingMenuPosition; FoldCaret; GeneratedFileCards; GeneratedOutputFileActions; GeogebraTabBridge; GeogebraTabProvider; HTMLAnchorElement; HTMLAudioElement; HTMLButtonElement; HTMLDivElement; HTMLInputElement; HandedToBadge; HeaderActionButton; HistorySessionPicker; Icon; InlineFileCardProvider; KnowledgeBase; LearningText; Loader2; MasteryHandoffCards; MasteryQuestionCard; MasterySourcePages; MasterySourcePresentation; MathAnimatorViewer; MemoryPicker; MessageThreadMarker; MyAgentsPicker; NotebookRecordPicker; PageBarSlot; PageCustomizeButton; PartnerDraftCard; PenLine; PendingAttachment; PlayAudioButton; ProcessBody; ProcessFold; QuestionBankPicker; QueuedMessages; QuizConfigPanel; QuizFollowupBridge; QuizFollowupProvider; QuizViewer; ReadingPassageQuote; ReadingReferencePicker; Record; ResearchConfigPanel; ResearchOutlineEditor; ResourceReuseContext; ReturnType; RotateCcw; RoughActionButton; SaveToNotebookModal; SelectionActions; SentMidTurn; SessionActionsMenuItems; SessionLoadingView; SessionMenuCaption; SessionMenuDivider; SessionMenuItem; SessionViewerPanel; SessionViewerPanelHandle; SetupCredentialCard; Square; StarterSuggestions; SubagentTabWatcher; Tooltip; TraceFlow; TurnNavigator; UsageFooter; UserMessage; VideoLessonViewer; VisualizationViewer; VisualizeConfigPanel; VisualizeFormConfig; Volume2

**Source evidence:**

- [web/app/(workspace)/chat/[sessionId]/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/chat/[sessionId]/page.tsx#L3) — `export default function ChatSessionPage() {`
- [web/features/chat/components/ChatWorkspace.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L21) — `useState,`
- [web/features/chat/components/ChatWorkspace.tsx:274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L274) — `export default function ChatWorkspace() {`
- [web/features/chat/components/ChatWorkspace.tsx:319](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L319) — `const [replyLanguageSavingKey, setReplyLanguageSavingKey] = useState<string | null>(null);`
- [web/features/chat/components/ChatWorkspace.tsx:340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L340) — `const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBase[]>([]);`
- [web/features/chat/components/ChatWorkspace.tsx:341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L341) — `const [knowledgeBasesLoaded, setKnowledgeBasesLoaded] = useState(false);`
- [web/features/chat/components/ChatWorkspace.tsx:371](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L371) — `const [draftTaskSelections, setDraftTaskSelections] = useState<Record<string, string[]>>({});`
- [web/features/chat/components/ChatWorkspace.tsx:388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L388) — `const [userEnabledTools, setUserEnabledTools] = useState<string[] | null>(`
- [web/features/chat/components/ChatWorkspace.tsx:391](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L391) — `const [attachments, setAttachments] = useState<PendingAttachment[]>([]);`
- [web/features/chat/components/ChatWorkspace.tsx:393](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L393) — `const [dragging, setDragging] = useState(false);`


## S06 — Composer controls and reference selection

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Composer toolbar/tray

**Purpose:** Model selection

**Visible sections:** Model selection; response style; who answers; skills/connectors/creation choices; selected resource tree; context budget

**User actions:** Search/select/remove model, persona, partner/group/subagent and resources; enable allowed tools

**Modals / dialogs / drawers / sheets:** Notebook, Book, Reading, History, MyAgents, QuestionBank and Memory pickers

**Loading state:** VERIFIED — catalog/answerer loading

**Empty state:** VERIFIED — unavailable/empty answerers and filtered resources vary by selector

**Error state:** VERIFIED — answerer and model-loading failure branches

**Success / completed state:** VERIFIED — selections reflected in composer and turn snapshot

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Short single-choice pickers may be bottom sheets; searchable multi-select references need a tall sheet or full screen. Keep each source resource type and its locator contract separate.

**Source components:** [`web/components/chat/home/ModelSelector.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx), [`web/components/chat/home/ComposerResources.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx), [`web/components/chat/home/ComposerTray.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx), [`web/components/chat/home/AnswerModeMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx), [`web/components/chat/home/ContextReferenceTree.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextReferenceTree.tsx)

**Reusable components:** Agent; AgentFace; AlertCircle; AnimatePresence; AnswerList; AnswerModeMenu; AnswerModeProps; ArrowLeft; ArrowUpRight; Bot; Budget; Check; ChevronDown; ChevronRight; ChosenIcon; ConnectorHubIcon; ConnectorsMenu; CreateMenu; DOMRect; ElbowMark; FoldMark; HTMLButtonElement; HTMLDivElement; HTMLElement; HTMLInputElement; HTMLSpanElement; Icon; Link; McpServerStatus; McpStoreState; MessageCircle; Minus; ModeMenu; ModelOptionRow; PartnerAvatar; PartnerFace; PartnerGroup; PartnerInfo; PartnerLinkList; PartnerLinkMenu; PencilRuler; PersonaInfo; PlainVoiceIcon; Plug; Plus; ProviderIcon; ResourceReuseControl; Search; Shapes; SkillDeckIcon; SkillList; SkillsMenu; ToolbarLabel; Tooltip; TrayFoot; TrayList; TrayMenu; TrayOption; TrayReuse; TraySearch; TraySection; UserRound; Users; ViewportPopover; Wand2

**Source evidence:**

- [web/components/chat/home/ModelSelector.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L3) — `import { useEffect, useMemo, useRef, useState } from "react";`
- [web/components/chat/home/ModelSelector.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L50) — `const [revealFull, setRevealFull] = useState(false);`
- [web/components/chat/home/ModelSelector.tsx:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L107) — `export default function ModelSelector({`
- [web/components/chat/home/ModelSelector.tsx:138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L138) — `const [open, setOpen] = useState(false);`
- [web/components/chat/home/ModelSelector.tsx:165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L165) — `const canRefresh = error && Boolean(onRefresh);`
- [web/components/chat/home/ModelSelector.tsx:168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L168) — `(!canRefresh && (error || (options.length === 0 && !allowSystemDefault)));`
- [web/components/chat/home/ModelSelector.tsx:209](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L209) — `{error ? (`
- [web/components/chat/home/ComposerResources.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L20) — `useState,`
- [web/components/chat/home/ComposerResources.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L55) — `export default function ComposerResources({`
- [web/components/chat/home/ComposerResources.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L89) — `const [selectedKey, setSelectedKey] = useState<string | null>(null);`


## S07 — Session viewer / activity workspace

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Drawer

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Conversation header; inline output/citation; viewer launcher

**Purpose:** Tabs for file, web, Markdown note, followup/consultation/subagent/GeoGebra content

**Visible sections:** Tabs for file, web, Markdown note, followup/consultation/subagent/GeoGebra content; activity and attachments

**User actions:** Open/switch/close/reopen viewer tabs; inspect activity; work with contextual content

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — web embed loaded/timeout state

**Empty state:** VERIFIED — viewer landing when tabs are empty

**Error state:** VERIFIED — embed timeout and file-preview-specific failures

**Success / completed state:** VERIFIED — selected tab content

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Treat viewer as a full-screen secondary destination on phones, retaining conversation ID and tab identities; restore reader/chat position on back.

**Source components:** [`web/components/chat/home/SessionViewerPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx), [`web/components/chat/home/SessionActivityPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx), [`web/components/chat/home/ChatMarkdownNoteTab.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx), [`web/components/chat/home/SubagentTabBody.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentTabBody.tsx), [`web/components/chat/home/ConsultationTabBody.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx)

**Reusable components:** AbortController; Activity; ActivityBody; ActivityHome; AlertCircle; ArrowLeft; ArrowUp; AttachmentRow; ChatMarkdownNoteTabBody; ChevronRight; ConsultationTabBody; DocxPreview; Download; ExternalLink; FallbackPreview; FileTabActions; FileTabBody; Geogebra; GeogebraTabBody; Globe; GroupDiscussionBody; HTMLDivElement; Icon; ImagePreview; LegacyPartnerConsultation; Link; Loader2; Map; MarkdownPreview; NoteWorkspace; OfficePdfPreview; OfficeTextPreview; PartnerChat; PartnerConsultationBody; PartnerConsultationPending; PartnerGroup; PartnerGroupChat; PartnerInfo; PdfPreview; Plus; PreviewBody; QuizFollowupTabBody; ReadonlyMap; ResponderFace; SectionCard; SessionViewerPanelHandle; Set; SideChatResponder; SpaceItemRow; SpaceSubsection; Square; StreamEvent; SubagentRunTranscript; SubagentTabBody; SvgPreview; TabBar; TaskPanelSection; TextPreview; Tooltip; VideoPreview; ViewerLauncher; ViewerTab; WebTabBody; Wrench; XlsxPreview

**Source evidence:**

- [web/components/chat/home/SessionViewerPanel.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L33) — `useState,`
- [web/components/chat/home/SessionViewerPanel.tsx:176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L176) — `type ViewerTab =`
- [web/components/chat/home/SessionViewerPanel.tsx:409](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L409) — `const [tabs, setTabs] = useState<ViewerTab[]>([]);`
- [web/components/chat/home/SessionViewerPanel.tsx:410](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L410) — `const [activeTabId, setActiveTabId] = useState<string | null>(null);`
- [web/components/chat/home/SessionViewerPanel.tsx:411](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L411) — `const [closedTabs, setClosedTabs] = useState<ViewerTab[]>([]);`
- [web/components/chat/home/SessionViewerPanel.tsx:478](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L478) — `const [stash, setStash] = useState<ReadonlyMap<string, StashedTabs>>(`
- [web/components/chat/home/SessionViewerPanel.tsx:481](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L481) — `const [trackedKey, setTrackedKey] = useState(tabsKey);`
- [web/components/chat/home/SessionViewerPanel.tsx:902](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L902) — `next.length === 0`
- [web/components/chat/home/SessionViewerPanel.tsx:1025](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1025) — `const [launcherThreadRows, setLauncherThreadRows] = useState<{`
- [web/components/chat/home/SessionViewerPanel.tsx:1032](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1032) — `const [threadsRevision, setThreadsRevision] = useState(0);`


## S08 — File preview

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Drawer

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Attachment tap; generated file; KB preview

**Purpose:** Attachment/output preview selected by file kind

**Visible sections:** Attachment/output preview selected by file kind; image, PDF, Office, sheet, Markdown, SVG, video/text and fallback renderers

**User actions:** Open; close; use available file actions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — per-format fetch/decode loading

**Empty state:** VERIFIED — fallback renderer for unsupported files

**Error state:** VERIFIED — per-preview fetch/decode failures

**Success / completed state:** VERIFIED — rendered file or supported fallback

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Full-screen format-specific preview; keep unsupported/download fallback. PDF/Office/EPUB fidelity requires a renderer spike before dependency selection.

**Source components:** [`web/components/chat/preview/FilePreviewDrawer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx), [`web/components/chat/preview/previewerFor.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewerFor.ts)

**Reusable components:** BookOpenText; Check; Copy; DocxPreview; Download; FallbackPreview; FilePreviewSource; HTMLButtonElement; HeaderIcon; ImagePreview; Loader2; MarkdownPreview; OfficePdfPreview; OfficeTextPreview; PdfPreview; PreviewBody; SvgPreview; TextPreview; Tooltip; VideoPreview; XlsxPreview

**Source evidence:**

- [web/components/chat/preview/FilePreviewDrawer.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L5) — `import { memo, useCallback, useEffect, useRef, useState } from "react";`
- [web/components/chat/preview/FilePreviewDrawer.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L64) — `export default function FilePreviewDrawer({`
- [web/components/chat/preview/FilePreviewDrawer.tsx:75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L75) — `useState<FilePreviewSource | null>(null);`
- [web/components/chat/preview/FilePreviewDrawer.tsx:82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L82) — `const [bodyMounted, setBodyMounted] = useState(false);`
- [web/components/chat/preview/FilePreviewDrawer.tsx:148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L148) — `const [copied, setCopied] = useState(false);`
- [web/components/chat/preview/FilePreviewDrawer.tsx:149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L149) — `const [openingInReader, setOpeningInReader] = useState(false);`
- [web/components/chat/preview/FilePreviewDrawer.tsx:150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L150) — `const [readerError, setReaderError] = useState("");`
- [web/components/chat/preview/FilePreviewDrawer.tsx:212](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L212) — `role="dialog"`
- [web/components/chat/preview/previewerFor.ts:97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewerFor.ts#L97) — `export function previewKindFor(source: FilePreviewSource): PreviewKind {`
- [web/components/chat/preview/previewerFor.ts:134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewerFor.ts#L134) — `export function resolveSourceUrl(`


## S09 — Conversation organization / history

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space/chat-history

**Parent layout:** utility

**Entry points:** Resources > Chat History; sidebar records

**Purpose:** Conversation history

**Visible sections:** Conversation history; search; kind and archive filters; mastery/reading labels

**User actions:** Search; filter; reopen/restore; use per-session actions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — list and search loading

**Empty state:** VERIFIED — filtered list/no matches requires exact runtime copy check

**Error state:** VERIFIED — searchError branch and retry version

**Success / completed state:** VERIFIED — restored conversation opens owning destination

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(utility)/space/chat-history/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/chat-history/page.tsx), [`web/components/space/ChatHistorySection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx), [`web/components/sessions/OrganizedSessionList.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx), [`web/components/sessions/SessionActionsMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/SessionActionsMenu.tsx)

**Reusable components:** ArchivedConversations; ChatHistorySection; Check; ChevronDown; ChevronRight; FloatingMenuPosition; GroupMark; HTMLButtonElement; HTMLDivElement; HTMLElement; Icon; Loader2; MasteryTopicLabel; MessagesSquare; MoreHorizontal; OrganizedSessionList; Pin; Record; RecordGroups; RecordTime; RefreshCw; Search; SessionActionsMenuItems; SessionAvatar; SessionMenuCaption; SessionMenuDivider; SessionMenuItem; SessionSearchResult; SessionSummary; Set; SpaceSectionHeader; Tooltip

**Source evidence:**

- [web/app/(utility)/space/chat-history/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/chat-history/page.tsx#L3) — `export default function SpaceChatHistoryPage() {`
- [web/components/space/ChatHistorySection.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L6) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/space/ChatHistorySection.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L56) — `export default function ChatHistorySection({`
- [web/components/space/ChatHistorySection.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L65) — `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [web/components/space/ChatHistorySection.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L66) — `const [masteryTopics, setMasteryTopics] = useState<MasteryTopicLabel[]>([]);`
- [web/components/space/ChatHistorySection.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L67) — `const [readingCollections, setReadingCollections] = useState<`
- [web/components/space/ChatHistorySection.tsx:70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L70) — `const [loading, setLoading] = useState(true);`
- [web/components/space/ChatHistorySection.tsx:71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L71) — `const [restoringId, setRestoringId] = useState<string | null>(null);`
- [web/components/space/ChatHistorySection.tsx:72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L72) — `const [query, setQuery] = useState("");`
- [web/components/space/ChatHistorySection.tsx:73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L73) — `const [searchResults, setSearchResults] = useState<SessionSearchResult[]>([]);`


## S10 — Archived chats

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/archive

**Parent layout:** settings

**Entry points:** Settings > Archived chats

**Purpose:** Archived conversation management

**Visible sections:** Archived conversation management

**User actions:** Search; unarchive; permanently delete

**Modals / dialogs / drawers / sheets:** Permanent delete confirmation

**Loading state:** VERIFIED — archived list loading

**Empty state:** VERIFIED — archived-list empty branch

**Error state:** VERIFIED — operation failure handling

**Success / completed state:** VERIFIED — restored/deleted list refresh

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/features/settings/sections/ArchivedChatsSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx), [`web/components/space/ArchivedConversations.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ArchivedConversations.tsx)

**Reusable components:** ArchiveKind; ArchiveRestore; ArchivedConversations; Icon; Loader2; MasteryTopicLabel; ReadingCollectionLabel; RefreshCw; Search; SessionSummary; SettingsPageHeader; Tooltip; Trash2

**Source evidence:**

- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L6) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L36) — `export default function ArchivedChatsSettingsSection() {`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L40) — `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L41) — `const [topics, setTopics] = useState<MasteryTopicLabel[]>([]);`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L42) — `const [collections, setCollections] = useState<ReadingCollectionLabel[]>([]);`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L43) — `const [loading, setLoading] = useState(true);`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L44) — `const [error, setError] = useState("");`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L45) — `const [busy, setBusy] = useState<string | null>(null);`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L46) — `const [query, setQuery] = useState("");`
- [web/features/settings/sections/ArchivedChatsSettingsSection.tsx:47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L47) — `const [kind, setKind] = useState<ArchiveKind | "all">("all");`


## S11 — Chat capabilities

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Composer mode/tray

**Purpose:** Chat/Auto

**Visible sections:** Chat/Auto; Solve; Ask Questions; Quiz; Research; Visualize; Video Lesson; configuration cards

**User actions:** Select capability; configure/confirm; submit through same composer

**Modals / dialogs / drawers / sheets:** Capability tray and contextual configuration

**Loading state:** VERIFIED — capability catalog discovery

**Empty state:** VERIFIED — unavailable capabilities filtered by catalog

**Error state:** VERIFIED — Quiz and Research configuration validation

**Success / completed state:** VERIFIED — selected capability drives the chat turn

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Keep source labels Solve and Research; do not create invented Deep Solve or Deep Research tabs. Mastery Path is excluded from Home by legacy flag and belongs in Mastery workspace.

**Source components:** [`web/features/capabilities/presentation.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx), [`web/components/chat/home/CapabilityConfigCard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CapabilityConfigCard.tsx), [`web/components/quiz/QuizConfigPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx), [`web/components/research/ResearchConfigPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx), [`web/components/visualize/VisualizeConfigPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizeConfigPanel.tsx)

**Reusable components:** Check; ChevronDown; CollapsibleConfigSection; ConfigurableCapability; DraggableRatioBar; DropdownRow; Field; FileText; HTMLButtonElement; HTMLDivElement; HTMLInputElement; Icon; NormalizedQuizQuestionType; NumberSlider; Record; ResearchDepth; ResearchMode; Tooltip; TypeMultiSelect; Upload; VisualizerCatalogItem

**Source evidence:**

- [web/features/capabilities/presentation.tsx:185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L185) — `export function getChatCapability(value: string | null): ChatCapabilityDef {`
- [web/features/capabilities/presentation.tsx:211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L211) — `export function mergeCapabilityPresentations(`
- [web/features/capabilities/presentation.tsx:256](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L256) — `export function visibleCapabilityPresentations(`
- [web/components/chat/home/CapabilityConfigCard.tsx:123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CapabilityConfigCard.tsx#L123) — `export default CapabilityConfigCard;`
- [web/components/quiz/QuizConfigPanel.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L10) — `useState,`
- [web/components/quiz/QuizConfigPanel.tsx:102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L102) — `export default memo(function QuizConfigPanel({`
- [web/components/quiz/QuizConfigPanel.tsx:112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L112) — `const [dragOver, setDragOver] = useState(false);`
- [web/components/quiz/QuizConfigPanel.tsx:385](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L385) — `const [open, setOpen] = useState(false);`
- [web/components/quiz/QuizConfigPanel.tsx:395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L395) — `const [menuPos, setMenuPos] = useState<{`
- [web/components/quiz/QuizConfigPanel.tsx:482](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L482) — `if (value.length === 0) return t("Auto");`


## S12 — Ask Questions / structured question

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Assistant ask_user or mastery question event

**Purpose:** Structured request for input embedded in tutor output

**Visible sections:** Structured request for input embedded in tutor output

**User actions:** Select options; type response; submit; source-supported skip

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — pending submit state

**Empty state:** UNVERIFIED — depends on server question payload

**Error state:** VERIFIED — submit failure/hint handled by chat owner

**Success / completed state:** VERIFIED — reply resumes existing turn

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Inline answer card with full-width choices and keyboard-safe free text; preserve question ID, multi-select semantics and turn continuation.

**Source components:** [`web/components/chat/home/AskUserOptions.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx), [`web/components/chat/home/MasteryQuestionCard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx)

**Reusable components:** AssistantResponse; ChevronDown; ChevronLeft; ChevronRight; GroupedMasteryQuestionCard; HTMLTextAreaElement; InlineMarkdown; InteractiveAskUserCard; LearningText; OptionRow; Pencil; QuestionBody; Record; ResolvedAskUserCard; SingleMasteryQuestionCard; StreamEvent

**Source evidence:**

- [web/components/chat/home/AskUserOptions.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L4) — `import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/chat/home/AskUserOptions.tsx:138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L138) — `export function extractAskUserPayload(`
- [web/components/chat/home/AskUserOptions.tsx:149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L149) — `if (!events || events.length === 0) return null;`
- [web/components/chat/home/AskUserOptions.tsx:348](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L348) — `export function extractMessageSegments(`
- [web/components/chat/home/AskUserOptions.tsx:361](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L361) — `if (!events || events.length === 0) return [];`
- [web/components/chat/home/AskUserOptions.tsx:692](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L692) — `if (said.length === 0) continue;`
- [web/components/chat/home/AskUserOptions.tsx:860](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L860) — `export function leadingTraceEvents(`
- [web/components/chat/home/AskUserOptions.tsx:949](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L949) — `if (questions.length === 0 && !(allowNoQuestions && intro)) return null;`
- [web/components/chat/home/AskUserOptions.tsx:1051](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1051) — `const [picks, setPicks] = useState<Record<string, string[]>>({});`
- [web/components/chat/home/AskUserOptions.tsx:1054](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1054) — `const [customText, setCustomText] = useState<Record<string, string>>({});`


## S13 — Quiz result and follow-up

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Quiz result in message or generated learning block

**Purpose:** Question pager

**Visible sections:** Question pager; choices or written/image answer; judgment/review; bookmark/category; follow-up

**User actions:** Answer; submit; reveal/review; attach answer image; bookmark; open question follow-up

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — judging busy state

**Empty state:** UNVERIFIED — requires actual generated result

**Error state:** VERIFIED — judgment error and per-question operation state

**Success / completed state:** VERIFIED — answer/judgment and review views

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Use a question-at-a-time view preserving the existing navigation and judgment states; keep generated quiz distinct from Practice review scheduling.

**Source components:** [`web/components/quiz/QuizViewer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx), [`web/components/quiz/QuizFollowupTabBody.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizFollowupTabBody.tsx)

**Reusable components:** AnswerState; AskUserOptions; AssistantThreadMessage; Bookmark; CategoryMenu; Check; ChevronDown; ChevronLeft; ChevronRight; Eye; FollowupChatComposer; HTMLDivElement; HTMLInputElement; Icon; ImagePlus; Loader2; Map; MarkdownRenderer; MessageSquarePlus; NotebookCategory; PinnedCard; Record; RotateCcw; Sparkles; Square; StreamingStatus; Tooltip; TraceFlow

**Source evidence:**

- [web/components/quiz/QuizViewer.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L9) — `useState,`
- [web/components/quiz/QuizViewer.tsx:191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L191) — `export default function QuizViewer({`
- [web/components/quiz/QuizViewer.tsx:203](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L203) — `const [idx, setIdx] = useState(0);`
- [web/components/quiz/QuizViewer.tsx:204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L204) — `const [answers, setAnswers] = useState<Record<number, AnswerState>>({});`
- [web/components/quiz/QuizViewer.tsx:207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L207) — `const [entryIds, setEntryIds] = useState<Record<string, number>>({});`
- [web/components/quiz/QuizViewer.tsx:208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L208) — `const [bookmarked, setBookmarked] = useState<Record<string, boolean>>({});`
- [web/components/quiz/QuizViewer.tsx:211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L211) — `const [followupSessionIds, setFollowupSessionIds] = useState<`
- [web/components/quiz/QuizViewer.tsx:214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L214) — `const [categories, setCategories] = useState<NotebookCategory[]>([]);`
- [web/components/quiz/QuizViewer.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L216) — `const [judgments, setJudgments] = useState<Record<number, JudgmentState>>({});`
- [web/components/quiz/QuizViewer.tsx:217](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L217) — `const [answerViews, setAnswerViews] = useState<Record<number, AnswerView>>(`


## S14 — Research outline and report

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Research capability output

**Purpose:** Research configuration

**Visible sections:** Research configuration; notes/report/comparison/learning_path modes; quick/standard/deep/manual depth; editable outline; streamed report

**User actions:** Configure; edit/confirm outline; read citations and report

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — shared live-turn activity

**Empty state:** UNVERIFIED — no standalone report library found

**Error state:** VERIFIED — research configuration validation

**Success / completed state:** VERIFIED — report rendered as assistant response

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Tall outline editor, followed by source-preserving report content and citations. A research learning_path output is not a new Mastery Path record unless source creation action does so.

**Source components:** [`web/components/research/ResearchOutlineEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx), [`web/components/research/ResearchConfigPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx), [`web/features/chat/messages/ChatMessageList.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx)

**Reusable components:** AbortController; ActivityFold; AlertCircle; AnswererMark; AskUserOptions; AssistantActivity; AssistantMessage; AssistantResponse; BranchNavigator; Check; ChevronDown; ChevronLeft; ChevronRight; CollapsibleConfigSection; ContextReferenceTree; Copy; CopyActionButton; CreationDraftCard; DeleteTurnButton; Field; FoldCaret; GeneratedFileCards; GeneratedOutputFileActions; HTMLAudioElement; HandedToBadge; Icon; InlineFileCardProvider; LearningText; Loader2; MasteryHandoffCards; MasteryQuestionCard; MasterySourcePages; MasterySourcePresentation; MathAnimatorViewer; MessageThreadMarker; NumberSlider; OutlineItem; PartnerDraftCard; Play; PlayAudioButton; Plus; ProcessBody; ProcessFold; QuizViewer; ReadingPassageQuote; ResearchDepth; ResearchMode; ResearchOutlineEditor; ReturnType; RoughActionButton; SentMidTurn; SetupCredentialCard; Square; StatusIcon; Tooltip; TraceFlow; Trash2; UsageFooter; UserMessage; VideoLessonViewer; VisualizationViewer; Volume2

**Source evidence:**

- [web/components/research/ResearchOutlineEditor.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L3) — `import { useCallback, useState } from "react";`
- [web/components/research/ResearchOutlineEditor.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L25) — `export default function ResearchOutlineEditor({`
- [web/components/research/ResearchOutlineEditor.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L32) — `const [items, setItems] = useState<OutlineItem[]>(initialOutline);`
- [web/components/research/ResearchOutlineEditor.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L33) — `const [localConfirmed, setLocalConfirmed] = useState(false);`
- [web/components/research/ResearchOutlineEditor.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L38) — `const [collapsed, setCollapsed] = useState(false);`
- [web/components/research/ResearchOutlineEditor.tsx:39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L39) — `const [userToggled, setUserToggled] = useState(false);`
- [web/components/research/ResearchOutlineEditor.tsx:76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L76) — `if (valid.length === 0) return;`
- [web/components/research/ResearchConfigPanel.tsx:83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L83) — `export default memo(function ResearchConfigPanel({`
- [web/features/chat/messages/ChatMessageList.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L12) — `useState,`
- [web/features/chat/messages/ChatMessageList.tsx:372](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L372) — `const [userOpen, setUserOpen] = useState<boolean | null>(null);`


## S15 — Visualize / math animation / Video Lesson output

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Assistant capability result; viewer tab

**Purpose:** Visualization presentation

**Visible sections:** Visualization presentation; SVG/HTML/charts/diagrams; code and fullscreen; math animation result; lesson player; GeoGebra board

**User actions:** Toggle code; copy; fullscreen; play; source-supported file actions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — rendering/player loading states vary by renderer

**Empty state:** UNVERIFIED — result payload required

**Error state:** VERIFIED — visualization render error and embed limitations

**Success / completed state:** VERIFIED — rendered presentation/video result

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Use full-screen viewer where needed. DOM/iframe/Chart.js/Remotion/GeoGebra need isolated embedded web rendering or a proven native equivalent; no promise of drop-in native conversion.

**Source components:** [`web/components/visualize/VisualizationViewer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx), [`web/components/math-animator/MathAnimatorViewer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/math-animator/MathAnimatorViewer.tsx), [`web/components/video-lesson/VideoLessonViewer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/video-lesson/VideoLessonViewer.tsx), [`web/components/Geogebra.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx)

**Reusable components:** CanvasVisualization; ChartJsRenderer; Check; Clapperboard; Code2; Copy; Expand; ExternalLink; Geogebra; GeogebraProps; HTMLCanvasElement; HTMLDivElement; HTMLIFrameElement; HTMLScriptElement; Header; HtmlRenderer; Icon; MathAnimatorViewer; Maximize2; Mermaid; PluginIframeRenderer; RenderFileActions; SvgFigure; SvgRenderer; Timer

**Source evidence:**

- [web/components/visualize/VisualizationViewer.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L4) — `import { useEffect, useMemo, useRef, useState, type MouseEvent } from "react";`
- [web/components/visualize/VisualizationViewer.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L53) — `const [error, setError] = useState<string | null>(null);`
- [web/components/visualize/VisualizationViewer.tsx:121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L121) — `const [height, setHeight] = useState(560);`
- [web/components/visualize/VisualizationViewer.tsx:186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L186) — `title={t("HTML visualization")}`
- [web/components/visualize/VisualizationViewer.tsx:198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L198) — `const [height, setHeight] = useState(560);`
- [web/components/visualize/VisualizationViewer.tsx:245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L245) — `title={result.presentation.title || result.renderer.id}`
- [web/components/visualize/VisualizationViewer.tsx:482](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L482) — `title={result.presentation.title}`
- [web/components/visualize/VisualizationViewer.tsx:511](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L511) — `export default function VisualizationViewer({`
- [web/components/visualize/VisualizationViewer.tsx:522](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L522) — `const [showCode, setShowCode] = useState(false);`
- [web/components/visualize/VisualizationViewer.tsx:523](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L523) — `const [copied, setCopied] = useState(false);`


## S16 — Personalized Learning / Learning

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning

**Parent layout:** workspace

**Entry points:** Learning shelf

**Purpose:** Learning dashboard

**Visible sections:** Learning dashboard; Books, Mastery Path, Practice, Immersive Reading; activity/items and source-specific counts

**User actions:** Open learning surface or item; create learning

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — feature data loading

**Empty state:** VERIFIED — feature-specific empty invitations

**Error state:** VERIFIED — feature load errors; inspect runtime for combined failure layout

**Success / completed state:** VERIFIED — existing learning records

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve the four separate learning surfaces in a stacked dashboard; source layout preference changes copy/presentation, not record identity.

**Source components:** [`web/app/(workspace)/learning/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/page.tsx), [`web/components/learning/LearningDashboard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx), [`web/features/ui-layout/classic/ClassicLearningDashboard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx), [`web/components/learning/surfaces.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/surfaces.ts)

**Reusable components:** BookOpen; LayoutLearningHome; LearningCard; LearningCreateMenu; LearningEmptyState; LearningErrorState; LearningKind; LearningShell; LearningSkeleton; LearningSources; LearningWays; Link; Route

**Source evidence:**

- [web/app/(workspace)/learning/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/page.tsx#L3) — `export default function LearningPage() {`
- [web/components/learning/LearningDashboard.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L5) — `import { useState } from 'react'`
- [web/components/learning/LearningDashboard.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L33) — `export function LearningDashboard() {`
- [web/components/learning/LearningDashboard.tsx:36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L36) — `const [kind, setKind] = useState<LearningKind | 'all'>('all')`
- [web/components/learning/LearningDashboard.tsx:37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L37) — `const [query, setQuery] = useState('')`
- [web/components/learning/LearningDashboard.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L38) — `const [limit, setLimit] = useState(24)`
- [web/components/learning/LearningDashboard.tsx:47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L47) — `title={t('navigation.learning')}`
- [web/components/learning/LearningDashboard.tsx:48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L48) — `subtitle={t('navigation.learningDescription')}`
- [web/components/learning/LearningDashboard.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L68) — `{loading ? (`
- [web/components/learning/LearningDashboard.tsx:74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L74) — `<h2 id="learning-todos" className="mb-3 text-[13.5px] font-semibold">`


## S17 — Create learning

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/new

**Parent layout:** workspace

**Entry points:** Learning > Create

**Purpose:** Choose which actual learning surface to create

**Visible sections:** Choose which actual learning surface to create

**User actions:** Start Books, Mastery Path, Practice import or Reading creation

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — auth, customization and module inventory gate LearningSkeleton

**Empty state:** VERIFIED — customize.emptyLearning when eligible surfaces are all hidden

**Error state:** VERIFIED — inventory/preferences error and reload controls

**Success / completed state:** VERIFIED — navigates to owning creation flow

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Keep the four source creation choices; creation forms remain owned by their feature.

**Source components:** [`web/app/(workspace)/learning/new/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/new/page.tsx), [`web/components/learning/NewLearningPage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx), [`web/components/learning/LearningCreateMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningCreateMenu.tsx), [`web/components/learning/surfaces.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/surfaces.ts)

**Reusable components:** ArrowUpRight; LearningEmptyState; LearningErrorState; LearningShell; LearningSkeleton; Link; NewLearningPage; PageCustomizeButton; Plus; Settings2; Tooltip

**Source evidence:**

- [web/app/(workspace)/learning/new/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/new/page.tsx#L3) — `export default function Page() {`
- [web/components/learning/NewLearningPage.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L20) — `export default function NewLearningPage() {`
- [web/components/learning/NewLearningPage.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L42) — `title={t('navigation.createLearning')}`
- [web/components/learning/NewLearningPage.tsx:43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L43) — `subtitle={t('navigation.createLearningDescription')}`
- [web/components/learning/NewLearningPage.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L57) — `{loading ? (`
- [web/components/learning/NewLearningPage.tsx:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L95) — `!inventory.error && (`
- [web/components/learning/NewLearningPage.tsx:98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L98) — `title={t('customize.emptyLearning')}`
- [web/components/learning/NewLearningPage.tsx:104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L104) — `{!loading && (`
- [web/components/learning/LearningCreateMenu.tsx:11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningCreateMenu.tsx#L11) — `export function LearningCreateMenu({ compact = false }: { compact?: boolean }) {`
- [web/components/learning/surfaces.ts:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/surfaces.ts#L1) — `import { BookOpen, BookText, ClipboardCheck, Route, type LucideIcon } from 'lucide-react'`


## S18 — Mastery Path atlas

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/mastery

**Parent layout:** workspace

**Entry points:** Learning > Mastery Path

**Purpose:** Learning goals/path cards

**Visible sections:** Learning goals/path cards; mastery progress; source and next-step context

**User actions:** Open path; create topic

**Modals / dialogs / drawers / sheets:** CreateTopicWizard

**Loading state:** VERIFIED — topic-card skeletons

**Empty state:** VERIFIED — Your atlas is still uncharted

**Error state:** VERIFIED — LearningErrorState with retry

**Success / completed state:** VERIFIED — path cards and mastery progress

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(workspace)/learning/mastery/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx), [`web/components/space/learning/TopicAtlas.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx), [`web/components/space/learning/TopicMapCard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicMapCard.tsx)

**Reusable components:** ArrowRight; CircleCheck; Compass; CreateTopicWizard; HTMLElement; LearningCardContent; LearningEmptyState; LearningErrorState; LearningShell; LearningSkeleton; Link; Loader2; MasteryPathRoute; MasteryTopic; Plus; Route; Sparkles; Suspense; TopicAtlas; TopicMapCard

**Source evidence:**

- [web/app/(workspace)/learning/mastery/page.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L8) — `useState,`
- [web/app/(workspace)/learning/mastery/page.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L29) — `const [topics, setTopics] = useState<MasteryTopic[]>([]);`
- [web/app/(workspace)/learning/mastery/page.tsx:30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L30) — `const [loading, setLoading] = useState(true);`
- [web/app/(workspace)/learning/mastery/page.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L31) — `const [error, setError] = useState<string | null>(null);`
- [web/app/(workspace)/learning/mastery/page.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L32) — `const [wizardOpen, setWizardOpen] = useState(requestedLearningCreation);`
- [web/app/(workspace)/learning/mastery/page.tsx:96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L96) — `export default function MasteryPathPage() {`
- [web/components/space/learning/TopicAtlas.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L27) — `export function TopicAtlas({`
- [web/components/space/learning/TopicAtlas.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L52) — `title={t('Mastery Path')}`
- [web/components/space/learning/TopicAtlas.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L53) — `subtitle={t(`
- [web/components/space/learning/TopicAtlas.tsx:110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L110) — `{error && <LearningErrorState message={error} onRetry={onRetry} />}`


## S19 — Create mastery goal

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Modal

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Mastery atlas; reading handoff

**Purpose:** Goal and emoji

**Visible sections:** Goal and emoji; source choices; step progression

**User actions:** Enter goal; select materials; create; continue outline conversation

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — busy creation

**Empty state:** VERIFIED — unselected sources/blank goal before entry

**Error state:** VERIFIED — creation error

**Success / completed state:** VERIFIED — creation opens owning goal/conversation

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Full-screen stepped modal; preserve goal/source requirements and automatic outline handoff rather than ask the user to retype it.

**Source components:** [`web/components/space/learning/CreateTopicWizard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx), [`web/components/space/learning/TopicWizardSteps.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx)

**Reusable components:** AlertCircle; ArrowLeft; ArrowRight; Check; ChevronDown; ChildSourceList; FileText; GoalStep; HTMLButtonElement; HTMLElement; Icon; Loader2; Set; SourceRow; SourceSection; SourcesStep; Sparkles

**Source evidence:**

- [web/components/space/learning/CreateTopicWizard.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L3) — `import { useState, type RefObject } from "react";`
- [web/components/space/learning/CreateTopicWizard.tsx:45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L45) — `export function CreateTopicWizard({`
- [web/components/space/learning/CreateTopicWizard.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L55) — `const [step, setStep] = useState(1);`
- [web/components/space/learning/CreateTopicWizard.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L56) — `const [goal, setGoal] = useState("");`
- [web/components/space/learning/CreateTopicWizard.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L57) — `const [emoji, setEmoji] = useState("🧭");`
- [web/components/space/learning/CreateTopicWizard.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L65) — `const [selected, setSelected] = useState<Set<string>>(new Set());`
- [web/components/space/learning/CreateTopicWizard.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L66) — `const [busy, setBusy] = useState(false);`
- [web/components/space/learning/CreateTopicWizard.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L67) — `const [error, setError] = useState<string | null>(null);`
- [web/components/space/learning/CreateTopicWizard.tsx:118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L118) — `role="dialog"`
- [web/components/space/learning/CreateTopicWizard.tsx:130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L130) — `<h2`


## S20 — Mastery Path detail

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/mastery/[pathId]

**Parent layout:** workspace

**Entry points:** Atlas card; learning dashboard

**Purpose:** Topic heading

**Visible sections:** Topic heading; sources; outline/board; knowledge points/objective reports; review trail; sessions; strategies/retention

**User actions:** Select point; inspect objective; start study/review; edit route; adjust available strategy/retention; reset/delete

**Modals / dialogs / drawers / sheets:** EditTopicRouteDialog; reset and permanent-delete confirmation

**Loading state:** VERIFIED — topic, sessions and strategies load separately

**Empty state:** VERIFIED — unfinished outline and no sessions have distinct handling

**Error state:** VERIFIED — topic/sessions/board/strategy/retention errors

**Success / completed state:** VERIFIED — progress and completed/mastered points

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Outline/board switch remains contextual; objective detail becomes a nested view or sheet. Preserve separate reset-progress and delete-topic confirmations.

**Source components:** [`web/app/(workspace)/learning/mastery/[pathId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx), [`web/components/space/learning/StudyOutline.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/StudyOutline.tsx), [`web/components/space/learning/LearningBoard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/LearningBoard.tsx), [`web/components/space/learning/ObjectiveDetail.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ObjectiveDetail.tsx), [`web/components/space/learning/ReviewTrail.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx)

**Reusable components:** AlertCircle; ArrowLeft; ArrowRight; BoardResult; BookOpen; Check; CheckCircle2; ChevronsLeft; ChevronsRight; Circle; CircleCheck; CircleDot; Clock3; Compass; ConfirmDialog; Copy; EditTopicRouteDialog; GateBar; HTMLElement; Icon; LearnerProfileCard; LearningBoard; Link; Loader2; MasteryPathCrumb; MasteryTopic; MessageSquare; ModuleOutline; MoreHorizontal; ObjectiveDetail; ObjectiveReport; ObjectiveStatus; PageBarSlot; PageContainer; PathTitle; PencilRuler; Play; PointMark; ReturnType; ReviewIntervalType; ReviewTrail; RotateCcw; Row; SessionCamp; StrategyForm; Tooltip; TopicSession; Trash2

**Source evidence:**

- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L8) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L70) — `export default function MasteryTopicPage() {`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L76) — `const [topic, setTopic] = useState<MasteryTopic | null>(null);`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L77) — `const [sessions, setSessions] = useState<TopicSession[]>([]);`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L78) — `const [loading, setLoading] = useState(true);`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L79) — `const [sessionsLoading, setSessionsLoading] = useState(true);`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L80) — `const [sessionsError, setSessionsError] = useState(false);`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L81) — `const [error, setError] = useState<string | null>(null);`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L82) — `const [selectedId, setSelectedId] = useState<string | null>(null);`
- [web/app/(workspace)/learning/mastery/[pathId]/page.tsx:83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L83) — `const [editorOpen, setEditorOpen] = useState(false);`


## S21 — Mastery study conversation

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/mastery/[pathId]/sessions

**Parent layout:** workspace

**Entry points:** Path start/continue/review or sessions URL

**Purpose:** Outline, Study, Review modes

**Visible sections:** Outline, Study, Review modes; study outline; transcript; contextual question cards; session camp; celebration

**User actions:** Send/stop; change mode when idle; answer/skip allowed questions; open sessions/outline; save

**Modals / dialogs / drawers / sheets:** Session viewer; save to Favorites; sessions panel; level-up celebration

**Loading state:** VERIFIED — useMasteryStudySession loading

**Empty state:** VERIFIED — mode-specific starter choices

**Error state:** VERIFIED — missing/unavailable session and action failures

**Success / completed state:** VERIFIED — mastered progress and level-up overlay

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — One tutor conversation with explicit mode selector; outline and session list open separately on phone. Disable mode switching while a turn runs.

**Source components:** [`web/app/(workspace)/learning/mastery/[pathId]/sessions/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/sessions/page.tsx), [`web/components/space/learning/MasteryStudy.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx), [`web/components/space/learning/ModeSwitch.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModeSwitch.tsx), [`web/components/space/learning/SessionCamp.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/SessionCamp.tsx), [`web/lib/mastery-mode.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mastery-mode.ts)

**Reusable components:** ArrowLeft; ArrowRight; BookmarkPlus; ChatMessageList; ChatViewerBridges; HTMLDivElement; Icon; LevelUpCelebration; Link; Loader2; Map; MapIcon; MasteryComposer; MasteryMode; MasteryPathCrumb; MasteryStudy; MessageCircle; ModeSwitch; PageBarSlot; PanelRight; Plus; ProgressRing; Radio; SaveToNotebookModal; SessionViewerPanel; SessionViewerPanelHandle; StudyOutline; Tooltip; TurnNavigator

**Source evidence:**

- [web/app/(workspace)/learning/mastery/[pathId]/sessions/page.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/sessions/page.tsx#L8) — `export default function MasteryStudyPage() {`
- [web/components/space/learning/MasteryStudy.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L23) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/space/learning/MasteryStudy.tsx:165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L165) — `export function MasteryStudy({`
- [web/components/space/learning/MasteryStudy.tsx:218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L218) — `const [viewerOpen, setViewerOpen] = useState(false);`
- [web/components/space/learning/MasteryStudy.tsx:219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L219) — `const [showSaveModal, setShowSaveModal] = useState(false);`
- [web/components/space/learning/MasteryStudy.tsx:308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L308) — `const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);`
- [web/components/space/learning/MasteryStudy.tsx:312](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L312) — `const [outlineOpen, setOutlineOpen] = useState(true);`
- [web/components/space/learning/MasteryStudy.tsx:357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L357) — `const [askHint, setAskHint] = useState("");`
- [web/components/space/learning/MasteryStudy.tsx:388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L388) — `const [celebration, setCelebration] = useState<{`
- [web/components/space/learning/MasteryStudy.tsx:512](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L512) — `const [modeBusy, setModeBusy] = useState(false);`


## S22 — Persisted mastery study session

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** /learning/mastery/[pathId]/sessions/[sessionId]

**Parent layout:** workspace

**Entry points:** SessionCamp/history/deep link

**Purpose:** Same Mastery study surface restored to a specific session

**Visible sections:** Same Mastery study surface restored to a specific session

**User actions:** Continue existing session using its persisted mode

**Modals / dialogs / drawers / sheets:** Same overlays as S21

**Loading state:** VERIFIED — existing session load

**Empty state:** UNVERIFIED — empty persisted session allowed by runtime

**Error state:** VERIFIED — session load failure handling in study owner

**Success / completed state:** VERIFIED — resumed transcript

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** S20–S21

**Mobile adaptation:** PROPOSED — Use the same mobile study screen as S21 with a session parameter; never count the URL alone as a new product feature.

**Source components:** [`web/app/(workspace)/learning/mastery/[pathId]/sessions/[sessionId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/sessions/[sessionId]/page.tsx), [`web/components/space/learning/MasteryStudy.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx)

**Reusable components:** ArrowLeft; ArrowRight; BookmarkPlus; ChatMessageList; ChatViewerBridges; HTMLDivElement; Icon; LevelUpCelebration; Link; Loader2; Map; MapIcon; MasteryComposer; MasteryPathCrumb; MasteryStudy; MessageCircle; ModeSwitch; PageBarSlot; PanelRight; ProgressRing; SaveToNotebookModal; SessionViewerPanel; SessionViewerPanelHandle; StudyOutline; Tooltip; TurnNavigator

**Source evidence:**

- [web/app/(workspace)/learning/mastery/[pathId]/sessions/[sessionId]/page.tsx:7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/sessions/[sessionId]/page.tsx#L7) — `export default function MasteryStudySessionPage() {`
- [web/components/space/learning/MasteryStudy.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L23) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/space/learning/MasteryStudy.tsx:165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L165) — `export function MasteryStudy({`
- [web/components/space/learning/MasteryStudy.tsx:218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L218) — `const [viewerOpen, setViewerOpen] = useState(false);`
- [web/components/space/learning/MasteryStudy.tsx:219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L219) — `const [showSaveModal, setShowSaveModal] = useState(false);`
- [web/components/space/learning/MasteryStudy.tsx:308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L308) — `const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);`
- [web/components/space/learning/MasteryStudy.tsx:312](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L312) — `const [outlineOpen, setOutlineOpen] = useState(true);`
- [web/components/space/learning/MasteryStudy.tsx:357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L357) — `const [askHint, setAskHint] = useState("");`
- [web/components/space/learning/MasteryStudy.tsx:388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L388) — `const [celebration, setCelebration] = useState<{`
- [web/components/space/learning/MasteryStudy.tsx:512](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L512) — `const [modeBusy, setModeBusy] = useState(false);`


## S23 — Practice / daily review

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/practice

**Parent layout:** workspace

**Entry points:** Learning > Practice; due review links

**Purpose:** Today review

**Visible sections:** Today review; due/overdue/next due; cross-workspace question references; practice insights; import entry

**User actions:** Start review; import questions; open source collections

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — summary/start/import busy states

**Empty state:** VERIFIED — caught-up state and next due

**Error state:** VERIFIED — LearningErrorState retry

**Success / completed state:** VERIFIED — session completion returns refreshed summary

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** S24–S27

**Mobile adaptation:** PROPOSED — Keep daily recall distinct from browsing Question Bank. Preserve workspace IDs on cross-workspace review references.

**Source components:** [`web/app/(workspace)/learning/practice/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/practice/page.tsx), [`web/components/learning/practice/PracticePage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx), [`web/components/learning/practice/ReviewHome.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx), [`web/components/learning/practice/PracticeInsights.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx)

**Reusable components:** ArrowRight; BarChart3; CalendarCheck; ChartNoAxesCombined; Check; ChevronDown; DailyChart; FileUp; HTMLDivElement; LearningErrorState; LearningShell; LearningSkeleton; Library; Link; Loader2; PracticeCollectionPage; PracticeImport; PracticeInsights; PracticePage; PracticePageShell; PracticeRef; PracticeSession; PracticeSummary; QuestionBankSection; RefreshCw; ReviewHome; SpaceSectionHeader; Suspense; Tooltip

**Source evidence:**

- [web/app/(workspace)/learning/practice/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/practice/page.tsx#L5) — `export default function Page() {`
- [web/components/learning/practice/PracticePage.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L3) — `import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";`
- [web/components/learning/practice/PracticePage.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L18) — `export function PracticePage({ mode = "practice" }: { mode?: "practice" | "library" }) {`
- [web/components/learning/practice/PracticePage.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L31) — `const [summary, setSummary] = useState<PracticeSummary | null>(null);`
- [web/components/learning/practice/PracticePage.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L32) — `const [error, setError] = useState("");`
- [web/components/learning/practice/PracticePage.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L33) — `const [importOpen, setImportOpen] = useState(initialImport);`
- [web/components/learning/practice/PracticePage.tsx:34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L34) — `const [notice, setNotice] = useState("");`
- [web/components/learning/practice/PracticePage.tsx:35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L35) — `const [revision, setRevision] = useState(0);`
- [web/components/learning/practice/PracticePage.tsx:36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L36) — `const [session, setSession] = useState<number[] | null>(() => {`
- [web/components/learning/practice/PracticePage.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L40) — `const [starting, setStarting] = useState(false);`


## S24 — Question Bank / Mistakes

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space/questions

**Parent layout:** utility

**Entry points:** Resources > Question Bank; Practice collection links

**Purpose:** Question Bank and Mistakes tabs

**Visible sections:** Question Bank and Mistakes tabs; filters/search/categories; question cards; bulk selection

**User actions:** Filter/search; select; organize categories; bookmark; practice selection; source-supported deletion

**Modals / dialogs / drawers / sheets:** CategoryManager; CategoryMenu; import panel

**Loading state:** VERIFIED — bank loading

**Empty state:** VERIFIED — No matching questions / Everything is filed / No entries yet / Nothing in this view

**Error state:** VERIFIED — bank error retry

**Success / completed state:** VERIFIED — organized cards or selected practice session

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** S23/S25/S26

**Mobile adaptation:** PROPOSED — Scrollable collection tabs and card list; filters/categories become sheet. Mistakes remains a collection view, not an invented learning course.

**Source components:** [`web/app/(utility)/space/questions/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/questions/page.tsx), [`web/components/learning/practice/PracticePage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx), [`web/components/space/question-bank/QuestionBankSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx), [`web/components/space/question-bank/BankToolbar.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankToolbar.tsx), [`web/components/space/question-bank/BankScopeRail.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankScopeRail.tsx), [`web/components/space/question-bank/QuestionCard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionCard.tsx)

**Reusable components:** AlertTriangle; AnswerBlock; ArrowDownWideNarrow; ArrowRight; BankScopeRail; BankSelectionBar; BankToolbar; Bookmark; CalendarCheck; CategoryManager; CategoryMenu; Check; CheckCheck; EmptyState; ExternalLink; FileUp; FolderOpen; Icon; LearningErrorState; LearningShell; LearningSkeleton; Link; Loader2; MarkdownRenderer; MessageSquare; NotebookEntry; PracticeCollectionPage; PracticeImport; PracticeInsights; PracticePage; PracticePageShell; PracticeSession; PracticeSummary; QuestionBankSection; QuestionCard; ReviewHome; RotateCcw; Search; Settings2; SpaceSectionHeader; Suspense; Tooltip; Trash2

**Source evidence:**

- [web/app/(utility)/space/questions/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/questions/page.tsx#L5) — `export default function SpaceQuestionsPage() {`
- [web/components/learning/practice/PracticePage.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L3) — `import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";`
- [web/components/learning/practice/PracticePage.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L18) — `export function PracticePage({ mode = "practice" }: { mode?: "practice" | "library" }) {`
- [web/components/learning/practice/PracticePage.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L31) — `const [summary, setSummary] = useState<PracticeSummary | null>(null);`
- [web/components/learning/practice/PracticePage.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L32) — `const [error, setError] = useState("");`
- [web/components/learning/practice/PracticePage.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L33) — `const [importOpen, setImportOpen] = useState(initialImport);`
- [web/components/learning/practice/PracticePage.tsx:34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L34) — `const [notice, setNotice] = useState("");`
- [web/components/learning/practice/PracticePage.tsx:35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L35) — `const [revision, setRevision] = useState(0);`
- [web/components/learning/practice/PracticePage.tsx:36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L36) — `const [session, setSession] = useState<number[] | null>(() => {`
- [web/components/learning/practice/PracticePage.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L40) — `const [starting, setStarting] = useState(false);`


## S25 — Practice question session

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Daily review; selected Question Bank questions

**Purpose:** Question queue

**Visible sections:** Question queue; answer/reveal; correctness; recall ratings Again, Hard, Mastered, Easy; completion summary

**User actions:** Answer/reveal; rate; retry conflict; skip where offered; finish

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — question fetch and answer/rating busy

**Empty state:** VERIFIED — queue completion with skipped count

**Error state:** VERIFIED — missing/conflicting question, error and reload

**Success / completed state:** VERIFIED — Practice complete; saved count and next due

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Promote active practice into a dedicated mobile route for focus/back handling; retain original queue, workspace reference and rating values again/hard/good/easy.

**Source components:** [`web/components/learning/practice/PracticeSession.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx)

**Reusable components:** ArrowLeft; CheckCircle2; Loader2; Markdown; PracticeQuestion; PracticeRef; PracticeTurn

**Source evidence:**

- [web/components/learning/practice/PracticeSession.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L6) — `import { useEffect, useRef, useState } from 'react'`
- [web/components/learning/practice/PracticeSession.tsx:26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L26) — `export function PracticeSession({`
- [web/components/learning/practice/PracticeSession.tsx:37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L37) — `const [queue, setQueue] = useState<PracticeRef[]>(`
- [web/components/learning/practice/PracticeSession.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L40) — `const [total] = useState(queue.length)`
- [web/components/learning/practice/PracticeSession.tsx:41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L41) — `const [skipped, setSkipped] = useState(0)`
- [web/components/learning/practice/PracticeSession.tsx:43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L43) — `const [index, setIndex] = useState(0)`
- [web/components/learning/practice/PracticeSession.tsx:44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L44) — `const [saved, setSaved] = useState(0)`
- [web/components/learning/practice/PracticeSession.tsx:45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L45) — `const [saving, setSaving] = useState(false)`
- [web/components/learning/practice/PracticeSession.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L46) — `const [nextDue, setNextDue] = useState<number | null>(null)`
- [web/components/learning/practice/PracticeSession.tsx:74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L74) — `<h2 className="font-serif text-2xl font-semibold">{t('Practice complete')}</h2>`


## S26 — Import practice questions

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Practice or Question Bank import

**Purpose:** Spreadsheet/file import

**Visible sections:** Spreadsheet/file import; target collection and result feedback

**User actions:** Choose file/target; import; inspect outcome

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — import busy

**Empty state:** UNVERIFIED — unselected file validation depends on input

**Error state:** VERIFIED — import failure notice

**Success / completed state:** VERIFIED — onImported feedback and parent refresh

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Use Android document picker; preserve accepted formats and server import result. Do not silently replace with invented AI question generation.

**Source components:** [`web/components/learning/practice/PracticeImport.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx)

**Reusable components:** Download; FileSpreadsheet; ImportPreview; Loader2

**Source evidence:**

- [web/components/learning/practice/PracticeImport.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L3) — `import { useRef, useState } from "react";`
- [web/components/learning/practice/PracticeImport.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L13) — `export function PracticeImport({`
- [web/components/learning/practice/PracticeImport.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L23) — `const [target, setTarget] = useState(initialTarget);`
- [web/components/learning/practice/PracticeImport.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L24) — `const [preview, setPreview] = useState<ImportPreview | null>(null);`
- [web/components/learning/practice/PracticeImport.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L25) — `const [filename, setFilename] = useState("");`
- [web/components/learning/practice/PracticeImport.tsx:26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L26) — `const [busy, setBusy] = useState(false);`
- [web/components/learning/practice/PracticeImport.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L28) — `const [error, setError] = useState("");`
- [web/components/learning/practice/PracticeImport.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L66) — `<h2 id="practice-import-title" className="flex items-center gap-2 text-base font-semibold">`
- [web/components/learning/practice/PracticeImport.tsx:141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L141) — `{error && (`


## S27 — Books library

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/books

**Parent layout:** workspace

**Entry points:** Learning > Books

**Purpose:** AI-authored book library

**Visible sections:** AI-authored book library; generation/readiness status; create entry

**User actions:** Open book; create; source-provided library actions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — loadingBooks

**Empty state:** VERIFIED — empty library

**Error state:** VERIFIED — booksError

**Success / completed state:** VERIFIED — generated books list

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(workspace)/learning/books/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/page.tsx), [`web/app/(workspace)/learning/books/BooksRoute.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx), [`web/app/(workspace)/learning/books/components/BookLibrary.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx)

**Reusable components:** ArrowLeft; Book; BookChatPanel; BookCreator; BookCrumb; BookDetail; BookGenerationActivity; BookHealthBanner; BookLibrary; BookLoadingText; BookOpen; BookPageInner; BookPausedBanner; BookProposal; BookSidebar; BookStatus; Clock3; EmptyState; FileText; GraduationCap; Layers; LearningCapture; LearningCapturePanel; LearningCardContent; LearningEmptyState; LearningErrorState; LearningShell; LearningSkeleton; Loader2; MessageSquare; PageReader; Plus; Record; ReturnType; Search; Sparkles; SpineEditor; StatCard; Suspense; Tooltip; Trash2; View

**Source evidence:**

- [web/app/(workspace)/learning/books/page.tsx:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/page.tsx#L1) — `export { default } from "./BooksRoute";`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L3) — `import { Suspense, useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react'`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L50) — `type View = 'list' | 'opening' | 'creator' | 'spine' | 'reader'`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L64) — `return !!page && page.blocks.length === 0 && (page.block_count ?? 0) > 0`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L84) — `export default function BookPage() {`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L112) — `const [books, setBooks] = useState<Book[]>([])`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L113) — `const [canCreateBook, setCanCreateBook] = useState(true)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L114) — `const [loadingBooks, setLoadingBooks] = useState(true)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L115) — `const [booksError, setBooksError] = useState<string | null>(null)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L116) — `const [view, setView] = useState<View>(requestedBookId ? 'opening' : requestedLearningCreation() ? 'creator' : 'list')`


## S28 — Create book / chapter spine

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Books create request

**Purpose:** Subject/proposal

**Visible sections:** Subject/proposal; proposed book; editable chapter spine; confirmation before pages

**User actions:** Create proposal; confirm; edit spine; begin generation

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — creating/proposal/spine confirmation busy

**Empty state:** VERIFIED — initial creator form

**Error state:** VERIFIED — book operation failure in route owner

**Success / completed state:** VERIFIED — confirmed spine transitions toward reader/generation

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Sequential full-screen creation and outline editing; preserve explicit proposal/spine confirmation checkpoints.

**Source components:** [`web/app/(workspace)/learning/books/components/BookCreator.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx), [`web/app/(workspace)/learning/books/components/SpineEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx), [`web/app/(workspace)/learning/books/BooksRoute.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx)

**Reusable components:** ArrowDown; ArrowLeft; ArrowUp; BlockTypeOption; Blocks; Book; BookChatPanel; BookCreator; BookCrumb; BookDepth; BookDetail; BookGenerationActivity; BookHealthBanner; BookLibrary; BookLoadingText; BookPageInner; BookPausedBanner; BookProposal; BookSidebar; Chapter; CheckCircle2; ChevronDown; ChevronUp; Clock3; EstimateBasis; FileText; HTMLDivElement; Layers; LearningCapture; LearningCapturePanel; Loader2; MessageSquare; PageContainer; PageHeader; PageReader; Pencil; Plus; ProposalForm; Record; ReturnType; ScopeOption; Set; SourcesStep; Sparkles; SpineEditor; Suspense; Tooltip; Trash2; View

**Source evidence:**

- [web/app/(workspace)/learning/books/components/BookCreator.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L4) — `import { useEffect, useRef, useState, type ReactNode } from 'react'`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L78) — `loading?: boolean`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L86) — `export default function BookCreator({`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L97) — `const [intent, setIntent] = useState('')`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L98) — `const [language, setLanguage] = useState<string>('auto')`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L99) — `const [depth, setDepth] = useState<BookDepth>('standard')`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L107) — `const [selected, setSelected] = useState<Set<string>>(new Set())`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L108) — `const [sourceError, setSourceError] = useState('')`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L109) — `const [preparing, setPreparing] = useState(false)`
- [web/app/(workspace)/learning/books/components/BookCreator.tsx:115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L115) — `const [editProposal, setEditProposal] = useState<BookProposal | null>(null)`


## S29 — Book / page reader

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/books/[bookId]

**Parent layout:** workspace

**Entry points:** Book card; book/page deep link

**Purpose:** Book spine

**Visible sections:** Book spine; selected page; generated blocks; generation activity; pause/health banners; tutor chat; captures

**User actions:** Navigate pages; read; answer quiz/flashcards; chat; deep dive; capture; pause/resume/rebuild/supplement when allowed

**Modals / dialogs / drawers / sheets:** Book chat and capture panels; block body editing where source enables it

**Loading state:** VERIFIED — opening book and unhydrated page loading

**Empty state:** VERIFIED — placeholder blocks during generation

**Error state:** VERIFIED — BookHealthBanner and page generation failure handling

**Success / completed state:** VERIFIED — generated chapter and saved reading position

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Full-width page reader; spine/chat/captures open separately; preserve book/page/block identity and independent generation states.

**Source components:** [`web/app/(workspace)/learning/books/[bookId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/[bookId]/page.tsx), [`web/app/(workspace)/learning/books/BooksRoute.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx), [`web/app/(workspace)/learning/books/components/PageReader.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx), [`web/app/(workspace)/learning/books/components/BookSidebar.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookSidebar.tsx), [`web/app/(workspace)/learning/books/components/BookChatPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx), [`web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx)

**Reusable components:** ActivityHeader; ActivityMark; ArrowLeft; AssistantResponse; BlockRenderer; Book; BookChatPanel; BookCreator; BookCrumb; BookDetail; BookGenerationActivity; BookHealthBanner; BookLibrary; BookLoadingText; BookPageInner; BookPausedBanner; BookProposal; BookSidebar; Bookmark; BookmarkCheck; ChapterScrollPlacement; ChatMessage; Check; ChevronDown; ChevronLeft; ChevronRight; ChevronUp; Compass; Download; FileText; HTMLDivElement; HTMLInputElement; HTMLTextAreaElement; LearningCapture; LearningCapturePanel; ListFilter; Loader2; MessageSquare; NavButton; PageOutlineNav; PageReader; Paperclip; Pencil; PendingAttachment; Plus; Record; RefreshCcw; ReturnType; RotateCcw; Send; Set; SpineEditor; Suspense; Tooltip; UnifiedTurnClient; View

**Source evidence:**

- [web/app/(workspace)/learning/books/[bookId]/page.tsx:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/[bookId]/page.tsx#L1) — `export { default } from "../BooksRoute";`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L3) — `import { Suspense, useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react'`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L50) — `type View = 'list' | 'opening' | 'creator' | 'spine' | 'reader'`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L64) — `return !!page && page.blocks.length === 0 && (page.block_count ?? 0) > 0`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L84) — `export default function BookPage() {`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L112) — `const [books, setBooks] = useState<Book[]>([])`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L113) — `const [canCreateBook, setCanCreateBook] = useState(true)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L114) — `const [loadingBooks, setLoadingBooks] = useState(true)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L115) — `const [booksError, setBooksError] = useState<string | null>(null)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L116) — `const [view, setView] = useState<View>(requestedBookId ? 'opening' : requestedLearningCreation() ? 'creator' : 'list')`


## S30 — Book page deep link

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** /learning/books/[bookId]/pages/[pageId]

**Parent layout:** workspace

**Entry points:** Page outline or citation

**Purpose:** Same reader as S29 focused on page ID

**Visible sections:** Same reader as S29 focused on page ID

**User actions:** Navigate/read specific page

**Modals / dialogs / drawers / sheets:** Same as S29

**Loading state:** VERIFIED — page hydration loading

**Empty state:** VERIFIED — page placeholders when not generated

**Error state:** VERIFIED — owner handles unavailable pages

**Success / completed state:** VERIFIED — page blocks displayed

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Reuse S29; preserve page ID and scroll locators in deep links.

**Source components:** [`web/app/(workspace)/learning/books/[bookId]/pages/[pageId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/[bookId]/pages/[pageId]/page.tsx), [`web/app/(workspace)/learning/books/BooksRoute.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx)

**Reusable components:** ArrowLeft; Book; BookChatPanel; BookCreator; BookCrumb; BookDetail; BookGenerationActivity; BookHealthBanner; BookLibrary; BookLoadingText; BookPageInner; BookPausedBanner; BookProposal; BookSidebar; LearningCapture; LearningCapturePanel; Loader2; MessageSquare; PageReader; Record; ReturnType; SpineEditor; Suspense; View

**Source evidence:**

- [web/app/(workspace)/learning/books/[bookId]/pages/[pageId]/page.tsx:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/[bookId]/pages/[pageId]/page.tsx#L1) — `export { default } from "../../../BooksRoute";`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L3) — `import { Suspense, useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react'`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L50) — `type View = 'list' | 'opening' | 'creator' | 'spine' | 'reader'`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L64) — `return !!page && page.blocks.length === 0 && (page.block_count ?? 0) > 0`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L84) — `export default function BookPage() {`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L112) — `const [books, setBooks] = useState<Book[]>([])`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L113) — `const [canCreateBook, setCanCreateBook] = useState(true)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L114) — `const [loadingBooks, setLoadingBooks] = useState(true)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L115) — `const [booksError, setBooksError] = useState<string | null>(null)`
- [web/app/(workspace)/learning/books/BooksRoute.tsx:116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L116) — `const [view, setView] = useState<View>(requestedBookId ? 'opening' : requestedLearningCreation() ? 'creator' : 'list')`


## S31 — Immersive Reading library

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/reading

**Parent layout:** workspace

**Entry points:** Learning > Immersive Reading

**Purpose:** Collections/folders and reading library

**Visible sections:** Collections/folders and reading library; creation/import entry

**User actions:** Search/browse; open collection; add materials; manage folder

**Modals / dialogs / drawers / sheets:** AddMaterialsDialog; FolderDialog

**Loading state:** VERIFIED — library load

**Empty state:** VERIFIED — empty library branch

**Error state:** VERIFIED — library load/action failures

**Success / completed state:** VERIFIED — created collection appears

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(workspace)/learning/reading/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/page.tsx), [`web/components/reading/library/ReadingLibrary.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx), [`web/components/reading/library/LibraryShell.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/LibraryShell.tsx)

**Reusable components:** BookOpen; DeleteCollectionDialog; EmptyCollections; FolderDialog; FolderDialogState; FolderGlyph; FolderTile; InvidiousAccountFeedback; LearningEmptyState; LearningErrorState; LearningShell; LearningSkeleton; LibraryShell; Link; Loader2; MoreHorizontal; Palette; Plus; ReadingLibraryMaterial; ReadingLibraryPage; ReadingWorkspace; Search; SortButton; SortMode; Suspense; Trash2; TriangleAlert; UnsettledRow; ViewTab

**Source evidence:**

- [web/app/(workspace)/learning/reading/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/page.tsx#L5) — `export default function ImmersiveReadingLibraryRoute() {`
- [web/components/reading/library/ReadingLibrary.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L27) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/reading/library/ReadingLibrary.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L50) — `export function ReadingLibraryPage() {`
- [web/components/reading/library/ReadingLibrary.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L53) — `const [collections, setCollections] = useState<ReadingWorkspace[]>([]);`
- [web/components/reading/library/ReadingLibrary.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L54) — `const [materials, setMaterials] = useState<ReadingLibraryMaterial[]>([]);`
- [web/components/reading/library/ReadingLibrary.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L55) — `const [loading, setLoading] = useState(true);`
- [web/components/reading/library/ReadingLibrary.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L56) — `const [error, setError] = useState("");`
- [web/components/reading/library/ReadingLibrary.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L57) — `const [search, setSearch] = useState("");`
- [web/components/reading/library/ReadingLibrary.tsx:58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L58) — `const [sort, setSort] = useState<SortMode>("recent");`
- [web/components/reading/library/ReadingLibrary.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L59) — `const [folderDialog, setFolderDialog] = useState<FolderDialogState | null>(`


## S32 — All reading materials

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/reading/materials

**Parent layout:** workspace

**Entry points:** Reading library navigation

**Purpose:** Materials library independent of collection

**Visible sections:** Materials library independent of collection; documents/web/video/audio

**User actions:** Browse/search; select/add material; import existing material

**Modals / dialogs / drawers / sheets:** Add materials; existing material picker; Invidious feedback

**Loading state:** VERIFIED — material fetch/loading

**Empty state:** VERIFIED — no material rows/matches

**Error state:** VERIFIED — import/link errors

**Success / completed state:** VERIFIED — selected/imported material available

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve distinction between a material and its collection membership; use typed import choices and native document selection.

**Source components:** [`web/app/(workspace)/learning/reading/materials/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/materials/page.tsx), [`web/components/reading/library/MaterialLibrary.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx), [`web/components/reading/library/AddMaterialsDialog.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx)

**Reusable components:** AddMaterialsDialog; AssignDialog; Check; DecisionChip; DeleteMaterialDialog; FilterChip; FolderPlus; HTMLDivElement; HTMLInputElement; LearningEmptyState; LearningErrorState; LearningSkeleton; Library; LibraryPicker; LibraryShell; Link; Link2; Loader2; MaterialGlyph; MaterialLibraryPage; MaterialRow; MoreHorizontal; PendingItem; PendingRow; ReadingLibraryCounts; ReadingLibraryFilter; ReadingLibraryMaterial; ReadingWorkspace; Rss; Search; Star; Trash2; Upload; WatchingBrowser

**Source evidence:**

- [web/app/(workspace)/learning/reading/materials/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/materials/page.tsx#L3) — `export default function ReadingMaterialsRoute() {`
- [web/components/reading/library/MaterialLibrary.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L24) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/reading/library/MaterialLibrary.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L60) — `export function MaterialLibraryPage() {`
- [web/components/reading/library/MaterialLibrary.tsx:62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L62) — `const [materials, setMaterials] = useState<ReadingLibraryMaterial[]>([]);`
- [web/components/reading/library/MaterialLibrary.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L63) — `const [counts, setCounts] = useState<ReadingLibraryCounts | null>(null);`
- [web/components/reading/library/MaterialLibrary.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L64) — `const [collections, setCollections] = useState<ReadingWorkspace[]>([]);`
- [web/components/reading/library/MaterialLibrary.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L65) — `const [filter, setFilter] = useState<ReadingLibraryFilter>("all");`
- [web/components/reading/library/MaterialLibrary.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L66) — `const [search, setSearch] = useState("");`
- [web/components/reading/library/MaterialLibrary.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L67) — `const [loading, setLoading] = useState(true);`
- [web/components/reading/library/MaterialLibrary.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L68) — `const [error, setError] = useState("");`


## S33 — Reading collection folder

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/reading/folders/[folderId]

**Parent layout:** workspace

**Entry points:** Reading folder card

**Purpose:** Collection files and conversations

**Visible sections:** Collection files and conversations; enter reading

**User actions:** Open material or conversation; manage collection membership

**Modals / dialogs / drawers / sheets:** Folder/add-material actions

**Loading state:** VERIFIED — folder load

**Empty state:** VERIFIED — empty folder invitation

**Error state:** VERIFIED — folder operation failure

**Success / completed state:** VERIFIED — collection contents and conversations

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(workspace)/learning/reading/folders/[folderId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/folders/[folderId]/page.tsx), [`web/components/reading/library/ReadingFolder.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx)

**Reusable components:** AddMaterialsDialog; ArrowRight; BookOpen; ChevronRight; CircleAlert; DeleteCollectionDialog; FeaturePage; FileRow; FolderDialog; FolderFrame; LearningSkeleton; Link; Loader2; MaterialGlyph; MessageSquare; MoreHorizontal; PageHeader; Palette; Plus; ReadingConversation; ReadingFolderCrumb; ReadingFolderPage; ReadingWorkspace; SectionHeading; Tooltip; Trash2

**Source evidence:**

- [web/app/(workspace)/learning/reading/folders/[folderId]/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/folders/[folderId]/page.tsx#L3) — `export default async function ImmersiveReadingFolderRoute({`
- [web/components/reading/library/ReadingFolder.tsx:19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L19) — `import { useCallback, useEffect, useState } from "react";`
- [web/components/reading/library/ReadingFolder.tsx:51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L51) — `export function ReadingFolderPage({ folderId }: { folderId: string }) {`
- [web/components/reading/library/ReadingFolder.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L54) — `const [folder, setFolder] = useState<ReadingWorkspace | null>(null);`
- [web/components/reading/library/ReadingFolder.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L55) — `const [sessions, setSessions] = useState<ReadingConversation[]>([]);`
- [web/components/reading/library/ReadingFolder.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L56) — `const [error, setError] = useState("");`
- [web/components/reading/library/ReadingFolder.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L57) — `const [loading, setLoading] = useState(true);`
- [web/components/reading/library/ReadingFolder.tsx:58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L58) — `const [opening, setOpening] = useState<string | null>(null);`
- [web/components/reading/library/ReadingFolder.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L59) — `const [menuOpen, setMenuOpen] = useState(false);`
- [web/components/reading/library/ReadingFolder.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L60) — `const [dialog, setDialog] = useState<"add" | "edit" | "delete" | null>(null);`


## S34 — Immersive Reading workspace

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /learning/reading/[workspaceId]

**Parent layout:** workspace

**Entry points:** Reading collection; selected material; history

**Purpose:** Sources/outline

**Visible sections:** Sources/outline; document or synchronized media/transcript stage; companion conversation; reading controls

**User actions:** Read; navigate locators/timestamps; select passage; ask tutor; annotate; read aloud; manage conversations; organize notes

**Modals / dialogs / drawers / sheets:** Source navigator; session list; link conversations; send to Notebook; organized notes; rename/remove; Build Mastery Path

**Loading state:** VERIFIED — reading workspace loading

**Empty state:** VERIFIED — EmptyWorkspace with add-material action

**Error state:** VERIFIED — error without workspace and operation errors

**Success / completed state:** VERIFIED — loaded reader, source-grounded conversation and annotations

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Reader first; explicit companion toggle opens chat with retained passage/timestamp. Preserve collection workspaceId separately from content workspace ID.

**Source components:** [`web/app/(workspace)/learning/reading/[workspaceId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/[workspaceId]/page.tsx), [`web/components/reading/workspace/ReadingWorkspace.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx), [`web/components/reading/ReaderPane.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx), [`web/components/reading/workspace/ReadingCompanion.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx), [`web/components/reading/workspace/SourceNavigator.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx), [`web/components/reading/workspace/MediaReadingStage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx)

**Reusable components:** AddMaterialsDialog; AnnotationList; AnnotationPopover; BilibiliReadingPlayer; BookmarkCheck; ChatMessageList; ChatViewerBridges; ChevronDown; ChevronRight; ChevronUp; ChevronsDown; CircleAlert; CompanionHead; CompanionWelcome; ConversationLinkDialog; EmptyWorkspace; EpubDocumentView; ExternalLink; FileAudio; FileText; HTMLAnchorElement; HTMLAudioElement; HTMLButtonElement; HTMLDivElement; HTMLElement; HTMLVideoElement; HeaderButton; Icon; JumpRequest; Link; Link2; ListOrdered; ListTree; Loader2; MaterialFailure; MaterialIcon; MaterialProcessing; Maximize2; MediaReadingStage; MenuToolButton; Minimize2; NavigatorTab; NotebookCaptureDialog; OrganizedNotesDialog; OutlineRow; PdfDocumentView; Pencil; PopoverAiAction; ReaderActionPayload; ReaderAskDetail; ReaderHead; ReaderHeading; ReaderPane; ReadingActionCards; ReadingActionsProvider; ReadingBar; ReadingCompanion; ReadingComposer; ReadingExtensionBar; ReadingLibraryMaterial; ReadingLocationHistory; ReadingMediaController; ReadingPanelSeparator; ReadingWorkspacePage; SaveToNotebookModal; Search; SelectionPayload; SessionViewerPanel; SessionViewerPanelHandle; Set; SourceNavigator; StickyNote; TextUnitView; Tooltip; Trash2; WorkspaceConfirmDialog; WorkspaceMenuContext; WorkspaceMenuItem; WorkspaceOutlineBranch; WorkspaceValueDialog; YouTubeReadingPlayer

**Source evidence:**

- [web/app/(workspace)/learning/reading/[workspaceId]/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/[workspaceId]/page.tsx#L3) — `export default function NewImmersiveReadingSessionRoute() {`
- [web/components/reading/workspace/ReadingWorkspace.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L20) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/reading/workspace/ReadingWorkspace.tsx:129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L129) — `export function ReadingWorkspacePage() {`
- [web/components/reading/workspace/ReadingWorkspace.tsx:177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L177) — `const [transcriptSearch, setTranscriptSearch] = useState("");`
- [web/components/reading/workspace/ReadingWorkspace.tsx:178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L178) — `const [selection, setSelection] = useState<{`
- [web/components/reading/workspace/ReadingWorkspace.tsx:183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L183) — `const [isDesktopWide, setIsDesktopWide] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L185) — `const [docSlot, setDocSlot] = useState<HTMLDivElement | null>(null);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L194) — `const [showSessions, setShowSessions] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L195) — `const [showLinker, setShowLinker] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L199) — `const [showNotebook, setShowNotebook] = useState(false);`


## S35 — Reading session URL variants

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** /learning/reading/[workspaceId]/sessions

**Parent layout:** workspace

**Entry points:** Reading workspace/history

**Purpose:** Same reading workspace

**Visible sections:** Same reading workspace; active/new conversation

**User actions:** Open/create/continue reading conversation

**Modals / dialogs / drawers / sheets:** Same as S34

**Loading state:** VERIFIED — session/workspace loading

**Empty state:** VERIFIED — new reading conversation

**Error state:** VERIFIED — workspace error handling

**Success / completed state:** VERIFIED — active reading transcript

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Reuse S34; session URL variant is not a distinct learning feature.

**Source components:** [`web/app/(workspace)/learning/reading/[workspaceId]/sessions/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/[workspaceId]/sessions/page.tsx), [`web/components/reading/workspace/ReadingWorkspace.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx)

**Reusable components:** AddMaterialsDialog; CircleAlert; CompanionHead; ConversationLinkDialog; EmptyWorkspace; HTMLDivElement; JumpRequest; Link; Loader2; MaterialFailure; MaterialProcessing; MediaReadingStage; NotebookCaptureDialog; OrganizedNotesDialog; ReaderAskDetail; ReaderHeading; ReaderPane; ReadingActionsProvider; ReadingBar; ReadingCompanion; ReadingLibraryMaterial; ReadingPanelSeparator; ReadingWorkspacePage; SourceNavigator; WorkspaceConfirmDialog; WorkspaceMenuContext; WorkspaceMenuItem; WorkspaceValueDialog

**Source evidence:**

- [web/app/(workspace)/learning/reading/[workspaceId]/sessions/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/[workspaceId]/sessions/page.tsx#L3) — `export default function ImmersiveReadingWorkspaceRoute() {`
- [web/components/reading/workspace/ReadingWorkspace.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L20) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/reading/workspace/ReadingWorkspace.tsx:129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L129) — `export function ReadingWorkspacePage() {`
- [web/components/reading/workspace/ReadingWorkspace.tsx:177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L177) — `const [transcriptSearch, setTranscriptSearch] = useState("");`
- [web/components/reading/workspace/ReadingWorkspace.tsx:178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L178) — `const [selection, setSelection] = useState<{`
- [web/components/reading/workspace/ReadingWorkspace.tsx:183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L183) — `const [isDesktopWide, setIsDesktopWide] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L185) — `const [docSlot, setDocSlot] = useState<HTMLDivElement | null>(null);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L194) — `const [showSessions, setShowSessions] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L195) — `const [showLinker, setShowLinker] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L199) — `const [showNotebook, setShowNotebook] = useState(false);`


## S36 — Persisted reading conversation

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** /learning/reading/[workspaceId]/sessions/[sessionId]

**Parent layout:** workspace

**Entry points:** Reading session list/deep link

**Purpose:** Same reader and companion restored to session

**Visible sections:** Same reader and companion restored to session

**User actions:** Continue selected reading conversation

**Modals / dialogs / drawers / sheets:** Same as S34

**Loading state:** VERIFIED — restore/load

**Empty state:** UNVERIFIED — depends on saved record

**Error state:** VERIFIED — owner load failure branch

**Success / completed state:** VERIFIED — restored reader conversation

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Reuse S34 with explicit session parameter.

**Source components:** [`web/app/(workspace)/learning/reading/[workspaceId]/sessions/[sessionId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/[workspaceId]/sessions/[sessionId]/page.tsx), [`web/components/reading/workspace/ReadingWorkspace.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx)

**Reusable components:** AddMaterialsDialog; CircleAlert; CompanionHead; ConversationLinkDialog; EmptyWorkspace; HTMLDivElement; JumpRequest; Link; Loader2; MaterialFailure; MaterialProcessing; MediaReadingStage; NotebookCaptureDialog; OrganizedNotesDialog; ReaderAskDetail; ReaderHeading; ReaderPane; ReadingActionsProvider; ReadingBar; ReadingCompanion; ReadingLibraryMaterial; ReadingPanelSeparator; ReadingWorkspacePage; SourceNavigator; WorkspaceConfirmDialog; WorkspaceMenuContext; WorkspaceMenuItem; WorkspaceValueDialog

**Source evidence:**

- [web/app/(workspace)/learning/reading/[workspaceId]/sessions/[sessionId]/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/reading/[workspaceId]/sessions/[sessionId]/page.tsx#L3) — `export default function ImmersiveReadingWorkspaceSessionRoute() {`
- [web/components/reading/workspace/ReadingWorkspace.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L20) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/reading/workspace/ReadingWorkspace.tsx:129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L129) — `export function ReadingWorkspacePage() {`
- [web/components/reading/workspace/ReadingWorkspace.tsx:177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L177) — `const [transcriptSearch, setTranscriptSearch] = useState("");`
- [web/components/reading/workspace/ReadingWorkspace.tsx:178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L178) — `const [selection, setSelection] = useState<{`
- [web/components/reading/workspace/ReadingWorkspace.tsx:183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L183) — `const [isDesktopWide, setIsDesktopWide] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L185) — `const [docSlot, setDocSlot] = useState<HTMLDivElement | null>(null);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L194) — `const [showSessions, setShowSessions] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L195) — `const [showLinker, setShowLinker] = useState(false);`
- [web/components/reading/workspace/ReadingWorkspace.tsx:199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L199) — `const [showNotebook, setShowNotebook] = useState(false);`


## S37 — Reading annotation and display tools

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Contextual menu

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Passage selection; reader toolbar

**Purpose:** Selection anchored annotation actions

**Visible sections:** Selection anchored annotation actions; highlight colors/note input; font size/family/line width/theme; EPUB spread

**User actions:** Highlight; write note; contextual tutor action; adjust/reset reading display

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** Not applicable — local controls; annotation persistence belongs to owner

**Empty state:** VERIFIED — empty annotation list handling in owner

**Error state:** UNVERIFIED — selection drift and persistence recovery need runtime

**Success / completed state:** VERIFIED — stored annotation/display preferences

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Selection action sheet anchored to persistent locators; native text selection must preserve PDF/EPUB/source anchors. Default reader text is 17, bounds 12–28; do not use arbitrary small/medium/large values.

**Source components:** [`web/components/reading/AnnotationPopover.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx), [`web/components/reading/AnnotationList.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationList.tsx), [`web/components/reading/ReaderDisplayControls.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderDisplayControls.tsx), [`web/lib/reading-display-preferences.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-display-preferences.ts)

**Reusable components:** AddToNote; AiChip; AlertCircle; AnnotationColor; Bookmark; Bot; HTMLDivElement; Icon; IconButton; MessageSquareQuote; PreferenceButton; ReaderDisplayPreferences; Sparkles; Tooltip; Trash2; ViewTab

**Source evidence:**

- [web/components/reading/AnnotationPopover.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L4) — `import { useEffect, useLayoutEffect, useRef, useState } from 'react'`
- [web/components/reading/AnnotationPopover.tsx:74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L74) — `export function AnnotationPopover({`
- [web/components/reading/AnnotationPopover.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L89) — `const [color, setColor] = useState<AnnotationColor>('yellow')`
- [web/components/reading/AnnotationPopover.tsx:90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L90) — `const [noteOpen, setNoteOpen] = useState(false)`
- [web/components/reading/AnnotationPopover.tsx:91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L91) — `const [note, setNote] = useState('')`
- [web/components/reading/AnnotationPopover.tsx:92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L92) — `const [overflowOpen, setOverflowOpen] = useState(false)`
- [web/components/reading/AnnotationPopover.tsx:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L95) — `const [position, setPosition] = useState({ left: anchor.x, top: anchor.y })`
- [web/components/reading/AnnotationPopover.tsx:103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L103) — `const [dragOffset, setDragOffset] = useState(0)`
- [web/components/reading/AnnotationPopover.tsx:213](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L213) — `title={noteSource.title}`
- [web/components/reading/AnnotationPopover.tsx:305](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L305) — `role="dialog"`


## S38 — Legacy watching session

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nonvisual logic

**Web route:** /learning/watching/[sessionId]

**Parent layout:** workspace

**Entry points:** Existing watching deep link

**Purpose:** Compatibility route into current reading/media behavior

**Visible sections:** Compatibility route into current reading/media behavior

**User actions:** Resolve/open previous watching session

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — legacy resolution state

**Empty state:** UNVERIFIED — record required

**Error state:** VERIFIED — legacy unavailable handling depends on resolution

**Success / completed state:** VERIFIED — resolves to supported reading session

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Support compatibility links; /learning/watching itself redirects to Reading. Do not add a separate Watching top-level destination.

**Source components:** [`web/app/(workspace)/learning/watching/[sessionId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/watching/[sessionId]/page.tsx), [`web/components/reading/workspace/LegacyWatchingSession.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx), [`web/components/reading/workspace/YouTubeReadingPlayer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/YouTubeReadingPlayer.tsx), [`web/components/reading/workspace/BilibiliReadingPlayer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/BilibiliReadingPlayer.tsx)

**Reusable components:** HTMLDivElement; LegacyWatchingSession; ReadingMediaController

**Source evidence:**

- [web/app/(workspace)/learning/watching/[sessionId]/page.tsx:2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/watching/[sessionId]/page.tsx#L2) — `export default async function WatchingPage({ params }: { params: Promise<{ sessionId: string }> }) {`
- [web/components/reading/workspace/LegacyWatchingSession.tsx:2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L2) — `import { useEffect, useState } from "react";`
- [web/components/reading/workspace/LegacyWatchingSession.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L8) — `export default function LegacyWatchingSession({ sessionId }: { sessionId: string }) {`
- [web/components/reading/workspace/LegacyWatchingSession.tsx:11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L11) — `const [error, setError] = useState("");`
- [web/components/reading/workspace/LegacyWatchingSession.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L12) — `const [retry, setRetry] = useState(0);`
- [web/components/reading/workspace/LegacyWatchingSession.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L22) — `return <div className="p-6 text-sm" role={error ? "alert" : "status"}>`
- [web/components/reading/workspace/LegacyWatchingSession.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L24) — `{error && <button type="button" className="ml-3 underline" onClick={() => { setError(""); setRetry(value => value + 1); }}>{t("Retry")}</button>}`
- [web/components/reading/workspace/YouTubeReadingPlayer.tsx:11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/YouTubeReadingPlayer.tsx#L11) — `export function YouTubeReadingPlayer({`
- [web/components/reading/workspace/BilibiliReadingPlayer.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/BilibiliReadingPlayer.tsx#L3) — `import { useEffect, useMemo, useRef, useState } from 'react'`
- [web/components/reading/workspace/BilibiliReadingPlayer.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/BilibiliReadingPlayer.tsx#L22) — `export function BilibiliReadingPlayer({`


## S39 — Resources / Learning Space

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space

**Parent layout:** utility

**Entry points:** Resources shelf; classic Learning Space

**Purpose:** Conversations & Materials

**Visible sections:** Conversations & Materials; Chat History, Favorites, Learning journal, Question Bank, Knowledge Center; conditional More Projects

**User actions:** Open actual resource; read available counts

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — per-tile load/count probes

**Empty state:** VERIFIED — conditional group omitted if no available items

**Error state:** UNVERIFIED — count failures vary by tile

**Success / completed state:** VERIFIED — resource tiles

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(utility)/space/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/page.tsx), [`web/components/space/SpaceDashboard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx), [`web/components/space/dashboard-groups.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts)

**Reusable components:** ArrowUpRight; DashKey; DashboardCard; Github; Icon; Link; PageHeader; Partial; Record; SpaceDashboard

**Source evidence:**

- [web/app/(utility)/space/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/page.tsx#L3) — `export default function SpaceIndexPage() {`
- [web/components/space/SpaceDashboard.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L4) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/space/SpaceDashboard.tsx:35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L35) — `export default function SpaceDashboard({`
- [web/components/space/SpaceDashboard.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L54) — `const [counts, setCounts] = useState<Partial<Record<DashKey, number>>>({});`
- [web/components/space/SpaceDashboard.tsx:86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L86) — `title={title ?? spaceLabel}`
- [web/components/space/SpaceDashboard.tsx:96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L96) — `<h2 className={'mb-3 ${PAGE_SECTION_TITLE_CLASS}'}>`
- [web/components/space/dashboard-groups.ts:282](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts#L282) — `export function visibleGroups(`


## S40 — Personalization

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /personalization

**Parent layout:** utility

**Entry points:** Personalization account shelf

**Purpose:** My Agents, Personas, Skills, MCP Services, CLI Apps, Memory

**Visible sections:** My Agents, Personas, Skills, MCP Services, CLI Apps, Memory

**User actions:** Open account-level resource managers

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — source count probes

**Empty state:** UNVERIFIED — no global empty state required

**Error state:** UNVERIFIED — count probe failure presentation

**Success / completed state:** VERIFIED — account-resource tiles

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve account-wide scope while workspace content changes.

**Source components:** [`web/app/(utility)/personalization/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/personalization/page.tsx), [`web/components/space/PersonalizationHub.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonalizationHub.tsx), [`web/components/space/dashboard-groups.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts)

**Reusable components:** FeaturePage; PersonalizationHub; SpaceDashboard

**Source evidence:**

- [web/app/(utility)/personalization/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/personalization/page.tsx#L3) — `export default function PersonalizationPage() {`
- [web/components/space/PersonalizationHub.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonalizationHub.tsx#L10) — `export function PersonalizationHub() {`
- [web/components/space/PersonalizationHub.tsx:16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonalizationHub.tsx#L16) — `title={t("navigation.personalization")}`
- [web/components/space/dashboard-groups.ts:282](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts#L282) — `export function visibleGroups(`


## S41 — Knowledge Center

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /knowledge-bases

**Parent layout:** utility

**Entry points:** Resources > Knowledge Center

**Purpose:** Knowledge bases and Knowledge engines tabs

**Visible sections:** Knowledge bases and Knowledge engines tabs; search/cards; source connectors Obsidian, MarginNote4, Kiwix

**User actions:** Search; open KB/engine; create/link KB; connect source

**Modals / dialogs / drawers / sheets:** CreateKbModal; ConnectKiwixModal

**Loading state:** VERIFIED — page loading and Suspense spinner

**Empty state:** VERIFIED — no bases / no matches

**Error state:** VERIFIED — page error banner

**Success / completed state:** VERIFIED — configured KB/engine cards

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(utility)/knowledge-bases/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/knowledge-bases/page.tsx), [`web/components/knowledge/KnowledgePage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx), [`web/components/knowledge/KnowledgeHome.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx)

**Reusable components:** Check; ChevronRight; Cloud; ConnectKiwixModal; CreateKbModal; Database; EngineDetail; EngineStatusBadge; FeaturePage; HardDrive; Icon; KnowledgeBaseDetail; KnowledgeEngineIcon; KnowledgeHome; KnowledgeHomeSection; KnowledgePage; Library; LinkedFolderInfo; Loader2; PageHeader; Plus; Search; Server; Star; StatusDot; Suspense; SyncFolderResponse

**Source evidence:**

- [web/app/(utility)/knowledge-bases/page.tsx:7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/knowledge-bases/page.tsx#L7) — `export default function Page() {`
- [web/components/knowledge/KnowledgePage.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L9) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/knowledge/KnowledgePage.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L50) — `export default function KnowledgePage() {`
- [web/components/knowledge/KnowledgePage.tsx:99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L99) — `const [explicitSelection, setExplicitSelection] = useState<string | null>(`
- [web/components/knowledge/KnowledgePage.tsx:102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L102) — `const [selectedEngineId, setSelectedEngineId] = useState<string | null>(`
- [web/components/knowledge/KnowledgePage.tsx:106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L106) — `useState<KnowledgeHomeSection>(initialHomeSection);`
- [web/components/knowledge/KnowledgePage.tsx:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L107) — `const [createOpen, setCreateOpen] = useState(false);`
- [web/components/knowledge/KnowledgePage.tsx:108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L108) — `const [kiwixOpen, setKiwixOpen] = useState(false);`
- [web/components/knowledge/KnowledgePage.tsx:109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L109) — `const [createPreset, setCreatePreset] = useState<{`
- [web/components/knowledge/KnowledgePage.tsx:127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L127) — `const [view, setView] = useState<"home" | "kb" | "engine">(`


## S42 — Knowledge base details

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /knowledge-bases/[kbName]

**Parent layout:** utility

**Entry points:** KB card; direct KB URL

**Purpose:** Files

**Visible sections:** Files; Add documents; Linked folders; GitHub; Web; Index versions; Devices; Articles; Settings; task logs and indexing status

**User actions:** Browse/upload/manage documents; configure sources; inspect/retry indexing and versions; read allowed previews

**Modals / dialogs / drawers / sheets:** File preview; folder linking; source-specific editors; index settings

**Loading state:** VERIFIED — page fetch, file loads and live task progress

**Empty state:** VERIFIED — per-section empty collections

**Error state:** VERIFIED — index-failure banner and retry handling

**Success / completed state:** VERIFIED — published/ready index and completed run

**Permissions:** Honor kb.read_only and per-engine/KB source eligibility. Not all nine sections appear for every base.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Section selector with individual lists; progress remains attached to KB/run ID. Server linked folders and Devices are server-side concepts, not permission to browse phone filesystem.

**Source components:** [`web/app/(utility)/knowledge-bases/[kbName]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/knowledge-bases/[kbName]/page.tsx), [`web/components/knowledge/KnowledgeBaseDetail.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx), [`web/components/knowledge/KbFilesTab.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx), [`web/components/knowledge/KbIndexingRun.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx), [`web/components/knowledge/KbTaskLogs.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbTaskLogs.tsx)

**Reusable components:** ArrowLeft; Database; FilePreviewSource; Icon; KbDetailSection; KbDocumentList; KbDocumentsSection; KbFilePreview; KbFilesTab; KbGitHubSourcesSection; KbIndexVersionsSection; KbIndexingRun; KbKiwixArticlesSection; KbLinkedFoldersSection; KbMarginNoteDevicesSection; KbSettingsSection; KbStatusBadge; KbTaskLogs; KbVisualCoverage; KbWebSourcesSection; KnowledgeBaseCrumb; KnowledgeBaseFile; KnowledgeEngineIcon; KnowledgePage; LightRagEmbeddingWarning; LinkedFolderInfo; Loader2; ProcessLogs; RefreshCw; Star; Suspense; SyncFolderResponse; Tooltip

**Source evidence:**

- [web/app/(utility)/knowledge-bases/[kbName]/page.tsx:7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/knowledge-bases/[kbName]/page.tsx#L7) — `export default function Page() {`
- [web/components/knowledge/KnowledgeBaseDetail.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L8) — `import { useState } from "react";`
- [web/components/knowledge/KnowledgeBaseDetail.tsx:111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L111) — `export default function KnowledgeBaseDetail({`
- [web/components/knowledge/KnowledgeBaseDetail.tsx:130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L130) — `const [section, setSection] = useState<KbDetailSection>("files");`
- [web/components/knowledge/KnowledgeBaseDetail.tsx:131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L131) — `const [retrySubmitting, setRetrySubmitting] = useState(false);`
- [web/components/knowledge/KnowledgeBaseDetail.tsx:234](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L234) — `<h1 className="truncate font-serif text-[18px] font-semibold tracking-tight text-[var(--foreground)]">`
- [web/components/knowledge/KbFilesTab.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx#L4) — `import { useEffect, useMemo, useState } from "react";`
- [web/components/knowledge/KbFilesTab.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx#L29) — `export default function KbFilesTab({ kb, task }: KbFilesTabProps) {`
- [web/components/knowledge/KbFilesTab.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx#L31) — `const [selectedFile, setSelectedFile] = useState<KnowledgeBaseFile | null>(`
- [web/components/knowledge/KbFilesTab.tsx:39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx#L39) — `const [refreshKey, setRefreshKey] = useState(0);`


## S43 — Create / link knowledge base

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Modal

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Knowledge Center create or source connector

**Purpose:** Create new / Link existing

**Visible sections:** Create new / Link existing; name/provider/files; source/server probes and engine defaults

**User actions:** Enter valid name; choose engine; add documents; probe link/server; submit

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — defaults/probe/submitting states

**Empty state:** VERIFIED — initial form and no files

**Error state:** VERIFIED — probe/config/submission errors

**Success / completed state:** VERIFIED — KB appears and indexing may continue

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Full-screen form preserving create/link mode, provider-dependent fields and probe results; distinguish phone file upload from server folder linking.

**Source components:** [`web/components/knowledge/CreateKbModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx), [`web/components/knowledge/LinkFolderModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx), [`web/components/knowledge/PageIndexSettingsModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx)

**Reusable components:** AlertTriangle; Awaited; Check; ChevronRight; Database; EmbeddingModelSelector; ExternalLink; File; FileDropZone; FolderSearch; FolderSync; Icon; ImaConnectionFields; KeyRound; KnowledgeEngineIcon; LightRagServerFields; LightRagServerProbe; Link2; LinkModeFields; LinkedFolderProbe; Loader2; Modal; Mode; ModeToggle; NewModeFields; PageIndexConfig; PageIndexConfigForm; Plus; ProbeVerdict; Server; ServerProbeVerdict; Tooltip; WeKnoraFields; WeKnoraProbe; WeKnoraProbeVerdict

**Source evidence:**

- [web/components/knowledge/CreateKbModal.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L6) — `import { useEffect, useRef, useState, type ReactNode } from "react";`
- [web/components/knowledge/CreateKbModal.tsx:129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L129) — `export default function CreateKbModal({`
- [web/components/knowledge/CreateKbModal.tsx:146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L146) — `const [mode, setMode] = useState<Mode>("new");`
- [web/components/knowledge/CreateKbModal.tsx:147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L147) — `const [name, setName] = useState("");`
- [web/components/knowledge/CreateKbModal.tsx:148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L148) — `const [provider, setProvider] = useState("llamaindex");`
- [web/components/knowledge/CreateKbModal.tsx:149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L149) — `const [files, setFiles] = useState<File[]>([]);`
- [web/components/knowledge/CreateKbModal.tsx:150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L150) — `const [pageIndexMode, setPageIndexMode] = useState<"" | "flash" | "standard">(`
- [web/components/knowledge/CreateKbModal.tsx:154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L154) — `const [linkSource, setLinkSource] = useState(OBSIDIAN_SOURCE);`
- [web/components/knowledge/CreateKbModal.tsx:155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L155) — `const [folderPath, setFolderPath] = useState("");`
- [web/components/knowledge/CreateKbModal.tsx:156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L156) — `const [probe, setProbe] = useState<LinkedFolderProbe | null>(null);`


## S44 — Knowledge engine configuration

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Knowledge Center > Knowledge engines

**Purpose:** Selected engine configuration

**Visible sections:** Selected engine configuration; engine-specific forms, model/index controls

**User actions:** Select engine; inspect/edit supported configuration; test/probe where provided

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — configuration loading

**Empty state:** UNVERIFIED — depends on engine/provider availability

**Error state:** VERIFIED — engine/model validation/probe failures in forms

**Success / completed state:** VERIFIED — saved engine configuration

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Separate engine detail destination from KB detail. Preserve engine forms and access controls; no invented local mobile index engine.

**Source components:** [`web/features/knowledge/components/engines/EngineDetail.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx), [`web/features/knowledge/components/engines/LlamaIndexForm.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/LlamaIndexForm.tsx), [`web/features/knowledge/components/engines/LightRagForm.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/LightRagForm.tsx), [`web/features/knowledge/components/engines/GraphRagForm.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/GraphRagForm.tsx), [`web/features/knowledge/components/engines/ImaForm.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/ImaForm.tsx)

**Reusable components:** ArrowLeft; Check; CheckCircle2; CheckRow; ChevronDown; CircleSlash; Copy; CopyableCommand; EnginePreflight; EnvRequirements; ExternalLink; FormSkeleton; GraphRagConfig; GraphRagForm; Icon; ImaAccountConfig; ImaForm; KnowledgeEngineIcon; LightRagConfig; LightRagForm; LightRagModelsForm; LightRagRoleModelsEditor; LightRagServerConfig; LightRagServerForm; LightRagServerProbe; Link; LlamaIndexConfig; LlamaIndexForm; Loader2; ModeSelector; ModelOptionsByKind; ModelsSection; NumberField; PageIndexConfigForm; RefreshCw; ResponseTypeSelect; SaveButton; Section; Server; ShieldCheck; StatusBadge; TextField; ToggleField; XCircle

**Source evidence:**

- [web/features/knowledge/components/engines/EngineDetail.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L3) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/features/knowledge/components/engines/EngineDetail.tsx:206](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L206) — `<h2 className="mb-3 flex items-center gap-2 text-[11px] font-medium uppercase tracking-wide text-[var(--muted-foreground)]">`
- [web/features/knowledge/components/engines/EngineDetail.tsx:217](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L217) — `const [outcome, setOutcome] = useState<"idle" | "copied" | "failed">("idle");`
- [web/features/knowledge/components/engines/EngineDetail.tsx:339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L339) — `const [selected, setSelected] = useState(`
- [web/features/knowledge/components/engines/EngineDetail.tsx:342](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L342) — `const [pending, setPending] = useState<string | null>(null);`
- [web/features/knowledge/components/engines/EngineDetail.tsx:399](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L399) — `export function LlamaIndexForm({`
- [web/features/knowledge/components/engines/EngineDetail.tsx:407](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L407) — `const [loaded, setLoaded] = useState<LlamaIndexConfig | null>(null);`
- [web/features/knowledge/components/engines/EngineDetail.tsx:408](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L408) — `const [form, setForm] = useState<LlamaIndexConfig | null>(null);`
- [web/features/knowledge/components/engines/EngineDetail.tsx:409](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L409) — `const [saving, setSaving] = useState(false);`
- [web/features/knowledge/components/engines/EngineDetail.tsx:742](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L742) — `export function ImaForm({`


## S45 — Favorites collections

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /notebooks

**Parent layout:** utility

**Entry points:** Resources > Favorites; legacy /notebook redirects

**Purpose:** Saved original conversations and sources

**Visible sections:** Saved original conversations and sources; collection cards/search; metadata

**User actions:** Create/open/rename collection

**Modals / dialogs / drawers / sheets:** NotebookMetaDialog

**Loading state:** VERIFIED — library loading

**Empty state:** VERIFIED — empty collections state

**Error state:** VERIFIED — Could not load your notebooks with recovery

**Success / completed state:** VERIFIED — collection list refreshed

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Use product context: navigation calls this Favorites while component UI still uses Notebooks. Keep separate from Learning notebook/Co-Writer.

**Source components:** [`web/app/(utility)/notebooks/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/notebooks/page.tsx), [`web/components/notebook/NotebookConsole.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx), [`web/components/notebook/useNotebookLibrary.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts)

**Reusable components:** AlertTriangle; CollectionCard; ConfirmDialog; ConsoleNotice; CrumbItem; FavoriteKindIcon; FeaturePage; FolderGlyph; HTMLDivElement; HeaderAction; Icon; InstanceCrumb; Loader2; NotebookDetail; NotebookDetailState; NotebookList; NotebookMetaDialog; NotebookRecordRow; NotebookSummary; PageBarSlot; PageHeader; Pencil; PickerShell; Plus; Record; RecordTime; Search; Tooltip

**Source evidence:**

- [web/app/(utility)/notebooks/page.tsx:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/notebooks/page.tsx#L1) — `export { default } from "./NotebooksRoute";`
- [web/components/notebook/NotebookConsole.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L4) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/notebook/NotebookConsole.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L81) — `export default function NotebookConsole({`
- [web/components/notebook/NotebookConsole.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L89) — `const [banner, setBanner] = useState<string | null>(null);`
- [web/components/notebook/NotebookConsole.tsx:126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L126) — `title={t("Could not load your notebooks")}`
- [web/components/notebook/NotebookConsole.tsx:172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L172) — `const [peeks, setPeeks] = useState<Record<string, NotebookRecordItem[]>>({});`
- [web/components/notebook/NotebookConsole.tsx:218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L218) — `const [query, setQuery] = useState("");`
- [web/components/notebook/NotebookConsole.tsx:219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L219) — `const [creating, setCreating] = useState(startCreating);`
- [web/components/notebook/NotebookConsole.tsx:220](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L220) — `const [editingId, setEditingId] = useState<string | null>(null);`
- [web/components/notebook/NotebookConsole.tsx:249](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L249) — `title={t("Notebooks")}`


## S46 — Favorites collection detail

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /notebooks/[notebookId]

**Parent layout:** utility

**Entry points:** Favorites collection; ?record= locator

**Purpose:** Collection heading

**Visible sections:** Collection heading; record-kind filter/search; original saved records; focused record query

**User actions:** Search/filter; inspect/use/delete records; edit/delete collection

**Modals / dialogs / drawers / sheets:** Metadata edit; collection delete confirmation

**Loading state:** VERIFIED — record loading

**Empty state:** VERIFIED — no records / no matches

**Error state:** VERIFIED — unavailable collection/record error

**Success / completed state:** VERIFIED — collection and matching records

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Nested list/detail retaining record source/type and focused record ID.

**Source components:** [`web/app/(utility)/notebooks/[notebookId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/notebooks/[notebookId]/page.tsx), [`web/components/notebook/NotebookConsole.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx), [`web/components/notebook/NotebookRecordRow.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx), [`web/components/notebook/NotebookRecordActions.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx)

**Reusable components:** AddToNote; AlertTriangle; ArrowLeft; BadgeIcon; CollectionCard; ConfirmDialog; ConsoleNotice; CrumbItem; ExternalLink; FavoriteContent; FavoriteKindIcon; FeaturePage; FolderGlyph; HTMLDivElement; HeaderAction; Icon; InstanceCrumb; Loader2; MarkdownRenderer; MenuItem; MoreHorizontal; NotebookDetail; NotebookList; NotebookMetaDialog; NotebookRecordActions; NotebookRecordRow; PageBarSlot; PageHeader; Panel; Pencil; Pending; PickerShell; Plus; Record; RecordEditor; RecordTime; Search; Tooltip

**Source evidence:**

- [web/app/(utility)/notebooks/[notebookId]/page.tsx:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/notebooks/[notebookId]/page.tsx#L1) — `export { default } from "../NotebooksRoute";`
- [web/components/notebook/NotebookConsole.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L4) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/notebook/NotebookConsole.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L81) — `export default function NotebookConsole({`
- [web/components/notebook/NotebookConsole.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L89) — `const [banner, setBanner] = useState<string | null>(null);`
- [web/components/notebook/NotebookConsole.tsx:126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L126) — `title={t("Could not load your notebooks")}`
- [web/components/notebook/NotebookConsole.tsx:172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L172) — `const [peeks, setPeeks] = useState<Record<string, NotebookRecordItem[]>>({});`
- [web/components/notebook/NotebookConsole.tsx:218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L218) — `const [query, setQuery] = useState("");`
- [web/components/notebook/NotebookConsole.tsx:219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L219) — `const [creating, setCreating] = useState(startCreating);`
- [web/components/notebook/NotebookConsole.tsx:220](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L220) — `const [editingId, setEditingId] = useState<string | null>(null);`
- [web/components/notebook/NotebookConsole.tsx:249](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L249) — `title={t("Notebooks")}`


## S47 — Save to Favorites / Notebook

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Modal

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Chat/partner save action; composer reference selector

**Purpose:** Choose collection

**Visible sections:** Choose collection; save original content; reference existing saved records

**User actions:** Select collection; save/cancel; choose records for composer

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — destination/record loading and save busy

**Empty state:** VERIFIED — no collections/records handling belongs to picker

**Error state:** VERIFIED — save/select failure handling

**Success / completed state:** VERIFIED — saved original/reference chip

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Keep collection selection and record multi-selection distinct; source content does not become an editable learning note automatically.

**Source components:** [`web/components/notebook/SaveToNotebookModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx), [`web/components/notebook/NotebookRecordPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordPicker.tsx)

**Reusable components:** AbortController; AddToNote; Check; Icon; Loader2; NotebookPen; NotebookSaveMessage; NotebookSelector; PickerHeader; PickerShell; Plus; RealNotebookSummary; Set

**Source evidence:**

- [web/components/notebook/SaveToNotebookModal.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L4) — `import { useEffect, useMemo, useRef, useState } from "react";`
- [web/components/notebook/SaveToNotebookModal.tsx:134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L134) — `if (messages.length === 0 || turnCount <= 0) return [];`
- [web/components/notebook/SaveToNotebookModal.tsx:139](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L139) — `if (userPositions.length === 0) {`
- [web/components/notebook/SaveToNotebookModal.tsx:149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L149) — `export default function SaveToNotebookModal({`
- [web/components/notebook/SaveToNotebookModal.tsx:157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L157) — `const [notebooks, setNotebooks] = useState<RealNotebookSummary[]>([]);`
- [web/components/notebook/SaveToNotebookModal.tsx:158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L158) — `const [selectedIds, setSelectedIds] = useState<string[]>([]);`
- [web/components/notebook/SaveToNotebookModal.tsx:159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L159) — `const [title, setTitle] = useState("");`
- [web/components/notebook/SaveToNotebookModal.tsx:160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L160) — `const [titleEdited, setTitleEdited] = useState(false);`
- [web/components/notebook/SaveToNotebookModal.tsx:161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L161) — `const [summaryPreview, setSummaryPreview] = useState("");`
- [web/components/notebook/SaveToNotebookModal.tsx:162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L162) — `const [isLoading, setIsLoading] = useState(false);`


## S48 — Learning journal

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space/journal

**Parent layout:** utility

**Entry points:** Resources > Learning journal

**Purpose:** Current mission

**Visible sections:** Current mission; last-session handoff; confirmed learning records

**User actions:** Inspect; refresh/retry

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — journal load pending

**Empty state:** VERIFIED — absent mission/handoff/records use source fallbacks

**Error state:** VERIFIED — corrupt/unreadable journal notice preserves original data

**Success / completed state:** VERIFIED — confirmed records displayed

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Read-only structured record view matching source. Do not add freeform diary editing, weekly summaries or progress charts based on unused mobile translation keys.

**Source components:** [`web/app/(utility)/space/journal/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/journal/page.tsx), [`web/components/space/LearningJournalPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx)

**Reusable components:** LearningJournalPanel; SpaceSectionHeader; Suspense

**Source evidence:**

- [web/app/(utility)/space/journal/page.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/journal/page.tsx#L4) — `export default function JournalPage() {`
- [web/components/space/LearningJournalPanel.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L3) — `import { useEffect, useState } from "react";`
- [web/components/space/LearningJournalPanel.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L9) — `export default function LearningJournalPanel() {`
- [web/components/space/LearningJournalPanel.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L12) — `const [result, setResult] = useState<{ workspace: string; revision: number; journal?: LearningJournal; error?: boolean } | null>(null);`
- [web/components/space/LearningJournalPanel.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L13) — `const [revision, setRevision] = useState(0);`
- [web/components/space/LearningJournalPanel.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L31) — `<SpaceSectionHeader title={t("Learning journal")} description={t("Your tutor's mission, handoff and confirmed learning records.")}`
- [web/components/space/LearningJournalPanel.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L33) — `{error ? <div role="alert" className={card}>{t("Could not read the learning journal. Its original data is preserved. Try refreshing.")}</div>`
- [web/components/space/LearningJournalPanel.tsx:37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L37) — `<h2 className="font-semibold">{t("Current mission")}</h2>`
- [web/components/space/LearningJournalPanel.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L46) — `<h2 className="font-semibold">{t("Last-session handoff")}</h2>`
- [web/components/space/LearningJournalPanel.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L54) — `<h2 className="font-semibold">{t("Confirmed learning records")}</h2>`


## S49 — Skills

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space/skills

**Parent layout:** utility

**Entry points:** Personalization > Skills

**Purpose:** Account skill library

**Visible sections:** Account skill library; scope; tags; Markdown skill viewer/editor; import

**User actions:** Create/edit/delete; view; filter/manage tags; import from EduHub

**Modals / dialogs / drawers / sheets:** Viewer; editor; tag management; EduHub import

**Loading state:** VERIFIED — list/viewer/editor busy

**Empty state:** VERIFIED — empty skills / no filtered matches

**Error state:** VERIFIED — list/editor/viewer errors and name validation

**Success / completed state:** VERIFIED — updated skill library

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Tall viewer/editor routes and filter sheet; preserve builtin/read-only distinctions and lowercase/digit/hyphen name restrictions.

**Source components:** [`web/app/(utility)/space/skills/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/skills/page.tsx), [`web/components/space/SkillsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx), [`web/components/space/SkillLibraryScope.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillLibraryScope.tsx), [`web/components/space/EduHubImportModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx)

**Reusable components:** AlertTriangle; ArrowLeft; ChatWorkspaceRegistration; Check; CheckCircle2; ChevronDown; DetailView; Download; EduHubImportModal; ExternalLink; Eye; HubSkillDetail; HubSkillListing; Icon; InstallButton; ListView; Loader2; Lock; Pencil; Plus; RefreshCw; Search; Set; SkillCard; SkillEditorState; SkillInfo; SkillMarkdown; SkillViewerState; SkillsSection; SpaceSectionHeader; Sparkles; Star; Store; TagFilterChip; TagIcon; Tooltip; Trash2; Wand2

**Source evidence:**

- [web/app/(utility)/space/skills/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/skills/page.tsx#L3) — `export default function SpaceSkillsPage() {`
- [web/components/space/SkillsSection.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L6) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/space/SkillsSection.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L78) — `export default function SkillsSection() {`
- [web/components/space/SkillsSection.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L81) — `const [skills, setSkills] = useState<SkillInfo[]>([]);`
- [web/components/space/SkillsSection.tsx:82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L82) — `const [tagVocab, setTagVocab] = useState<string[]>([]);`
- [web/components/space/SkillsSection.tsx:83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L83) — `const [loading, setLoading] = useState(false);`
- [web/components/space/SkillsSection.tsx:84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L84) — `const [errorMsg, setErrorMsg] = useState<string | null>(null);`
- [web/components/space/SkillsSection.tsx:85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L85) — `const [editor, setEditor] = useState<SkillEditorState | null>(null);`
- [web/components/space/SkillsSection.tsx:86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L86) — `const [viewer, setViewer] = useState<SkillViewerState | null>(null);`
- [web/components/space/SkillsSection.tsx:87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L87) — `const [deleting, setDeleting] = useState<string | null>(null);`


## S50 — Personas

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space/personas

**Parent layout:** utility

**Entry points:** Personalization > Personas; composer style picker

**Purpose:** Behavior presets

**Visible sections:** Behavior presets; Markdown content; builtin indicators; viewer/editor

**User actions:** Create/view/edit/delete supported personas

**Modals / dialogs / drawers / sheets:** Persona viewer/editor

**Loading state:** VERIFIED — list/viewer load

**Empty state:** VERIFIED — empty personas

**Error state:** VERIFIED — errors and name validation

**Success / completed state:** VERIFIED — updated presets

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(utility)/space/personas/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/personas/page.tsx), [`web/components/space/PersonasSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx)

**Reusable components:** Eye; Loader2; Lock; Pencil; PersonaEditorState; PersonaInfo; PersonaMarkdown; PersonaViewerState; PersonasSection; Plus; SpaceSectionHeader; Sparkles; Tooltip; Trash2; UserRound

**Source evidence:**

- [web/app/(utility)/space/personas/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/personas/page.tsx#L3) — `export default function SpacePersonasPage() {`
- [web/components/space/PersonasSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L5) — `import { useCallback, useEffect, useState } from "react";`
- [web/components/space/PersonasSection.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L63) — `export default function PersonasSection() {`
- [web/components/space/PersonasSection.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L66) — `const [personas, setPersonas] = useState<PersonaInfo[]>([]);`
- [web/components/space/PersonasSection.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L67) — `const [loading, setLoading] = useState(false);`
- [web/components/space/PersonasSection.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L68) — `const [errorMsg, setErrorMsg] = useState<string | null>(null);`
- [web/components/space/PersonasSection.tsx:69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L69) — `const [editor, setEditor] = useState<PersonaEditorState | null>(null);`
- [web/components/space/PersonasSection.tsx:70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L70) — `const [viewer, setViewer] = useState<PersonaViewerState | null>(null);`
- [web/components/space/PersonasSection.tsx:71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L71) — `const [deleting, setDeleting] = useState<string | null>(null);`
- [web/components/space/PersonasSection.tsx:245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L245) — `title={t("Personas")}`


## S51 — My Agents

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /agents

**Parent layout:** utility

**Entry points:** Personalization > My Agents; classic navigation More

**Purpose:** Local/remote connected agents and connection configuration

**Visible sections:** Local/remote connected agents and connection configuration; imported-history agent library in MyAgentsSection (S117–S118)

**User actions:** Connect/configure/test/remove supported backend; inspect availability

**Modals / dialogs / drawers / sheets:** Connection editor and source-specific controls

**Loading state:** VERIFIED — connection discovery/loading

**Empty state:** VERIFIED — no connections handling in ConnectedAgents

**Error state:** VERIFIED — detection/list fetch catches fall back to empty arrays; explicit load error is not retained in ConnectedAgents. Disconnect errors may propagate without an inline message. Import errors are separate in S118.

**Success / completed state:** VERIFIED — configured agent available to chat

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Configuration targets server-side agents, not CLI processes running on Android; defer complicated setup from first delivery while inventory retains parity.

**Source components:** [`web/app/(utility)/agents/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/agents/page.tsx), [`web/components/agents/AgentsHub.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/AgentsHub.tsx), [`web/components/agents/ConnectedAgents.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx)

**Reusable components:** AgentsHub; ConnectModal; ConnectedAgents; Cpu; FeaturePage; Glyph; Loader2; MyAgentsSection; Plug; Plus; SpaceSectionHeader; SubagentBackendInfo; SubagentConnection; Tooltip; Trash2

**Source evidence:**

- [web/app/(utility)/agents/page.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/agents/page.tsx#L4) — `export default function AgentsPage() {`
- [web/components/agents/AgentsHub.tsx:11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/AgentsHub.tsx#L11) — `export default function AgentsHub() {`
- [web/components/agents/ConnectedAgents.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/agents/ConnectedAgents.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L28) — `export default function ConnectedAgents() {`
- [web/components/agents/ConnectedAgents.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L33) — `const [backends, setBackends] = useState<SubagentBackendInfo[]>([]);`
- [web/components/agents/ConnectedAgents.tsx:34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L34) — `const [connections, setConnections] = useState<SubagentConnection[]>([]);`
- [web/components/agents/ConnectedAgents.tsx:35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L35) — `const [loading, setLoading] = useState(true);`
- [web/components/agents/ConnectedAgents.tsx:36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L36) — `const [modalOpen, setModalOpen] = useState(false);`
- [web/components/agents/ConnectedAgents.tsx:37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L37) — `const [busyName, setBusyName] = useState<string | null>(null);`
- [web/components/agents/ConnectedAgents.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L89) — `title={tr({ zh: "连接的智能体", en: "Connected agents" })}`


## S52 — MCP Services

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space/mcp

**Parent layout:** utility

**Entry points:** Personalization > MCP Services

**Purpose:** Account hosted connections

**Visible sections:** Account hosted connections; catalog; deployment/admin registry; tool lists/status

**User actions:** Connect/edit/remove; discover tools; inspect deployment; administer only where authorized

**Modals / dialogs / drawers / sheets:** MCP form; tool list; catalog; key-value editor

**Loading state:** VERIFIED — fetch/discovery states

**Empty state:** VERIFIED — no configured server/tool cases

**Error state:** VERIFIED — server connection/discovery error states

**Success / completed state:** VERIFIED — usable connection status

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve account versus deployment management boundary; phone only configures backend connections.

**Source components:** [`web/app/(utility)/space/mcp/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/mcp/page.tsx), [`web/components/space/McpStoreSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx), [`web/components/mcp/McpServerList.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerList.tsx), [`web/components/mcp/McpServerForm.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx), [`web/components/mcp/McpCatalogBrowser.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx), [`web/components/mcp/McpAdminRegistry.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpAdminRegistry.tsx), [`web/components/mcp/McpDeploymentList.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpDeploymentList.tsx)

**Reusable components:** AlertTriangle; ArrowLeft; BookOpen; BrandIcon; CheckCircle2; ChevronDown; Download; EntryCard; EntryDetail; ExternalLink; FilterChip; KeyValueEditor; Loader2; McpAdminRegistry; McpCatalogBrowser; McpCatalogEntry; McpCatalogList; McpDeploymentList; McpKvPair; McpServerConfig; McpServerForm; McpServerList; McpServerRow; McpStatusBadge; McpStoreSection; McpStoreState; McpTestResult; McpTool; McpToolList; Plug; Plus; Record; RefreshCw; RejectedServers; Search; ShieldAlert; ShieldCheck; SpaceSectionHeader; Tab; TabButton; Tooltip; TrademarkNote

**Source evidence:**

- [web/app/(utility)/space/mcp/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/mcp/page.tsx#L3) — `export default function SpaceMcpPage() {`
- [web/components/space/McpStoreSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L3) — `import { useState } from "react";`
- [web/components/space/McpStoreSection.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L18) — `type Tab = "installed" | "store";`
- [web/components/space/McpStoreSection.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L28) — `export default function McpStoreSection() {`
- [web/components/space/McpStoreSection.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L32) — `const [tab, setTab] = useState<Tab>("installed");`
- [web/components/space/McpStoreSection.tsx:41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L41) — `title={t("MCP Services")}`
- [web/components/mcp/McpServerList.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerList.tsx#L12) — `export default function McpServerList({`
- [web/components/mcp/McpServerList.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerList.tsx#L56) — `if (names.length === 0) {`
- [web/components/mcp/McpServerForm.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L3) — `import { useCallback, useState } from "react";`
- [web/components/mcp/McpServerForm.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L27) — `export default function McpServerForm({`


## S53 — CLI Apps

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /space/cli-apps

**Parent layout:** utility

**Entry points:** Personalization > CLI Apps

**Purpose:** Server CLI-Anything catalog

**Visible sections:** Server CLI-Anything catalog; installed/granted/enabled distinctions

**User actions:** Browse; source-supported enable/configure/install/grant actions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — catalog load/busy

**Empty state:** VERIFIED — absent apps/catalog entries

**Error state:** VERIFIED — app action/load errors

**Success / completed state:** VERIFIED — granted enabled apps usable from chat

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Administrative integration view for backend apps; do not imply Android executable installation.

**Source components:** [`web/app/(utility)/space/cli-apps/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/cli-apps/page.tsx), [`web/components/cli-apps/CliAppsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx)

**Reusable components:** AlertTriangle; ArrowLeft; Banner; BookOpen; BrandIcon; CheckCircle2; CliAppState; CliAppsSection; CliCatalogEntry; Download; Empty; EntryCard; EntryDetail; ExternalLink; Field; FilterChip; Installed; Loader2; Lock; Record; RefreshCw; Search; ShieldCheck; SpaceSectionHeader; Spinner; Store; Tab; TabButton; Terminal; Toggle; Tooltip; TrademarkNote; Trash2; TrustChip

**Source evidence:**

- [web/app/(utility)/space/cli-apps/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/space/cli-apps/page.tsx#L3) — `export default function SpaceCliAppsPage() {`
- [web/components/cli-apps/CliAppsSection.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L4) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/cli-apps/CliAppsSection.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L40) — `type Tab = "installed" | "store";`
- [web/components/cli-apps/CliAppsSection.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L52) — `export default function CliAppsSection() {`
- [web/components/cli-apps/CliAppsSection.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L57) — `const [state, setState] = useState<CliAppState | null>(null);`
- [web/components/cli-apps/CliAppsSection.tsx:58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L58) — `const [loadError, setLoadError] = useState<string | null>(null);`
- [web/components/cli-apps/CliAppsSection.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L59) — `const [tab, setTab] = useState<Tab>("installed");`
- [web/components/cli-apps/CliAppsSection.tsx:90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L90) — `title={t("CLI Apps")}`
- [web/components/cli-apps/CliAppsSection.tsx:158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L158) — `const [busy, setBusy] = useState<string | null>(null);`
- [web/components/cli-apps/CliAppsSection.tsx:159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L159) — `const [error, setError] = useState<string | null>(null);`


## S54 — Memory hub

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /memory

**Parent layout:** utility

**Entry points:** Personalization > Memory

**Purpose:** L1 Workspace mirror

**Visible sections:** L1 Workspace mirror; L2 Per-surface summaries; L3 Cross-surface knowledge; graph/run access

**User actions:** Open layer; refresh; inspect memory process

**Modals / dialogs / drawers / sheets:** MemoryRunPanel

**Loading state:** VERIFIED — overview and L1 totals loading

**Empty state:** UNVERIFIED — no-memory hub copy needs runtime

**Error state:** UNVERIFIED — overview failure may degrade silently; verify

**Success / completed state:** VERIFIED — memory overview

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(utility)/memory/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/page.tsx), [`web/components/memory/MemoryHub.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx)

**Reusable components:** ArrowRight; FeaturePage; GraphCallout; Icon; LayerCard; Link; MemoryArchivedBanner; MemoryHub; OverviewResponse; PageHeader; RefreshCw; Sparkles

**Source evidence:**

- [web/app/(utility)/memory/page.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/page.tsx#L4) — `export default function MemoryPage() {`
- [web/components/memory/MemoryHub.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L5) — `import { useCallback, useEffect, useState } from "react";`
- [web/components/memory/MemoryHub.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L52) — `export default function MemoryHub() {`
- [web/components/memory/MemoryHub.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L54) — `const [overview, setOverview] = useState<OverviewResponse | null>(null);`
- [web/components/memory/MemoryHub.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L55) — `const [l1Total, setL1Total] = useState<number | null>(null);`
- [web/components/memory/MemoryHub.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L56) — `const [loading, setLoading] = useState(true);`
- [web/components/memory/MemoryHub.tsx:93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L93) — `title={t("Memory")}`
- [web/components/memory/MemoryHub.tsx:103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L103) — `className={loading ? "h-3 w-3 animate-spin" : "h-3 w-3"}`
- [web/components/memory/MemoryHub.tsx:121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L121) — `title={t("L1 · Workspace mirror")}`
- [web/components/memory/MemoryHub.tsx:133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L133) — `title={t("L2 · Per-surface summaries")}`


## S55 — L1 workspace mirror

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /memory/l1

**Parent layout:** utility

**Entry points:** Memory hub; ?surface= or ?ref= footnote

**Purpose:** Chat/notebook/quiz/kb/book/partner/cowriter surfaces

**Visible sections:** Chat/notebook/quiz/kb/book/partner/cowriter surfaces; counts/pending; reference-focused mirror

**User actions:** Switch surface; focus reference; trigger supported memory run

**Modals / dialogs / drawers / sheets:** Memory run panel

**Loading state:** VERIFIED — run/count requests

**Empty state:** UNVERIFIED — per-surface no-mirror state needs runtime

**Error state:** UNVERIFIED — owner toast/error presentation needs runtime

**Success / completed state:** VERIFIED — mirrored content and active reference

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Single surface selector plus focused document; preserve read/mirror semantics rather than expose invented freeform memory creation.

**Source components:** [`web/app/(utility)/memory/l1/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l1/page.tsx), [`web/components/memory/MemoryL1Workbench.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx)

**Reusable components:** ArrowLeft; Breadcrumb; Icon; L1View; LayerSwitcher; Layers; Link; MemoryL1PageInner; MemoryL1Workbench; Record; Surface; Suspense

**Source evidence:**

- [web/app/(utility)/memory/l1/page.tsx:61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l1/page.tsx#L61) — `export default function MemoryL1Page() {`
- [web/components/memory/MemoryL1Workbench.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L4) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/memory/MemoryL1Workbench.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L60) — `export default function MemoryL1Workbench({`
- [web/components/memory/MemoryL1Workbench.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L68) — `const [surface, setSurface] = useState<Surface>(initialSurface || "notebook");`
- [web/components/memory/MemoryL1Workbench.tsx:69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L69) — `const [counts, setCounts] = useState<Record<Surface, number>>(`
- [web/components/memory/MemoryL1Workbench.tsx:72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L72) — `const [pending, setPending] = useState<Record<Surface, number>>(`
- [web/components/memory/MemoryL1Workbench.tsx:75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L75) — `const [focusRef, setFocusRef] = useState<string | null>(`
- [web/components/memory/MemoryL1Workbench.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L78) — `const [toast, setToast] = useState("");`


## S56 — L2 summaries

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /memory/l2

**Parent layout:** utility

**Entry points:** Memory hub; /memory/l2/[surface]

**Purpose:** Per-surface summaries

**Visible sections:** Per-surface summaries; rendered/line-number view; editable content

**User actions:** Select surface; edit/save/cancel; inspect reference lines

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — overview/content fetch

**Empty state:** VERIFIED — EmptyState when no lines

**Error state:** VERIFIED — save/error toast paths require runtime exact copy

**Success / completed state:** VERIFIED — saved content/line view

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Master list followed by document; retain focus line IDs and rendered/line view switch.

**Source components:** [`web/app/(utility)/memory/l2/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l2/page.tsx), [`web/components/memory/MemoryWorkbench.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx)

**Reusable components:** ArrowLeft; Breadcrumb; EmptyState; HTMLDivElement; Icon; LayerSwitcher; LineNumberedView; LineRowDTO; Link; Loader2; MarkdownRenderer; MemoryRunPanel; MemoryWorkbench; Network; Pencil; Record; Save; ULID; ViewMode; ViewSwitch; Workflow

**Source evidence:**

- [web/app/(utility)/memory/l2/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l2/page.tsx#L5) — `export default function MemoryL2Page() {`
- [web/components/memory/MemoryWorkbench.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L6) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/memory/MemoryWorkbench.tsx:170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L170) — `type ViewMode = "plain" | "lines";`
- [web/components/memory/MemoryWorkbench.tsx:183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L183) — `export default function MemoryWorkbench({`
- [web/components/memory/MemoryWorkbench.tsx:191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L191) — `const [docKey, setDocKey] = useState<string>(initialKey || nav[0].key);`
- [web/components/memory/MemoryWorkbench.tsx:197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L197) — `const [overview, setOverview] = useState<Record<string, DocOverview>>({});`
- [web/components/memory/MemoryWorkbench.tsx:198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L198) — `const [content, setContent] = useState("");`
- [web/components/memory/MemoryWorkbench.tsx:199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L199) — `const [lines, setLines] = useState<LineRowDTO[]>([]);`
- [web/components/memory/MemoryWorkbench.tsx:200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L200) — `const [view, setView] = useState<ViewMode>("plain");`
- [web/components/memory/MemoryWorkbench.tsx:201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L201) — `const [editing, setEditing] = useState(false);`


## S57 — L2 focused surface

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** /memory/l2/[surface]

**Parent layout:** utility

**Entry points:** L2 selector; resolver footnote

**Purpose:** Same L2 workbench on validated surface

**Visible sections:** Same L2 workbench on validated surface; ?focus= line

**User actions:** Inspect/edit surface summary

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — same owner load

**Empty state:** VERIFIED — same empty lines

**Error state:** VERIFIED — invalid surface calls notFound

**Success / completed state:** VERIFIED — focused document

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Reuse S56 with validated surface/focus params.

**Source components:** [`web/app/(utility)/memory/l2/[surface]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l2/[surface]/page.tsx), [`web/components/memory/MemoryWorkbench.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx)

**Reusable components:** ArrowLeft; Breadcrumb; EmptyState; HTMLDivElement; Icon; L2WorkbenchInner; LayerSwitcher; LineNumberedView; LineRowDTO; Link; Loader2; MarkdownRenderer; MemoryRunPanel; MemoryWorkbench; Network; Pencil; Record; Save; Suspense; ULID; ViewMode; ViewSwitch; Workflow

**Source evidence:**

- [web/app/(utility)/memory/l2/[surface]/page.tsx:34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l2/[surface]/page.tsx#L34) — `export default function MemoryL2WorkbenchPage() {`
- [web/components/memory/MemoryWorkbench.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L6) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/memory/MemoryWorkbench.tsx:170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L170) — `type ViewMode = "plain" | "lines";`
- [web/components/memory/MemoryWorkbench.tsx:183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L183) — `export default function MemoryWorkbench({`
- [web/components/memory/MemoryWorkbench.tsx:191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L191) — `const [docKey, setDocKey] = useState<string>(initialKey || nav[0].key);`
- [web/components/memory/MemoryWorkbench.tsx:197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L197) — `const [overview, setOverview] = useState<Record<string, DocOverview>>({});`
- [web/components/memory/MemoryWorkbench.tsx:198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L198) — `const [content, setContent] = useState("");`
- [web/components/memory/MemoryWorkbench.tsx:199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L199) — `const [lines, setLines] = useState<LineRowDTO[]>([]);`
- [web/components/memory/MemoryWorkbench.tsx:200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L200) — `const [view, setView] = useState<ViewMode>("plain");`
- [web/components/memory/MemoryWorkbench.tsx:201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L201) — `const [editing, setEditing] = useState(false);`


## S58 — L3 cross-surface knowledge

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /memory/l3

**Parent layout:** utility

**Entry points:** Memory hub

**Purpose:** Recent summary

**Visible sections:** Recent summary; User profile; Knowledge scope; rendered/line-number editor

**User actions:** Select slot; edit/save; inspect references

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — shared workbench load

**Empty state:** VERIFIED — EmptyState when no lines

**Error state:** VERIFIED — shared save failure paths

**Success / completed state:** VERIFIED — saved cross-surface content

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Reuse workbench presentation but keep L3 slot semantics distinct from L2 summaries.

**Source components:** [`web/app/(utility)/memory/l3/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l3/page.tsx), [`web/components/memory/MemoryWorkbench.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx)

**Reusable components:** ArrowLeft; Breadcrumb; EmptyState; HTMLDivElement; Icon; LayerSwitcher; LineNumberedView; LineRowDTO; Link; Loader2; MarkdownRenderer; MemoryRunPanel; MemoryWorkbench; Network; Pencil; Record; Save; ULID; ViewMode; ViewSwitch; Workflow

**Source evidence:**

- [web/app/(utility)/memory/l3/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l3/page.tsx#L5) — `export default function MemoryL3Page() {`
- [web/components/memory/MemoryWorkbench.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L6) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/memory/MemoryWorkbench.tsx:170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L170) — `type ViewMode = "plain" | "lines";`
- [web/components/memory/MemoryWorkbench.tsx:183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L183) — `export default function MemoryWorkbench({`
- [web/components/memory/MemoryWorkbench.tsx:191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L191) — `const [docKey, setDocKey] = useState<string>(initialKey || nav[0].key);`
- [web/components/memory/MemoryWorkbench.tsx:197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L197) — `const [overview, setOverview] = useState<Record<string, DocOverview>>({});`
- [web/components/memory/MemoryWorkbench.tsx:198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L198) — `const [content, setContent] = useState("");`
- [web/components/memory/MemoryWorkbench.tsx:199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L199) — `const [lines, setLines] = useState<LineRowDTO[]>([]);`
- [web/components/memory/MemoryWorkbench.tsx:200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L200) — `const [view, setView] = useState<ViewMode>("plain");`
- [web/components/memory/MemoryWorkbench.tsx:201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L201) — `const [editing, setEditing] = useState(false);`


## S59 — L3 focused slot

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nested screen

**Web route:** /memory/l3/[slot]

**Parent layout:** utility

**Entry points:** L3 selector; deep link

**Purpose:** Same L3 workbench, validated recent/profile/scope

**Visible sections:** Same L3 workbench, validated recent/profile/scope

**User actions:** Inspect/edit selected slot

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — shared workbench load

**Empty state:** VERIFIED — empty lines

**Error state:** VERIFIED — invalid slot calls notFound

**Success / completed state:** VERIFIED — selected slot

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Reuse S58. Source comment explicitly says L3 focus targets are not currently surfaced; do not promise them.

**Source components:** [`web/app/(utility)/memory/l3/[slot]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l3/[slot]/page.tsx), [`web/components/memory/MemoryWorkbench.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx)

**Reusable components:** ArrowLeft; Breadcrumb; EmptyState; HTMLDivElement; Icon; L3WorkbenchInner; LayerSwitcher; LineNumberedView; LineRowDTO; Link; Loader2; MarkdownRenderer; MemoryRunPanel; MemoryWorkbench; Network; Pencil; Record; Save; Suspense; ULID; ViewMode; ViewSwitch; Workflow

**Source evidence:**

- [web/app/(utility)/memory/l3/[slot]/page.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/l3/[slot]/page.tsx#L24) — `export default function MemoryL3WorkbenchPage() {`
- [web/components/memory/MemoryWorkbench.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L6) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/memory/MemoryWorkbench.tsx:170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L170) — `type ViewMode = "plain" | "lines";`
- [web/components/memory/MemoryWorkbench.tsx:183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L183) — `export default function MemoryWorkbench({`
- [web/components/memory/MemoryWorkbench.tsx:191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L191) — `const [docKey, setDocKey] = useState<string>(initialKey || nav[0].key);`
- [web/components/memory/MemoryWorkbench.tsx:197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L197) — `const [overview, setOverview] = useState<Record<string, DocOverview>>({});`
- [web/components/memory/MemoryWorkbench.tsx:198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L198) — `const [content, setContent] = useState("");`
- [web/components/memory/MemoryWorkbench.tsx:199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L199) — `const [lines, setLines] = useState<LineRowDTO[]>([]);`
- [web/components/memory/MemoryWorkbench.tsx:200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L200) — `const [view, setView] = useState<ViewMode>("plain");`
- [web/components/memory/MemoryWorkbench.tsx:201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L201) — `const [editing, setEditing] = useState(false);`


## S60 — Memory graph

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /memory/graph

**Parent layout:** utility

**Entry points:** Memory navigation

**Purpose:** Memory relationship graph and source-specific graph controls

**Visible sections:** Memory relationship graph and source-specific graph controls

**User actions:** Inspect/select graph items and their references

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — graph loading state in owner

**Empty state:** UNVERIFIED — empty graph needs runtime

**Error state:** UNVERIFIED — graph runtime errors need execution

**Success / completed state:** VERIFIED — graph nodes/edges rendered

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Full-screen pan/zoom surface and accessible selected-node detail; prove graph library/rendering compatibility first.

**Source components:** [`web/app/(utility)/memory/graph/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/graph/page.tsx), [`web/components/memory/MemoryGraph.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx)

**Reusable components:** ArrowLeft; Controls; EdgePath; Eye; EyeOff; GraphView; HTMLDivElement; Header; HoverCard; HoverState; IconButton; Layer; Legend; Link; Loader2; Maximize2; MemoryGraph; NodeDot; Record; RefreshCw; SetStateAction; Tooltip; ViewState; ZoomIn; ZoomOut

**Source evidence:**

- [web/app/(utility)/memory/graph/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/graph/page.tsx#L5) — `export default function MemoryGraphPage() {`
- [web/components/memory/MemoryGraph.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L9) — `useState,`
- [web/components/memory/MemoryGraph.tsx:70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L70) — `export default function MemoryGraph() {`
- [web/components/memory/MemoryGraph.tsx:72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L72) — `const [graph, setGraph] = useState<MemoryGraph | null>(null);`
- [web/components/memory/MemoryGraph.tsx:73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L73) — `const [loading, setLoading] = useState(true);`
- [web/components/memory/MemoryGraph.tsx:74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L74) — `const [layerOn, setLayerOn] = useState<Record<Layer, boolean>>({`
- [web/components/memory/MemoryGraph.tsx:79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L79) — `const [hover, setHover] = useState<HoverState | null>(null);`
- [web/components/memory/MemoryGraph.tsx:80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L80) — `const [selected, setSelected] = useState<string | null>(null);`
- [web/components/memory/MemoryGraph.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L81) — `const [view, setView] = useState<ViewState>(INITIAL_VIEW);`
- [web/components/memory/MemoryGraph.tsx:266](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L266) — `{loading && (`


## S61 — Memory reference resolver

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Nonvisual logic

**Web route:** /memory/resolve

**Parent layout:** utility

**Entry points:** Memory footnote

**Purpose:** Resolve memory footnote IDs to workbench destination

**Visible sections:** Resolve memory footnote IDs to workbench destination

**User actions:** Resolve/navigate; recover from missing ID/failure

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — resolver busy/spinner

**Empty state:** VERIFIED — missing ?id= in URL

**Error state:** VERIFIED — Resolver failed

**Success / completed state:** VERIFIED — redirects to resolved layer/surface

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Resolve to existing mobile layer route and preserve validation/error behavior.

**Source components:** [`web/app/(utility)/memory/resolve/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/resolve/page.tsx)

**Reusable components:** Link; Loader2; ResolveInner; Suspense; ULID

**Source evidence:**

- [web/app/(utility)/memory/resolve/page.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/resolve/page.tsx#L10) — `import { Suspense, useEffect, useState } from "react";`
- [web/app/(utility)/memory/resolve/page.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/resolve/page.tsx#L27) — `const [error, setError] = useState<string | null>(null);`
- [web/app/(utility)/memory/resolve/page.tsx:93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/resolve/page.tsx#L93) — `export default function MemoryResolvePage() {`


## S62 — Learning notebook / Co-Writer library

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /co-writer

**Parent layout:** workspace

**Entry points:** Home shelf > Co-Writer; source calls heading Learning notebook

**Purpose:** Hierarchical note pages

**Visible sections:** Hierarchical note pages; pinned/recent cards; search; Word import; review entry

**User actions:** Create/open; import Word; pin/unpin; delete; search all pages

**Modals / dialogs / drawers / sheets:** Per-card actions and inline destructive confirmation; NoteReview

**Loading state:** VERIFIED — six-card loading skeleton

**Empty state:** VERIFIED — Your notebook is empty / no matching pages

**Error state:** VERIFIED — load/create/import/pin/delete error

**Success / completed state:** VERIFIED — new/imported page navigates to detail

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain hierarchy, pinned and recent grouping; distinguish Favorites at /notebooks from editable learning notes here.

**Source components:** [`web/app/(workspace)/co-writer/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx), [`web/features/notes/components/NoteReview.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx)

**Reusable components:** Card; FeaturePage; FileDown; FileText; HTMLDivElement; HTMLInputElement; Layers; Link; Loader2; MoreHorizontal; NoteReview; NoteSummary; PageCard; PageHeader; PickerShell; Pin; PinOff; Plus; Search; Trash2; Upload

**Source evidence:**

- [web/app/(workspace)/co-writer/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L5) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/app/(workspace)/co-writer/page.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L54) — `const [open, setOpenState] = useState(false);`
- [web/app/(workspace)/co-writer/page.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L55) — `const [confirming, setConfirming] = useState(false);`
- [web/app/(workspace)/co-writer/page.tsx:144](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L144) — `export default function CoWriterHomePage() {`
- [web/app/(workspace)/co-writer/page.tsx:147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L147) — `const [pages, setPages] = useState<NoteSummary[]>([]);`
- [web/app/(workspace)/co-writer/page.tsx:148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L148) — `const [loading, setLoading] = useState(true);`
- [web/app/(workspace)/co-writer/page.tsx:149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L149) — `const [creating, setCreating] = useState(false);`
- [web/app/(workspace)/co-writer/page.tsx:150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L150) — `const [importing, setImporting] = useState(false);`
- [web/app/(workspace)/co-writer/page.tsx:151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L151) — `const [busyId, setBusyId] = useState<string | null>(null);`
- [web/app/(workspace)/co-writer/page.tsx:152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L152) — `const [query, setQuery] = useState("");`


## S63 — Learning notebook editor

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /co-writer/[docId]

**Parent layout:** workspace

**Entry points:** Note card/new page; /co-writer/[docId]

**Purpose:** Page tree

**Visible sections:** Page tree; outline; rich blocks; title/icon/cover; linked-from pages; source/favorites pickers; Dito companion; AI suggestions/reviews

**User actions:** Edit/save; insert/reorder blocks; select sources; accept/reject supported suggestions; manage subpages/references; review

**Modals / dialogs / drawers / sheets:** Source picker; favorites picker; page tree; companion and review margin; recovery controls

**Loading state:** VERIFIED — note load and saving status

**Empty state:** VERIFIED — new blank note content

**Error state:** VERIFIED — save conflict/recovery and per-review errors

**Success / completed state:** VERIFIED — Saved status and revised page

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Rich editor is a fidelity spike: BlockNote is DOM-based. Use an isolated embedded editor candidate with explicit message bridge, or prove a native block editor preserves schema/selection/undo. Legacy features/co-writer/CoWriterWorkspace is not the route owner.

**Source components:** [`web/app/(workspace)/co-writer/[docId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/[docId]/page.tsx), [`web/features/notes/components/NoteWorkspace.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx), [`web/features/notes/components/NoteEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx), [`web/features/notes/components/NoteCompanion.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx), [`web/features/notes/components/NoteInsertMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInsertMenu.tsx), [`web/features/notes/components/NoteSourcePicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx)

**Reusable components:** ArrowDown; ArrowUp; ArrowUpRight; BlockIcon; BlockNoteViewRaw; ChatMessageList; ChatViewerBridges; Check; ChevronDown; Companion; Copy; CornerDownLeft; Editor; EmbeddedNotice; FavoritesPicker; FileText; FormattingToolbarController; GripVertical; HTMLAnchorElement; HTMLDivElement; HTMLElement; HTMLInputElement; HTMLTextAreaElement; Handles; Icon; LLMOption; LLMSelection; LearningContent; Link; LinkIcon; ListTree; Markdown; MessagesSquare; ModelSelector; NoteBlockPreview; NoteCompanionProps; NoteEditorHandle; NoteFavoriteBlock; NoteInlineReviews; NoteMath; NoteMenuItem; NoteOutline; NotePage; NotePageHead; NotePageTree; NoteSaveStatus; NoteSuggestion; NoteSummary; NoteThreadMarkers; NoteTopBar; NoteWorkspace; PickerShell; Plus; Promise; Record; RefreshCcw; ReturnType; RoughActionButton; Search; SessionViewerPanel; SessionViewerPanelHandle; SideMenuController; SourcePicker; Sparkles; Square; SuggestionMenuController; ThreadComposer; ThreadPanel; ThreadSwitcher; Tooltip; Trash2; WandSparkles

**Source evidence:**

- [web/app/(workspace)/co-writer/[docId]/page.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/[docId]/page.tsx#L10) — `export default function CoWriterPage() {`
- [web/features/notes/components/NoteWorkspace.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L4) — `import { useCallback, useEffect, useRef, useState, type ComponentType } from 'react'`
- [web/features/notes/components/NoteWorkspace.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L46) — `export default function NoteWorkspace({`
- [web/features/notes/components/NoteWorkspace.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L59) — `auth.statusAvailable && !auth.loading ? (auth.enabled ? auth.userId : 'local') : null`
- [web/features/notes/components/NoteWorkspace.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L60) — `const [mutating, setMutating] = useState(false)`
- [web/features/notes/components/NoteWorkspace.tsx:61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L61) — `const [page, setPage] = useState<NotePage | null>(null)`
- [web/features/notes/components/NoteWorkspace.tsx:62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L62) — `const [pages, setPages] = useState<NoteSummary[]>([])`
- [web/features/notes/components/NoteWorkspace.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L63) — `const [error, setError] = useState('')`
- [web/features/notes/components/NoteWorkspace.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L64) — `const [reviewErrors, setReviewErrors] = useState<Record<string, string>>({})`
- [web/features/notes/components/NoteWorkspace.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L65) — `const [status, setStatus] = useState<NoteSaveStatus>('Saved')`


## S64 — Task Board

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /kanban

**Parent layout:** workspace

**Entry points:** Home shelf > Task Board; linked task controls

**Purpose:** Task columns

**Visible sections:** Task columns; quick add; edit title/note/due date/color; date filters; archived tasks

**User actions:** Create/edit; move status; archive/restore/delete available tasks; link to chat

**Modals / dialogs / drawers / sheets:** Inline task editor; date/color controls

**Loading state:** VERIFIED — board load and action busy

**Empty state:** VERIFIED — empty column/board prompts in source

**Error state:** VERIFIED — loadError and action error

**Success / completed state:** VERIFIED — updated task columns

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Show horizontally pageable columns or a status-filtered list with the same statuses; provide explicit Move action as equivalent to web drag/drop. Preserve server task identity.

**Source components:** [`web/app/(workspace)/kanban/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/kanban/page.tsx), [`web/features/tasks/components/KanbanBoard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx), [`web/components/tasks/TaskBoardRuntime.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskBoardRuntime.tsx), [`web/components/tasks/TaskLinkSelector.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskLinkSelector.tsx)

**Reusable components:** Archive; ArrowLeft; ArrowRight; Check; FeaturePage; Link; Plus; RotateCcw; SpaceSectionHeader; TaskBoard; TaskColorPicker; TaskStatus; Tooltip

**Source evidence:**

- [web/app/(workspace)/kanban/page.tsx:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/kanban/page.tsx#L1) — `export { default } from '@/features/tasks/components/KanbanBoard'`
- [web/features/tasks/components/KanbanBoard.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L8) — `import { useRef, useState } from 'react'`
- [web/features/tasks/components/KanbanBoard.tsx:45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L45) — `export default function KanbanBoard() {`
- [web/features/tasks/components/KanbanBoard.tsx:49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L49) — `const [title, setTitle] = useState('')`
- [web/features/tasks/components/KanbanBoard.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L50) — `const [editing, setEditing] = useState<string | null>(null)`
- [web/features/tasks/components/KanbanBoard.tsx:51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L51) — `const [draftTitle, setDraftTitle] = useState('')`
- [web/features/tasks/components/KanbanBoard.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L52) — `const [draftNote, setDraftNote] = useState('')`
- [web/features/tasks/components/KanbanBoard.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L53) — `const [dueDate, setDueDate] = useState('')`
- [web/features/tasks/components/KanbanBoard.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L54) — `const [dateFilter, setDateFilter] = useState('all')`
- [web/features/tasks/components/KanbanBoard.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L55) — `const [busy, setBusy] = useState(false)`


## S65 — Calendar

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /calendar

**Parent layout:** workspace

**Entry points:** Home shelf > Calendar

**Purpose:** Day/week/month/agenda views

**Visible sections:** Day/week/month/agenda views; mini month; layer toggles; search; item details; event editor; recurrence/reminders

**User actions:** Navigate dates; change view/layers; search; create/edit/move/delete; choose recurrence scope; undo; import/export supported actions

**Modals / dialogs / drawers / sheets:** Anchored item popover; event editor; recurring-edit scope control

**Loading state:** VERIFIED — load/search/action busy

**Empty state:** VERIFIED — agenda/no-event branches in owner

**Error state:** VERIFIED — page/editor error; notification unsupported/permission states

**Success / completed state:** VERIFIED — event saved/undo feedback

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Start with source Month and Agenda patterns on phone; preserve Day/Week as parity work. Browser notifications do not establish native reminder/background guarantees; validate before promising Android scheduling.

**Source components:** [`web/app/(workspace)/calendar/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/calendar/page.tsx), [`web/features/calendar/components/CalendarPage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx), [`web/features/calendar/components/EventEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx), [`web/features/calendar/components/ItemDetails.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx), [`web/features/calendar/components/CalendarRail.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx)

**Reusable components:** AgendaView; AlignLeft; AnchoredPopover; ArrowUpRight; AutomationDetails; Bell; BellOff; CalendarEntry; CalendarRail; CalendarRow; Check; CircleCheck; CircleDashed; Clock; Download; EditScope; EventDetails; EventDraft; EventEditor; FootprintDetails; GripVertical; HTMLInputElement; HTMLLIElement; Head; HeaderActionButton; Icon; LayerRow; LayerToggles; Link; MapPin; MessageSquare; MiniMonth; MonthView; MoreHorizontal; NewCalendar; NotificationPermission; PageBarSlot; PageHeader; Panel; Pick; Plus; Repeat2; RepeatPreset; ReviewDetails; Row; ScopeSelect; Search; SearchResults; Swatch; TaskDetails; TimeGrid; Tooltip; Trash2; View

**Source evidence:**

- [web/app/(workspace)/calendar/page.tsx:1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/calendar/page.tsx#L1) — `export { default } from '@/features/calendar/components/CalendarPage'`
- [web/features/calendar/components/CalendarPage.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L4) — `import { useEffect, useMemo, useRef, useState } from 'react'`
- [web/features/calendar/components/CalendarPage.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L66) — `type View = 'day' | 'week' | 'month' | 'agenda'`
- [web/features/calendar/components/CalendarPage.tsx:77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L77) — `export default function CalendarPage() {`
- [web/features/calendar/components/CalendarPage.tsx:86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L86) — `const [cursor, setCursor] = useState(() => new Date())`
- [web/features/calendar/components/CalendarPage.tsx:87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L87) — `const [view, setView] = useState<View>('month')`
- [web/features/calendar/components/CalendarPage.tsx:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L88) — `const [now, setNow] = useState(() => new Date())`
- [web/features/calendar/components/CalendarPage.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L89) — `const [toggles, setToggles] = useState<LayerToggles>(DEFAULT_LAYERS)`
- [web/features/calendar/components/CalendarPage.tsx:90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L90) — `const [rail, setRail] = useState(true)`
- [web/features/calendar/components/CalendarPage.tsx:91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L91) — `const [panel, setPanel] = useState<Panel | null>(null)`


## S66 — Partners directory

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /partners

**Parent layout:** workspace

**Entry points:** Partners account shelf

**Purpose:** Partners and groups in one roster

**Visible sections:** Partners and groups in one roster; avatars; channel/runtime summaries

**User actions:** Open partner/group; create partner/group

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — list loading

**Empty state:** VERIFIED — initial no-partner directory state

**Error state:** UNVERIFIED — list load failure may collapse to empty; verify runtime

**Success / completed state:** VERIFIED — partner/group roster

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(workspace)/partners/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx)

**Reusable components:** ChannelIcon; FeaturePage; HeartHandshake; Link; Loader2; PageHeader; PartnerAvatar; PartnerGroup; PartnerInfo; Plus; Users

**Source evidence:**

- [web/app/(workspace)/partners/page.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L12) — `import { useEffect, useState } from "react";`
- [web/app/(workspace)/partners/page.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L32) — `export default function PartnersPage() {`
- [web/app/(workspace)/partners/page.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L38) — `const [partners, setPartners] = useState<PartnerInfo[]>([]);`
- [web/app/(workspace)/partners/page.tsx:39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L39) — `const [groups, setGroups] = useState<PartnerGroup[]>([]);`
- [web/app/(workspace)/partners/page.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L40) — `const [loading, setLoading] = useState(true);`
- [web/app/(workspace)/partners/page.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L81) — `title={t("Partners")}`
- [web/app/(workspace)/partners/page.tsx:96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L96) — `{loading ? (`
- [web/app/(workspace)/partners/page.tsx:100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L100) — `) : partners.length === 0 ? (`
- [web/app/(workspace)/partners/page.tsx:188](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L188) — `{!loading && partners.length > 0 ? (`
- [web/app/(workspace)/partners/page.tsx:192](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L192) — `title={t("Groups")}`


## S67 — Create partner

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /partners/new

**Parent layout:** workspace

**Entry points:** Partners > new partner

**Purpose:** Five steps Identity → Soul → Mind → Library → Review

**Visible sections:** Five steps Identity → Soul → Mind → Library → Review; name/face/language; models/tools; workspace/assets

**User actions:** Complete steps; choose primary/backup model; select assets/tools; create

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — model/tools fetch and creating

**Empty state:** VERIFIED — initial wizard inputs

**Error state:** VERIFIED — model load and creation error

**Success / completed state:** VERIFIED — opens created partner

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve five steps and validation; channels are connected after creation, not invented as another wizard step.

**Source components:** [`web/app/(workspace)/partners/new/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx), [`web/components/partners/FaceEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/FaceEditor.tsx), [`web/components/partners/SoulPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx), [`web/components/partners/PartnerModelPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelPicker.tsx), [`web/components/partners/ToolPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ToolPicker.tsx), [`web/components/partners/AssetPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx)

**Reusable components:** ArrowLeft; ArrowRight; AssetPicker; AssetSelection; Check; ChipGroup; FaceEditor; FaceValue; HTMLInputElement; Icon; ImagePlus; LLMOption; LLMSelection; Link; Loader2; McpToolGroups; Option; PageContainer; PageHeader; PartnerAvatar; PartnerModelPicker; PartnerModelSelect; PartnerReplyLanguageSelect; PartnerWorkspacePicker; Row; Save; SoulEditor; SoulPicker; SoulSources; SoulSpec; SourceTab; Sparkles; StepKey; ToggleRow; ToolOptions; ToolPicker; Tooltip

**Source evidence:**

- [web/app/(workspace)/partners/new/page.tsx:11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L11) — `import { useEffect, useMemo, useState } from "react";`
- [web/app/(workspace)/partners/new/page.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L42) — `export default function NewPartnerPage() {`
- [web/app/(workspace)/partners/new/page.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L53) — `const [stepIndex, setStepIndex] = useState(0);`
- [web/app/(workspace)/partners/new/page.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L57) — `const [name, setName] = useState("");`
- [web/app/(workspace)/partners/new/page.tsx:58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L58) — `const [description, setDescription] = useState("");`
- [web/app/(workspace)/partners/new/page.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L59) — `const [face, setFace] = useState<FaceValue>({`
- [web/app/(workspace)/partners/new/page.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L64) — `const [language, setLanguage] = useState("");`
- [web/app/(workspace)/partners/new/page.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L65) — `const [soul, setSoul] = useState<SoulSpec>({ source: "default" });`
- [web/app/(workspace)/partners/new/page.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L66) — `const [selection, setSelection] = useState<LLMSelection | null>(null);`
- [web/app/(workspace)/partners/new/page.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L67) — `const [backupSelection, setBackupSelection] = useState<LLMSelection | null>(`


## S68 — Partner detail / chat

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /partners/[partnerId]

**Parent layout:** workspace

**Entry points:** Partner roster or history

**Purpose:** Identity/run state

**Visible sections:** Identity/run state; Chat, Configure, Channels and archives-related content; chat continuity/session controls

**User actions:** Chat; select session; configure; connect channel; lifecycle actions; archive/export/save/link/delete where offered

**Modals / dialogs / drawers / sheets:** PartnerLinkModal; channel onboarding; SaveToNotebookModal

**Loading state:** VERIFIED — partner/auth/continuity resolving

**Empty state:** VERIFIED — partner unavailable and empty chat states

**Error state:** VERIFIED — continuity blocks, runtime session error/retry

**Success / completed state:** VERIFIED — live/resumed partner chat and configured state

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Scrollable detail tabs and nested configuration/channel forms. Keep continuity readiness gate; do not silently start a different session after a failed restore.

**Source components:** [`web/app/(workspace)/partners/[partnerId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx), [`web/components/partners/PartnerChat.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx), [`web/components/partners/PartnerConfigure.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx), [`web/components/partners/PartnerChannels.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx), [`web/components/partners/PartnerArchives.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx)

**Reusable components:** Archive; ArrowLeft; AssetPicker; AssetSelection; AssistantActivity; AssistantResponse; AttachmentStrip; BookmarkPlus; ChannelIcon; ChannelOnboardingPanel; ChannelRuntimeStatus; ChannelsSchemaResponse; ChatMsg; Clock3; Download; ExportableMessage; ExternalDraft; FaceEditor; FaceValue; HTMLDivElement; HistoryMessage; Icon; InlineFileCard; InlineFileCardProvider; LLMOption; LLMSelection; Link; Link2; Loader2; MessageSquareText; MonitorSmartphone; NotebookSaveMessage; NotebookSavePayload; PageBarSlot; Paperclip; PartnerArchives; PartnerAssets; PartnerAvatar; PartnerChannels; PartnerChat; PartnerComposer; PartnerConfigure; PartnerCrumb; PartnerDetail; PartnerGeneratedFiles; PartnerInfo; PartnerLinkModal; PartnerModelSelect; PartnerReplyLanguageSelect; PartnerSessionInfo; PartnerWorkspacePicker; Play; Plus; ReconnectingWebSocket; Record; RefreshCw; RotateCcw; Save; SaveToNotebookModal; SchemaField; Section; Set; SoulEditor; Square; Suspense; Tab; ToolOptions; ToolPicker; Tooltip; Trash2; User; Users; WeixinQrLogin

**Source evidence:**

- [web/app/(workspace)/partners/[partnerId]/page.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L9) — `import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L63) — `type Tab = "chat" | "configure" | "channels" | "archive";`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L74) — `const [tab, setTab] = useState<Tab>(`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L79) — `const [partner, setPartner] = useState<PartnerInfo | null>(null);`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L80) — `const [showLinkModal, setShowLinkModal] = useState(false);`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L90) — `const [loading, setLoading] = useState(true);`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L91) — `const [lifecycleBusy, setLifecycleBusy] = useState(false);`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L92) — `const [toast, setToast] = useState("");`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L95) — `const [chatMessages, setChatMessages] = useState<ExportableMessage[]>([]);`
- [web/app/(workspace)/partners/[partnerId]/page.tsx:96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L96) — `const [archiveMessages, setArchiveMessages] = useState<ExportableMessage[]>(`


## S69 — Partner channel onboarding

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Tab

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Partner > Channels

**Purpose:** Schema-driven channel config

**Visible sections:** Schema-driven channel config; onboarding; Weixin QR login; runtime status

**User actions:** Enter channel settings; connect; inspect QR/status; stop/retry where supported

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — channel/QR lifecycle waiting

**Empty state:** UNVERIFIED — channel-dependent initial state

**Error state:** VERIFIED — runtime connection errors

**Success / completed state:** VERIFIED — connected channel/runtime state

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain provider-specific fields and QR lifecycle. Ability to complete same-device scanning must be verified; do not invent an alternate login capability.

**Source components:** [`web/components/partners/ChannelOnboardingPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx), [`web/components/partners/PartnerChannels.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx), [`web/components/partners/WeixinQrLogin.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx), [`web/components/partners/ChannelRuntimeStatus.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelRuntimeStatus.tsx)

**Reusable components:** AlertCircle; ChannelIcon; ChannelOnboardingPanel; ChannelRuntimeStatus; ChannelsSchemaResponse; CheckCircle2; ExternalLink; Loader2; PartnerChannelOnboardingSession; PartnerChannelRuntimeEntry; QrCode; Record; RefreshCw; Save; SchemaField; Set; TriangleAlert; WeixinQrLogin; WeixinQrSession; Wifi

**Source evidence:**

- [web/components/partners/ChannelOnboardingPanel.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L3) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/partners/ChannelOnboardingPanel.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L25) — `export default function ChannelOnboardingPanel({`
- [web/components/partners/ChannelOnboardingPanel.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L38) — `useState<PartnerChannelOnboardingSession | null>(null);`
- [web/components/partners/ChannelOnboardingPanel.tsx:39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L39) — `const [busy, setBusy] = useState(false);`
- [web/components/partners/ChannelOnboardingPanel.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L40) — `const [error, setError] = useState<string | null>(null);`
- [web/components/partners/ChannelOnboardingPanel.tsx:41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L41) — `const [nowMs, setNowMs] = useState(() => Date.now());`
- [web/components/partners/ChannelOnboardingPanel.tsx:225](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L225) — `{error && (`
- [web/components/partners/PartnerChannels.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L9) — `import { useCallback, useEffect, useState } from "react";`
- [web/components/partners/PartnerChannels.tsx:43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L43) — `export default function PartnerChannels({`
- [web/components/partners/PartnerChannels.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L52) — `useState<ChannelsSchemaResponse | null>(null);`


## S70 — Create partner group

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /partners/groups/new

**Parent layout:** workspace

**Entry points:** Partners > new group

**Purpose:** Name/description

**Visible sections:** Name/description; emoji/color; members; discussion mode

**User actions:** Select members/mode; create

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — member load and creating

**Empty state:** VERIFIED — no partners available state

**Error state:** VERIFIED — creation failure

**Success / completed state:** VERIFIED — group detail route

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve content and actions in a single scrolling view; move multi-column secondary detail into a separately opened panel. Enlarge touch targets and retain source action availability.

**Source components:** [`web/app/(workspace)/partners/groups/new/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx), [`web/components/partners/group/DiscussionModePicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx)

**Reusable components:** ArrowLeft; Check; DiscussionMode; DiscussionModePicker; FeaturePage; Link; Loader2; PageHeader; PartnerAvatar; PartnerInfo; Plus; Set; Users

**Source evidence:**

- [web/app/(workspace)/partners/groups/new/page.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L4) — `import { useEffect, useMemo, useState } from "react";`
- [web/app/(workspace)/partners/groups/new/page.tsx:17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L17) — `export default function NewPartnerGroupPage() {`
- [web/app/(workspace)/partners/groups/new/page.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L20) — `const [partners, setPartners] = useState<PartnerInfo[]>([]);`
- [web/app/(workspace)/partners/groups/new/page.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L21) — `const [loading, setLoading] = useState(true);`
- [web/app/(workspace)/partners/groups/new/page.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L22) — `const [name, setName] = useState("");`
- [web/app/(workspace)/partners/groups/new/page.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L23) — `const [description, setDescription] = useState("");`
- [web/app/(workspace)/partners/groups/new/page.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L24) — `const [selected, setSelected] = useState<Set<string>>(new Set());`
- [web/app/(workspace)/partners/groups/new/page.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L25) — `const [emoji, setEmoji] = useState("👥");`
- [web/app/(workspace)/partners/groups/new/page.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L28) — `const [color, setColor] = useState<string>(PARTNER_COLORS[0]);`
- [web/app/(workspace)/partners/groups/new/page.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L29) — `const [mode, setMode] = useState("panel_parallel");`


## S71 — Partner group discussion

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /partners/groups/[groupId]

**Parent layout:** workspace

**Entry points:** Group roster; session deep link

**Purpose:** Group chat

**Visible sections:** Group chat; rounds/member seats; discussion mode; session selector; side panel

**User actions:** Send; mention member; switch sessions; inspect round/invocation; export; edit/delete group

**Modals / dialogs / drawers / sheets:** Group editor; side panel; session picker; delete confirmation

**Loading state:** VERIFIED — group/member/session load

**Empty state:** VERIFIED — group unavailable and GroupEmptyState

**Error state:** VERIFIED — selectionError and group edit failures

**Success / completed state:** VERIFIED — completed round and session content

**Permissions:** Route requires llm access when authentication is enabled; learning policy and runtime capability/module checks also apply.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Full-width group transcript; member/session/details sheet; preserve mode and member-specific response attribution.

**Source components:** [`web/app/(workspace)/partners/groups/[groupId]/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx), [`web/components/partners/group/PartnerGroupChat.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx), [`web/components/partners/group/GroupSidePanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSidePanel.tsx), [`web/components/partners/group/GroupSessionPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSessionPicker.tsx)

**Reusable components:** AlertCircle; ArrowLeft; AssistantActivity; Check; ChevronDown; DiscussionModePicker; Download; Empty; GroupComposer; GroupEmptyState; GroupRound; GroupSessionPicker; GroupSidePanel; HTMLDivElement; HTMLElement; Link; Loader2; ManageGroupDialog; MessagesSquare; PanelRight; PanelTab; PartnerAvatar; PartnerGroup; PartnerGroupChat; PartnerGroupMessage; PartnerGroupSession; PartnerInfo; Pencil; Plus; QuotedSpeech; Set; TabButton; Tooltip; TraceFocus; Trash2; TurnNavigator; WhiteboardEntry

**Source evidence:**

- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L3) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L38) — `export default function PartnerGroupPage() {`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L44) — `const [selectionError, setSelectionError] = useState("");`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L47) — `const [group, setGroup] = useState<PartnerGroup | null>(null);`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L48) — `const [loading, setLoading] = useState(true);`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L49) — `const [editing, setEditing] = useState(false);`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L50) — `const [panelOpen, setPanelOpen] = useState(false);`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L51) — `const [sessionKey, setSessionKey] = useState("");`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L52) — `const [sessionTitle, setSessionTitle] = useState("");`
- [web/app/(workspace)/partners/groups/[groupId]/page.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L53) — `const [groupMessages, setGroupMessages] = useState<PartnerGroupMessage[]>([]);`


## S72 — Whisper practice room

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /whisper

**Parent layout:** workspace

**Entry points:** Conditional Resources > More Projects

**Purpose:** Optional dual-seat practice room

**Visible sections:** Optional dual-seat practice room; visitor/trainee seats; supervisor whisper; room and connection status

**User actions:** Choose seat; start/send; handle closed room and crisis state

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — connection and submit retry state

**Empty state:** VERIFIED — absent capability shows unavailable view

**Error state:** VERIFIED — room closed/stream error/disconnection unlock

**Success / completed state:** VERIFIED — live room dialogue

**Permissions:** Only offered when out-of-tree whisper_visitor capability is reported available; stock repository does not supply that plugin.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Inventory conditional feature; do not include in stock mobile MVP or imply backend capability is bundled.

**Source components:** [`web/app/(workspace)/whisper/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx), [`web/components/whisper/WhisperMessageList.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/whisper/WhisperMessageList.tsx), [`web/components/whisper/WhisperComposer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/whisper/WhisperComposer.tsx)

**Reusable components:** Ear; HTMLDivElement; HTMLTextAreaElement; Loader2; Lock; MarkdownRenderer; Record; ReturnType; Send; Set; UnifiedTurnClient; WhisperComposer; WhisperMessage; WhisperMessageList; WhisperRoomChip; WhisperSeat

**Source evidence:**

- [web/app/(workspace)/whisper/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L3) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/app/(workspace)/whisper/page.tsx:39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L39) — `export default function WhisperPage() {`
- [web/app/(workspace)/whisper/page.tsx:41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L41) — `const [seat, setSeat] = useState<WhisperSeat>("visitor");`
- [web/app/(workspace)/whisper/page.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L42) — `const [roomId, setRoomId] = useState<string | null>(null);`
- [web/app/(workspace)/whisper/page.tsx:43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L43) — `const [messages, setMessages] = useState<WhisperMessage[]>([]);`
- [web/app/(workspace)/whisper/page.tsx:44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L44) — `const [busy, setBusy] = useState(false);`
- [web/app/(workspace)/whisper/page.tsx:45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L45) — `const [crisisHit, setCrisisHit] = useState(false);`
- [web/app/(workspace)/whisper/page.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L46) — `const [roomClosed, setRoomClosed] = useState(false);`
- [web/app/(workspace)/whisper/page.tsx:47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L47) — `const [draft, setDraft] = useState("");`
- [web/app/(workspace)/whisper/page.tsx:48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L48) — `const [dtSessionId, setDtSessionId] = useState<string | null>(null);`


## S73 — Login

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /login

**Parent layout:** auth

**Entry points:** Auth redirect; logout; registration success

**Purpose:** Email or username label

**Visible sections:** Email or username label; password; registration and preserved return path

**User actions:** Sign in; register

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — auth/first-user checks and Signing in…

**Empty state:** VERIFIED — initial empty fields

**Error state:** VERIFIED — Login failed response

**Success / completed state:** VERIFIED — redirects to normalized intended route

**Permissions:** Respect deployment auth.enabled; first user can be directed to registration.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve the visible Email or username label and username request field; do not invent social login. Keep normalized return URL and cookie/session contract; mobile persistence needs proof.

**Source components:** [`web/app/(auth)/login/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx), [`web/lib/auth.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/auth.ts)

**Reusable components:** AuthStatus; Link; LoginPageContent; Suspense

**Source evidence:**

- [web/app/(auth)/login/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L3) — `import { Suspense, useCallback, useState, useEffect } from "react";`
- [web/app/(auth)/login/page.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L29) — `const [username, setUsername] = useState("");`
- [web/app/(auth)/login/page.tsx:30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L30) — `const [password, setPassword] = useState("");`
- [web/app/(auth)/login/page.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L31) — `const [error, setError] = useState("");`
- [web/app/(auth)/login/page.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L32) — `const [loading, setLoading] = useState(false);`
- [web/app/(auth)/login/page.tsx:62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L62) — `setError(result.error ?? t("Login failed"));`
- [web/app/(auth)/login/page.tsx:71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L71) — `<h1 className="font-serif text-2xl font-semibold text-[var(--foreground)] tracking-tight">`
- [web/app/(auth)/login/page.tsx:138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L138) — `{error && (`
- [web/app/(auth)/login/page.tsx:154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L154) — `{loading ? t("Signing in…") : t("Sign in")}`
- [web/app/(auth)/login/page.tsx:176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L176) — `export default function LoginPage() {`


## S74 — Registration

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /register

**Parent layout:** auth

**Entry points:** Login; first-user setup

**Purpose:** Email or username label

**Visible sections:** Email or username label; password/confirmation; first-user status and server registration policy

**User actions:** Create account; sign in

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — checkingFirst and Creating account…

**Empty state:** VERIFIED — blank form

**Error state:** VERIFIED — mismatch and server registration failure

**Success / completed state:** VERIFIED — /login?registered=1

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain first-user/admin bootstrap messaging and policy. Do not invent OAuth, forgot-password or email verification screens.

**Source components:** [`web/app/(auth)/register/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx)

**Reusable components:** Link

**Source evidence:**

- [web/app/(auth)/register/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L3) — `import { useState, useEffect } from "react";`
- [web/app/(auth)/register/page.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L9) — `export default function RegisterPage() {`
- [web/app/(auth)/register/page.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L13) — `const [username, setUsername] = useState("");`
- [web/app/(auth)/register/page.tsx:14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L14) — `const [password, setPassword] = useState("");`
- [web/app/(auth)/register/page.tsx:15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L15) — `const [confirmPassword, setConfirmPassword] = useState("");`
- [web/app/(auth)/register/page.tsx:16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L16) — `const [error, setError] = useState("");`
- [web/app/(auth)/register/page.tsx:17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L17) — `const [loading, setLoading] = useState(false);`
- [web/app/(auth)/register/page.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L18) — `const [isFirst, setIsFirst] = useState(false);`
- [web/app/(auth)/register/page.tsx:19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L19) — `const [checkingFirst, setCheckingFirst] = useState(true);`
- [web/app/(auth)/register/page.tsx:49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L49) — `setError(result.error ?? t("Registration failed"));`


## S75 — Profile

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /profile

**Parent layout:** utility

**Entry points:** Account menu

**Purpose:** Account identity/role

**Visible sections:** Account identity/role; avatar selection/upload/remove; password change; session/account utilities

**User actions:** Update avatar; change password; logout; open authorized account utilities

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — profile load; avatar/password busy

**Empty state:** UNVERIFIED — no-profile fallback depends on auth

**Error state:** VERIFIED — image size/decode; wrong current password; min length/mismatch

**Success / completed state:** VERIFIED — password notice and updated profile

**Permissions:** Redirects if auth disabled/unauthenticated; role-specific controls.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Native image selection for existing avatar action, maintaining server validation; no invented profile fields.

**Source components:** [`web/app/(utility)/profile/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx)

**Reusable components:** ArrowLeft; Blob; FeaturePage; HTMLImageElement; HTMLInputElement; ImageUp; KeyRound; Link; Lock; LogOut; PageHeader; ProfileInfo; ShieldCheck; Trash2; UserAvatar

**Source evidence:**

- [web/app/(utility)/profile/page.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L4) — `import { useCallback, useEffect, useRef, useState } from "react";`
- [web/app/(utility)/profile/page.tsx:100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L100) — `export default function ProfilePage() {`
- [web/app/(utility)/profile/page.tsx:103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L103) — `const [profile, setProfile] = useState<ProfileInfo | null>(null);`
- [web/app/(utility)/profile/page.tsx:104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L104) — `const [loading, setLoading] = useState(true);`
- [web/app/(utility)/profile/page.tsx:105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L105) — `const [busy, setBusy] = useState(false);`
- [web/app/(utility)/profile/page.tsx:106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L106) — `const [error, setError] = useState<string | null>(null);`
- [web/app/(utility)/profile/page.tsx:109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L109) — `const [currentPassword, setCurrentPassword] = useState("");`
- [web/app/(utility)/profile/page.tsx:110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L110) — `const [newPassword, setNewPassword] = useState("");`
- [web/app/(utility)/profile/page.tsx:111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L111) — `const [confirmPassword, setConfirmPassword] = useState("");`
- [web/app/(utility)/profile/page.tsx:112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L112) — `const [passwordBusy, setPasswordBusy] = useState(false);`


## S76 — User administration

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /admin/users

**Parent layout:** admin

**Entry points:** AdminLink/account menu

**Purpose:** Users table/search/bulk selection

**Visible sections:** Users table/search/bulk selection; expanded permissions/profile/guardian/book grants; create; CSV import result

**User actions:** Create/import; edit grants; reset/delete supported user actions; bulk delete

**Modals / dialogs / drawers / sheets:** Create/import dialogs; destructive single/batch confirmation

**Loading state:** VERIFIED — users load and operation busy

**Empty state:** VERIFIED — filtered/empty table cases need exact runtime copy

**Error state:** VERIFIED — load/action/create/import error fields

**Success / completed state:** VERIFIED — per-row import results and refreshed users

**Permissions:** Checks authenticated admin; redirects ordinary users and unauthenticated users.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Defer from learner MVP, retain complete parity backlog. User detail becomes nested route; CSV import and grant editing keep exact server contracts.

**Source components:** [`web/app/(admin)/admin/users/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx), [`web/features/multi-user/components/GrantEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx), [`web/features/multi-user/components/BookPermissionEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx), [`web/features/multi-user/components/LearnerProfileEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/LearnerProfileEditor.tsx), [`web/features/multi-user/components/GuardianRelationshipsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx)

**Reusable components:** AccountPreset; AdminBook; AlertCircle; ArrowLeft; BookOpen; BookPermission; BookPermissionEditor; Check; CheckCircle2; CheckRow; ConfirmDialog; File; Fragment; GraduationCap; GrantEditor; GrantPayload; GuardianRelationship; GuardianRelationshipsEditor; GuardianReport; KeyRound; LearnerProfile; LearnerProfileEditor; Link; Loader2; McpToolGroups; ModeSwitch; MultiUserResources; RefreshCw; Save; SaveState; Search; SectionTitle; Shield; ShieldCheck; ShieldOff; SlidersHorizontal; Tooltip; Trash2; Upload; UserAvatar; UserImportResult; UserPlus; UserRecord; Users

**Source evidence:**

- [web/app/(admin)/admin/users/page.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L4) — `import { Fragment, useEffect, useState, useCallback } from "react";`
- [web/app/(admin)/admin/users/page.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L56) — `export default function AdminUsersPage() {`
- [web/app/(admin)/admin/users/page.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L60) — `const [currentUser, setCurrentUser] = useState<string | null>(null);`
- [web/app/(admin)/admin/users/page.tsx:61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L61) — `const [users, setUsers] = useState<UserRecord[]>([]);`
- [web/app/(admin)/admin/users/page.tsx:62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L62) — `const [loading, setLoading] = useState(true);`
- [web/app/(admin)/admin/users/page.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L63) — `const [error, setError] = useState("");`
- [web/app/(admin)/admin/users/page.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L64) — `const [actionError, setActionError] = useState("");`
- [web/app/(admin)/admin/users/page.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L65) — `const [expandedUserId, setExpandedUserId] = useState<string | null>(null);`
- [web/app/(admin)/admin/users/page.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L66) — `const [showCreateDialog, setShowCreateDialog] = useState(false);`
- [web/app/(admin)/admin/users/page.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L67) — `const [showImportDialog, setShowImportDialog] = useState(false);`


## S77 — Session handoff link creation

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /session-handoff

**Parent layout:** utility

**Entry points:** Account/session utilities

**Purpose:** Public origin

**Visible sections:** Public origin; temporary session handoff code/link

**User actions:** Create/copy handoff; inspect expiry

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — generation busy

**Empty state:** VERIFIED — no handoff before create

**Error state:** VERIFIED — generation/copy errors

**Success / completed state:** VERIFIED — generated handoff details

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Security-sensitive account utility; preserve expiry/one-use constraints as established by server, without treating it as generic share-chat.

**Source components:** [`web/app/(utility)/session-handoff/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx)

**Reusable components:** ArrowLeft; ClipboardCopy; KeyRound; Link; Link2; SessionHandoff

**Source evidence:**

- [web/app/(utility)/session-handoff/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L3) — `import { useCallback, useEffect, useState } from "react";`
- [web/app/(utility)/session-handoff/page.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L12) — `export default function SessionHandoffPage() {`
- [web/app/(utility)/session-handoff/page.tsx:15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L15) — `const [publicOrigin, setPublicOrigin] = useState("https://");`
- [web/app/(utility)/session-handoff/page.tsx:16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L16) — `const [handoff, setHandoff] = useState<SessionHandoff | null>(null);`
- [web/app/(utility)/session-handoff/page.tsx:17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L17) — `const [loading, setLoading] = useState(false);`
- [web/app/(utility)/session-handoff/page.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L18) — `const [error, setError] = useState("");`
- [web/app/(utility)/session-handoff/page.tsx:19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L19) — `const [copied, setCopied] = useState(false);`
- [web/app/(utility)/session-handoff/page.tsx:69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L69) — `<h1 className="text-lg font-semibold text-[var(--foreground)]">`
- [web/app/(utility)/session-handoff/page.tsx:102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L102) — `{loading ? t("Creating…") : t("Create link")}`
- [web/app/(utility)/session-handoff/page.tsx:106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L106) — `{error && (`


## S78 — Session handoff redemption

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /handoff

**Parent layout:** host surface

**Entry points:** Handoff URL or manual code

**Purpose:** Handoff URL/code input

**Visible sections:** Handoff URL/code input; idle/working/error

**User actions:** Redeem code; continue to normalized destination

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — working state

**Empty state:** VERIFIED — manual code entry

**Error state:** VERIFIED — redemption error

**Success / completed state:** VERIFIED — router replace after successful redemption

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Deep-link entry must be distinct from conversation sharing and validate internal return paths.

**Source components:** [`web/app/handoff/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx)

**Reusable components:** HandoffPageContent; KeyRound; Suspense

**Source evidence:**

- [web/app/handoff/page.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L3) — `import { Suspense, useCallback, useEffect, useRef, useState } from "react";`
- [web/app/handoff/page.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L18) — `const [manualCode, setManualCode] = useState("");`
- [web/app/handoff/page.tsx:19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L19) — `const [status, setStatus] = useState<"idle" | "working" | "error">("idle");`
- [web/app/handoff/page.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L20) — `const [error, setError] = useState("");`
- [web/app/handoff/page.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L57) — `<h1 className="text-lg font-semibold text-[var(--foreground)]">`
- [web/app/handoff/page.tsx:105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L105) — `export default function HandoffPage() {`


## S79 — Learning progress

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/progress

**Parent layout:** utility

**Entry points:** Settings > Learning progress

**Purpose:** Reading progress and recent learning actions

**Visible sections:** Reading progress and recent learning actions

**User actions:** Inspect activity/progress

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** VERIFIED — progress load state

**Empty state:** VERIFIED — No learning activity yet; No reading progress yet; No learning actions yet

**Error state:** VERIFIED — page error state in source

**Success / completed state:** VERIFIED — recorded reading/activity summary

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Preserve measured progress and recent actions; do not invent weekly mastery dashboards from the mobile translation file.

**Source components:** [`web/app/(utility)/settings/progress/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx)

**Reusable components:** FeaturePage; LearningRecords; PageHeader; Record

**Source evidence:**

- [web/app/(utility)/settings/progress/page.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L4) — `import { useEffect, useState } from "react";`
- [web/app/(utility)/settings/progress/page.tsx:17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L17) — `export default function LearningProgressPage() {`
- [web/app/(utility)/settings/progress/page.tsx:19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L19) — `const [records, setRecords] = useState<LearningRecords | null>(null);`
- [web/app/(utility)/settings/progress/page.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L20) — `const [materialTitles, setMaterialTitles] = useState<Record<string, string>>({});`
- [web/app/(utility)/settings/progress/page.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L21) — `const [error, setError] = useState(false);`
- [web/app/(utility)/settings/progress/page.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L42) — `<PageHeader title={t("Learning progress")} description={t("Review your own reading and learning activity.")} />`
- [web/app/(utility)/settings/progress/page.tsx:43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L43) — `{error ? (`
- [web/app/(utility)/settings/progress/page.tsx:62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L62) — `<h2 className="text-sm font-semibold">{t("Reading progress")}</h2>`
- [web/app/(utility)/settings/progress/page.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L63) — `{progress.length === 0 ? (`
- [web/app/(utility)/settings/progress/page.tsx:94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L94) — `<h2 className="text-sm font-semibold">{t("Recent learning actions")}</h2>`


## S80 — Avatar preview developer surface

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /avatar-preview

**Parent layout:** utility

**Entry points:** Direct developer URL; no primary navigation established

**Purpose:** Session avatar state gallery

**Visible sections:** Session avatar state gallery; phase, auto and size controls

**User actions:** Preview animation states

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** Not applicable — local gallery

**Empty state:** Not applicable

**Error state:** UNVERIFIED — rendering only

**Success / completed state:** VERIFIED — phase gallery

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Exclude developer gallery from user MVP; keep as reference for avatar state parity.

**Source components:** [`web/app/(utility)/avatar-preview/page.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx)

**Reusable components:** SessionAvatar; SidebarMock

**Source evidence:**

- [web/app/(utility)/avatar-preview/page.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L5) — `import { useEffect, useState } from "react";`
- [web/app/(utility)/avatar-preview/page.tsx:58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L58) — `export default function AvatarPreview() {`
- [web/app/(utility)/avatar-preview/page.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L60) — `const [phase, setPhase] = useState(0);`
- [web/app/(utility)/avatar-preview/page.tsx:61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L61) — `const [auto, setAuto] = useState(true);`
- [web/app/(utility)/avatar-preview/page.tsx:62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L62) — `const [size, setSize] = useState(12);`
- [web/app/(utility)/avatar-preview/page.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L78) — `<h1 className="text-[15px] font-semibold">{t("Session avatars — states")}</h1>`


## S81 — General

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/general

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Interface language

**Visible sections:** Interface language; model output language; Classic/Modern layout; setup help

**User actions:** Select supported locale/layout; stage and apply preferences

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SettingsOverview.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; AgentSetupHelp; ArrowRight; Component; LanguageSelect; Link; SettingRow; SettingSection; SettingsPageHeader; UiLayout

**Source evidence:**

- [web/components/settings/SettingsOverview.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L56) — `export default function SettingsOverview() {`
- [web/components/settings/SettingsOverview.tsx:75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L75) — `title={t("General")}`
- [web/components/settings/SettingsOverview.tsx:80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L80) — `<SettingSection title={t("Language")}>`
- [web/components/settings/SettingsOverview.tsx:82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L82) — `title={t("Interface language")}`
- [web/components/settings/SettingsOverview.tsx:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L95) — `title={t("Model output language")}`
- [web/components/settings/SettingsOverview.tsx:119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L119) — `<SettingSection title={t("Layout")}>`
- [web/components/settings/SettingsOverview.tsx:121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L121) — `title={t("Interface layout")}`
- [web/components/settings/SettingsOverview.tsx:142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L142) — `title={t("Set up chat first")}`
- [web/components/settings/SettingsOverview.tsx:179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L179) — `title={t("Add more when you need it")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`


## S82 — Appearance

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/appearance

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Default/Cream/Dark/Glass/System themes

**Visible sections:** Default/Cream/Dark/Glass/System themes; learning text; code blocks

**User actions:** Change theme; adjust text/code preferences

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/AppearanceSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; RichCodeBlockPreview; SettingRow; SettingSection; SettingsPageHeader; ThemePreviewCard; Toggle

**Source evidence:**

- [web/features/settings/sections/AppearanceSettingsSection.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L46) — `export default function AppearanceSettingsPage() {`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L78) — `title={t("Appearance")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L85) — `title={t("Theme")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L124) — `title={t("Learning text")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L130) — `title={t("Text size")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L154) — `title={t("Line spacing")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L214) — `title={t("Code blocks")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:233](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L233) — `title={t("Syntax theme")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L261) — `title={t("Show line numbers")}`
- [web/features/settings/sections/AppearanceSettingsSection.tsx:274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L274) — `title={t("Wrap long lines")}`


## S83 — Workspace

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/workspace

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** System/general/custom workspaces

**Visible sections:** System/general/custom workspaces; root folder; resource bindings; storage migration

**User actions:** Create/edit/switch/manage permitted workspace; choose server folder; migrate storage

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/WorkspaceSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Archive; ArchiveRestore; Component; FileText; Folder; FolderInput; Icon; Link; Pencil; Plus; ServerFolderPicker; SettingSection; Settings2; SettingsPageHeader; SystemWorkspaceSnapshot; Tooltip; WorkspaceCatalog; WorkspaceInstructionsField; WorkspaceResourcePicker; WorkspaceRow

**Source evidence:**

- [web/features/settings/sections/WorkspaceSettingsSection.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L4) — `import { useCallback, useEffect, useState } from 'react'`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L25) — `const [resourcesOpen, setResourcesOpen] = useState(false)`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L26) — `const [instructionsOpen, setInstructionsOpen] = useState(false)`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L27) — `const [instructions, setInstructions] = useState(row.instructions ?? '')`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L28) — `const [resources, setResources] = useState(row.resources ?? inheritedWorkspaceResources())`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L29) — `const [editing, setEditing] = useState(false)`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L30) — `const [name, setName] = useState(row.display_name)`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L31) — `const [moving, setMoving] = useState(false)`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L32) — `const [destination, setDestination] = useState('')`
- [web/features/settings/sections/WorkspaceSettingsSection.tsx:93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L93) — `{row.error && <p role="alert" className="mt-2 text-xs text-[var(--destructive)]">{row.error}</p>}`


## S84 — Data migration

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/data-migration

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Discover/migrate/export learning data

**Visible sections:** Discover/migrate/export learning data

**User actions:** Discover; preview; migrate/export according to source controls

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/DataMigrationSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Discovery; Download; FolderInput; Link; Operation; Preview; RefreshCw

**Source evidence:**

- [web/features/settings/sections/DataMigrationSettingsSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L3) — `import { useEffect, useState } from 'react'`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L32) — `error?: string`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L74) — `export default function DataMigrationSettingsSection() {`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L79) — `const [source, setSource] = useState(activeWorkspaceId)`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L80) — `const [target, setTarget] = useState('')`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L81) — `const [discovery, setDiscovery] = useState<Discovery | null>(null)`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L82) — `const [selected, setSelected] = useState<string[]>([])`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L83) — `const [preview, setPreview] = useState<Preview | null>(null)`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L84) — `const [operations, setOperations] = useState<Operation[]>([])`
- [web/features/settings/sections/DataMigrationSettingsSection.tsx:85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L85) — `const [busy, setBusy] = useState(false)`


## S85 — Usage statistics

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/usage

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Model usage

**Visible sections:** Model usage; conversation activity

**User actions:** Change source-supported usage filters; inspect totals/activity

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/UsageSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; ChevronLeft; ChevronRight; Component; Link; RefreshCw; SettingsPageHeader; UsageActivity

**Source evidence:**

- [web/features/settings/sections/UsageSettingsSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L3) — `import { useEffect, useState } from 'react'`
- [web/features/settings/sections/UsageSettingsSection.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L12) — `export default function UsageSettingsSection() {`
- [web/features/settings/sections/UsageSettingsSection.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L18) — `const [snapshot, setSnapshot] = useState<{`
- [web/features/settings/sections/UsageSettingsSection.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L23) — `const [revision, setRevision] = useState(0)`
- [web/features/settings/sections/UsageSettingsSection.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L27) — `const error = !loading && Boolean(snapshot?.error)`
- [web/features/settings/sections/UsageSettingsSection.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L60) — `title={t('Usage statistics')}`
- [web/features/settings/sections/UsageSettingsSection.tsx:92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L92) — `<RefreshCw size={15} className={loading ? 'animate-spin' : ''} />`
- [web/features/settings/sections/UsageSettingsSection.tsx:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L95) — `{error && (`
- [web/features/settings/sections/UsageSettingsSection.tsx:102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L102) — `{snapshot?.error && <span className="mt-1 block break-words">{t(snapshot.error)}</span>}`
- [web/features/settings/sections/UsageSettingsSection.tsx:113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L113) — `{loading && !visible && (`


## S86 — Providers

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/connections

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Provider connection list/editor

**Visible sections:** Provider connection list/editor; names/endpoints/credentials; connectivity

**User actions:** Add/edit/test/remove provider connection

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/models/ConnectionsSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/ConnectionsSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; ProvidersWorkspace; SettingsPageHeader

**Source evidence:**

- [web/features/settings/sections/models/ConnectionsSettingsSection.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/ConnectionsSettingsSection.tsx#L8) — `export default function ConnectionsSettingsPage() {`
- [web/features/settings/sections/models/ConnectionsSettingsSection.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/ConnectionsSettingsSection.tsx#L13) — `title={t("Providers")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S87 — Language models

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/llm

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Language model list

**Visible sections:** Language model list; context window/capabilities; configured provider; tests

**User actions:** Add/edit/discover/test models; choose defaults

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/models/LlmSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/LlmSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; ModelsWorkspace; SettingsPageHeader

**Source evidence:**

- [web/features/settings/sections/models/LlmSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/LlmSettingsSection.tsx#L5) — `export default function LlmSettingsPage() {`
- [web/features/settings/sections/models/LlmSettingsSection.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/LlmSettingsSection.tsx#L10) — `title={t("Language models")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S88 — Task models

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/task-models

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Models for DeepTutor background calls

**Visible sections:** Models for DeepTutor background calls

**User actions:** Assign model for listed task roles

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/models/TaskModelsSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/TaskModelsSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; SettingsPageHeader; TaskModelsWorkspace

**Source evidence:**

- [web/features/settings/sections/models/TaskModelsSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/TaskModelsSettingsSection.tsx#L5) — `export default function TaskModelsSettingsPage() {`
- [web/features/settings/sections/models/TaskModelsSettingsSection.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/TaskModelsSettingsSection.tsx#L10) — `title={t("Task models")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S89 — Embedding models

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/embedding

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Embedding models

**Visible sections:** Embedding models; dimensions; usage and tests

**User actions:** Configure/test model and dimensions; inspect usage

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/models/EmbeddingSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/EmbeddingSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; ModelsWorkspace; SettingsPageHeader

**Source evidence:**

- [web/features/settings/sections/models/EmbeddingSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/EmbeddingSettingsSection.tsx#L5) — `export default function EmbeddingSettingsPage() {`
- [web/features/settings/sections/models/EmbeddingSettingsSection.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/EmbeddingSettingsSection.tsx#L10) — `title={t("Embedding models")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S90 — Search

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/search

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Search providers

**Visible sections:** Search providers; source-specific service configuration

**User actions:** Configure provider; test/select as supported

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/models/SearchSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/SearchSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; ModelsWorkspace; SettingsPageHeader

**Source evidence:**

- [web/features/settings/sections/models/SearchSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/SearchSettingsSection.tsx#L5) — `export default function SearchSettingsPage() {`
- [web/features/settings/sections/models/SearchSettingsSection.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/SearchSettingsSection.tsx#L10) — `title={t("Search")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S91 — Voice

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/voice

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** TTS and STT sub-surfaces

**Visible sections:** TTS and STT sub-surfaces; saved providers; preview/playback preferences

**User actions:** Configure synthesis/transcription; discover voices; preview

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/models/VoiceSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/VoiceSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; ModelsWorkspace; SettingsPageHeader; VoicePlaybackPrefs

**Source evidence:**

- [web/features/settings/sections/models/VoiceSettingsSection.tsx:6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/VoiceSettingsSection.tsx#L6) — `export default function VoiceSettingsPage() {`
- [web/features/settings/sections/models/VoiceSettingsSection.tsx:11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/VoiceSettingsSection.tsx#L11) — `title={t("settings.serviceConfig.voiceServices")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S92 — Multimodal generation

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/multimodal

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Image and video generation model configuration

**Visible sections:** Image and video generation model configuration

**User actions:** Configure image/video services; test where offered

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/models/MultimodalSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/MultimodalSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; ModelsWorkspace; SettingsPageHeader

**Source evidence:**

- [web/features/settings/sections/models/MultimodalSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/MultimodalSettingsSection.tsx#L5) — `export default function MultimodalSettingsPage() {`
- [web/features/settings/sections/models/MultimodalSettingsSection.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/MultimodalSettingsSection.tsx#L10) — `title={t("Multimodal generation")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S93 — Starting points

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/starters

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** History/material scope shaping composer starters

**Visible sections:** History/material scope shaping composer starters

**User actions:** Adjust source/history suggestion scope

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/StartersSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; ArrowUpRight; ChatResponseTimeoutSection; Component; Link; Loader2; SettingRow; SettingSection; SettingsPageHeader; StarterSettings; StarterSettingsPayload; Toggle

**Source evidence:**

- [web/features/settings/sections/StartersSettingsSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L3) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/features/settings/sections/StartersSettingsSection.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L27) — `export default function StarterSettingsPage() {`
- [web/features/settings/sections/StartersSettingsSection.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L31) — `const [payload, setPayload] = useState<StarterSettingsPayload | null>(null);`
- [web/features/settings/sections/StartersSettingsSection.tsx:32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L32) — `const [draft, setDraft] = useState<StarterSettings | null>(null);`
- [web/features/settings/sections/StartersSettingsSection.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L33) — `const [loading, setLoading] = useState(true);`
- [web/features/settings/sections/StartersSettingsSection.tsx:34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L34) — `const [error, setError] = useState<string | null>(null);`
- [web/features/settings/sections/StartersSettingsSection.tsx:132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L132) — `title={t("Conversation")}`
- [web/features/settings/sections/StartersSettingsSection.tsx:140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L140) — `{loading && (`
- [web/features/settings/sections/StartersSettingsSection.tsx:147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L147) — `{!loading && error && (`
- [web/features/settings/sections/StartersSettingsSection.tsx:153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L153) — `{!loading && payload && draft && (`


## S94 — Attachments

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/attachments

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Upload size caps and extraction budgets

**Visible sections:** Upload size caps and extraction budgets

**User actions:** Edit attachment limits where authorized

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/AttachmentsSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; AttachmentSettings; AttachmentSettingsPayload; Component; Link; Loader2; SettingRow; SettingSection; SettingsPageHeader

**Source evidence:**

- [web/features/settings/sections/AttachmentsSettingsSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L3) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L47) — `export default function AttachmentSettingsPage() {`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L51) — `const [payload, setPayload] = useState<AttachmentSettingsPayload | null>(`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L54) — `const [draft, setDraft] = useState<AttachmentSettings | null>(null);`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L55) — `const [loading, setLoading] = useState(true);`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L56) — `const [error, setError] = useState<string | null>(null);`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L157) — `title={t("Attachments")}`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L163) — `{loading && (`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L170) — `{!loading && error && (`
- [web/features/settings/sections/AttachmentsSettingsSection.tsx:176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L176) — `{!loading && payload && draft && (`


## S95 — Video Learning

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/video-learning

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Native YouTube/local Invidious provider settings

**Visible sections:** Native YouTube/local Invidious provider settings

**User actions:** Configure/test permitted playback provider

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/VideoLearningSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Icon; Link; Loader2; SettingsPageHeader

**Source evidence:**

- [web/features/settings/sections/VideoLearningSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L5) — `import { useEffect, useState } from "react";`
- [web/features/settings/sections/VideoLearningSettingsSection.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L23) — `export default function VideoLearningSettingsPage() {`
- [web/features/settings/sections/VideoLearningSettingsSection.tsx:26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L26) — `const [live, setLive] = useState(DEFAULTS);`
- [web/features/settings/sections/VideoLearningSettingsSection.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L28) — `const [loading, setLoading] = useState(true);`
- [web/features/settings/sections/VideoLearningSettingsSection.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L29) — `const [message, setMessage] = useState("");`
- [web/features/settings/sections/VideoLearningSettingsSection.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L63) — `title={t("Video Learning")}`
- [web/features/settings/sections/VideoLearningSettingsSection.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L68) — `{loading ? (`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`


## S96 — Learner profile

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/learner-profile

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Age/grade/explanation preferences

**Visible sections:** Age/grade/explanation preferences

**User actions:** Edit permitted learner fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Only authenticated learner preset (showLearnerOnly).

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/LearnerProfileSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; LearnerProfile; Link

**Source evidence:**

- [web/features/settings/sections/LearnerProfileSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L5) — `import { useEffect, useState } from "react";`
- [web/features/settings/sections/LearnerProfileSettingsSection.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L22) — `export default function LearnerProfileSettingsPage() {`
- [web/features/settings/sections/LearnerProfileSettingsSection.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L25) — `const [live, setLive] = useState<LearnerProfile>({});`
- [web/features/settings/sections/LearnerProfileSettingsSection.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L27) — `const [status, setStatus] = useState<"idle" | "loading" | "saved" | "error">(`
- [web/features/settings/sections/LearnerProfileSettingsSection.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L54) — `<h1 className="text-xl font-semibold">{t("Learner profile")}</h1>`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`


## S97 — Guardian

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/guardian

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Authorized learners and permitted learning materials

**Visible sections:** Authorized learners and permitted learning materials

**User actions:** Inspect/manage only authorized relationships/materials

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Only authenticated standard/custom users allowed by showGuardianOnly; resource access still server-authorized.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/GuardianSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; BusyAction; Component; ConfirmAction; ConfirmDialog; GuardianExtension; GuardianMaterial; GuardianRelationship; GuardianReport; GuardianRestrictions; KeyRound; Library; Link; ShieldOff; SlidersHorizontal

**Source evidence:**

- [web/features/settings/sections/GuardianSettingsSection.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L4) — `import { useEffect, useState } from "react";`
- [web/features/settings/sections/GuardianSettingsSection.tsx:44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L44) — `export default function GuardianSettingsPage() {`
- [web/features/settings/sections/GuardianSettingsSection.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L46) — `const [relationships, setRelationships] = useState<GuardianRelationship[]>(`
- [web/features/settings/sections/GuardianSettingsSection.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L50) — `useState<GuardianRelationship | null>(null);`
- [web/features/settings/sections/GuardianSettingsSection.tsx:51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L51) — `const [report, setReport] = useState<GuardianReport | null>(null);`
- [web/features/settings/sections/GuardianSettingsSection.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L52) — `const [materials, setMaterials] = useState<GuardianMaterial[]>([]);`
- [web/features/settings/sections/GuardianSettingsSection.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L53) — `const [liveMaterialIds, setLiveMaterialIds] = useState<string[]>([]);`
- [web/features/settings/sections/GuardianSettingsSection.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L55) — `const [liveRestrictions, setLiveRestrictions] = useState<GuardianRestrictions | null>(`
- [web/features/settings/sections/GuardianSettingsSection.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L59) — `const [extensions, setExtensions] = useState<GuardianExtension[]>([]);`
- [web/features/settings/sections/GuardianSettingsSection.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L60) — `const [newPassword, setNewPassword] = useState("");`


## S98 — Memory settings

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/memory

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Chunking, budget, deduplication and reference policies

**Visible sections:** Chunking, budget, deduplication and reference policies

**User actions:** Edit memory runtime policies

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/MemorySettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; Loader2; MemorySettingsDTO; NumberRow; SelectRow; SettingRow; SettingSection; SettingsPageHeader; ToggleRow

**Source evidence:**

- [web/features/settings/sections/MemorySettingsSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L3) — `import { useCallback, useEffect, useRef, useState } from "react";`
- [web/features/settings/sections/MemorySettingsSection.tsx:37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L37) — `export default function MemorySettingsPage() {`
- [web/features/settings/sections/MemorySettingsSection.tsx:41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L41) — `const [error, setError] = useState<string | null>(null);`
- [web/features/settings/sections/MemorySettingsSection.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L42) — `const [settings, setSettings] = useState<MemorySettingsDTO | null>(null);`
- [web/features/settings/sections/MemorySettingsSection.tsx:44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L44) — `useState<MemorySettingsDTO | null>(null);`
- [web/features/settings/sections/MemorySettingsSection.tsx:128](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L128) — `title={t("Memory")}`
- [web/features/settings/sections/MemorySettingsSection.tsx:134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L134) — `title={t("Update mode")}`
- [web/features/settings/sections/MemorySettingsSection.tsx:158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L158) — `title={t("Audit mode")}`
- [web/features/settings/sections/MemorySettingsSection.tsx:180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L180) — `title={t("Dedup")}`
- [web/features/settings/sections/MemorySettingsSection.tsx:200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L200) — `title={t("Merge footnotes")}`


## S99 — Tools

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/tools

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** User-toggleable built-in tools

**Visible sections:** User-toggleable built-in tools

**User actions:** Enable/configure source-supported tools

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/ToolsSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; BuiltinTool; ChevronDown; Component; Field; Link; Loader2; Lock; Record; Search; Set; SettingsPageHeader; ToolSection; ToolToggle; Tooltip; Wrench

**Source evidence:**

- [web/features/settings/sections/ToolsSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L5) — `import { useEffect, useMemo, useState } from "react";`
- [web/features/settings/sections/ToolsSettingsSection.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L78) — `export default function ToolsSettingsPage() {`
- [web/features/settings/sections/ToolsSettingsSection.tsx:82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L82) — `const [tools, setTools] = useState<BuiltinTool[] | null>(null);`
- [web/features/settings/sections/ToolsSettingsSection.tsx:83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L83) — `const [error, setError] = useState<string | null>(null);`
- [web/features/settings/sections/ToolsSettingsSection.tsx:84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L84) — `const [expanded, setExpanded] = useState<Set<string>>(new Set());`
- [web/features/settings/sections/ToolsSettingsSection.tsx:85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L85) — `const [liveTools, setLiveTools] = useState({ enabled_tools: [] as string[] });`
- [web/features/settings/sections/ToolsSettingsSection.tsx:90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L90) — `const [query, setQuery] = useState("");`
- [web/features/settings/sections/ToolsSettingsSection.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L239) — `title={t("Tools")}`
- [web/features/settings/sections/ToolsSettingsSection.tsx:277](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L277) — `{error && (`
- [web/features/settings/sections/ToolsSettingsSection.tsx:285](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L285) — `{!tools && !error && (`


## S100 — Capabilities

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/capabilities

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Per-capability LLM parameters/runtime controls

**Visible sections:** Per-capability LLM parameters/runtime controls

**User actions:** Configure installed capability parameters

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/CapabilitiesSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CapabilitiesSettingsDTO; Component; Link; Loader2; NumberRow; QuestionExtras; ResearchExtras; SettingRow; SettingSection; SettingsPageHeader; SimpleLLMBlock; SolveExtras; ToggleRow

**Source evidence:**

- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L3) — `import { useCallback, useEffect, useRef, useState } from "react";`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L88) — `export default function CapabilitiesSettingsPage() {`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L92) — `const [settings, setSettings] = useState<CapabilitiesSettingsDTO | null>(`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L96) — `useState<CapabilitiesSettingsDTO | null>(null);`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L97) — `const [loadError, setLoadError] = useState<string | null>(null);`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L299) — `title={t("Capabilities")}`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:304](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L304) — `title={t("Chat")}`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L350) — `title={t("Solve")}`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L395) — `title={t("Question")}`
- [web/features/settings/sections/CapabilitiesSettingsSection.tsx:440](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L440) — `title={t("Research")}`


## S101 — Knowledge Base / document parsing

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/knowledge

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Document parsing engine

**Visible sections:** Document parsing engine; MinerU and source-supported settings

**User actions:** Configure/test parsing

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/DocumentParsingSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; DoclingPanel; DocumentParsingPayload; Download; ImageDescriptionModelSetting; JobButton; JobLog; JobStatus; Link; LiteParsePanel; Loader2; MarkItDownPanel; MinerUEngineSettings; ModelDownloadRow; NotInstalledSection; PyMuPDF4LLMPanel; ReadinessBadge; ReadinessNotice; SettingRow; SettingSection; SettingsPageHeader; TextOnlyPanel; TikaPanel; Toggle; XCircle

**Source evidence:**

- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L5) — `import { useCallback, useEffect, useRef, useState } from "react";`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L66) — `export default function DocumentParsingSettingsPage() {`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L68) — `const [liveData, setLiveData] = useState<DocumentParsingPayload | null>(null);`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L70) — `const [loading, setLoading] = useState(true);`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L71) — `const [error, setError] = useState<string | null>(null);`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L121) — `title={t("Document Parsing")}`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L127) — `{loading && (`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L134) — `{!loading && error && (`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L140) — `{!loading && data && (`
- [web/features/settings/sections/DocumentParsingSettingsSection.tsx:149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L149) — `<h2 className="text-[15px] font-semibold tracking-tight text-[var(--foreground)]">`


## S102 — Network

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/network

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Ports

**Visible sections:** Ports; browser API base; CORS

**User actions:** Edit deployment network settings where authorized

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/NetworkSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; DetailTile; Link; Loader2; NetworkSettings; NetworkSettingsPayload; RuntimeHealthCard; SettingRow; SettingSection; SettingsPageHeader; TurnCoordinationSettings

**Source evidence:**

- [web/features/settings/sections/NetworkSettingsSection.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L3) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/features/settings/sections/NetworkSettingsSection.tsx:87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L87) — `title={value}`
- [web/features/settings/sections/NetworkSettingsSection.tsx:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L95) — `export default function NetworkSettingsPage() {`
- [web/features/settings/sections/NetworkSettingsSection.tsx:102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L102) — `const [payload, setPayload] = useState<NetworkSettingsPayload | null>(null);`
- [web/features/settings/sections/NetworkSettingsSection.tsx:103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L103) — `const [draft, setDraft] = useState<NetworkSettings | null>(null);`
- [web/features/settings/sections/NetworkSettingsSection.tsx:104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L104) — `const [corsText, setCorsText] = useState("");`
- [web/features/settings/sections/NetworkSettingsSection.tsx:105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L105) — `const [loading, setLoading] = useState(true);`
- [web/features/settings/sections/NetworkSettingsSection.tsx:106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L106) — `const [error, setError] = useState<string | null>(null);`
- [web/features/settings/sections/NetworkSettingsSection.tsx:210](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L210) — `title={t("Network")}`
- [web/features/settings/sections/NetworkSettingsSection.tsx:240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L240) — `{loading && (`


## S103 — Runtime status

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/status

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Service readiness/diagnostics

**Visible sections:** Service readiness/diagnostics; memory usage; modules and turn coordination

**User actions:** Refresh diagnostics; inspect source-supported module/runtime actions

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SettingsRuntimePage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsRuntimePage.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; Component; Link; ModulesPanel; SettingsPageHeader; SettingsReadinessPanel; SettingsStatusPanel

**Source evidence:**

- [web/components/settings/SettingsRuntimePage.tsx:10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsRuntimePage.tsx#L10) — `export default function SettingsRuntimePage() {`
- [web/components/settings/SettingsRuntimePage.tsx:16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsRuntimePage.tsx#L16) — `title={t("Runtime status")}`
- [web/components/settings/SettingsPageContent.tsx:216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L216) — `export default function SettingsPageContent({ section }: { section: string }) {`
- [web/components/settings/SettingsPageContent.tsx:239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L239) — `<h1 className="text-xl font-semibold">`
- [web/features/settings/navigation/settings-nav.ts:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L88) — `export function isSettingsLeafVisible(`
- [web/features/settings/navigation/settings-nav.ts:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L95) — `export function isSettingsCategoryVisible(`
- [web/features/settings/navigation/settings-nav.ts:107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L107) — `export function visibleSettingsChildren(`
- [web/features/settings/navigation/settings-nav.ts:578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L578) — `export function resolveSettingsKey(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:583](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L583) — `export function settingsAnchorHref(key: string): string {`
- [web/features/settings/navigation/settings-nav.ts:637](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L637) — `export function storagePathFor(`


## S104 — About

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/about

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** App version

**Visible sections:** App version; updates; project resources

**User actions:** Inspect version; open official resources/check updates where offered

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Settings access resolves before rendering. Admin-owned catalog/config controls follow catalogEditable and feature gates; source SettingsAccessProvider remains authoritative.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/features/settings/sections/AboutSettingsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; AppUpdateStatus; ArrowUpRight; Button; Check; CircleAlert; ClientEdition; CodeValue; Component; ConfirmDialog; Download; Github; InstallMode; Link; RefreshCw; ResourceRow; RotateCw; SettingRow; SettingSection; SettingsPageHeader; ShieldCheck; Toggle; UpdateJob

**Source evidence:**

- [web/features/settings/sections/AboutSettingsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/features/settings/sections/AboutSettingsSection.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L59) — `export default function AboutSettingsPage() {`
- [web/features/settings/sections/AboutSettingsSection.tsx:61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L61) — `const [status, setStatus] = useState<AppUpdateStatus | null>(null);`
- [web/features/settings/sections/AboutSettingsSection.tsx:62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L62) — `const [job, setJob] = useState<UpdateJob | null>(null);`
- [web/features/settings/sections/AboutSettingsSection.tsx:63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L63) — `const [loading, setLoading] = useState(true);`
- [web/features/settings/sections/AboutSettingsSection.tsx:64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L64) — `const [checking, setChecking] = useState(false);`
- [web/features/settings/sections/AboutSettingsSection.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L66) — `const [liveChecks, setLiveChecks] = useState({ enabled: false });`
- [web/features/settings/sections/AboutSettingsSection.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L68) — `const [requesting, setRequesting] = useState(false);`
- [web/features/settings/sections/AboutSettingsSection.tsx:69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L69) — `const [confirmOpen, setConfirmOpen] = useState(false);`
- [web/features/settings/sections/AboutSettingsSection.tsx:70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L70) — `const [error, setError] = useState("");`


## S105 — Partners & agents: claude-code

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-claude-code

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S106 — Partners & agents: codex

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-codex

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S107 — Partners & agents: grok

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-grok

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S108 — Partners & agents: antigravity

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-antigravity

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S109 — Partners & agents: kimi

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-kimi

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S110 — Partners & agents: opencode

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-opencode

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S111 — Partners & agents: mimo

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-mimo

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S112 — Partners & agents: hermes

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-hermes

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S113 — Partners & agents: hermes-remote

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-hermes-remote

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S114 — Partners & agents: openclaw

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-openclaw

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S115 — Partners & agents: deepseek-harness

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Full screen

**Web route:** /settings/agent-deepseek-harness

**Parent layout:** settings

**Entry points:** Settings navigation; /settings legacy hash normalization

**Purpose:** Backend-specific model/reasoning/run parameters

**Visible sections:** Backend-specific model/reasoning/run parameters; agent setup help

**User actions:** Configure the selected supported backend; stage/apply available fields

**Modals / dialogs / drawers / sheets:** Shared staged-settings apply/discard controls; section-specific discovery/test/confirmation surfaces where rendered.

**Loading state:** VERIFIED — SettingsPageContent waits for access/settings; dynamic section skeleton

**Empty state:** UNVERIFIED — section-specific unconfigured/empty controls require runtime; no universal empty screen

**Error state:** VERIFIED — unavailable page guard; shared load/save banners; section operation errors must be visually verified

**Success / completed state:** VERIFIED — shared fieldset disabled during saving/applying; persisted settings reflected after successful apply

**Permissions:** Admin-only navigation leaf when auth is enabled; hidden for non-admin and pending auth failures.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Dedicated settings destination using scrollable forms; master/detail service editors split into list and editor. Keep staged apply/discard semantics. Advanced infrastructure may be deferred from MVP without dropping inventory.

**Source components:** [`web/components/settings/SubagentSettingsEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx), [`web/components/settings/SettingsPageContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx), [`web/features/settings/navigation/settings-nav.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts), [`web/features/settings/navigation/settings-access.ts`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-access.ts)

**Reusable components:** Agent; CheckCircle2; Component; Glyph; Link; Loader2; RefreshCw; SettingRow; SettingSection; SettingsPageHeader; SubagentBackendConfig; SubagentBackendOptions; Toggle; XCircle

**Source evidence:**

- [web/components/settings/SubagentSettingsEditor.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SubagentSettingsEditor.tsx:324](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L324) — `export function SubagentSettingsEditor({ kind }: { kind: string }) {`
- [web/components/settings/SubagentSettingsEditor.tsx:329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329) — `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330) — `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [web/components/settings/SubagentSettingsEditor.tsx:334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334) — `const [customModel, setCustomModel] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335) — `const [loading, setLoading] = useState(true);`
- [web/components/settings/SubagentSettingsEditor.tsx:336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336) — `const [syncing, setSyncing] = useState(false);`
- [web/components/settings/SubagentSettingsEditor.tsx:338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338) — `const [error, setError] = useState<string | null>(null);`
- [web/components/settings/SubagentSettingsEditor.tsx:435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435) — `title={displayName}`
- [web/components/settings/SubagentSettingsEditor.tsx:449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449) — `{loading && (`


## S116 — Page customization

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Dialog

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Chat/learning page customization button

**Purpose:** Chat modes, controls and starter groups

**Visible sections:** Chat modes, controls and starter groups; learning visibility; reset defaults

**User actions:** Toggle visibility; edit starter label/prompt; save/reset; retry load

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/customization/PageCustomizeDialog.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx), [`web/components/customization/PageCustomizeButton.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeButton.tsx)

**Reusable components:** ChoiceRow; Dialog; Loader2; PageCustomizeDialog; Plus; RotateCcw; SlidersHorizontal; StarterGroup; Tooltip; Trash2

**Source evidence:**

- [web/components/customization/PageCustomizeDialog.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L3) — `import { useState } from 'react'`
- [web/components/customization/PageCustomizeDialog.tsx:26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L26) — `export function ChoiceRow({`
- [web/components/customization/PageCustomizeDialog.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L65) — `export default function PageCustomizeDialog({`
- [web/components/customization/PageCustomizeDialog.tsx:81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L81) — `const [draft, setDraft] = useState(() => structuredClone(initial))`
- [web/components/customization/PageCustomizeDialog.tsx:82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L82) — `const [tab, setTab] = useState<'modes' | 'controls' | 'starters'>('modes')`
- [web/components/customization/PageCustomizeDialog.tsx:83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L83) — `const [group, setGroup] = useState<StarterGroup>('explain')`
- [web/components/customization/PageCustomizeDialog.tsx:84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L84) — `const [saving, setSaving] = useState(false)`
- [web/components/customization/PageCustomizeDialog.tsx:85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L85) — `const [error, setError] = useState(false)`
- [web/components/customization/PageCustomizeDialog.tsx:109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L109) — `title={t('customize.title')}`
- [web/components/customization/PageCustomizeDialog.tsx:166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L166) — `{loading ? (`


## S117 — Imported-history agents

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Second half of AgentsHub after ConnectedAgents

**Purpose:** Imported agent transcripts

**Visible sections:** Imported agent transcripts; project/date scope; search and synchronization

**User actions:** Import; select scope; synchronize; open supported imported sessions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/space/MyAgentsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx), [`web/components/space/ScopePicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopePicker.tsx)

**Reusable components:** AgentCard; Bot; Check; ChevronDown; ChevronRight; EmptyState; GroupIcon; HTMLDivElement; ImportAgent; ImportWizard; Loader2; MenuItem; MoreHorizontal; Pencil; Plus; RefreshCw; RenameInput; ScopeEditorModal; Search; SessionList; SessionSummary; Set; SlidersHorizontal; SpaceSectionHeader; Tooltip; Trash2; UngroupedCard

**Source evidence:**

- [web/components/space/MyAgentsSection.tsx:5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L5) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/space/MyAgentsSection.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L89) — `export default function MyAgentsSection() {`
- [web/components/space/MyAgentsSection.tsx:93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L93) — `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [web/components/space/MyAgentsSection.tsx:94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L94) — `const [registry, setRegistry] = useState<ImportAgent[]>([]);`
- [web/components/space/MyAgentsSection.tsx:95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L95) — `const [loading, setLoading] = useState(true);`
- [web/components/space/MyAgentsSection.tsx:96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L96) — `const [selectedKey, setSelectedKey] = useState<string | null>(null);`
- [web/components/space/MyAgentsSection.tsx:97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L97) — `const [query, setQuery] = useState("");`
- [web/components/space/MyAgentsSection.tsx:98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L98) — `const [wizardOpen, setWizardOpen] = useState(false);`
- [web/components/space/MyAgentsSection.tsx:99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L99) — `const [refreshingId, setRefreshingId] = useState<string | null>(null);`
- [web/components/space/MyAgentsSection.tsx:100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L100) — `const [note, setNote] = useState("");`


## S118 — Chat history import wizard

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Modal

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** MyAgentsSection Import and scope editor

**Purpose:** intro → scanning → select → importing → done/error

**Visible sections:** intro → scanning → select → importing → done/error; source and project/date scope

**User actions:** Select source/files or server-compatible history; scan; choose scope; import; inspect result

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/space/ImportWizard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx), [`web/components/space/ScopeEditorModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx)

**Reusable components:** AlertTriangle; Button; CenteredStatus; CheckCircle2; DoneView; ErrorView; Eye; FileJson; FolderInput; FolderOpen; HTMLInputElement; ImportScanErrorCode; ImportingView; IntroView; Loader2; Modal; Phase; ScanResult; ScopePicker; SelectGroup; Set; SlidersHorizontal; WizardFooter

**Source evidence:**

- [web/components/space/ImportWizard.tsx:7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L7) — `useState,`
- [web/components/space/ImportWizard.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L59) — `export default function ImportWizard({`
- [web/components/space/ImportWizard.tsx:65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L65) — `const [phase, setPhase] = useState<Phase>("intro");`
- [web/components/space/ImportWizard.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L66) — `const [scan, setScan] = useState<ScanResult | null>(null);`
- [web/components/space/ImportWizard.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L67) — `const [name, setName] = useState("");`
- [web/components/space/ImportWizard.tsx:68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L68) — `const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());`
- [web/components/space/ImportWizard.tsx:69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L69) — `const [errorCode, setErrorCode] = useState<ImportScanErrorCode | "generic">(`
- [web/components/space/ImportWizard.tsx:72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L72) — `const [progress, setProgress] = useState({`
- [web/components/space/ImportWizard.tsx:77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L77) — `const [result, setResult] = useState<{ imported: number; skipped: number }>({`
- [web/components/space/ImportWizard.tsx:161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L161) — `if (!scan || selectedRefs.length === 0) return;`


## S119 — Question categories and bulk organization

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Dialog

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Question Bank toolbar and selection

**Purpose:** Category manager/menu

**Visible sections:** Category manager/menu; selected-question actions

**User actions:** Manage categories; apply source-supported bulk actions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/space/question-bank/CategoryManager.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx), [`web/components/space/question-bank/CategoryMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx), [`web/components/space/question-bank/BankSelectionBar.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankSelectionBar.tsx)

**Reusable components:** CategoryMenu; Check; CheckSquare; FolderMinus; FolderPlus; HTMLDivElement; Loader2; Pencil; Plus; Tooltip; Trash2

**Source evidence:**

- [web/components/space/question-bank/CategoryManager.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L3) — `import { useCallback, useState } from "react";`
- [web/components/space/question-bank/CategoryManager.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L23) — `export default function CategoryManager({`
- [web/components/space/question-bank/CategoryManager.tsx:30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L30) — `const [newName, setNewName] = useState("");`
- [web/components/space/question-bank/CategoryManager.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L31) — `const [renaming, setRenaming] = useState<{ id: number; name: string } | null>(`
- [web/components/space/question-bank/CategoryManager.tsx:34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L34) — `const [busy, setBusy] = useState(false);`
- [web/components/space/question-bank/CategoryManager.tsx:148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L148) — `{categories.length === 0 && (`
- [web/components/space/question-bank/CategoryMenu.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L3) — `import { useCallback, useEffect, useRef, useState } from "react";`
- [web/components/space/question-bank/CategoryMenu.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L38) — `export default function CategoryMenu({`
- [web/components/space/question-bank/CategoryMenu.tsx:51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L51) — `const [open, setOpen] = useState(false);`
- [web/components/space/question-bank/CategoryMenu.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L52) — `const [name, setName] = useState("");`


## S120 — Edit mastery route

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Dialog

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Mastery Path detail edit action

**Purpose:** Editable route draft

**Visible sections:** Editable route draft; structure and validation

**User actions:** Edit draft; validate; confirm/cancel

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/space/learning/EditTopicRouteDialog.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx), [`web/components/space/learning/RouteDraftEditor.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/RouteDraftEditor.tsx)

**Reusable components:** AlertTriangle; ArrowDown; ArrowUp; Check; HTMLElement; Loader2; OrderButtons; Plus; RouteDraftEditor; Trash2

**Source evidence:**

- [web/components/space/learning/EditTopicRouteDialog.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L3) — `import { useMemo, useState, type RefObject } from "react";`
- [web/components/space/learning/EditTopicRouteDialog.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L40) — `export function EditTopicRouteDialog({`
- [web/components/space/learning/EditTopicRouteDialog.tsx:53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L53) — `const [draft, setDraft] = useState(original);`
- [web/components/space/learning/EditTopicRouteDialog.tsx:54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L54) — `const [busy, setBusy] = useState(false);`
- [web/components/space/learning/EditTopicRouteDialog.tsx:55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L55) — `const [error, setError] = useState<string | null>(null);`
- [web/components/space/learning/EditTopicRouteDialog.tsx:75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L75) — `role="dialog"`
- [web/components/space/learning/EditTopicRouteDialog.tsx:86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L86) — `<h2`
- [web/components/space/learning/EditTopicRouteDialog.tsx:116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L116) — `{error && <p className="mt-4 text-xs text-red-600">{error}</p>}`
- [web/components/space/learning/RouteDraftEditor.tsx:31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/RouteDraftEditor.tsx#L31) — `export function RouteDraftEditor({`


## S121 — Notebook flashcard review

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Overlay

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Learning notebook library Review flashcards (hidden if no due cards)

**Purpose:** Due note flashcards

**Visible sections:** Due note flashcards; reveal back; remembered/not remembered; source page/block link; export all for Anki

**User actions:** Reveal; grade; follow source; export; close

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/features/notes/components/NoteReview.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx)

**Reusable components:** Card; FileDown; Layers; Link; PickerShell

**Source evidence:**

- [web/features/notes/components/NoteReview.tsx:2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L2) — `import { useEffect, useState } from 'react'`
- [web/features/notes/components/NoteReview.tsx:17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L17) — `export default function NoteReview() {`
- [web/features/notes/components/NoteReview.tsx:19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L19) — `const [cards, setCards] = useState<Card[]>([])`
- [web/features/notes/components/NoteReview.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L20) — `const [open, setOpen] = useState(false)`
- [web/features/notes/components/NoteReview.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L21) — `const [revealed, setRevealed] = useState(false)`
- [web/features/notes/components/NoteReview.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L22) — `const [error, setError] = useState('')`
- [web/features/notes/components/NoteReview.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L23) — `const [busy, setBusy] = useState(false)`
- [web/features/notes/components/NoteReview.tsx:124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L124) — `{error && (`


## S122 — Note source and favorites selection

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Overlay

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Note editor insert or source controls

**Purpose:** Sources/favorites selection

**Visible sections:** Sources/favorites selection; block insertion choices

**User actions:** Select source/favorite; insert source-supported block kind

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/features/notes/components/NoteSourcePicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx), [`web/features/notes/components/NoteFavoritesPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx), [`web/features/notes/components/NoteInsertMenu.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInsertMenu.tsx)

**Reusable components:** Check; ChevronDown; CornerDownLeft; FavoriteContent; FavoriteKindIcon; FileText; HTMLDivElement; HTMLInputElement; Item; Library; NoteBlockPreview; NoteMenuItem; NotePage; NotebookSummary; PickerShell; Search; Sparkles

**Source evidence:**

- [web/features/notes/components/NoteSourcePicker.tsx:2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L2) — `import { useCallback, useState } from 'react'`
- [web/features/notes/components/NoteSourcePicker.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L13) — `export default function NoteSourcePicker({`
- [web/features/notes/components/NoteSourcePicker.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L28) — `const [query, setQuery] = useState('')`
- [web/features/notes/components/NoteSourcePicker.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L29) — `const [busy, setBusy] = useState(false)`
- [web/features/notes/components/NoteSourcePicker.tsx:30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L30) — `const [error, setError] = useState('')`
- [web/features/notes/components/NoteSourcePicker.tsx:75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L75) — `<h2 className="text-sm font-medium">{t('Reference a source')}</h2>`
- [web/features/notes/components/NoteSourcePicker.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L89) — `{loading ? (`
- [web/features/notes/components/NoteSourcePicker.tsx:114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L114) — `{error && (`
- [web/features/notes/components/NoteFavoritesPicker.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L13) — `import { useEffect, useMemo, useRef, useState } from 'react'`
- [web/features/notes/components/NoteFavoritesPicker.tsx:35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L35) — `export default function NoteFavoritesPicker({`


## S123 — Note review and generated suggestion margin

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Note companion and editor selection

**Purpose:** Inline reviews

**Visible sections:** Inline reviews; generated suggestions; anchored thread markers

**User actions:** Inspect/accept/reject source-supported review; follow thread

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/features/notes/components/NoteInlineReviews.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInlineReviews.tsx), [`web/features/notes/components/NoteSuggestionContent.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSuggestionContent.tsx), [`web/features/notes/components/NoteThreadMarkers.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx)

**Reusable components:** AskOrb; BlockNoteEditor; Check; Entry; HTMLDivElement; HTMLElement; Learning; Markdown; MessageSquare; NoteSuggestionContent; OrbStack; Placement; ReturnType; Sparkles; ThreadPreview; Trash2

**Source evidence:**

- [web/features/notes/components/NoteInlineReviews.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInlineReviews.tsx#L3) — `import { useCallback, useEffect, useState, useSyncExternalStore } from 'react'`
- [web/features/notes/components/NoteInlineReviews.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInlineReviews.tsx#L22) — `export default function NoteInlineReviews({`
- [web/features/notes/components/NoteInlineReviews.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInlineReviews.tsx#L46) — `const [snapshot, setSnapshot] = useState(() => ({`
- [web/features/notes/components/NoteSuggestionContent.tsx:9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSuggestionContent.tsx#L9) — `export default function NoteSuggestionContent({`
- [web/features/notes/components/NoteThreadMarkers.tsx:15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L15) — `import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'`
- [web/features/notes/components/NoteThreadMarkers.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L25) — `export function blockLineCenter(container: HTMLElement, blockId: string): number | null {`
- [web/features/notes/components/NoteThreadMarkers.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L42) — `export default function NoteThreadMarkers({`
- [web/features/notes/components/NoteThreadMarkers.tsx:66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L66) — `const [placements, setPlacements] = useState<Placement[]>([])`
- [web/features/notes/components/NoteThreadMarkers.tsx:67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L67) — `const [hoverBlock, setHoverBlock] = useState<{ blockId: string; top: number } | null>(null)`
- [web/features/notes/components/NoteThreadMarkers.tsx:200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L200) — `const [anchor, setAnchor] = useState<HTMLDivElement | null>(null)`


## S124 — Book learning block family

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Generated book page BlockRenderer

**Purpose:** Text/section/callout/code/figure/timeline/flashcards/quiz/deep dive/animation/concept graph/interactive/user note/placeholder blocks

**Visible sections:** Text/section/callout/code/figure/timeline/flashcards/quiz/deep dive/animation/concept graph/interactive/user note/placeholder blocks

**User actions:** Use block-specific reveal/answer/play/deep-dive/edit actions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx), [`web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx), [`web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx), [`web/app/(workspace)/learning/books/components/blocks/InteractiveBlock.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/InteractiveBlock.tsx)

**Reusable components:** AlertTriangle; AnimationBlock; ArrowDown; ArrowUp; BlockBodyEditor; CalloutBlock; CheckCircle2; ChevronLeft; ChevronRight; CodeBlock; ConceptGraphBlock; DeepDiveBlock; Eye; EyeOff; FigureBlock; FlashCardsBlock; InteractiveBlock; Loader2; MarkdownRenderer; Pencil; PlaceholderBlock; QuizBlock; QuizQuestionCard; RefreshCw; Replace; RotateCcw; SectionBlock; SelfGradeButton; Sparkles; TextBlock; TimelineBlock; Tooltip; Trash2; UserNoteBlock; VisualizationViewer; XCircle

**Source evidence:**

- [web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L3) — `import { useEffect, useState } from "react";`
- [web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx:85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L85) — `export default function BlockRenderer({`
- [web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx:104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L104) — `const [showTypeMenu, setShowTypeMenu] = useState(false);`
- [web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx:105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L105) — `const [editingBody, setEditingBody] = useState(false);`
- [web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx:106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L106) — `const [confirmDelete, setConfirmDelete] = useState(false);`
- [web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L3) — `import { useState } from "react";`
- [web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L18) — `export default function FlashCardsBlock({ block }: FlashCardsBlockProps) {`
- [web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L21) — `const [idx, setIdx] = useState(0);`
- [web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L22) — `const [showBack, setShowBack] = useState(false);`
- [web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L23) — `if (cards.length === 0) return null;`


## S125 — Knowledge source management

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Tab

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** KnowledgeBaseDetail eligible sections

**Purpose:** URL sources

**Visible sections:** URL sources; GitHub sources; linked server folders; MarginNote devices; Kiwix articles

**User actions:** Add/configure/synchronize/remove sources according to KB kind and permission

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/knowledge/KbWebSourcesSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx), [`web/components/knowledge/KbGitHubSourcesSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx), [`web/components/knowledge/KbLinkedFoldersSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx), [`web/components/knowledge/KbMarginNoteDevicesSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx), [`web/components/knowledge/KbKiwixArticlesSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx)

**Reusable components:** AlertTriangle; Ban; BookOpen; Check; CheckCircle2; Copy; Field; FolderSync; FormField; GitHubSource; Github; Globe; HTMLFormElement; KiwixArticle; LinkFolderModal; LinkedFolderCard; LinkedFolderInfo; Loader2; MarginNoteDevice; MarginNoteLibraryStatus; MarginNotePairing; Plus; ProcessLogs; Record; RefreshCw; RotateCcw; Search; Smartphone; SourceCard; SyncFolderResponse; SyncProgress; Tooltip; Trash2; WebSource; WebSourceCard; WebSourceSyncJob

**Source evidence:**

- [web/components/knowledge/KbWebSourcesSection.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L4) — `import { useCallback, useEffect, useState } from "react";`
- [web/components/knowledge/KbWebSourcesSection.tsx:33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L33) — `export default function KbWebSourcesSection({`
- [web/components/knowledge/KbWebSourcesSection.tsx:37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L37) — `const [sources, setSources] = useState<WebSource[]>([]);`
- [web/components/knowledge/KbWebSourcesSection.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L38) — `const [jobs, setJobs] = useState<WebSourceSyncJob[]>([]);`
- [web/components/knowledge/KbWebSourcesSection.tsx:39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L39) — `const [loading, setLoading] = useState(true);`
- [web/components/knowledge/KbWebSourcesSection.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L40) — `const [showForm, setShowForm] = useState(false);`
- [web/components/knowledge/KbWebSourcesSection.tsx:41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L41) — `const [syncing, setSyncing] = useState(false);`
- [web/components/knowledge/KbWebSourcesSection.tsx:42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L42) — `const [error, setError] = useState<string | null>(null);`
- [web/components/knowledge/KbWebSourcesSection.tsx:44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L44) — `const [urlInput, setUrlInput] = useState("");`
- [web/components/knowledge/KbWebSourcesSection.tsx:45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L45) — `const [maxDepth, setMaxDepth] = useState(3);`


## S126 — KB indexing history and diagnostics

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** KB detail and indexing panels

**Purpose:** Index versions

**Visible sections:** Index versions; update provenance; visual coverage; failure/recovery notice

**User actions:** Inspect run/version/provenance; retry/publish only where source exposes action

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/knowledge/KbIndexVersionsSection.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx), [`web/components/knowledge/KbUpdateHistory.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbUpdateHistory.tsx), [`web/components/knowledge/KbVisualCoverage.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbVisualCoverage.tsx), [`web/components/knowledge/KbIndexFailureBanner.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexFailureBanner.tsx)

**Reusable components:** AlertCircle; AlertTriangle; CheckCircle2; ChevronDown; ChevronRight; Clock; Coverage; EmbeddingModelSelector; History; Icon; IndexVersionRow; KbIndexFailureBanner; Layers; LightRagEmbeddingWarning; LightRagIndexingProvenance; LightRagRebuildConfig; Link; Loader2; Modal; RefreshCw; Settings; Star; Tooltip; Trash2

**Source evidence:**

- [web/components/knowledge/KbIndexVersionsSection.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L4) — `import { useEffect, useState } from "react";`
- [web/components/knowledge/KbIndexVersionsSection.tsx:50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L50) — `export default function KbIndexVersionsSection({`
- [web/components/knowledge/KbIndexVersionsSection.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L56) — `const [submitting, setSubmitting] = useState(false);`
- [web/components/knowledge/KbIndexVersionsSection.tsx:57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L57) — `const [modelDialogOpen, setModelDialogOpen] = useState(false);`
- [web/components/knowledge/KbIndexVersionsSection.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L59) — `useState<LightRagRebuildConfig | null>(null);`
- [web/components/knowledge/KbIndexVersionsSection.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L60) — `const [dialogError, setDialogError] = useState<string | null>(null);`
- [web/components/knowledge/KbIndexVersionsSection.tsx:61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L61) — `const [configLoading, setConfigLoading] = useState(false);`
- [web/components/knowledge/KbIndexVersionsSection.tsx:363](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L363) — `title={t("Rebuild index with current defaults")}`
- [web/components/knowledge/KbIndexVersionsSection.tsx:422](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L422) — `title={t("Rebuild configuration")}`
- [web/components/knowledge/KbUpdateHistory.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbUpdateHistory.tsx#L4) — `import { useState } from "react";`


## S127 — Kiwix connection

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Modal

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Knowledge Center source connector

**Purpose:** Kiwix service connection form

**Visible sections:** Kiwix service connection form

**User actions:** Enter/probe/connect source; cancel

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/knowledge/ConnectKiwixModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx)

**Reusable components:** KiwixArchive; Loader2; Modal; Server

**Source evidence:**

- [web/components/knowledge/ConnectKiwixModal.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L3) — `import { useState } from "react";`
- [web/components/knowledge/ConnectKiwixModal.tsx:15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L15) — `export default function ConnectKiwixModal({ onClose, onConnect }: Props) {`
- [web/components/knowledge/ConnectKiwixModal.tsx:17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L17) — `const [name, setName] = useState("");`
- [web/components/knowledge/ConnectKiwixModal.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L18) — `const [serverUrl, setServerUrl] = useState("");`
- [web/components/knowledge/ConnectKiwixModal.tsx:19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L19) — `const [zimName, setZimName] = useState("");`
- [web/components/knowledge/ConnectKiwixModal.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L20) — `const [verifiedTitle, setVerifiedTitle] = useState("");`
- [web/components/knowledge/ConnectKiwixModal.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L21) — `const [catalogQuery, setCatalogQuery] = useState("");`
- [web/components/knowledge/ConnectKiwixModal.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L22) — `const [archives, setArchives] = useState<KiwixArchive[]>([]);`
- [web/components/knowledge/ConnectKiwixModal.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L23) — `const [catalogSearched, setCatalogSearched] = useState(false);`
- [web/components/knowledge/ConnectKiwixModal.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L24) — `const [browsing, setBrowsing] = useState(false);`


## S128 — Server folder chooser

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Dialog

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Workspace settings and linked-folder controls

**Purpose:** Allowed server folders

**Visible sections:** Allowed server folders; system workspace snapshot

**User actions:** Browse permitted server folder; choose root; inspect snapshot

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/workspaces/ServerFolderPicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx), [`web/components/workspaces/SystemWorkspaceSnapshot.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/SystemWorkspaceSnapshot.tsx)

**Reusable components:** ArrowUp; ChevronRight; Dialog; Folder; Link; RefreshCw; ServerFolderListing; Snapshot

**Source evidence:**

- [web/components/workspaces/ServerFolderPicker.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L3) — `import { useEffect, useState } from 'react'`
- [web/components/workspaces/ServerFolderPicker.tsx:15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L15) — `export function ServerFolderPicker({`
- [web/components/workspaces/ServerFolderPicker.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L23) — `const [path, setPath] = useState('')`
- [web/components/workspaces/ServerFolderPicker.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L24) — `const [listing, setListing] = useState<ServerFolderListing | null>(null)`
- [web/components/workspaces/ServerFolderPicker.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L25) — `const [loading, setLoading] = useState(true)`
- [web/components/workspaces/ServerFolderPicker.tsx:26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L26) — `const [saving, setSaving] = useState(false)`
- [web/components/workspaces/ServerFolderPicker.tsx:27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L27) — `const [error, setError] = useState('')`
- [web/components/workspaces/ServerFolderPicker.tsx:28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L28) — `const [filter, setFilter] = useState('')`
- [web/components/workspaces/ServerFolderPicker.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L29) — `const [attempt, setAttempt] = useState(0)`
- [web/components/workspaces/ServerFolderPicker.tsx:83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L83) — `title={t('Choose a server folder')}`


## S129 — Workspace resource assignment

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Workspace settings

**Purpose:** Account resources assigned to workspace

**Visible sections:** Account resources assigned to workspace; workspace instructions

**User actions:** Select bindings; edit allowed instructions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/workspaces/WorkspaceResourcePicker.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx), [`web/components/workspaces/WorkspaceInstructionsField.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceInstructionsField.tsx)

**Reusable components:** Link; WorkspaceResourceCatalog

**Source evidence:**

- [web/components/workspaces/WorkspaceResourcePicker.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L3) — `import { useEffect, useState } from 'react'`
- [web/components/workspaces/WorkspaceResourcePicker.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L12) — `export function WorkspaceResourcePicker({`
- [web/components/workspaces/WorkspaceResourcePicker.tsx:22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L22) — `const [catalog, setCatalog] = useState<WorkspaceResourceCatalog | null>(null)`
- [web/components/workspaces/WorkspaceResourcePicker.tsx:23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L23) — `const [error, setError] = useState('')`
- [web/components/workspaces/WorkspaceResourcePicker.tsx:24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L24) — `const [attempt, setAttempt] = useState(0)`
- [web/components/workspaces/WorkspaceResourcePicker.tsx:56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L56) — `{error && (`
- [web/components/workspaces/WorkspaceResourcePicker.tsx:106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L106) — `{!catalog && !error && (`
- [web/components/workspaces/WorkspaceInstructionsField.tsx:7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceInstructionsField.tsx#L7) — `export function WorkspaceInstructionsField({`


## S130 — Settings readiness and guided setup

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Overlay

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Settings shell and setup entry

**Purpose:** Readiness

**Visible sections:** Readiness; presets; guided tour overlay; module inventory

**User actions:** Inspect/setup; apply permitted preset; step/dismiss tour; manage supported modules

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/settings/SettingsReadinessPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx), [`web/components/settings/SettingsPresetsPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx), [`web/components/settings/SettingsTourOverlay.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsTourOverlay.tsx), [`web/components/settings/ModulesPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModulesPanel.tsx)

**Reusable components:** ArrowUpRight; Check; ChevronLeft; ChevronRight; DOMRect; Link; Loader2; ProviderIcon; ReadinessGroup; ReadinessRow; ReadinessSeverity; ReadinessState; Record; RefreshCcw; ServiceName; SettingsPreset; SettingsReadinessSnapshot; Sparkles

**Source evidence:**

- [web/components/settings/SettingsReadinessPanel.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L3) — `import { useCallback, useEffect, useMemo, useState } from "react";`
- [web/components/settings/SettingsReadinessPanel.tsx:119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L119) — `export default function SettingsReadinessPanel({`
- [web/components/settings/SettingsReadinessPanel.tsx:126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L126) — `const [snapshot, setSnapshot] = useState<SettingsReadinessSnapshot | null>(`
- [web/components/settings/SettingsReadinessPanel.tsx:129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L129) — `const [loading, setLoading] = useState(false);`
- [web/components/settings/SettingsReadinessPanel.tsx:130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L130) — `const [error, setError] = useState(false);`
- [web/components/settings/SettingsReadinessPanel.tsx:236](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L236) — `<h2`
- [web/components/settings/SettingsReadinessPanel.tsx:253](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L253) — `{loading ? (`
- [web/components/settings/SettingsReadinessPanel.tsx:263](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L263) — `{error && (`
- [web/components/settings/SettingsReadinessPanel.tsx:269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L269) — `{!snapshot && !error && (`
- [web/components/settings/SettingsReadinessPanel.tsx:284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L284) — `{attention.length === 0 ? (`


## S131 — Provider credential and test subpanels

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Settings provider/model editor

**Purpose:** Provider creation/discovery/test

**Visible sections:** Provider creation/discovery/test; backend OAuth/profile credential setup

**User actions:** Add/discover/test; follow backend-specific authentication instructions

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/settings/AddProviderPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx), [`web/components/settings/ProviderModelDiscovery.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx), [`web/components/settings/ModelTestPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelTestPanel.tsx), [`web/components/settings/CodexOAuthCard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx), [`web/components/settings/CodeBuddyAuthCard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx)

**Reusable components:** AbortController; ApiFormat; Button; CheckCircle2; CircleAlert; CodeBuddyAuthStatus; CodexLoginStart; CodexOAuthStatus; DiscoveryForm; ExternalLink; FlaskConical; Loader2; LogIn; LogOut; PlugZap; ProviderIcon; ProviderProtocol; Record; RefreshCw; ShieldCheck; Tooltip; Unplug

**Source evidence:**

- [web/components/settings/AddProviderPanel.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L3) — `import { useId, useState } from 'react'`
- [web/components/settings/AddProviderPanel.tsx:30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L30) — `export function ProviderProtocol({`
- [web/components/settings/AddProviderPanel.tsx:60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L60) — `export function AddProviderPanel({`
- [web/components/settings/AddProviderPanel.tsx:76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L76) — `const [filter, setFilter] = useState<string>('all')`
- [web/components/settings/AddProviderPanel.tsx:77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L77) — `const [query, setQuery] = useState('')`
- [web/components/settings/AddProviderPanel.tsx:78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L78) — `const [name, setName] = useState('')`
- [web/components/settings/AddProviderPanel.tsx:79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L79) — `const [url, setUrl] = useState('')`
- [web/components/settings/AddProviderPanel.tsx:80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L80) — `const [protocol, setProtocol] = useState<ApiFormat>('openai_chat')`
- [web/components/settings/ProviderModelDiscovery.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L3) — `import { useEffect, useId, useRef, useState } from "react";`
- [web/components/settings/ProviderModelDiscovery.tsx:46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L46) — `export function ProviderModelDiscovery(props: DiscoveryProps) {`


## S132 — Partner link and archive selection

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Modal

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Partner detail or group round

**Purpose:** Link partner

**Visible sections:** Link partner; archived messages; group invocation trace

**User actions:** Link; inspect/restore supported archive; inspect invocation

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/partners/PartnerLinkModal.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx), [`web/components/partners/PartnerArchives.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx), [`web/components/partners/group/InvocationCard.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/InvocationCard.tsx)

**Reusable components:** Archive; ArrowRight; AssistantResponse; ChannelIcon; Check; Clock3; Copy; HTMLDivElement; HistoryMessage; InlineFileCardProvider; Link2; Loader2; MessageSquareText; PartnerLink; PartnerLinkCode; PartnerSessionInfo; RefreshCw; RotateCcw; Tooltip; Trash2; User; Users

**Source evidence:**

- [web/components/partners/PartnerLinkModal.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L13) — `import { useCallback, useEffect, useState } from "react";`
- [web/components/partners/PartnerLinkModal.tsx:25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L25) — `export default function PartnerLinkModal({`
- [web/components/partners/PartnerLinkModal.tsx:35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L35) — `const [links, setLinks] = useState<PartnerLink[]>([]);`
- [web/components/partners/PartnerLinkModal.tsx:36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L36) — `const [code, setCode] = useState<PartnerLinkCode | null>(null);`
- [web/components/partners/PartnerLinkModal.tsx:37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L37) — `const [loading, setLoading] = useState(true);`
- [web/components/partners/PartnerLinkModal.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L38) — `const [issuing, setIssuing] = useState(false);`
- [web/components/partners/PartnerLinkModal.tsx:39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L39) — `const [copied, setCopied] = useState(false);`
- [web/components/partners/PartnerLinkModal.tsx:40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L40) — `const [error, setError] = useState("");`
- [web/components/partners/PartnerLinkModal.tsx:104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L104) — `<h2 className="text-[15px] font-semibold text-[var(--foreground)]">`
- [web/components/partners/PartnerLinkModal.tsx:169](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L169) — `{error ? (`


## S133 — Memory processing run

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Embedded component

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Memory hub/workbench

**Purpose:** Memory operation progress

**Visible sections:** Memory operation progress; run detail; archived notice

**User actions:** Run/inspect/cancel only where owner offers action

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/memory/MemoryRunPanel.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx), [`web/components/memory/MemoryArchivedBanner.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryArchivedBanner.tsx)

**Reusable components:** AlertCircle; Archive; Bot; ChevronDown; ChevronRight; ChevronUp; Disclosure; EmptyTrace; HTMLDivElement; Icon; LLMOption; LLMSelection; LLMTurnCard; Loader2; MemorySettingsDTO; ModelPill; NumberInput; Octagon; Record; RotateCcw; RunMode; Send; SystemEventRow; Tooltip; Trash2; Turn; TurnCard; Undo2

**Source evidence:**

- [web/components/memory/MemoryRunPanel.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L4) — `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [web/components/memory/MemoryRunPanel.tsx:59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L59) — `export default function MemoryRunPanel({`
- [web/components/memory/MemoryRunPanel.tsx:69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L69) — `const [mode, setMode] = useState<RunMode>("update");`
- [web/components/memory/MemoryRunPanel.tsx:73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L73) — `const [overrides, setOverrides] = useState<Record<RunMode, number | null>>({`
- [web/components/memory/MemoryRunPanel.tsx:88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L88) — `const [selection, setSelection] = useState<LLMSelection | null>(null);`
- [web/components/memory/MemoryRunPanel.tsx:89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L89) — `const [activeDefault, setActiveDefault] = useState<LLMSelection | null>(null);`
- [web/components/memory/MemoryRunPanel.tsx:90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L90) — `const [modelOptions, setModelOptions] = useState<LLMOption[]>([]);`
- [web/components/memory/MemoryRunPanel.tsx:91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L91) — `const [modelLoading, setModelLoading] = useState(true);`
- [web/components/memory/MemoryRunPanel.tsx:92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L92) — `const [modelError, setModelError] = useState(false);`
- [web/components/memory/MemoryRunPanel.tsx:93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L93) — `const [settings, setSettings] = useState<MemorySettingsDTO | null>(null);`


## S134 — Shared confirmation

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Dialog

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Delete/reset/archive/discard owners

**Purpose:** Action-specific destructive copy

**Visible sections:** Action-specific destructive copy; confirm/cancel; busy state

**User actions:** Confirm or cancel the named operation

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/ui/ConfirmDialog.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/ui/ConfirmDialog.tsx), [`web/components/space/learning/ConfirmDialog.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ConfirmDialog.tsx)

**Reusable components:** AlertTriangle; HTMLElement; Loader2

**Source evidence:**

- [web/components/ui/ConfirmDialog.tsx:29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/ui/ConfirmDialog.tsx#L29) — `export function ConfirmDialog({`
- [web/components/ui/ConfirmDialog.tsx:70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/ui/ConfirmDialog.tsx#L70) — `<h2 className="text-base font-semibold text-[var(--foreground)]">`
- [web/components/space/learning/ConfirmDialog.tsx:8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ConfirmDialog.tsx#L8) — `export function ConfirmDialog({`
- [web/components/space/learning/ConfirmDialog.tsx:52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ConfirmDialog.tsx#L52) — `<h2 id="confirm-dialog-title" className="text-base font-semibold">`


## S135 — Shared transient feedback

**Evidence label:** VERIFIED — surface/component wiring exists in source; runtime appearance remains UNVERIFIED

**Classification:** Overlay

**Web route:** No independent route; hosted by parent

**Parent layout:** host surface

**Entry points:** Root layout and feature owners

**Purpose:** Toast feedback

**Visible sections:** Toast feedback; protocol mismatch; settings load status

**User actions:** Dismiss/retry/recover as offered by owning notice

**Modals / dialogs / drawers / sheets:** No separate overlay established for this surface; shared host overlays may apply.

**Loading state:** UNVERIFIED — per-control busy/load behavior; inspect owning state excerpts

**Empty state:** UNVERIFIED — payload-dependent or not applicable; no generic empty state specified

**Error state:** UNVERIFIED — exact runtime failure presentation; source evidence index preserves branches

**Success / completed state:** VERIFIED — owning source renders the named operation/content; successful backend operation UNVERIFIED

**Permissions:** Account/workspace scope and server authorization apply. Do not infer write permission from navigation visibility.

**Dependencies:** Owning feature store and current account/workspace; see source imports.

**Mobile adaptation:** PROPOSED — Retain host ownership and exact action eligibility. Use a bottom sheet for short contextual choices, full-height modal for long editable forms, and inline treatment for small status/content elements; no new product feature is introduced.

**Source components:** [`web/components/common/ToastViewport.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx), [`web/features/chat/components/turn/ProtocolMismatchNotice.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/turn/ProtocolMismatchNotice.tsx), [`web/components/settings/SettingsLoadStatusBanner.tsx`](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsLoadStatusBanner.tsx)

**Reusable components:** AlertTriangle; Button; InlineAlert; Loader2; Notification; RefreshCw

**Source evidence:**

- [web/components/common/ToastViewport.tsx:4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx#L4) — `import { useEffect, useState } from "react";`
- [web/components/common/ToastViewport.tsx:18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx#L18) — `export default function ToastViewport() {`
- [web/components/common/ToastViewport.tsx:20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx#L20) — `const [toasts, setToasts] = useState<Notification[]>([]);`
- [web/components/common/ToastViewport.tsx:38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx#L38) — `if (toasts.length === 0) return null;`
- [web/features/chat/components/turn/ProtocolMismatchNotice.tsx:12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/turn/ProtocolMismatchNotice.tsx#L12) — `export function ProtocolMismatchNotice({`
- [web/features/chat/components/turn/ProtocolMismatchNotice.tsx:21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/turn/ProtocolMismatchNotice.tsx#L21) — `title={t("Frontend update required")}`
- [web/components/settings/SettingsLoadStatusBanner.tsx:3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsLoadStatusBanner.tsx#L3) — `import { useState } from "react";`
- [web/components/settings/SettingsLoadStatusBanner.tsx:13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsLoadStatusBanner.tsx#L13) — `export function SettingsLoadStatusBanner() {`
- [web/components/settings/SettingsLoadStatusBanner.tsx:16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsLoadStatusBanner.tsx#L16) — `const [retrying, setRetrying] = useState(false);`

