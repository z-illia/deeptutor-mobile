# Source evidence index

VERIFIED source excerpts. This mechanically selected index assists review; an identifier is not proof that a visual branch is reachable. Screen interpretation is in screen-inventory.md.

### web/app/(admin)/admin/users/page.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L4): `import { Fragment, useEffect, useState, useCallback } from "react";`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L60): `const [currentUser, setCurrentUser] = useState<string | null>(null);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L61): `const [users, setUsers] = useState<UserRecord[]>([]);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L62): `const [loading, setLoading] = useState(true);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L63): `const [error, setError] = useState("");`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L64): `const [actionError, setActionError] = useState("");`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L65): `const [expandedUserId, setExpandedUserId] = useState<string | null>(null);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L66): `const [showCreateDialog, setShowCreateDialog] = useState(false);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L67): `const [showImportDialog, setShowImportDialog] = useState(false);`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L68): `const [query, setQuery] = useState("");`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L69): `const [selectedUsernames, setSelectedUsernames] = useState<string[]>([]);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L70): `const [showBatchDeleteConfirm, setShowBatchDeleteConfirm] = useState(false);`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L71): `const [batchDeleteBusy, setBatchDeleteBusy] = useState(false);`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L72): `const [confirmTarget, setConfirmTarget] = useState<{`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L76): `const [confirmBusy, setConfirmBusy] = useState(false);`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L77): `const [createUsername, setCreateUsername] = useState("");`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L78): `const [createPassword, setCreatePassword] = useState("");`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L79): `const [createPreset, setCreatePreset] = useState<AccountPreset>("standard");`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L80): `const [createSubmitting, setCreateSubmitting] = useState(false);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L81): `const [createError, setCreateError] = useState("");`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L82): `const [importFile, setImportFile] = useState<File | null>(null);`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L83): `const [importSubmitting, setImportSubmitting] = useState(false);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L84): `const [importError, setImportError] = useState("");`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L85): `const [importResult, setImportResult] = useState<UserImportResult | null>(null);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L103): `router.replace("/login");`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L107): `router.replace("/");`
- [237](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L237): `if (batchDeleteBusy || selectedUsernames.length === 0) return;`
- [279](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L279): `if (selectedUsernames.length === 0) return;`
- [349](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L349): `className={loading ? "animate-spin" : ""}`
- [363](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L363): `{!loading && !error && users.length > 0 && (`
- [394](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L394): `{!loading && !error && selectedUsernames.length > 0 && (`
- [418](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L418): `{loading ? (`
- [434](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L434): `) : error ? (`
- [438](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L438): `) : users.length === 0 ? (`
- [461](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L461): `) : filteredUsers.length === 0 ? (`
- [488](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L488): `disabled={selectableFilteredUsers.length === 0}`
- [704](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L704): `<ConfirmDialog`
- [706](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L706): `title={`
- [771](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L771): `<ConfirmDialog`
- [773](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L773): `title={t("Delete users")}`
- [799](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L799): `role="dialog"`
- [923](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(admin)/admin/users/page.tsx#L923): `role="dialog"`

### web/app/(auth)/login/page.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L3): `import { Suspense, useCallback, useState, useEffect } from "react";`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L29): `const [username, setUsername] = useState("");`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L30): `const [password, setPassword] = useState("");`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L31): `const [error, setError] = useState("");`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L32): `const [loading, setLoading] = useState(false);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L38): `router.replace(resolvedNext());`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L43): `if (first) router.replace("/register");`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L58): `router.replace(`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L62): `setError(result.error ?? t("Login failed"));`
- [138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L138): `{error && (`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/login/page.tsx#L154): `{loading ? t("Signing in…") : t("Sign in")}`

### web/app/(auth)/register/page.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L3): `import { useState, useEffect } from "react";`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L13): `const [username, setUsername] = useState("");`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L14): `const [password, setPassword] = useState("");`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L15): `const [confirmPassword, setConfirmPassword] = useState("");`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L16): `const [error, setError] = useState("");`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L17): `const [loading, setLoading] = useState(false);`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L18): `const [isFirst, setIsFirst] = useState(false);`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L19): `const [checkingFirst, setCheckingFirst] = useState(true);`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L24): `if (status?.authenticated) router.replace("/");`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L47): `router.replace("/login?registered=1");`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L49): `setError(result.error ?? t("Registration failed"));`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L155): `{error && (`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(auth)/register/page.tsx#L171): `{loading ? t("Creating account…") : t("Create account")}`

### web/app/(settings)/settings/page.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(settings)/settings/page.tsx#L13): `router.replace(`

### web/app/(utility)/avatar-preview/page.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L5): `import { useEffect, useState } from "react";`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L60): `const [phase, setPhase] = useState(0);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L61): `const [auto, setAuto] = useState(true);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/avatar-preview/page.tsx#L62): `const [size, setSize] = useState(12);`

### web/app/(utility)/memory/resolve/page.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/resolve/page.tsx#L10): `import { Suspense, useEffect, useState } from "react";`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/resolve/page.tsx#L27): `const [error, setError] = useState<string | null>(null);`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/memory/resolve/page.tsx#L52): `router.replace(`

### web/app/(utility)/profile/page.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L4): `import { useCallback, useEffect, useRef, useState } from "react";`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L103): `const [profile, setProfile] = useState<ProfileInfo | null>(null);`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L104): `const [loading, setLoading] = useState(true);`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L105): `const [busy, setBusy] = useState(false);`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L106): `const [error, setError] = useState<string | null>(null);`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L109): `const [currentPassword, setCurrentPassword] = useState("");`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L110): `const [newPassword, setNewPassword] = useState("");`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L111): `const [confirmPassword, setConfirmPassword] = useState("");`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L112): `const [passwordBusy, setPasswordBusy] = useState(false);`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L113): `const [passwordNotice, setPasswordNotice] = useState<string | null>(null);`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L114): `const [passwordError, setPasswordError] = useState<string | null>(null);`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L123): `router.replace("/");`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L127): `router.replace("/login");`
- [193](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L193): `router.replace("/login");`
- [263](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L263): `<PageHeader title={t("My profile")} description={t("View your account and personalize your avatar")} />`
- [266](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L266): `{error && (`
- [272](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/profile/page.tsx#L272): `{loading ? (`

### web/app/(utility)/session-handoff/page.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L3): `import { useCallback, useEffect, useState } from "react";`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L15): `const [publicOrigin, setPublicOrigin] = useState("https://");`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L16): `const [handoff, setHandoff] = useState<SessionHandoff | null>(null);`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L17): `const [loading, setLoading] = useState(false);`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L18): `const [error, setError] = useState("");`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L19): `const [copied, setCopied] = useState(false);`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L25): `if (!status?.enabled || !status.authenticated) router.replace("/login");`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L102): `{loading ? t("Creating…") : t("Create link")}`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/session-handoff/page.tsx#L106): `{error && (`

### web/app/(utility)/settings/progress/page.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L4): `import { useEffect, useState } from "react";`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L19): `const [records, setRecords] = useState<LearningRecords | null>(null);`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L20): `const [materialTitles, setMaterialTitles] = useState<Record<string, string>>({});`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L21): `const [error, setError] = useState(false);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L42): `<PageHeader title={t("Learning progress")} description={t("Review your own reading and learning activity.")} />`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L43): `{error ? (`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L63): `{progress.length === 0 ? (`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(utility)/settings/progress/page.tsx#L95): `{activities.length === 0 ? (`

### web/app/(workspace)/co-writer/page.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L5): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L54): `const [open, setOpenState] = useState(false);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L55): `const [confirming, setConfirming] = useState(false);`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L99): `<div className="dt-popover dt-notes-card-popover" role="menu">`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L101): `role="menuitem"`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L120): `role="menuitem"`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L132): `<button role="menuitem" className="dt-menu-item is-danger" onClick={() => setConfirming(true)}>`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L147): `const [pages, setPages] = useState<NoteSummary[]>([]);`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L148): `const [loading, setLoading] = useState(true);`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L149): `const [creating, setCreating] = useState(false);`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L150): `const [importing, setImporting] = useState(false);`
- [151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L151): `const [busyId, setBusyId] = useState<string | null>(null);`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L152): `const [query, setQuery] = useState("");`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L153): `const [error, setError] = useState("");`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L178): `router.push('/co-writer/${page.id}');`
- [193](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L193): `router.push('/co-writer/${document.id}');`
- [273](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L273): `title={t("Learning notebook")}`
- [300](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L300): `{error ? <div className="dt-notes-error" role="alert">{error}</div> : null}`
- [302](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L302): `{loading ? (`
- [308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/page.tsx#L308): `) : pages.length === 0 ? (`

### web/app/(workspace)/co-writer/sampleTemplate.ts

- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/co-writer/sampleTemplate.ts#L36): `The <abbr title="Large Language Model">LLM</abbr> layer powers DeepTutor while the <abbr title="Retrieval Augmented Generation">RAG</abbr> layer provides grounded knowledge support.`

### web/app/(workspace)/learning/books/BooksRoute.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L3): `import { Suspense, useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react'`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L64): `return !!page && page.blocks.length === 0 && (page.block_count ?? 0) > 0`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L112): `const [books, setBooks] = useState<Book[]>([])`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L113): `const [canCreateBook, setCanCreateBook] = useState(true)`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L114): `const [loadingBooks, setLoadingBooks] = useState(true)`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L115): `const [booksError, setBooksError] = useState<string | null>(null)`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L116): `const [view, setView] = useState<View>(requestedBookId ? 'opening' : requestedLearningCreation() ? 'creator' : 'list')`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L118): `const [selectedBookId, setSelectedBookId] = useState<string | null>(null)`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L120): `const [detail, setDetail] = useState<BookDetail | null>(null)`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L121): `const [selectedPageId, setSelectedPageId] = useState<string | null>(null)`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L124): `const [creating, setCreating] = useState(false)`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L125): `const [confirmingProposal, setConfirmingProposal] = useState(false)`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L126): `const [pendingProposal, setPendingProposal] = useState<BookProposal | null>(null)`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L127): `const [pendingBook, setPendingBook] = useState<Book | null>(null)`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L130): `const [confirmingSpine, setConfirmingSpine] = useState(false)`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L133): `const [compilingPageId, setCompilingPageId] = useState<string | null>(null)`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L136): `const [pendingDeepDiveTopic, setPendingDeepDiveTopic] = useState<string | null>(null)`
- [137](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L137): `const [chatOpen, setChatOpen] = useState(Boolean(requestedChatId))`
- [138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L138): `const [shownChatId, setShownChatId] = useState(requestedChatId)`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L143): `const [rebuildingBook, setRebuildingBook] = useState(false)`
- [144](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L144): `const [resumingBook, setResumingBook] = useState(false)`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L145): `const [pausingBook, setPausingBook] = useState(false)`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L146): `const [supplementingBlockId, setSupplementingBlockId] = useState<string | null>(null)`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L147): `const [learningCaptures, setLearningCaptures] = useState<LearningCapture[]>([])`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L148): `const [loadingLearningCaptures, setLoadingLearningCaptures] = useState(false)`
- [422](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L422): `if (requestedBookId) router.push(bookRoute())`
- [427](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L427): `router.push(targetPath)`
- [506](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L506): `router.replace(bookRoute())`
- [581](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L581): `router.push(bookRoute(result.book.id))`
- [685](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/BooksRoute.tsx#L685): `router.push(bookRoute(selectedBookId, pageId))`

### web/app/(workspace)/learning/books/components/BookChatPanel.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L9): `import { useEffect, useLayoutEffect, useRef, useState } from "react";`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L113): `const [messages, setMessages] = useState<ChatMessage[]>([]);`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L114): `const [input, setInput] = useState("");`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L115): `const [busy, setBusy] = useState(false);`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L116): `const [width, setWidth] = useState(360);`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L117): `const [attachments, setAttachments] = useState<PendingAttachment[]>([]);`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L119): `const [attachmentError, setAttachmentError] = useState<string | null>(null);`
- [385](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L385): `if ((!text && attachments.length === 0) || busy || !book || !page) return;`
- [491](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L491): `{messages.length === 0 ? (`
- [625](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookChatPanel.tsx#L625): `(!input.trim() && attachments.length === 0) ||`

### web/app/(workspace)/learning/books/components/BookCreator.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L4): `import { useEffect, useRef, useState, type ReactNode } from 'react'`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L27): `const BOOK_LANGUAGES: Array<{ code: string; label: string }> = [`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L28): `{ code: 'auto', label: 'Auto' },`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L29): `{ code: 'en', label: 'English' },`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L30): `{ code: 'zh', label: '简体中文' },`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L31): `{ code: 'zh-tw', label: '繁體中文' },`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L32): `{ code: 'ja', label: '日本語' },`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L33): `{ code: 'ko', label: '한국어' },`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L34): `{ code: 'es', label: 'Español' },`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L35): `{ code: 'fr', label: 'Français' },`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L36): `{ code: 'de', label: 'Deutsch' },`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L37): `{ code: 'uk', label: 'Українська' },`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L38): `{ code: 'ru', label: 'Русский' },`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L39): `{ code: 'pt', label: 'Português' },`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L40): `{ code: 'it', label: 'Italiano' },`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L41): `{ code: 'tr', label: 'Türkçe' },`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L42): `{ code: 'vi', label: 'Tiếng Việt' },`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L45): `const DEPTH_OPTIONS: Array<{ value: BookDepth; label: string; hint: string }> = [`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L48): `label: 'Brief',`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L53): `label: 'Standard',`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L58): `label: 'Deep',`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L78): `loading?: boolean`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L97): `const [intent, setIntent] = useState('')`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L98): `const [language, setLanguage] = useState<string>('auto')`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L99): `const [depth, setDepth] = useState<BookDepth>('standard')`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L107): `const [selected, setSelected] = useState<Set<string>>(new Set())`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L108): `const [sourceError, setSourceError] = useState('')`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L109): `const [preparing, setPreparing] = useState(false)`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L115): `const [editProposal, setEditProposal] = useState<BookProposal | null>(null)`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L116): `const [formCollapsed, setFormCollapsed] = useState(false)`
- [162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L162): `? [{ icon: Database, label: t('{{count}} selected', { count: selected.size }) }]`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L168): `<PageHeader title={t('Create a new book')} description={t('Describe what you want to learn, then pick the knowledge sources to fuse into a structured, interactive book.')} />`
- [190](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L190): `{summaryChips.length === 0 ? (`
- [248](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L248): `<p role="alert" className="text-sm text-destructive">`
- [299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L299): `{loading ? (`
- [429](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookCreator.tsx#L429): `{effectiveKbs.length === 0 ? (`

### web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx#L71): `const [open, setOpen] = useState(false);`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx#L92): `const [now, setNow] = useState(() => Date.now());`
- [236](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx#L236): `role="dialog"`
- [248](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx#L248): `title={row.title}`
- [259](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx#L259): `title={`
- [322](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookGenerationActivity.tsx#L322): `label: string;`

### web/app/(workspace)/learning/books/components/BookHealthBanner.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L3): `import { useEffect, useState } from "react";`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L56): `const [kbDrift, setKbDrift] = useState<KbDrift | null>(null);`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L57): `const [logHealth, setLogHealth] = useState<LogHealth | null>(null);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L58): `const [generation, setGeneration] = useState<GenerationSummary | null>(null);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L59): `const [dismissed, setDismissed] = useState(false);`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L60): `const [busy, setBusy] = useState(false);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L61): `const [acknowledgeError, setAcknowledgeError] = useState<string | null>(null);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookHealthBanner.tsx#L62): `const [canForce, setCanForce] = useState(false);`

### web/app/(workspace)/learning/books/components/BookLibrary.tsx

- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L14): `import { useMemo, useState } from 'react'`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L33): `const STATUS_STYLES: Record<BookStatus, { label: string; className: string; dot: string }> = {`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L35): `label: 'Draft',`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L40): `label: 'Outline',`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L45): `label: 'Compiling',`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L50): `label: 'Paused',`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L55): `label: 'Ready',`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L60): `label: 'Error',`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L65): `label: 'Archived',`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L74): `error?: string | null`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L93): `const [query, setQuery] = useState('')`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L94): `const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null)`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L122): `title={t('Books')}`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L123): `subtitle={t('Generate, browse and study your AI-authored books.')}`
- [191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L191): `{error && <LearningErrorState message={error} onRetry={onRetry} />}`
- [192](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L192): `{loading ? (`
- [194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L194): `) : books.length === 0 ? (`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L195): `error ? null : (`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L196): `<EmptyState onNewBook={canCreate ? onNewBook : undefined} />`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L198): `) : filtered.length === 0 ? (`
- [283](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L283): `title={book.title || t('Untitled book')}`
- [284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L284): `subtitle={`
- [378](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L378): `label: string`
- [400](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookLibrary.tsx#L400): `title={t('No books yet')}`

### web/app/(workspace)/learning/books/components/BookSidebar.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookSidebar.tsx#L3): `import { useEffect, useState } from "react";`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookSidebar.tsx#L79): `const [collapsed, setCollapsed] = useState(false);`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookSidebar.tsx#L80): `const [confirmRebuild, setConfirmRebuild] = useState(false);`
- [164](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookSidebar.tsx#L164): `title={book.title || t("Untitled book")}`
- [231](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/BookSidebar.tsx#L231): `{pages.length === 0 ? (`

### web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx#L4): `import { useMemo, useState } from "react";`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx#L60): `const [showAll, setShowAll] = useState(false);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx#L61): `const [open, setOpen] = useState(true);`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx#L115): `{!open ? null : loading && filteredCaptures.length === 0 ? (`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/LearningCapturePanel.tsx#L119): `) : filteredCaptures.length === 0 ? (`

### web/app/(workspace)/learning/books/components/PageOutlineNav.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageOutlineNav.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageOutlineNav.tsx#L126): `const [activeId, setActiveId] = useState<string | null>(null);`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageOutlineNav.tsx#L133): `if (!scrollContainer || visibleBlocks.length === 0) return;`
- [138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageOutlineNav.tsx#L138): `if (elements.length === 0) return;`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageOutlineNav.tsx#L168): `if (visibleBlocks.length === 0) return null;`

### web/app/(workspace)/learning/books/components/PageReader.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L5): `import { useCallback, useEffect, useRef, useState } from "react";`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L102): `loading?: boolean;`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L150): `const [showInsertMenu, setShowInsertMenu] = useState(false);`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L152): `const [outlineCollapsed, setOutlineCollapsed] = useState(true);`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L153): `const [inserting, setInserting] = useState(false);`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L154): `const [scrollContainer, setScrollContainer] = useState<HTMLDivElement | null>(`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L157): `const [readingPercent, setReadingPercent] = useState(0);`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L158): `const [chapterHasScroll, setChapterHasScroll] = useState(false);`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L166): `const [headerCollapsed, setHeaderCollapsed] = useState(false);`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L167): `const [userToggled, setUserToggled] = useState(false);`
- [228](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L228): `page.blocks.length === 0 && (loading || (page.block_count ?? 0) > 0);`
- [353](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L353): `if (loading && page?.blocks.length === 0) return false;`
- [452](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L452): `!writing && !queued && page.blocks.length === 0 && (page.block_count ?? 0) > 0;`
- [455](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L455): `!!onCaptureSelection && !loading && page.blocks.length > 0;`
- [475](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L475): `title={page.title || t("Untitled chapter")}`
- [522](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L522): `{loading ? (`
- [527](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L527): `{loading ? t("Regenerating…") : t("Force regenerate")}`
- [556](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L556): `{(writing || hydrating) && page.blocks.length === 0 ? (`
- [569](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L569): `) : queued && page.blocks.length === 0 ? (`
- [609](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L609): `{loading ? (`
- [614](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L614): `{loading ? t("Regenerating…") : t("Regenerate page")}`
- [677](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L677): `{page.blocks.length === 0 && !writing && !queued && !hydrating && (`
- [801](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/PageReader.tsx#L801): `label: string;`

### web/app/(workspace)/learning/books/components/SpineEditor.tsx

- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L16): `import { useEffect, useMemo, useRef, useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L32): `label: string;`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L56): `label: string;`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L78): `label: "Theory",`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L83): `label: "Derivation",`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L89): `label: "History",`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L94): `label: "Practice",`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L100): `label: "Concept",`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L113): `loading?: boolean;`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L130): `const [chapters, setChapters] = useState<Chapter[]>(() =>`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L133): `const [autoCompile, setAutoCompile] = useState(true);`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L141): `const [blockTypes, setBlockTypes] = useState<string[] | null>(null);`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L142): `const [typeCatalog, setTypeCatalog] = useState<BlockTypeOption[]>([]);`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L143): `const [typesOpen, setTypesOpen] = useState(false);`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L196): `const [basis, setBasis] = useState<EstimateBasis | null>(null);`
- [582](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/SpineEditor.tsx#L582): `{loading ? (`

### web/app/(workspace)/learning/books/components/blocks/AnimationBlock.tsx

- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/AnimationBlock.tsx#L37): `if (!rawVideoUrl && artifacts.length === 0) {`

### web/app/(workspace)/learning/books/components/blocks/BlockBodyEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockBodyEditor.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockBodyEditor.tsx#L26): `const [draft, setDraft] = useState(initialValue);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockBodyEditor.tsx#L27): `const [saving, setSaving] = useState(false);`

### web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L3): `import { useEffect, useState } from "react";`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L104): `const [showTypeMenu, setShowTypeMenu] = useState(false);`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L105): `const [editingBody, setEditingBody] = useState(false);`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/BlockRenderer.tsx#L106): `const [confirmDelete, setConfirmDelete] = useState(false);`

### web/app/(workspace)/learning/books/components/blocks/ConceptGraphBlock.tsx

- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/ConceptGraphBlock.tsx#L116): `{index.chapters.length === 0 && (`

### web/app/(workspace)/learning/books/components/blocks/DeepDiveBlock.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/DeepDiveBlock.tsx#L3): `import { useState } from "react";`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/DeepDiveBlock.tsx#L39): `const [busy, setBusy] = useState<string | null>(null);`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/DeepDiveBlock.tsx#L41): `if (suggestions.length === 0) return null;`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/DeepDiveBlock.tsx#L45): `(index === 0 && Object.keys(pagesByTopic).length === 0`

### web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L3): `import { useState } from "react";`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L21): `const [idx, setIdx] = useState(0);`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L22): `const [showBack, setShowBack] = useState(false);`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/FlashCardsBlock.tsx#L23): `if (cards.length === 0) return null;`

### web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx#L3): `import { useEffect, useMemo, useRef, useState } from "react";`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx#L69): `const [gotSomethingWrong, setGotSomethingWrong] = useState(false);`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx#L77): `if (questions.length === 0) {`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx#L156): `const [selected, setSelected] = useState<string | null>(`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx#L159): `const [revealed, setRevealed] = useState(!!previous);`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx#L160): `const [selfGraded, setSelfGraded] = useState<boolean | null>(`
- [351](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/QuizBlock.tsx#L351): `label: string;`

### web/app/(workspace)/learning/books/components/blocks/TimelineBlock.tsx

- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/TimelineBlock.tsx#L17): `if (events.length === 0) return null;`

### web/app/(workspace)/learning/books/components/blocks/UserNoteBlock.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/UserNoteBlock.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/UserNoteBlock.tsx#L35): `const [editing, setEditing] = useState(autoEdit && editable);`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/UserNoteBlock.tsx#L36): `const [draft, setDraft] = useState(body);`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/books/components/blocks/UserNoteBlock.tsx#L37): `const [saving, setSaving] = useState(false);`

### web/app/(workspace)/learning/mastery/[pathId]/page.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L8): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L76): `const [topic, setTopic] = useState<MasteryTopic | null>(null);`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L77): `const [sessions, setSessions] = useState<TopicSession[]>([]);`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L78): `const [loading, setLoading] = useState(true);`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L79): `const [sessionsLoading, setSessionsLoading] = useState(true);`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L80): `const [sessionsError, setSessionsError] = useState(false);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L81): `const [error, setError] = useState<string | null>(null);`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L82): `const [selectedId, setSelectedId] = useState<string | null>(null);`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L83): `const [editorOpen, setEditorOpen] = useState(false);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L84): `const [confirmAction, setConfirmAction] = useState<"reset" | "delete" | null>(`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L87): `const [topicView, setTopicView] = useState<"outline" | "board">("outline");`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L88): `const [board, setBoard] = useState<BoardResult | null>(null);`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L89): `const [boardError, setBoardError] = useState(false);`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L90): `const [boardRequestNonce, setBoardRequestNonce] = useState(0);`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L91): `const [mutationBusy, setMutationBusy] = useState(false);`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L92): `const [retentionBusy, setRetentionBusy] = useState(false);`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L93): `const [retentionError, setRetentionError] = useState<string | null>(null);`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L94): `const [strategies, setStrategies] = useState<`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L97): `const [strategiesLoading, setStrategiesLoading] = useState(true);`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L98): `const [strategiesError, setStrategiesError] = useState<string | null>(null);`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L99): `const [strategyBusy, setStrategyBusy] = useState(false);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L100): `const [strategyError, setStrategyError] = useState<string | null>(null);`
- [357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L357): `router.replace(scopedUrl(MASTERY_HOME));`
- [368](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L368): `router.push(masterySessionsRoute(pathId));`
- [379](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L379): `router.push(masterySessionRoute(pathId, "review"));`
- [382](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L382): `if (loading && !topic) {`
- [778](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L778): `<ConfirmDialog`
- [779](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L779): `title={t("Reset learning progress?")}`
- [792](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L792): `<ConfirmDialog`
- [793](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/[pathId]/page.tsx#L793): `title={t("Permanently delete this topic?")}`

### web/app/(workspace)/learning/mastery/page.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L8): `useState,`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L29): `const [topics, setTopics] = useState<MasteryTopic[]>([]);`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L30): `const [loading, setLoading] = useState(true);`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L31): `const [error, setError] = useState<string | null>(null);`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L32): `const [wizardOpen, setWizardOpen] = useState(requestedLearningCreation);`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/mastery/page.tsx#L88): `router.push(masterySessionRoute(topic.path_id, "outline"));`

### web/app/(workspace)/learning/watching/page.tsx

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/learning/watching/page.tsx#L7): `redirect(READING_HOME + (query.size ? '?${query}' : ""));`

### web/app/(workspace)/page.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/page.tsx#L9): `redirect("/chat");`

### web/app/(workspace)/partners/[partnerId]/page.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L9): `import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L74): `const [tab, setTab] = useState<Tab>(`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L79): `const [partner, setPartner] = useState<PartnerInfo | null>(null);`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L80): `const [showLinkModal, setShowLinkModal] = useState(false);`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L90): `const [loading, setLoading] = useState(true);`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L91): `const [lifecycleBusy, setLifecycleBusy] = useState(false);`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L92): `const [toast, setToast] = useState("");`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L95): `const [chatMessages, setChatMessages] = useState<ExportableMessage[]>([]);`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L96): `const [archiveMessages, setArchiveMessages] = useState<ExportableMessage[]>(`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L99): `const [showSaveModal, setShowSaveModal] = useState(false);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L100): `const [archiveBusy, setArchiveBusy] = useState(false);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L103): `const [sessionKey, setSessionKey] = useState("");`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L104): `const [localSessionKey, setLocalSessionKey] = useState("");`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L105): `const [continuityEnabled, setContinuityEnabled] = useState(false);`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L106): `const [continuityReady, setContinuityReady] = useState(false);`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L107): `const [continuityBusy, setContinuityBusy] = useState(false);`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L108): `const [continuityError, setContinuityError] = useState(false);`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L109): `const [runtimeContinuityError, setRuntimeContinuityError] = useState(false);`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L110): `const [continuityRetry, setContinuityRetry] = useState(0);`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L111): `const [switchingSession, setSwitchingSession] = useState(false);`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L112): `const [chatBusy, setChatBusy] = useState(false);`
- [248](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L248): `router.replace('/partners/${encodeURIComponent(partnerId)}?${query}', { scroll: false });`
- [373](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L373): `if (!sessionKey || chatMessages.length === 0 || archiveBusy) return;`
- [448](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L448): `router.push("/partners");`
- [496](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L496): `const tabs: { key: Tab; label: string; icon: typeof MessageCircle }[] = [`
- [497](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L497): `{ key: "chat", label: t("Chat"), icon: MessageCircle },`
- [500](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L500): `{ key: "configure", label: t("Configure"), icon: Settings2 },`
- [501](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L501): `{ key: "channels", label: t("Channels"), icon: Radio },`
- [504](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L504): `{ key: "archive", label: t("History"), icon: Archive },`
- [625](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L625): `<div role="tablist" aria-label={partner.name} className="dt-bar-tabs">`
- [630](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/[partnerId]/page.tsx#L630): `role="tab"`

### web/app/(workspace)/partners/groups/[groupId]/page.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L3): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L44): `const [selectionError, setSelectionError] = useState("");`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L47): `const [group, setGroup] = useState<PartnerGroup | null>(null);`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L48): `const [loading, setLoading] = useState(true);`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L49): `const [editing, setEditing] = useState(false);`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L50): `const [panelOpen, setPanelOpen] = useState(false);`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L51): `const [sessionKey, setSessionKey] = useState("");`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L52): `const [sessionTitle, setSessionTitle] = useState("");`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L53): `const [groupMessages, setGroupMessages] = useState<PartnerGroupMessage[]>([]);`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L126): `{selectionError && <div role="alert" className="border-b border-border px-6 py-2 text-xs text-destructive">{selectionError}</div>}`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L178): `router.replace('/partners/groups/${encodeURIComponent(groupId)}?${new URLSearchParams({ session: key })}', { scroll: false });`
- [183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L183): `router.replace('/partners/groups/${encodeURIComponent(groupId)}', { scroll: false });`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L238): `onDeleted={() => router.push("/partners")}`
- [257](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L257): `const [partners, setPartners] = useState<PartnerInfo[]>([]);`
- [258](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L258): `const [name, setName] = useState(group.name);`
- [259](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L259): `const [description, setDescription] = useState(group.description);`
- [260](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L260): `const [members, setMembers] = useState<Set<string>>(`
- [263](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L263): `const [mode, setMode] = useState(group.discussion_mode);`
- [264](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L264): `const [saving, setSaving] = useState(false);`
- [265](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L265): `const [confirmingDelete, setConfirmingDelete] = useState(false);`
- [266](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L266): `const [error, setError] = useState("");`
- [356](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L356): `title={t("How they discuss")}`
- [397](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/[groupId]/page.tsx#L397): `{error ? (`

### web/app/(workspace)/partners/groups/new/page.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L4): `import { useEffect, useMemo, useState } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L20): `const [partners, setPartners] = useState<PartnerInfo[]>([]);`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L21): `const [loading, setLoading] = useState(true);`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L22): `const [name, setName] = useState("");`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L23): `const [description, setDescription] = useState("");`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L24): `const [selected, setSelected] = useState<Set<string>>(new Set());`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L25): `const [emoji, setEmoji] = useState("👥");`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L28): `const [color, setColor] = useState<string>(PARTNER_COLORS[0]);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L29): `const [mode, setMode] = useState("panel_parallel");`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L30): `const [creating, setCreating] = useState(false);`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L31): `const [error, setError] = useState("");`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L69): `router.push('/partners/groups/${encodeURIComponent(group.group_id)}');`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L85): `<PageHeader title={t("Create a Partner Group")} description={t("Choose at least two Partners, then how they should discuss.")} />`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L197): `{loading ? (`
- [266](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L266): `title={t("How they discuss")}`
- [272](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/groups/new/page.tsx#L272): `{error ? <p className="text-[12px] text-red-500">{error}</p> : null}`

### web/app/(workspace)/partners/new/page.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L11): `import { useEffect, useMemo, useState } from "react";`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L46): `const steps: { key: StepKey; label: string }[] = [`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L47): `{ key: "identity", label: t("Identity") },`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L48): `{ key: "soul", label: t("Soul") },`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L49): `{ key: "mind", label: t("Mind") },`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L50): `{ key: "library", label: t("Library") },`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L51): `{ key: "review", label: t("Review") },`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L53): `const [stepIndex, setStepIndex] = useState(0);`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L57): `const [name, setName] = useState("");`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L58): `const [description, setDescription] = useState("");`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L59): `const [face, setFace] = useState<FaceValue>({`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L64): `const [language, setLanguage] = useState("");`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L65): `const [soul, setSoul] = useState<SoulSpec>({ source: "default" });`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L66): `const [selection, setSelection] = useState<LLMSelection | null>(null);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L67): `const [backupSelection, setBackupSelection] = useState<LLMSelection | null>(`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L70): `const [workspaceId, setWorkspaceId] = useState("");`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L71): `const [workspaceName, setWorkspaceName] = useState("");`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L72): `const [assets, setAssets] = useState<AssetSelection>({`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L78): `const [llmOptions, setLLMOptions] = useState<LLMOption[]>([]);`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L79): `const [activeLLMDefault, setActiveLLMDefault] = useState<LLMSelection | null>(`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L82): `const [llmLoading, setLLMLoading] = useState(true);`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L83): `const [llmError, setLLMError] = useState(false);`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L85): `const [toolOptions, setToolOptions] = useState<ToolOptions | null>(null);`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L86): `const [enabledTools, setEnabledTools] = useState<string[]>([]);`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L87): `const [builtinTools, setBuiltinTools] = useState<string[]>([]);`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L88): `const [mcpTools, setMcpTools] = useState<string[]>([]);`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L89): `const [toolsTouched, setToolsTouched] = useState(false);`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L91): `const [creating, setCreating] = useState(false);`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L92): `const [error, setError] = useState("");`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L165): `router.push('/partners/${result.partner_id}');`
- [300](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L300): `<PageHeader title={stepTitle[step].title} description={stepTitle[step].subtitle} />`
- [476](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/new/page.tsx#L476): `{error && (`

### web/app/(workspace)/partners/page.tsx

- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L12): `import { useEffect, useState } from "react";`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L38): `const [partners, setPartners] = useState<PartnerInfo[]>([]);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L39): `const [groups, setGroups] = useState<PartnerGroup[]>([]);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L40): `const [loading, setLoading] = useState(true);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L81): `title={t("Partners")}`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L96): `{loading ? (`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L100): `) : partners.length === 0 ? (`
- [188](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L188): `{!loading && partners.length > 0 ? (`
- [192](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L192): `title={t("Groups")}`
- [205](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/partners/page.tsx#L205): `{groups.length === 0 ? (`

### web/app/(workspace)/whisper/page.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L41): `const [seat, setSeat] = useState<WhisperSeat>("visitor");`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L42): `const [roomId, setRoomId] = useState<string | null>(null);`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L43): `const [messages, setMessages] = useState<WhisperMessage[]>([]);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L44): `const [busy, setBusy] = useState(false);`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L45): `const [crisisHit, setCrisisHit] = useState(false);`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L46): `const [roomClosed, setRoomClosed] = useState(false);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L47): `const [draft, setDraft] = useState("");`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L48): `const [dtSessionId, setDtSessionId] = useState<string | null>(null);`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L49): `const [connected, setConnected] = useState(false);`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L50): `const [everConnected, setEverConnected] = useState(false);`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L340): `role="tablist"`
- [350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/(workspace)/whisper/page.tsx#L350): `role="tab"`

### web/app/handoff/page.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L3): `import { Suspense, useCallback, useEffect, useRef, useState } from "react";`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L18): `const [manualCode, setManualCode] = useState("");`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L19): `const [status, setStatus] = useState<"idle" | "working" | "error">("idle");`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L20): `const [error, setError] = useState("");`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/app/handoff/page.tsx#L30): `router.replace(next);`

### web/components/Geogebra.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx#L3): `import React, { useEffect, useRef, useState } from 'react'`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx#L111): `const [error, setError] = useState<string | null>(null)`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx#L112): `const [loading, setLoading] = useState(true)`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx#L113): `const [commandErrors, setCommandErrors] = useState<string[]>([])`
- [221](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx#L221): `{error ? (`
- [229](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx#L229): `role="alert"`
- [248](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Geogebra.tsx#L248): `{loading ? (`

### web/components/Mermaid.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Mermaid.tsx#L3): `import React, { useEffect, useRef, useState } from "react";`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Mermaid.tsx#L82): `const [svg, setSvg] = useState<string>("");`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Mermaid.tsx#L83): `const [error, setError] = useState<string | null>(null);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Mermaid.tsx#L84): `const [stable, setStable] = useState(false);`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Mermaid.tsx#L85): `const [id] = useState(() => 'mermaid-${++mermaidIdCounter}');`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/Mermaid.tsx#L86): `const [themeToken, setThemeToken] = useState(0);`

### web/components/SessionList.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/SessionList.tsx#L4): `import { useMemo, useState } from "react";`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/SessionList.tsx#L24): `loading?: boolean;`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/SessionList.tsx#L41): `const [editingId, setEditingId] = useState<string | null>(null);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/SessionList.tsx#L42): `const [draftTitle, setDraftTitle] = useState("");`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/SessionList.tsx#L120): `if (sessions.length === 0) {`

### web/components/UserAvatar.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/UserAvatar.tsx#L3): `import { createElement, useState } from "react";`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/UserAvatar.tsx#L97): `const [imageBroken, setImageBroken] = useState(false);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/UserAvatar.tsx#L102): `const [lastImageKey, setLastImageKey] = useState(imageKey);`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/UserAvatar.tsx#L143): `title={suppressTitle ? undefined : isAdmin ? '${username} — ${adminLabel}' : username}`

### web/components/access/CapabilityAccessContext.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/access/CapabilityAccessContext.tsx#L8): `useState,`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/access/CapabilityAccessContext.tsx#L54): `const [isAdmin, setIsAdmin] = useState(true);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/access/CapabilityAccessContext.tsx#L55): `const [hasLlm, setHasLlm] = useState(true);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/access/CapabilityAccessContext.tsx#L56): `const [loading, setLoading] = useState(true);`

### web/components/activity/ActivityHeader.tsx

- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/activity/ActivityHeader.tsx#L42): `label: ReactNode;`

### web/components/activity/ActivityRow.tsx

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/activity/ActivityRow.tsx#L7): `useState,`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/activity/ActivityRow.tsx#L101): `const [userOpen, setUserOpen] = useState<boolean | null>(null);`

### web/components/activity/ActivityStack.tsx

- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/activity/ActivityStack.tsx#L57): `label: ReactNode;`

### web/components/agents/ConnectedAgents.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L5): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L33): `const [backends, setBackends] = useState<SubagentBackendInfo[]>([]);`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L34): `const [connections, setConnections] = useState<SubagentConnection[]>([]);`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L35): `const [loading, setLoading] = useState(true);`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L36): `const [modalOpen, setModalOpen] = useState(false);`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L37): `const [busyName, setBusyName] = useState<string | null>(null);`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L89): `title={tr({ zh: "连接的智能体", en: "Connected agents" })}`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L108): `{loading ? (`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L120): `) : connections.length === 0 ? (`
- [203](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L203): `() => backends.map((b) => ({ kind: b.kind, label: b.display_name })),`
- [207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L207): `const [kind, setKind] = useState(options[0]?.kind ?? "");`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L208): `const [name, setName] = useState("");`
- [209](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L209): `const [cwd, setCwd] = useState("");`
- [210](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L210): `const [error, setError] = useState("");`
- [211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L211): `const [submitting, setSubmitting] = useState(false);`
- [336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/agents/ConnectedAgents.tsx#L336): `{error && (`

### web/components/auth/LogoutButton.tsx

- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/auth/LogoutButton.tsx#L23): `router.replace("/login");`

### web/components/auth/ProfileLink.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/auth/ProfileLink.tsx#L3): `import { useEffect, useState } from "react";`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/auth/ProfileLink.tsx#L18): `const [status, setStatus] = useState<AuthStatus | null>(null);`

### web/components/chat/BookReferencePicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L61): `const [books, setBooks] = useState<Book[]>([]);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L62): `const [details, setDetails] = useState<Record<string, BookDetail>>({});`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L63): `const [activeBookId, setActiveBookId] = useState<string | null>(null);`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L64): `const [selected, setSelected] = useState<SelectedBookReference[]>([]);`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L65): `const [query, setQuery] = useState("");`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L66): `const [loadingBooks, setLoadingBooks] = useState(false);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L67): `const [loadingDetail, setLoadingDetail] = useState(false);`
- [231](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L231): `title={t("Select Book Chapters")}`
- [232](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/BookReferencePicker.tsx#L232): `subtitle={t(`

### web/components/chat/HistorySessionPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L3): `import { useEffect, useMemo, useRef, useState } from "react";`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L62): `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L63): `const [selectedSessions, setSelectedSessions] = useState<`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L66): `const [query, setQuery] = useState("");`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L68): `const [loading, setLoading] = useState(false);`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L69): `const [searchResults, setSearchResults] = useState<SessionSearchResult[]>([]);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L70): `const [searchTotal, setSearchTotal] = useState(0);`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L71): `const [searchLoading, setSearchLoading] = useState(false);`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L72): `const [loadingMore, setLoadingMore] = useState(false);`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L80): `const [activeId, setActiveId] = useState<string | null>(null);`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L82): `const [details, setDetails] = useState<Record<string, SessionDetail>>({});`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L87): `const [previewLoadingId, setPreviewLoadingId] = useState<string | null>(null);`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L239): `title={t("Select History Sessions")}`
- [240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L240): `subtitle={t(`
- [508](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/HistorySessionPicker.tsx#L508): `if (turns.length === 0) {`

### web/components/chat/MemoryPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MemoryPicker.tsx#L3): `import { useEffect, useState } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MemoryPicker.tsx#L20): `label: string;`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MemoryPicker.tsx#L28): `label: "Summary",`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MemoryPicker.tsx#L35): `label: "Profile",`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MemoryPicker.tsx#L48): `const [selected, setSelected] = useState<SpaceMemoryFile[]>(initialFiles);`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MemoryPicker.tsx#L88): `title={t("Select Memory")}`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MemoryPicker.tsx#L89): `subtitle={t(`

### web/components/chat/MyAgentsPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L3): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L61): `label: string;`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L98): `const [sessions, setSessions] = useState<`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L101): `const [agents, setAgents] = useState<ImportAgent[]>([]);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L102): `const [selectedIds, setSelectedIds] = useState<string[]>([]);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L103): `const [query, setQuery] = useState("");`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L104): `const [activeAgent, setActiveAgent] = useState<string>(ALL);`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L105): `const [expanded, setExpanded] = useState<Set<string>>(new Set());`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L106): `const [loading, setLoading] = useState(false);`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L107): `const [preview, setPreview] = useState<PreviewState | null>(null);`
- [224](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L224): `label: labelForKey(key),`
- [246](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L246): `label: row.groupLabel,`
- [333](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L333): `title={t("Select agent conversations")}`
- [334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L334): `subtitle={t(`
- [388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L388): `) : loading ? (`
- [549](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L549): `label: string;`
- [624](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L624): `{loading ? (`
- [656](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/MyAgentsPicker.tsx#L656): `label: string;`

### web/components/chat/PersonaPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L24): `const [personas, setPersonas] = useState<PersonaInfo[]>([]);`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L25): `const [loading, setLoading] = useState(false);`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L26): `const [selected, setSelected] = useState<string | null>(initialPersona);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L27): `const [query, setQuery] = useState("");`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L84): `title={t("Select Persona")}`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L85): `subtitle={t(`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L133): `{loading ? (`
- [183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/PersonaPicker.tsx#L183): `{personas.length === 0`

### web/components/chat/QuestionBankPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L51): `const FILTER_MODES: { value: FilterMode; label: string }[] = [`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L52): `{ value: "all", label: "All" },`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L53): `{ value: "bookmarked", label: "Bookmarked" },`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L54): `{ value: "wrong", label: "Wrong Only" },`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L64): `const [entries, setEntries] = useState<NotebookEntry[]>([]);`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L65): `const [categories, setCategories] = useState<NotebookCategory[]>([]);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L66): `const [materials, setMaterials] = useState<QuestionBankMaterial[]>([]);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L67): `const [filter, setFilter] = useState<FilterMode>("all");`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L68): `const [activeCategoryId, setActiveCategoryId] = useState<number | null>(null);`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L69): `const [activeMaterialId, setActiveMaterialId] = useState("");`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L70): `const [selectedById, setSelectedById] = useState<Map<number, SelectedQuestionEntry>>(`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L73): `const [query, setQuery] = useState("");`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L74): `const [loading, setLoading] = useState(false);`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L195): `title={t("Select Question Bank Entries")}`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L196): `subtitle={t("Choose quiz questions to ground the next request.")}`
- [291](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L291): `{loading ? (`
- [369](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/QuestionBankPicker.tsx#L369): `{entries.length === 0`

### web/components/chat/ReadingReferencePicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L63): `const [materials, setMaterials] = useState<MaterialInfo[]>([]);`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L64): `const [details, setDetails] = useState<Record<string, MaterialDetail>>({});`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L65): `const [activeMaterialId, setActiveMaterialId] = useState<string | null>(null);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L66): `const [selected, setSelected] = useState<SelectedReadingReference[]>([]);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L67): `const [query, setQuery] = useState("");`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L68): `const [loadingMaterials, setLoadingMaterials] = useState(false);`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L69): `const [loadingDetail, setLoadingDetail] = useState(false);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L70): `const [error, setError] = useState<string | null>(null);`
- [321](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L321): `title={t("Select Reading Sections")}`
- [322](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L322): `subtitle={t(`
- [328](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L328): `{error ? (`
- [330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/ReadingReferencePicker.tsx#L330): `role="alert"`

### web/components/chat/home/AnswerModeMenu.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L4): `import { useEffect, useState, type ReactNode } from "react";`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L35): `loading?: boolean;`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L36): `error?: boolean;`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L45): `loading?: boolean;`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L46): `error?: boolean;`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L142): `const [personas, setPersonas] = useState<PersonaInfo[]>([]);`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L143): `const [query, setQuery] = useState("");`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L178): `<TraySection title={t("Response style")}>`
- [187](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L187): `title={t("Default")}`
- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L200): `title={item.name}`
- [207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L207): `<TraySection title={t("composer.tray.whoAnswers")} hint={t("composer.tray.whoAnswersHint")}>`
- [213](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L213): `title={t("composer.tray.deeptutor")}`
- [223](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L223): `title={item.name}`
- [233](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L233): `title={item.name}`
- [237](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L237): `{answerers.loading && <p className="dt-tray-empty">{t("Loading...")}</p>}`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L238): `{answerers.error && !answerers.loading && (`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L239): `<p role="alert" className="dt-tray-empty">`
- [243](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L243): `{!answerers.loading && !needle && !partnerRows.length && !agentRows.length && (`
- [325](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L325): `<TraySection title={t("Ask partner")} hint={t("composer.tray.askPartnerHint")}>`
- [337](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L337): `title={item.name}`
- [345](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L345): `<TraySection title={t("Organize partner discussion")}>`
- [357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L357): `title={item.name}`
- [365](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L365): `<TraySection title={t("Ask subagent")} hint={t("composer.tray.askAgentHint")}>`
- [378](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L378): `title={item.name}`
- [389](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L389): `{loading && <p className="dt-tray-empty">{t("Loading...")}</p>}`
- [390](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L390): `{failed && !loading && (`
- [391](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L391): `<p role="alert" className="dt-tray-empty">`
- [395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AnswerModeMenu.tsx#L395): `{nothing && !loading && !failed && <p className="dt-tray-empty">{t("No partners yet")}</p>}`

### web/components/chat/home/AskUserOptions.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L4): `import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L36): `label: string;`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L149): `if (!events || events.length === 0) return null;`
- [361](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L361): `if (!events || events.length === 0) return [];`
- [692](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L692): `if (said.length === 0) continue;`
- [949](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L949): `if (questions.length === 0 && !(allowNoQuestions && intro)) return null;`
- [1051](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1051): `const [picks, setPicks] = useState<Record<string, string[]>>({});`
- [1054](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1054): `const [customText, setCustomText] = useState<Record<string, string>>({});`
- [1058](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1058): `const [customSelected, setCustomSelected] = useState<Record<string, boolean>>(`
- [1061](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1061): `const [activeIdx, setActiveIdx] = useState(0);`
- [1134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1134): `(question: AskUserQuestion, label: string) => {`
- [1224](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1224): `if (locked || !activeQuestion || activeQuestion.options.length === 0) {`
- [1450](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1450): `onPickOption: (label: string) => void;`
- [1588](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/AskUserOptions.tsx#L1588): `const [manualCollapsed, setManualCollapsed] = useState<boolean | null>(null);`

### web/components/chat/home/CapabilityConfigCard.tsx

- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CapabilityConfigCard.tsx#L37): `label: string;`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CapabilityConfigCard.tsx#L41): `deep_question: { icon: PenLine, label: "Quiz settings" },`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CapabilityConfigCard.tsx#L42): `math_animator: { icon: Clapperboard, label: "Animator settings" },`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CapabilityConfigCard.tsx#L43): `visualize: { icon: BarChart3, label: "Visualize settings" },`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CapabilityConfigCard.tsx#L44): `deep_research: { icon: Microscope, label: "Research settings" },`

### web/components/chat/home/ChatComposer.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L9): `useState,`
- [421](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L421): `replyLanguageOptions?: readonly { value: string; label: string }[];`
- [522](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L522): `const [hasContent, setHasContent] = useState(false);`
- [523](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L523): `const [moreCapsOpen, setMoreCapsOpen] = useState(false);`
- [524](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L524): `const [lastCapMenuOpen, setLastCapMenuOpen] = useState(capMenuOpen);`
- [979](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L979): `...attachments.flatMap((file, index): ContextTreeItem[] => isQuoteAttachment(file) ? [] : [{key:'file-${index}', icon:Paperclip, kind:t("Attach files"),label:file.filename,thumbnailUrl:file.type === "image" ? file.previewUrl : undefined,onClick:()=>onPreviewAttachment?.(index),onRemove:()=>onRemoveAttachment(index)}]),`
- [980](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L980): `...selectedKnowledgeBases.map((id): ContextTreeItem => ({key:'kb-${id}',icon:Database,kind:t("Knowledge"),label:knowledgeBases.find(kb=>knowledgeBaseRef(kb)===id)?.name || id,onRemove:()=>onToggleKB(id)})),`
- [985](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L985): `label: '${book.bookTitle} (${book.pages.length})',`
- [992](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L992): `label: '${material.materialTitle} (${material.units.length})',`
- [1001](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1001): `label: '${group.notebookName} (${group.count})',`
- [1008](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1008): `label: session.title,`
- [1015](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1015): `label: session.title,`
- [1022](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1022): `label: entry.question,`
- [1031](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1031): `label: selectedPersona,`
- [1040](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1040): `label: file === "summary" ? t("Summary") : t("Profile"),`
- [1055](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1055): `label: capabilityLabel(activeCap),`
- [1077](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1077): `label: t(createKindDef.labelKey),`
- [1101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1101): `label: resourceCatalog?.skills.find((option) => option.id === id)?.name || id,`
- [1112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1112): `label: resourceCatalog?.mcp.find((option) => option.id === id)?.name || id,`
- [1220](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1220): `label: t("tasks.linked"),`
- [1249](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1249): `label: t("Knowledge"),`
- [1378](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1378): `{recorder.error && (`
- [1379](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1379): `<div role="alert" className="px-4 pb-2 text-[11px] text-red-600">`
- [1469](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatComposer.tsx#L1469): `if (loopCaps.length === 0) return null;`

### web/components/chat/home/ChatMarkdownNoteTab.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L3): `import { useEffect, useState } from 'react'`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L15): `!auth.loading && auth.statusAvailable ? (auth.enabled ? auth.userId : 'local') : null`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L16): `const [recoverable, setRecoverable] = useState(false)`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L17): `const [docId, setDocId] = useState<string | null>(null)`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L18): `const [error, setError] = useState('')`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L19): `const [busy, setBusy] = useState(false)`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L57): `{error && <p role="alert">{error}</p>}`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ChatMarkdownNoteTab.tsx#L72): `{error && <p role="alert">{error}</p>}`

### web/components/chat/home/ComposerInput.tsx

- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L12): `useState,`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L77): `replyLanguageOptions?: readonly { value: string; label: string }[];`
- [201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L201): `const [input, setInput] = useState("");`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L202): `const [leadWidth, setLeadWidth] = useState(0);`
- [203](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L203): `const [armed, setArmed] = useState(false);`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L204): `const [scrolled, setScrolled] = useState(false);`
- [206](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L206): `const [showAtPopup, setShowAtPopup] = useState(false);`
- [207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L207): `const [showSlashPopup, setShowSlashPopup] = useState(false);`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L208): `const [slashCommands, setSlashCommands] = useState<SlashCommand[]>([]);`
- [209](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L209): `const [activeSlashIndex, setActiveSlashIndex] = useState(0);`
- [210](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L210): `const [showLanguagePopup, setShowLanguagePopup] = useState(false);`
- [211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L211): `const [activeLanguageIndex, setActiveLanguageIndex] = useState(0);`
- [212](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L212): `const [atQuery, setAtQuery] = useState("");`
- [222](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L222): `label: '${t("Account default")} (${replyLanguageDefaultLabel})',`
- [592](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L592): `{filteredAgents.length === 0 ? (`
- [594](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerInput.tsx#L594): `{connectedAgents.length === 0`

### web/components/chat/home/ComposerLead.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerLead.tsx#L11): `label: string;`

### web/components/chat/home/ComposerResources.tsx

- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L20): `useState,`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L37): `label: string;`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L89): `const [selectedKey, setSelectedKey] = useState<string | null>(null);`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L90): `const [query, setQuery] = useState("");`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L91): `const [position, setPosition] = useState<{`
- [299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerResources.tsx#L299): `role="dialog"`

### web/components/chat/home/ComposerTray.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L5): `import { createElement, useEffect, useId, useMemo, useState, type ReactNode } from "react";`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L59): `const [state, setState] = useState<McpStoreState | null>(null);`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L86): `return { option, status, tools: row?.tools.length ?? 0, error: row?.error ?? "" };`
- [211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L211): `title={capabilityLabel(cap)}`
- [269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L269): `const [query, setQuery] = useState("");`
- [285](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L285): `title={t("composer.tray.allSkills")}`
- [299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L299): `title={option.name}`
- [350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L350): `title={t("composer.tray.allConnectors")}`
- [375](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L375): `title={item.option.name}`
- [436](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTray.tsx#L436): `title={t(def.labelKey)}`

### web/components/chat/home/ComposerTrayFold.ts

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayFold.ts#L13): `useState,`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayFold.ts#L99): `const [dragging, setDragging] = useState(false);`

### web/components/chat/home/ComposerTrayMenu.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayMenu.tsx#L10): `useState,`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayMenu.tsx#L74): `label: string;`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayMenu.tsx#L96): `const [openState, setOpenState] = useState(false);`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayMenu.tsx#L97): `const [room, setRoom] = useState<Room | null>(null);`
- [225](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayMenu.tsx#L225): `role="dialog"`
- [273](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ComposerTrayMenu.tsx#L273): `label: string;`

### web/components/chat/home/ConsultationTabBody.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L3): `import { useEffect, useState } from 'react'`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L57): `const [group, setGroup] = useState<PartnerGroup | null>(null)`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L58): `const [error, setError] = useState('')`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L59): `const [panelOpen, setPanelOpen] = useState(false)`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L75): `<p role="alert" className="p-4 text-sm">`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L104): `return error ? (`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L105): `<p role="alert" className="p-4 text-sm text-[var(--destructive)]">{error.content}</p>`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L112): `const [partner, setPartner] = useState<PartnerInfo | null>(null)`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L113): `const [error, setError] = useState('')`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L114): `const [notice, setNotice] = useState('')`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L124): `if (error) return <p role="alert" className="p-4 text-sm">{error}</p>`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ConsultationTabBody.tsx#L147): `const [identity, setIdentity] = useState<{ partner_id: string; session_key: string } | null>(null)`

### web/components/chat/home/ContextBudgetChip.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextBudgetChip.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextBudgetChip.tsx#L136): `label: string;`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextBudgetChip.tsx#L176): `const [open, setOpen] = useState(false);`
- [252](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextBudgetChip.tsx#L252): `role="dialog"`

### web/components/chat/home/ContextReferenceTree.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextReferenceTree.tsx#L3): `import { memo, useState } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextReferenceTree.tsx#L20): `label: string;`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextReferenceTree.tsx#L117): `const [expanded, setExpanded] = useState(false);`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ContextReferenceTree.tsx#L118): `if (items.length === 0) return null;`

### web/components/chat/home/CreationDraftCard.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L3): `import { memo, useEffect, useState } from "react";`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L51): `const [name, setName] = useState(data.name);`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L52): `const [description, setDescription] = useState(data.description);`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L53): `const [content, setContent] = useState(data.content);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L54): `const [tagsText, setTagsText] = useState(data.tags.join(", "));`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L55): `const [editingFields, setEditingFields] = useState(false);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L56): `const [bodyExpanded, setBodyExpanded] = useState(false);`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L57): `const [openReference, setOpenReference] = useState<string | null>(null);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L59): `const [approval, setApproval] = useState<CreationApproval>(`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L62): `const [saved, setSaved] = useState<{ name: string; replaced: boolean } | null>(`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L65): `const [saving, setSaving] = useState(false);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L66): `const [error, setError] = useState("");`
- [262](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/CreationDraftCard.tsx#L262): `{error ? (`

### web/components/chat/home/KnowledgeSelector.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/KnowledgeSelector.tsx#L5): `import { useEffect, useRef, useState } from "react";`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/KnowledgeSelector.tsx#L45): `const [openState, setOpenState] = useState(false);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/KnowledgeSelector.tsx#L59): `const [query, setQuery] = useState("");`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/KnowledgeSelector.tsx#L133): `{knowledgeBases.length === 0 ? (`

### web/components/chat/home/LazySessionViewerPanel.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/LazySessionViewerPanel.tsx#L10): `useState,`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/LazySessionViewerPanel.tsx#L37): `const [loadRequested, setLoadRequested] = useState(props.open);`

### web/components/chat/home/MasteryHandoffCard.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryHandoffCard.tsx#L3): `import { memo, useState } from "react";`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryHandoffCard.tsx#L104): `const [draft, setDraft] = useState(data.opening_message);`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryHandoffCard.tsx#L118): `router.push(masteryHandoffHref(data));`
- [235](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryHandoffCard.tsx#L235): `if (handoffs.length === 0) return null;`

### web/components/chat/home/MasteryQuestionCard.tsx

- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L21): `import { memo, useCallback, useEffect, useRef, useState } from "react";`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L50): `option: { label: string; body: string };`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L130): `const [picked, setPicked] = useState<string>(() => grade?.final === false ? grade.learnerAnswer : "");`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L131): `const [skipping, setSkipping] = useState(false);`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L132): `const [sourceUnavailable, setSourceUnavailable] = useState(false);`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L133): `const [freeText, setFreeText] = useState(() => grade?.final === false ? grade.learnerAnswer : "");`
- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L134): `const [freeSelected, setFreeSelected] = useState(false);`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L197): `const optionState = (option: { label: string }): OptionState => {`
- [222](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L222): `{sourceUnavailable && <p role="alert">{t("The source image is unavailable. Open the source or ask your tutor to inspect its current version.")}</p>}`
- [296](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L296): `<LearningText inline size={12.5}>{t("Answer: {{label}}", { label: grade.correctLabel })}</LearningText>`
- [370](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L370): `const [answers, setAnswers] = useState<Record<string, { text: string; available: boolean }>>({});`
- [371](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L371): `const [skipping, setSkipping] = useState(false);`
- [372](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/MasteryQuestionCard.tsx#L372): `const [skipFailed, setSkipFailed] = useState(false);`

### web/components/chat/home/ModelSelector.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L3): `import { useEffect, useMemo, useRef, useState } from "react";`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L50): `const [revealFull, setRevealFull] = useState(false);`
- [138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L138): `const [open, setOpen] = useState(false);`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L165): `const canRefresh = error && Boolean(onRefresh);`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L168): `(!canRefresh && (error || (options.length === 0 && !allowSystemDefault)));`
- [209](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ModelSelector.tsx#L209): `{error ? (`

### web/components/chat/home/PartnerDraftCard.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L3): `import { memo, useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L25): `const [editing, setEditing] = useState(false);`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L26): `const [showSoul, setShowSoul] = useState(false);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L27): `const [name, setName] = useState(data.name);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L28): `const [description, setDescription] = useState(data.description);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L29): `const [soul, setSoul] = useState(data.soul);`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L30): `const [language, setLanguage] = useState(data.language);`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L31): `const [emoji, setEmoji] = useState(data.emoji || "🤝");`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L32): `const [color, setColor] = useState(data.color || "#6366f1");`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L33): `const [creating, setCreating] = useState(false);`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L34): `const [createdId, setCreatedId] = useState(data.created_partner_id || "");`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L35): `const [error, setError] = useState("");`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L161): `{error ? (`
- [169](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/PartnerDraftCard.tsx#L169): `router.push('/partners/${encodeURIComponent(createdId)}')`

### web/components/chat/home/ResourceReuse.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ResourceReuse.tsx#L2): `import { createContext, useContext, useMemo, useState } from "react";`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ResourceReuse.tsx#L13): `const [byScope, setByScope] = useState<Record<string, ResourceReuse>>({});`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ResourceReuse.tsx#L14): `const [previous, setPrevious] = useState({ scope, continuityKey });`

### web/components/chat/home/ResponderList.tsx

- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ResponderList.tsx#L125): `label: string;`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ResponderList.tsx#L145): `label: string;`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ResponderList.tsx#L152): `role="menuitem"`

### web/components/chat/home/SelectedResources.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SelectedResources.tsx#L3): `import { useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SelectedResources.tsx#L32): `const [expanded, setExpanded] = useState(false);`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SelectedResources.tsx#L33): `const [editFiles, setEditFiles] = useState(false);`

### web/components/chat/home/SessionActivityPanel.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L11): `import { useEffect, useState, type ReactNode } from "react";`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L69): `const [sessions, setSessions] = useState<Map<string, string>>(new Map());`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L70): `const [notebooks, setNotebooks] = useState<Map<string, string>>(new Map());`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L71): `const [books, setBooks] = useState<Map<string, string>>(new Map());`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L141): `label: string;`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L149): `label: "Chat history",`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L155): `label: "Books",`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L161): `label: "Notebooks",`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L167): `label: "Question bank",`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L173): `label: "Persona",`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L179): `label: "Memory",`
- [222](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L222): `title={sessions.get(id) ?? id}`
- [223](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L223): `subtitle={id.slice(0, 8)}`
- [241](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L241): `title={books.get(id) ?? id}`
- [242](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L242): `subtitle={t("{{n}} page(s)", { n: pages })}`
- [257](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L257): `<SpaceItemRow key={id} title={notebooks.get(id) ?? id} />`
- [270](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L270): `<SpaceItemRow key={id} title={t("Question #{{n}}", { n: id })} />`
- [283](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L283): `<SpaceItemRow key={persona} title={persona} />`
- [296](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L296): `<SpaceItemRow key={kind} title={kind} />`
- [330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L330): `<SectionCard icon={Wrench} title={t("Tools used")} count={tools.length}>`
- [350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L350): `title={t("Knowledge bases")}`
- [367](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L367): `<SectionCard icon={AtSign} title={t("Space")}>`
- [377](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L377): `title={t("Generated files")}`
- [395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionActivityPanel.tsx#L395): `title={t("Attachments")}`

### web/components/chat/home/SessionLoadingView.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionLoadingView.tsx#L3): `import { useEffect, useState } from "react";`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionLoadingView.tsx#L37): `const [showHint, setShowHint] = useState(false);`

### web/components/chat/home/SessionViewerPanel.tsx

- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L33): `useState,`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L177): `| { kind: "file"; id: string; label: string; source: FilePreviewSource }`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L178): `| { kind: "web"; id: string; label: string; url: string }`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L179): `| { kind: "markdown-note"; id: string; label: string }`
- [183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L183): `label: string;`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L189): `label: string;`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L195): `label: string;`
- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L200): `| { kind: "new"; id: string; label: string }`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L204): `label: string;`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L238): `openSubagentTab(callId: string, label: string, events: StreamEvent[], focus?: boolean): void;`
- [409](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L409): `const [tabs, setTabs] = useState<ViewerTab[]>([]);`
- [410](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L410): `const [activeTabId, setActiveTabId] = useState<string | null>(null);`
- [411](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L411): `const [closedTabs, setClosedTabs] = useState<ViewerTab[]>([]);`
- [478](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L478): `const [stash, setStash] = useState<ReadonlyMap<string, StashedTabs>>(`
- [481](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L481): `const [trackedKey, setTrackedKey] = useState(tabsKey);`
- [538](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L538): `label: hostnameFor(url),`
- [553](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L553): `: [...prev, { kind: "new", id: newTabId, label: t("New tab") }],`
- [575](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L575): `label: t("Markdown note"),`
- [595](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L595): `label: context.tabLabel,`
- [606](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L606): `label: context.tabLabel,`
- [767](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L767): `label: responderLabel(responder),`
- [810](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L810): `{ kind: "geogebra", id, label: t("GeoGebra board"), script: "", editable: true },`
- [827](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L827): `label: payload.title || "GeoGebra",`
- [838](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L838): `label: payload.title || "GeoGebra",`
- [854](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L854): `(callId: string, label: string, events: StreamEvent[], focus = false) => {`
- [902](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L902): `next.length === 0`
- [1025](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1025): `const [launcherThreadRows, setLauncherThreadRows] = useState<{`
- [1032](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1032): `const [threadsRevision, setThreadsRevision] = useState(0);`
- [1084](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1084): `.map((tab) => ({ id: tab.id, label: tab.label, icon: tabIcon(tab) }));`
- [1102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1102): `const [entered, setEntered] = useState(false);`
- [1115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1115): `// tabs.length === 0 case renders a "Landing" page where the user can`
- [1143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1143): `role="dialog"`
- [1616](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1616): `const [loaded, setLoaded] = useState(false);`
- [1617](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1617): `const [timedOut, setTimedOut] = useState(false);`
- [1694](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1694): `title={host}`
- [1735](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SessionViewerPanel.tsx#L1735): `const [size, setSize] = useState<{ width: number; height: number } | null>(`

### web/components/chat/home/SetupCredentialCard.tsx

- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SetupCredentialCard.tsx#L48): `onClick={() => router.push(data.settingsPath)}`

### web/components/chat/home/SideChatResponderMenu.tsx

- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SideChatResponderMenu.tsx#L95): `title={title}`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SideChatResponderMenu.tsx#L101): `<TraySection title={t("Answered by")}>`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SideChatResponderMenu.tsx#L110): `<TraySection title={t("Agents")}>`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SideChatResponderMenu.tsx#L124): `title={t("Partner groups")}`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SideChatResponderMenu.tsx#L149): `<TraySection title={t("Partners")}>`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SideChatResponderMenu.tsx#L167): `{loading && <p className="dt-tray-empty">{t("Loading...")}</p>}`

### web/components/chat/home/StandaloneComposer.tsx

- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L23): `import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L150): `label: "Chat",`
- [274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L274): `const [attachments, setAttachments] = useState<PendingAttachment[]>([]);`
- [276](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L276): `const [seededId, setSeededId] = useState<number | null>(null);`
- [285](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L285): `const [attachmentError, setAttachmentError] = useState<string | null>(null);`
- [289](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L289): `const [dragging, setDragging] = useState(false);`
- [290](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L290): `const [capMenuOpen, setCapMenuOpen] = useState(false);`
- [292](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L292): `const [spaceMenuOpen, setSpaceMenuOpen] = useState(false);`
- [293](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L293): `const [quizConfig, setQuizConfig] = useState<DeepQuestionFormConfig>({`
- [296](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L296): `const [quizPdf, setQuizPdf] = useState<File | null>(null);`
- [297](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L297): `const [visualizeConfig, setVisualizeConfig] = useState<VisualizeFormConfig>({`
- [300](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L300): `const [researchConfig, setResearchConfig] = useState<DeepResearchFormConfig>(`
- [304](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L304): `useState(false);`
- [306](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L306): `const [ownKnowledgeBases, setOwnKnowledgeBases] = useState<string[]>([]);`
- [308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L308): `const [selectedBookReferences, setSelectedBookReferences] = useState<`
- [311](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L311): `const [selectedNotebookRecords, setSelectedNotebookRecords] = useState<`
- [314](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L314): `const [selectedHistorySessions, setSelectedHistorySessions] = useState<`
- [317](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L317): `const [selectedQuestionEntries, setSelectedQuestionEntries] = useState<`
- [320](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L320): `const [selectedPersona, setSelectedPersona] = useState<string | null>(null);`
- [321](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L321): `const [selectedMemoryFiles, setSelectedMemoryFiles] = useState<`
- [326](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L326): `const [showNotebookPicker, setShowNotebookPicker] = useState(false);`
- [327](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L327): `const [showBookPicker, setShowBookPicker] = useState(false);`
- [328](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L328): `const [showHistoryPicker, setShowHistoryPicker] = useState(false);`
- [329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L329): `const [showQuestionBankPicker, setShowQuestionBankPicker] = useState(false);`
- [330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L330): `const [showPersonaPicker, setShowPersonaPicker] = useState(false);`
- [331](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L331): `const [showMemoryPicker, setShowMemoryPicker] = useState(false);`
- [334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L334): `const [personaSelectorOpen, setPersonaSelectorOpen] = useState(false);`
- [337](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L337): `const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBaseSummary[]>(`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L340): `const [llmOptions, setLLMOptions] = useState<LLMOption[]>([]);`
- [341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L341): `const [activeLLMDefault, setActiveLLMDefault] = useState<LLMSelection | null>(`
- [344](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L344): `const [ownLLMSelection, setOwnLLMSelection] = useState<LLMSelection | null>(`
- [348](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L348): `const [llmOptionsLoading, setLLMOptionsLoading] = useState(true);`
- [349](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L349): `const [llmOptionsError, setLLMOptionsError] = useState(false);`
- [633](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L633): `const [subagentBudget, setSubagentBudget] = useState<number | null>(null);`
- [634](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L634): `const [selectedPartner, setSelectedPartner] = useState<string | null>(null);`
- [635](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L635): `const [selectedPartnerGroup, setSelectedPartnerGroup] = useState<string | null>(null);`
- [708](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L708): `label: capabilityLabel(capability),`
- [854](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StandaloneComposer.tsx#L854): `canConfirm={quizValidationErrors.length === 0}`

### web/components/chat/home/StarterSuggestions.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StarterSuggestions.tsx#L3): `import { useCallback, useEffect, useId, useRef, useState, type ReactNode } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StarterSuggestions.tsx#L25): `label: string;`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StarterSuggestions.tsx#L105): `const [view, setView] = useState<View>({ kind: "loading" });`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/StarterSuggestions.tsx#L106): `const [open, setOpen] = useState<string | null>(null);`

### web/components/chat/home/SubagentRunTranscript.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentRunTranscript.tsx#L3): `import { useMemo, useState } from "react";`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentRunTranscript.tsx#L62): `{visible.length === 0 ? (`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentRunTranscript.tsx#L155): `const [open, setOpen] = useState(false);`

### web/components/chat/home/SubagentTabBody.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentTabBody.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentTabBody.tsx#L30): `const [localEvents, setLocalEvents] = useState<StreamEvent[]>([]);`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentTabBody.tsx#L31): `const [draft, setDraft] = useState("");`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentTabBody.tsx#L32): `const [busy, setBusy] = useState(false);`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentTabBody.tsx#L33): `const [error, setError] = useState<string | null>(null);`
- [137](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/SubagentTabBody.tsx#L137): `{error && (`

### web/components/chat/home/TurnNavigator.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/TurnNavigator.tsx#L4): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/TurnNavigator.tsx#L105): `const [left, setLeft] = useState<number | null>(null);`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/TurnNavigator.tsx#L106): `const [activeKey, setActiveKey] = useState<string | null>(null);`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/TurnNavigator.tsx#L107): `const [hoveredKey, setHoveredKey] = useState<string | null>(null);`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/TurnNavigator.tsx#L108): `const [pointerInside, setPointerInside] = useState(false);`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/TurnNavigator.tsx#L109): `const [cardY, setCardY] = useState<number | null>(null);`

### web/components/chat/home/ViewerLauncher.tsx

- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ViewerLauncher.tsx#L22): `useState,`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ViewerLauncher.tsx#L62): `label: string;`
- [232](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ViewerLauncher.tsx#L232): `const [value, setValue] = useState("");`
- [284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ViewerLauncher.tsx#L284): `label: string;`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ViewerLauncher.tsx#L340): `const [menuOpen, setMenuOpen] = useState(false);`
- [401](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/ViewerLauncher.tsx#L401): `role="menu"`

### web/components/chat/home/composer-field.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/home/composer-field.tsx#L13): `label: string;`

### web/components/chat/preview/FilePreviewDrawer.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L5): `import { memo, useCallback, useEffect, useRef, useState } from "react";`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L75): `useState<FilePreviewSource | null>(null);`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L82): `const [bodyMounted, setBodyMounted] = useState(false);`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L148): `const [copied, setCopied] = useState(false);`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L149): `const [openingInReader, setOpeningInReader] = useState(false);`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L150): `const [readerError, setReaderError] = useState("");`
- [191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L191): `router.push(readingCollectionRoute(workspace.workspace_id));`
- [212](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/FilePreviewDrawer.tsx#L212): `role="dialog"`

### web/components/chat/preview/previewers/DocxPreview.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/DocxPreview.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/DocxPreview.tsx#L13): `if (!wrapper || pages.length === 0) return;`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/DocxPreview.tsx#L46): `const [rendering, setRendering] = useState(true);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/DocxPreview.tsx#L47): `const [failed, setFailed] = useState(false);`

### web/components/chat/preview/previewers/ImagePreview.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/ImagePreview.tsx#L3): `import { useState } from "react";`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/ImagePreview.tsx#L23): `const [state, setState] = useState<"loading" | "ready" | "error">("loading");`

### web/components/chat/preview/previewers/OfficePdfPreview.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/OfficePdfPreview.tsx#L3): `import { useEffect, useState, type ReactNode } from "react";`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/OfficePdfPreview.tsx#L33): `const [state, setState] = useState<PreviewState>({`

### web/components/chat/preview/previewers/PdfPreview.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/PdfPreview.tsx#L3): `import { useState } from "react";`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/PdfPreview.tsx#L24): `const [loading, setLoading] = useState(true);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/PdfPreview.tsx#L28): `{loading && (`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/PdfPreview.tsx#L37): `title={filename}`

### web/components/chat/preview/previewers/VideoPreview.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/VideoPreview.tsx#L3): `import { useState } from "react";`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/VideoPreview.tsx#L16): `const [state, setState] = useState<"loading" | "ready" | "error">("loading");`

### web/components/chat/preview/previewers/XlsxPreview.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/XlsxPreview.tsx#L3): `import { useEffect, useState } from "react";`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/XlsxPreview.tsx#L28): `const [sheets, setSheets] = useState<SheetModel[] | null>(null);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/XlsxPreview.tsx#L29): `const [active, setActive] = useState(0);`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/XlsxPreview.tsx#L30): `const [failed, setFailed] = useState(false);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/XlsxPreview.tsx#L103): `if (sheets.length === 0) {`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/XlsxPreview.tsx#L131): `title={cell}`

### web/components/chat/preview/previewers/useBinarySource.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/useBinarySource.ts#L3): `import { useEffect, useRef, useState } from "react";`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/useBinarySource.ts#L23): `const [state, setState] = useState<BinarySourceState>({ kind: "loading" });`

### web/components/chat/preview/previewers/useTextSource.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/useTextSource.ts#L3): `import { useEffect, useRef, useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/preview/previewers/useTextSource.ts#L25): `const [state, setState] = useState<TextSourceState>(() =>`

### web/components/chat/space/ChatSpaceMenu.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L3): `import { Fragment, memo, useEffect, useRef, useState } from "react";`
- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L134): `label: "Attach files",`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L142): `label: "Knowledge",`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L150): `label: variant === "resources" ? "Agent conversations" : "My Agents",`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L158): `label: "Books",`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L166): `label: "Reading",`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L174): `label: "Persona",`
- [188](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L188): `const [activeIdx, setActiveIdx] = useState(0);`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L208): `// on each open, so a fresh 'useState(0)' initial value already gives us`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/chat/space/ChatSpaceMenu.tsx#L218): `if (list.length === 0) return;`

### web/components/cli-apps/CliAppsSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L4): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L57): `const [state, setState] = useState<CliAppState | null>(null);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L58): `const [loadError, setLoadError] = useState<string | null>(null);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L59): `const [tab, setTab] = useState<Tab>("installed");`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L90): `title={t("CLI Apps")}`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L158): `const [busy, setBusy] = useState<string | null>(null);`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L159): `const [error, setError] = useState<string | null>(null);`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L177): `if (apps.length === 0) {`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L180): `title={t("No CLI apps installed")}`
- [333](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L333): `const [draft, setDraft] = useState("");`
- [334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L334): `const [query, setQuery] = useState("");`
- [335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L335): `const [category, setCategory] = useState("");`
- [336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L336): `const [showAll, setShowAll] = useState(false);`
- [338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L338): `const [entries, setEntries] = useState<CliCatalogEntry[]>([]);`
- [339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L339): `const [categories, setCategories] = useState<Record<string, number>>({});`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L340): `const [cursor, setCursor] = useState("");`
- [341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L341): `const [total, setTotal] = useState(0);`
- [342](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L342): `const [loading, setLoading] = useState(true);`
- [343](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L343): `const [loadingMore, setLoadingMore] = useState(false);`
- [344](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L344): `const [error, setError] = useState<string | null>(null);`
- [345](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L345): `const [selected, setSelected] = useState<CliCatalogEntry | null>(null);`
- [496](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L496): `{loading ? (`
- [498](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L498): `) : entries.length === 0 ? (`
- [500](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L500): `title={t("Nothing matches")}`
- [604](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L604): `const [installing, setInstalling] = useState(false);`
- [605](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L605): `const [error, setError] = useState<string | null>(null);`
- [606](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L606): `const [log, setLog] = useState<string | null>(null);`
- [825](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L825): `label: string;`
- [853](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L853): `label: string;`
- [928](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L928): `label: string;`
- [966](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/cli-apps/CliAppsSection.tsx#L966): `label: string;`

### web/components/common/McpToolGroups.tsx

- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/McpToolGroups.tsx#L17): `import { useState, type ReactNode } from "react";`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/McpToolGroups.tsx#L52): `const [overrides, setOverrides] = useState<Record<string, boolean>>({});`

### web/components/common/Modal.tsx

- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/Modal.tsx#L107): `if (focusables.length === 0) return;`
- [137](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/Modal.tsx#L137): `role="dialog"`

### web/components/common/ModelThinkingCard.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ModelThinkingCard.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ModelThinkingCard.tsx#L38): `const [userToggled, setUserToggled] = useState<boolean | null>(null);`

### web/components/common/PickerShell.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/PickerShell.tsx#L8): `useState,`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/PickerShell.tsx#L124): `const [originRect, setOriginRect] = useState<DOMRect | null>(null);`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/PickerShell.tsx#L125): `const [wasOpen, setWasOpen] = useState(false);`
- [213](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/PickerShell.tsx#L213): `const activeDialog = document.activeElement?.closest('[role="dialog"]');`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/PickerShell.tsx#L239): `if (focusables.length === 0) return;`
- [308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/PickerShell.tsx#L308): `role="dialog"`

### web/components/common/ProcessLogs.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ProcessLogs.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ProcessLogs.tsx#L22): `const [open, setOpen] = useState(true);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ProcessLogs.tsx#L27): `if (executing && logs.length === 0) {`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ProcessLogs.tsx#L88): `{executing && logs.length === 0 && (`

### web/components/common/RichInlineMarkdown.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/RichInlineMarkdown.tsx#L4): `import React, { useEffect, useState } from "react";`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/RichInlineMarkdown.tsx#L49): `const [plugins, setPlugins] = useState<Plugins>({});`

### web/components/common/RichMarkdownRenderer.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/RichMarkdownRenderer.tsx#L3): `import React, { useEffect, useMemo, useState } from "react";`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/RichMarkdownRenderer.tsx#L131): `const [plugins, setPlugins] = useState<PluginBundle>({});`
- [478](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/RichMarkdownRenderer.tsx#L478): `title={ggbTitle}`

### web/components/common/ToastViewport.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx#L4): `import { useEffect, useState } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx#L20): `const [toasts, setToasts] = useState<Notification[]>([]);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/ToastViewport.tsx#L38): `if (toasts.length === 0) return null;`

### web/components/common/code-block-themes.ts

- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L115): `label: string;`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L122): `{ id: "a11yDark", label: "A11Y Dark", style: a11yDark },`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L123): `{ id: "a11yOneLight", label: "A11Y One Light", style: a11yOneLight },`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L124): `{ id: "atomDark", label: "Atom Dark", style: atomDark },`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L127): `label: "Base16 Atelier Sulphurpool Light",`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L130): `{ id: "cb", label: "CB", style: cb },`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L131): `{ id: "coldarkCold", label: "Coldark Cold", style: coldarkCold },`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L132): `{ id: "coldarkDark", label: "Coldark Dark", style: coldarkDark },`
- [135](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L135): `label: "Coy Without Shadows",`
- [138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L138): `{ id: "coy", label: "Coy", style: coy },`
- [139](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L139): `{ id: "darcula", label: "Darcula", style: darcula },`
- [140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L140): `{ id: "dark", label: "Dark", style: dark },`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L141): `{ id: "dracula", label: "Dracula", style: dracula },`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L142): `{ id: "duotoneDark", label: "Duotone Dark", style: duotoneDark },`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L143): `{ id: "duotoneEarth", label: "Duotone Earth", style: duotoneEarth },`
- [144](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L144): `{ id: "duotoneForest", label: "Duotone Forest", style: duotoneForest },`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L145): `{ id: "duotoneLight", label: "Duotone Light", style: duotoneLight },`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L146): `{ id: "duotoneSea", label: "Duotone Sea", style: duotoneSea },`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L147): `{ id: "duotoneSpace", label: "Duotone Space", style: duotoneSpace },`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L148): `{ id: "funky", label: "Funky", style: funky },`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L149): `{ id: "ghcolors", label: "GH Colors", style: ghcolors },`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L150): `{ id: "gruvboxDark", label: "Gruvbox Dark", style: gruvboxDark },`
- [151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L151): `{ id: "gruvboxLight", label: "Gruvbox Light", style: gruvboxLight },`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L152): `{ id: "holiTheme", label: "Holi Theme", style: holiTheme },`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L153): `{ id: "hopscotch", label: "Hopscotch", style: hopscotch },`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L154): `{ id: "lucario", label: "Lucario", style: lucario },`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L155): `{ id: "materialDark", label: "Material Dark", style: materialDark },`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L156): `{ id: "materialLight", label: "Material Light", style: materialLight },`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L157): `{ id: "materialOceanic", label: "Material Oceanic", style: materialOceanic },`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L158): `{ id: "nightOwl", label: "Night Owl", style: nightOwl },`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L159): `{ id: "nord", label: "Nord", style: nord },`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L160): `{ id: "okaidia", label: "Okaidia", style: okaidia },`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L161): `{ id: "oneDark", label: "One Dark", style: oneDark },`
- [162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L162): `{ id: "oneLight", label: "One Light", style: oneLight },`
- [163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L163): `{ id: "pojoaque", label: "Pojoaque", style: pojoaque },`
- [164](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L164): `{ id: "prism", label: "Prism", style: prism },`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L165): `{ id: "shadesOfPurple", label: "Shades of Purple", style: shadesOfPurple },`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L168): `label: "Solarized Dark Atom",`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L171): `{ id: "solarizedlight", label: "Solarized Light", style: solarizedlight },`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L172): `{ id: "synthwave84", label: "Synthwave 84", style: synthwave84 },`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L173): `{ id: "tomorrow", label: "Tomorrow", style: tomorrow },`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L174): `{ id: "twilight", label: "Twilight", style: twilight },`
- [175](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L175): `{ id: "vsDark", label: "VS Dark", style: vsDark },`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L176): `{ id: "vs", label: "VS", style: vs },`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L177): `{ id: "vscDarkPlus", label: "VSC Dark Plus", style: vscDarkPlus },`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L178): `{ id: "xonokai", label: "Xonokai", style: xonokai },`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/common/code-block-themes.ts#L179): `{ id: "zTouch", label: "Z Touch", style: zTouch },`

### web/components/customization/PageCustomizeButton.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeButton.tsx#L3): `import { useState } from 'react'`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeButton.tsx#L26): `const [open, setOpen] = useState(false)`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeButton.tsx#L30): `<Tooltip label={t(error ? 'customize.loadError' : 'customize.title')}>`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeButton.tsx#L33): `aria-label={t(error ? 'customize.loadError' : 'customize.title')}`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeButton.tsx#L36): `onClick={() => (error ? reload() : setOpen(true))}`

### web/components/customization/PageCustomizeDialog.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L3): `import { useState } from 'react'`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L32): `label: string`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L81): `const [draft, setDraft] = useState(() => structuredClone(initial))`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L82): `const [tab, setTab] = useState<'modes' | 'controls' | 'starters'>('modes')`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L83): `const [group, setGroup] = useState<StarterGroup>('explain')`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L84): `const [saving, setSaving] = useState(false)`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L85): `const [error, setError] = useState(false)`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L107): `<Dialog`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L109): `title={t('customize.title')}`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L155): `role="alert"`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L166): `{loading ? (`
- [286](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L286): `i === index ? { ...item, label: event.target.value } : item`
- [332](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/customization/PageCustomizeDialog.tsx#L332): `onClick={() => updatePrompts([...prompts, { label: '', prompt: '' }])}`

### web/components/files/OutputFileActions.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L3): `import { useState } from 'react'`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L29): `const [removed, setRemoved] = useState(false)`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L31): `const [open, setOpen] = useState(false)`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L32): `const [storage, setStorage] = useState<RenderStorage | null>(null)`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L33): `const [busy, setBusy] = useState(false)`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L34): `const [confirm, setConfirm] = useState(false)`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L35): `const [error, setError] = useState('')`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L36): `const [message, setMessage] = useState('')`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L107): `{error ? (`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L108): `<p role="alert" className="text-red-600">`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L196): `<ConfirmDialog`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/files/OutputFileActions.tsx#L198): `title={render ? t('Clean render files?') : t('Remove generated file?')}`

### web/components/knowledge/ConnectKiwixModal.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L3): `import { useState } from "react";`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L17): `const [name, setName] = useState("");`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L18): `const [serverUrl, setServerUrl] = useState("");`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L19): `const [zimName, setZimName] = useState("");`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L20): `const [verifiedTitle, setVerifiedTitle] = useState("");`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L21): `const [catalogQuery, setCatalogQuery] = useState("");`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L22): `const [archives, setArchives] = useState<KiwixArchive[]>([]);`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L23): `const [catalogSearched, setCatalogSearched] = useState(false);`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L24): `const [browsing, setBrowsing] = useState(false);`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L25): `const [busy, setBusy] = useState<"probe" | "connect" | null>(null);`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L26): `const [error, setError] = useState("");`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L71): `<Modal isOpen onClose={onClose} title={t("Connect Kiwix archive")} titleIcon={<Server className="h-4 w-4" />} footer={`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L103): `{catalogSearched && archives.length === 0 && <p className="text-[11px] text-[var(--muted-foreground)]">{t("No archives returned. Enter the ZIM name manually or search by title.")}</p>}`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ConnectKiwixModal.tsx#L113): `{error && <p role="alert" className="text-[12px] text-red-600">{error}</p>}`

### web/components/knowledge/CreateKbModal.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L6): `import { useEffect, useRef, useState, type ReactNode } from "react";`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L146): `const [mode, setMode] = useState<Mode>("new");`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L147): `const [name, setName] = useState("");`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L148): `const [provider, setProvider] = useState("llamaindex");`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L149): `const [files, setFiles] = useState<File[]>([]);`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L150): `const [pageIndexMode, setPageIndexMode] = useState<"" | "flash" | "standard">(`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L154): `const [linkSource, setLinkSource] = useState(OBSIDIAN_SOURCE);`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L155): `const [folderPath, setFolderPath] = useState("");`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L156): `const [probe, setProbe] = useState<LinkedFolderProbe | null>(null);`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L157): `const [probing, setProbing] = useState(false);`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L159): `const [serverUrl, setServerUrl] = useState("");`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L160): `const [apiKey, setApiKey] = useState("");`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L161): `const [retrievalMode, setRetrievalMode] = useState("");`
- [162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L162): `const [serverDefault, setServerDefault] = useState<{`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L166): `const [engineDefaultSummary, setEngineDefaultSummary] = useState<string[]>(`
- [169](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L169): `const [serverProbe, setServerProbe] = useState<LightRagServerProbe | null>(`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L172): `const [serverProbing, setServerProbing] = useState(false);`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L173): `const [weKnoraKnowledgeBaseId, setWeKnoraKnowledgeBaseId] = useState("");`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L174): `const [weKnoraProbe, setWeKnoraProbe] = useState<WeKnoraProbe | null>(null);`
- [175](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L175): `const [weKnoraProbing, setWeKnoraProbing] = useState(false);`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L176): `const [submitting, setSubmitting] = useState(false);`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L177): `const [lightRagConfig, setLightRagConfig] = useState<Awaited<`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L180): `const [lightRagConfigLoaded, setLightRagConfigLoaded] = useState(false);`
- [181](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L181): `const [lightRagConfigError, setLightRagConfigError] = useState(false);`
- [182](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L182): `const [error, setError] = useState<string | null>(null);`
- [229](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L229): `const [defaultsRevision, setDefaultsRevision] = useState(0);`
- [608](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L608): `<Modal`
- [611](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L611): `title={t("Create knowledge base")}`
- [709](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L709): `!llmCatalog.loading &&`
- [714](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L714): `<p role="alert" className="text-[12px] text-red-600">`
- [785](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L785): `{error && (`
- [812](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L812): `label: string;`
- [818](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L818): `label: t("Create new"),`
- [824](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L824): `label: t("Link existing"),`
- [1179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1179): `disabled={submitting || probing || serverUrl.trim().length === 0}`
- [1248](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1248): `{probe.error && <p className="mt-1 leading-relaxed">{probe.error}</p>}`
- [1298](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1298): `serverUrl.trim().length === 0 ||`
- [1299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1299): `apiKey.trim().length === 0 ||`
- [1300](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1300): `knowledgeBaseId.trim().length === 0;`
- [1381](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1381): `{probe.error && <p className="mt-1 leading-relaxed">{probe.error}</p>}`
- [1574](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1574): `submitting || probing || folderPath.trim().length === 0`
- [1611](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/CreateKbModal.tsx#L1611): `{probe.error && <p className="mt-1 leading-relaxed">{probe.error}</p>}`

### web/components/knowledge/EmbeddingModelSelector.tsx

- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/EmbeddingModelSelector.tsx#L41): `{catalog.loading ? t("Loading...") : t("Select an embedding model")}`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/EmbeddingModelSelector.tsx#L55): `{catalog.error && (`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/EmbeddingModelSelector.tsx#L56): `<p role="alert" className="text-xs text-red-600">`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/EmbeddingModelSelector.tsx#L60): `{!catalog.loading && !catalog.error && catalog.options.length === 0 && (`

### web/components/knowledge/FileDropZone.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/FileDropZone.tsx#L4): `import { useCallback, useMemo, useRef, useState, type DragEvent } from "react";`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/FileDropZone.tsx#L49): `const [dropState, setDropState] = useState<DropState>(EMPTY_DROP_STATE);`
- [359](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/FileDropZone.tsx#L359): `{item.error && (`

### web/components/knowledge/ImaConnectionFields.tsx

- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ImaConnectionFields.tsx#L130): `{loading && connection.lookup.knowledgeBases.length === 0 ? (`
- [185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ImaConnectionFields.tsx#L185): `{loading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/ImaConnectionFields.tsx#L218): `{loading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}`

### web/components/knowledge/IndexingModelSelector.tsx

- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/IndexingModelSelector.tsx#L134): `if (loading && options.length === 0) {`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/IndexingModelSelector.tsx#L141): `if (error && options.length === 0) {`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/IndexingModelSelector.tsx#L150): `if (options.length === 0) {`

### web/components/knowledge/KbDocumentList.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L4): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L117): `const [files, setFiles] = useState<KnowledgeBaseFile[]>([]);`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L118): `const [loading, setLoading] = useState(true);`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L119): `const [error, setError] = useState<string | null>(null);`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L120): `const [expanded, setExpanded] = useState<Set<string>>(new Set());`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L121): `const [newFolderOpen, setNewFolderOpen] = useState(false);`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L122): `const [newFolderName, setNewFolderName] = useState("");`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L123): `const [moveMenuFor, setMoveMenuFor] = useState<string | null>(null);`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L124): `const [confirmDeleteFor, setConfirmDeleteFor] = useState<string | null>(null);`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L125): `const [dragPath, setDragPath] = useState<string | null>(null);`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L126): `const [dropTarget, setDropTarget] = useState<string | null>(null);`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L127): `const [busy, setBusy] = useState(false);`
- [453](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L453): `{folderPaths.length === 0 && parentOf(node.path) === "" && (`
- [498](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L498): `{loading ? (`
- [554](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L554): `{error ? (`
- [565](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L565): `) : loading && !files.length ? (`
- [574](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentList.tsx#L574): `) : fileEntries.length === 0 && folderPaths.length === 0 ? (`

### web/components/knowledge/KbDocumentsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentsSection.tsx#L3): `import { useEffect, useState } from "react";`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentsSection.tsx#L53): `const [files, setFiles] = useState<File[]>([]);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentsSection.tsx#L54): `const [submitting, setSubmitting] = useState(false);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentsSection.tsx#L55): `const [retrySubmitting, setRetrySubmitting] = useState(false);`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentsSection.tsx#L57): `const [folders, setFolders] = useState<string[]>([]);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbDocumentsSection.tsx#L58): `const [destSubdir, setDestSubdir] = useState("");`

### web/components/knowledge/KbFilePreview.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilePreview.tsx#L5): `import { useEffect, useMemo, useState } from "react";`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilePreview.tsx#L119): `const [copied, setCopied] = useState(false);`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilePreview.tsx#L122): `const [fullscreen, setFullscreen] = useState(false);`

### web/components/knowledge/KbFilesTab.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx#L4): `import { useEffect, useMemo, useState } from "react";`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx#L31): `const [selectedFile, setSelectedFile] = useState<KnowledgeBaseFile | null>(`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbFilesTab.tsx#L39): `const [refreshKey, setRefreshKey] = useState(0);`

### web/components/knowledge/KbGitHubSourcesSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L4): `import { useCallback, useEffect, useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L25): `const [sources, setSources] = useState<GitHubSource[]>([]);`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L26): `const [loading, setLoading] = useState(true);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L27): `const [showForm, setShowForm] = useState(false);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L28): `const [syncing, setSyncing] = useState(false);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L29): `const [error, setError] = useState<string | null>(null);`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L32): `const [repoInput, setRepoInput] = useState("");`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L33): `const [branchInput, setBranchInput] = useState("main");`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L34): `const [pathInput, setPathInput] = useState("");`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L35): `const [globInput, setGlobInput] = useState("*.md");`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L36): `const [submitting, setSubmitting] = useState(false);`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L98): `.map((r) => '${r.repo}: ${r.error ?? "unknown error"}')`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L136): `disabled={syncing || sources.length === 0}`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L158): `{error && (`
- [230](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L230): `{sources.length === 0 ? (`
- [303](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L303): `{source.last_sync_error && (`
- [328](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbGitHubSourcesSection.tsx#L328): `label: string;`

### web/components/knowledge/KbIndexVersionsSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L4): `import { useEffect, useState } from "react";`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L56): `const [submitting, setSubmitting] = useState(false);`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L57): `const [modelDialogOpen, setModelDialogOpen] = useState(false);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L59): `useState<LightRagRebuildConfig | null>(null);`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L60): `const [dialogError, setDialogError] = useState<string | null>(null);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L61): `const [configLoading, setConfigLoading] = useState(false);`
- [260](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L260): `role="alert"`
- [270](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L270): `role="alert"`
- [281](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L281): `role="alert"`
- [360](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L360): `<Modal`
- [363](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L363): `title={t("Rebuild index with current defaults")}`
- [422](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexVersionsSection.tsx#L422): `title={t("Rebuild configuration")}`

### web/components/knowledge/KbIndexingRun.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L3): `import { useEffect, useState } from "react";`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L22): `error?: string;`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L28): `const [open, setOpen] = useState(false);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L29): `const [snapshot, setSnapshot] = useState<{ key: string; run: Run | null }>();`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L30): `const [error, setError] = useState<{ key: string; taskId?: string }>();`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L31): `const [now, setNow] = useState(Date.now() / 1000);`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L32): `const [cancelling, setCancelling] = useState<string>();`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L76): `{error?.key === kbName && (!error.taskId || error.taskId === run?.task_id) && <p role="alert">{t("Could not read indexing state. Refresh and retry.")}</p>}`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbIndexingRun.tsx#L86): `{run.error && <p role="alert">{run.error}</p>}`

### web/components/knowledge/KbKiwixArticlesSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L3): `import { useState, type FormEvent } from "react";`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L14): `const [query, setQuery] = useState("");`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L15): `const [results, setResults] = useState<KiwixArticle[]>([]);`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L16): `const [searched, setSearched] = useState(false);`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L17): `const [searching, setSearching] = useState(false);`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L18): `const [openingPath, setOpeningPath] = useState("");`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L19): `const [error, setError] = useState("");`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L47): `router.push(readingCollectionRoute(result.workspace.workspace_id));`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L71): `{error && <p role="alert" className="text-[12px] text-red-600">{error}</p>}`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbKiwixArticlesSection.tsx#L72): `{searched && results.length === 0 && <p className="text-[12px] text-[var(--muted-foreground)]">{t("No readable articles found.")}</p>}`

### web/components/knowledge/KbLinkedFoldersSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L4): `import { useCallback, useEffect, useRef, useState } from "react";`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L45): `const [folders, setFolders] = useState<LinkedFolderInfo[]>([]);`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L46): `const [loading, setLoading] = useState(true);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L47): `const [loadError, setLoadError] = useState<string | null>(null);`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L48): `const [error, setError] = useState<string | null>(null);`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L49): `const [linkOpen, setLinkOpen] = useState(false);`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L50): `const [unlinkingId, setUnlinkingId] = useState<string | null>(null);`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L51): `const [syncingId, setSyncingId] = useState<string | null>(null);`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L52): `const [activeSyncFolderId, setActiveSyncFolderId] = useState<string | null>(`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L55): `const [syncResults, setSyncResults] = useState<`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L172): `if (folders.length === 0 && (loading || loadError)) {`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L178): `role="alert"`
- [243](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L243): `{error && (`
- [245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L245): `role="alert"`
- [268](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L268): `{folders.length === 0 ? (`
- [351](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L351): `title={folder.path}`
- [464](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L464): `title={t("Sync Process")}`
- [474](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L474): `{task.error && (`
- [476](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbLinkedFoldersSection.tsx#L476): `role="alert"`

### web/components/knowledge/KbMarginNoteDevicesSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L4): `import { useCallback, useEffect, useState } from "react";`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L43): `const [devices, setDevices] = useState<MarginNoteDevice[] | null>(null);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L44): `const [status, setStatus] = useState<MarginNoteLibraryStatus | null>(null);`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L45): `const [deviceName, setDeviceName] = useState("");`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L46): `const [pairing, setPairing] = useState(false);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L47): `const [issued, setIssued] = useState<MarginNotePairing | null>(null);`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L48): `const [copied, setCopied] = useState(false);`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L49): `const [error, setError] = useState<string | null>(null);`
- [201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L201): `{error && (`
- [216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L216): `) : devices.length === 0 ? (`
- [267](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbMarginNoteDevicesSection.tsx#L267): `label: string;`

### web/components/knowledge/KbSettingsSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L4): `import { useEffect, useState } from "react";`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L34): `const [workspaces, setWorkspaces] = useState<ChatWorkspaceRegistration[]>([]);`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L35): `const [targetWorkspaceId, setTargetWorkspaceId] = useState("");`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L36): `const [movePreview, setMovePreview] = useState<KnowledgeMovePreview | null>(null);`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L37): `const [moveBusy, setMoveBusy] = useState(false);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L38): `const [moveError, setMoveError] = useState<string | null>(null);`
- [199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L199): `<p key={blocker} role="alert" className="text-red-600">{blocker}</p>`
- [201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L201): `{movePreview.blockers.length === 0 && (`
- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L214): `{moveError && <p role="alert" className="text-[11.5px] text-red-600">{moveError}</p>}`
- [251](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbSettingsSection.tsx#L251): `label: string;`

### web/components/knowledge/KbTaskLogs.tsx

- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbTaskLogs.tsx#L40): `title={t("Process Logs")}`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbTaskLogs.tsx#L63): `{task?.error && (`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbTaskLogs.tsx#L65): `role="alert"`

### web/components/knowledge/KbUpdateHistory.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbUpdateHistory.tsx#L4): `import { useState } from "react";`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbUpdateHistory.tsx#L30): `const [expandedId, setExpandedId] = useState<string | null>(null);`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbUpdateHistory.tsx#L32): `if (entries.length === 0) return null;`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbUpdateHistory.tsx#L106): `{entry.error && (`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbUpdateHistory.tsx#L116): `!entry.error && (`

### web/components/knowledge/KbVisualCoverage.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbVisualCoverage.tsx#L3): `import { useEffect, useState } from "react";`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbVisualCoverage.tsx#L18): `const [offset, setOffset] = useState(0);`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbVisualCoverage.tsx#L19): `const [expanded, setExpanded] = useState(false);`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbVisualCoverage.tsx#L21): `const [result, setResult] = useState<{ key: string; data?: Coverage; error?: boolean }>();`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbVisualCoverage.tsx#L39): `{current?.error ? <p role="alert">{t("Could not read visual coverage. Open the original document to inspect the source.")}</p>`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbVisualCoverage.tsx#L41): `: !report ? <p role="alert">{t("Source document is unavailable. Refresh the file list.")}</p> : <>`

### web/components/knowledge/KbWebSourcesSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L4): `import { useCallback, useEffect, useState } from "react";`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L37): `const [sources, setSources] = useState<WebSource[]>([]);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L38): `const [jobs, setJobs] = useState<WebSourceSyncJob[]>([]);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L39): `const [loading, setLoading] = useState(true);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L40): `const [showForm, setShowForm] = useState(false);`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L41): `const [syncing, setSyncing] = useState(false);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L42): `const [error, setError] = useState<string | null>(null);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L44): `const [urlInput, setUrlInput] = useState("");`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L45): `const [maxDepth, setMaxDepth] = useState(3);`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L46): `const [submitting, setSubmitting] = useState(false);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L47): `const [busySource, setBusySource] = useState<string | null>(null);`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L48): `const [intervalInputs, setIntervalInputs] = useState<Record<string, number>>(`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L160): `{error ? (`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L202): `disabled={syncing || sources.length === 0}`
- [223](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L223): `{error && (`
- [277](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L277): `{sources.length === 0 ? (`
- [387](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L387): `title={source.bilingual_pairings`
- [443](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L443): `{source.last_sync_error && (`
- [448](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KbWebSourcesSection.tsx#L448): `{job?.error && (`

### web/components/knowledge/KnowledgeBaseDetail.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L8): `import { useState } from "react";`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L95): `{ label: string; Icon: typeof FileText }`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L97): `files: { label: "Files", Icon: FileText },`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L98): `add: { label: "Add documents", Icon: Upload },`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L99): `folders: { label: "Linked folders", Icon: FolderSync },`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L100): `github: { label: "GitHub", Icon: Github },`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L101): `web: { label: "Web", Icon: Globe },`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L102): `versions: { label: "Index versions", Icon: Layers },`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L103): `devices: { label: "Devices", Icon: Smartphone },`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L104): `kiwix: { label: "Articles", Icon: FileText },`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L105): `settings: { label: "Settings", Icon: SettingsIcon },`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L130): `const [section, setSection] = useState<KbDetailSection>("files");`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeBaseDetail.tsx#L131): `const [retrySubmitting, setRetrySubmitting] = useState(false);`

### web/components/knowledge/KnowledgeHome.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L5): `import { useMemo, useState } from "react";`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L108): `const [query, setQuery] = useState("");`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L239): `title={t("Knowledge Center")}`
- [254](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L254): `role="tablist"`
- [261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L261): `label: t("Knowledge bases"),`
- [267](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L267): `label: t("Knowledge engines"),`
- [279](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L279): `role="tab"`
- [307](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L307): `role="tabpanel"`
- [335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L335): `{kbs.length === 0 ? (`
- [355](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L355): `) : filteredKbs.length === 0 ? (`
- [413](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgeHome.tsx#L413): `role="tabpanel"`

### web/components/knowledge/KnowledgePage.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L9): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L99): `const [explicitSelection, setExplicitSelection] = useState<string | null>(`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L102): `const [selectedEngineId, setSelectedEngineId] = useState<string | null>(`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L106): `useState<KnowledgeHomeSection>(initialHomeSection);`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L107): `const [createOpen, setCreateOpen] = useState(false);`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L108): `const [kiwixOpen, setKiwixOpen] = useState(false);`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L109): `const [createPreset, setCreatePreset] = useState<{`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L127): `const [view, setView] = useState<"home" | "kb" | "engine">(`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L165): `if (loading && explicitSelection) return explicitSelection;`
- [231](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L231): `router.replace(search ? '${pathname}?${search}' : pathname, {`
- [396](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L396): `{error && (`
- [418](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/KnowledgePage.tsx#L418): `{loading ? (`

### web/components/knowledge/LinkFolderModal.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L3): `import { useEffect, useState } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L20): `const [folderPath, setFolderPath] = useState("");`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L21): `const [error, setError] = useState<string | null>(null);`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L22): `const [submitting, setSubmitting] = useState(false);`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L51): `<Modal`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L54): `title={t("Link a local folder")}`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L115): `aria-describedby={'linked-folder-help${error ? " linked-folder-error" : ""}'}`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L126): `{error && (`
- [129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/LinkFolderModal.tsx#L129): `role="alert"`

### web/components/knowledge/PageIndexSettingsModal.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L3): `import { useEffect, useState } from "react";`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L36): `const [config, setConfig] = useState<PageIndexConfig | null>(null);`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L37): `const [apiKey, setApiKey] = useState("");`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L38): `const [loading, setLoading] = useState(true);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L39): `const [saving, setSaving] = useState(false);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L40): `const [error, setError] = useState<string | null>(null);`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L107): `{loading ? (`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L141): `{error && (`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L189): `const [saving, setSaving] = useState(false);`
- [192](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L192): `<Modal`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/knowledge/PageIndexSettingsModal.tsx#L195): `title={t("PageIndex settings")}`

### web/components/layout/AppShell.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L8): `useState,`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L59): `const [drawerOpen, setDrawerOpen] = useState(false);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/AppShell.tsx#L66): `const [trackedPathname, setTrackedPathname] = useState(pathname);`

### web/components/layout/LocationCrumbs.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L5): `import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L22): `const [open, setOpen] = useState(false)`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L37): `<div role="menu" aria-label={section.label} className="dt-popover dt-crumb-panel">`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L42): `role="menuitem"`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L61): `label: string`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L98): `label: ReactNode`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L111): `create?: { label: string; href?: string; onSelect?: () => void }`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L112): `all?: { label: string; href: string }`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L122): `const [open, setOpen] = useState(false)`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L123): `const [items, setItems] = useState<CrumbItem[] | null>(null)`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L124): `const [failed, setFailed] = useState(false)`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L125): `const [query, setQuery] = useState('')`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L126): `const [found, setFound] = useState<CrumbItem[] | null>(null)`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L176): `if (item.href) router.push(item.href)`
- [209](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L209): `<div role="menu" aria-label={menuLabel} className="dt-popover dt-crumb-panel is-instances">`
- [225](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L225): `role="menuitem"`
- [237](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L237): `role="menuitem"`
- [249](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L249): `) : rows.length === 0 ? (`
- [258](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L258): `role="menuitem"`
- [285](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L285): `role="menuitem"`
- [295](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L295): `role="menuitem"`
- [329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/LocationCrumbs.tsx#L329): `label: string`

### web/components/layout/PageChrome.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/PageChrome.tsx#L3): `import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/PageChrome.tsx#L24): `const [slots, setSlots] = useState<Slots>({ instance: null, meta: null, actions: null })`

### web/components/layout/instance-crumbs.tsx

- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L31): `label: string`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L47): `label: collection.title || t('Untitled collection'),`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L60): `all={{ label: t('All collections'), href: READING_HOME }}`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L71): `label: '${topic.emoji ? '${topic.emoji} ' : ''}${topic.name || topic.path_id}',`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L84): `all={{ label: t('All paths'), href: MASTERY_HOME }}`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L98): `label: book.title || t('Untitled book'),`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L112): `all={{ label: t('All books'), href: BOOKS_HOME }}`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L123): `.map(kb => ({ id: kb.name, label: kb.name, href: knowledgeBaseRoute(kb.name) })),`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L133): `all={{ label: t('Knowledge Center'), href: knowledgeBaseRoute() }}`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L150): `label: partner.name,`
- [164](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L164): `create={{ label: t('New partner'), href: '/partners/new' }}`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/layout/instance-crumbs.tsx#L165): `all={{ label: t('All partners'), href: '/partners' }}`

### web/components/learning/LearningDashboard.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L5): `import { useState } from 'react'`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L36): `const [kind, setKind] = useState<LearningKind | 'all'>('all')`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L37): `const [query, setQuery] = useState('')`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L38): `const [limit, setLimit] = useState(24)`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L47): `title={t('navigation.learning')}`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L48): `subtitle={t('navigation.learningDescription')}`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L68): `{loading ? (`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L82): `title={topic.name || topic.metadata.goal}`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L84): `subtitle={t('{{count}} reviews due', {`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L104): `title={book.title}`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L106): `subtitle={`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L131): `title={item.title}`
- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L134): `subtitle={t(surface.title)}`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L143): `{!all.length && failed.length === 0 && <LearningWays />}`
- [144](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L144): `{!recent.length && failed.length === 0 && (`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningDashboard.tsx#L146): `title={t(all.length ? 'navigation.noResults' : 'Your next learning journey starts here')}`

### web/components/learning/LearningShell.tsx

- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningShell.tsx#L57): `<PageHeader title={title} description={subtitle} action={action} icon={icon ?? surfaceIcon ?? BookOpen} />`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningShell.tsx#L101): `role="alert"`

### web/components/learning/LearningWays.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningWays.tsx#L5): `import { useCallback, useEffect, useId, useRef, useState } from 'react'`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningWays.tsx#L25): `const [openKind, setOpenKind] = useState<LearningKind | null>(null)`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/LearningWays.tsx#L196): `role="dialog"`

### web/components/learning/NewLearningPage.tsx

- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L42): `title={t('navigation.createLearning')}`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L43): `subtitle={t('navigation.createLearningDescription')}`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L57): `{loading ? (`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L70): `onClick={() => navigateTask('${item.href}?create=1', router.push)}`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L95): `!inventory.error && (`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L98): `title={t('customize.emptyLearning')}`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/NewLearningPage.tsx#L104): `{!loading && (`

### web/components/learning/create-request.ts

- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/create-request.ts#L21): `router.replace('${pathname}${next.size ? '?${next}' : ''}', { scroll: false })`

### web/components/learning/practice/PracticeImport.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L3): `import { useRef, useState } from "react";`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L23): `const [target, setTarget] = useState(initialTarget);`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L24): `const [preview, setPreview] = useState<ImportPreview | null>(null);`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L25): `const [filename, setFilename] = useState("");`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L26): `const [busy, setBusy] = useState(false);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L28): `const [error, setError] = useState("");`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L141): `{error && (`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L142): `<p role="alert" className="mt-3 text-sm text-destructive">`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeImport.tsx#L157): `role="alert"`

### web/components/learning/practice/PracticeInsights.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L3): `import { useEffect, useId, useRef, useState } from "react";`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L15): `const METRICS: { key: PracticeMetric; label: string; color: string }[] = [`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L16): `{ key: "questions", label: "New questions", color: "#4f70d9" },`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L17): `{ key: "mistakes", label: "New mistakes", color: "#d08732" },`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L18): `{ key: "reviews", label: "Review submissions", color: "#329080" },`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L41): `const [result, setResult] = useState<{ scope: string; data: PracticeAnalytics } | null>(null);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L42): `const [error, setError] = useState("");`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L43): `const [loading, setLoading] = useState(true);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L44): `const [retry, setRetry] = useState(0);`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L50): `router.replace(practiceRoute(query), { scroll: false });`
- [163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L163): `{error && (`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L165): `role="alert"`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L238): `{loading ? t("Loading…") : t("Statistics unavailable")}`
- [296](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L296): `label: string;`
- [302](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L302): `const [width, setWidth] = useState(600);`
- [303](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeInsights.tsx#L303): `const [selected, setSelected] = useState<string | null>(null);`

### web/components/learning/practice/PracticePage.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L3): `import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L31): `const [summary, setSummary] = useState<PracticeSummary | null>(null);`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L32): `const [error, setError] = useState("");`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L33): `const [importOpen, setImportOpen] = useState(initialImport);`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L34): `const [notice, setNotice] = useState("");`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L35): `const [revision, setRevision] = useState(0);`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L36): `const [session, setSession] = useState<number[] | null>(() => {`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L40): `const [starting, setStarting] = useState(false);`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L98): `router.replace(pageRoute(next), { scroll: false });`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L143): `{error && <LearningErrorState message={error} onRetry={() => void refresh()} />}`
- [207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L207): `role="tablist"`
- [216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L216): `role="tab"`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L238): `<div id="practice-collection" role="tabpanel" aria-labelledby={'practice-tab-${tab}'}>`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L271): `title={t("Question Bank")}`
- [281](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L281): `title={t("Practice")}`
- [282](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticePage.tsx#L282): `subtitle={t("Collect what you learn. Practice what matters. Remember it for longer.")}`

### web/components/learning/practice/PracticeSession.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L6): `import { useEffect, useRef, useState } from 'react'`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L19): `const RATINGS: { value: PracticeRating; label: string; description: string }[] = [`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L20): `{ value: 'again', label: 'Again', description: 'Practice again this round' },`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L21): `{ value: 'hard', label: 'Hard', description: 'I needed a hint' },`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L22): `{ value: 'good', label: 'Mastered', description: 'Review in a few days' },`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L23): `{ value: 'easy', label: 'Easy', description: 'I knew it confidently' },`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L37): `const [queue, setQueue] = useState<PracticeRef[]>(`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L40): `const [total] = useState(queue.length)`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L41): `const [skipped, setSkipped] = useState(0)`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L43): `const [index, setIndex] = useState(0)`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L44): `const [saved, setSaved] = useState(0)`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L45): `const [saving, setSaving] = useState(false)`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L46): `const [nextDue, setNextDue] = useState<number | null>(null)`
- [140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L140): `const [question, setQuestion] = useState<PracticeQuestion | null>(null)`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L141): `const [answer, setAnswer] = useState('')`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L142): `const [revealed, setRevealed] = useState(false)`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L143): `const [correct, setCorrect] = useState<boolean | null>(null)`
- [144](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L144): `const [busy, setBusy] = useState(false)`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L145): `const [error, setError] = useState('')`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L146): `const [conflict, setConflict] = useState(false)`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L147): `const [reload, setReload] = useState(0)`
- [229](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L229): `{error && (`
- [230](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/PracticeSession.tsx#L230): `<div role="alert" className="mb-4 rounded-lg bg-destructive/5 p-3 text-sm text-destructive">`

### web/components/learning/practice/ReviewHome.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L3): `import { useCallback, useEffect, useRef, useState } from 'react'`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L21): `const [summary, setSummary] = useState<PracticeSummary | null>(null)`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L22): `const [error, setError] = useState('')`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L23): `const [revision, setRevision] = useState(0)`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L24): `const [session, setSession] = useState<PracticeRef[] | null>(null)`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L25): `const [starting, setStarting] = useState(false)`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L26): `const [importing, setImporting] = useState(false)`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L27): `const [notice, setNotice] = useState('')`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L81): `title={t('Practice')}`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L82): `subtitle={t('A little recall today. Remember more tomorrow.')}`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/learning/practice/ReviewHome.tsx#L102): `{error && <LearningErrorState message={error} onRetry={() => void refresh()} />}`

### web/components/math-animator/MathAnimatorViewer.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/math-animator/MathAnimatorViewer.tsx#L3): `import { useEffect, useMemo, useRef, useState } from "react";`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/math-animator/MathAnimatorViewer.tsx#L19): `const [fullscreenUrl, setFullscreenUrl] = useState<string | null>(null);`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/math-animator/MathAnimatorViewer.tsx#L96): `{!bare && <Header icon={Video} title={t("Video Output")} />}`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/math-animator/MathAnimatorViewer.tsx#L114): `{!bare && <Header icon={ImageIcon} title={t("Image Output")} />}`

### web/components/mcp/KeyValueEditor.tsx

- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/KeyValueEditor.tsx#L31): `label: string;`

### web/components/mcp/McpAdminRegistry.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpAdminRegistry.tsx#L3): `import { useState } from "react";`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpAdminRegistry.tsx#L27): `const [open, setOpen] = useState(false);`

### web/components/mcp/McpCatalogBrowser.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L4): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L106): `const [queryDraft, setQueryDraft] = useState("");`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L107): `const [query, setQuery] = useState("");`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L108): `const [category, setCategory] = useState("");`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L109): `const [tier, setTier] = useState("");`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L111): `const [list, setList] = useState<McpCatalogList | null>(null);`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L112): `const [loading, setLoading] = useState(true);`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L113): `const [loadingMore, setLoadingMore] = useState(false);`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L114): `const [error, setError] = useState<string | null>(null);`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L116): `const [selected, setSelected] = useState<McpCatalogEntry | null>(null);`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L117): `const [installState, setInstallState] = useState<`
- [280](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L280): `{error && (`
- [286](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L286): `{loading ? (`
- [290](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L290): `) : !list || list.entries.length === 0 ? (`
- [449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L449): `const [name, setName] = useState(() => installedAs[0] ?? entry.id);`
- [450](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L450): `const [values, setValues] = useState<Record<string, string>>({});`
- [451](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L451): `const [probe, setProbe] = useState<McpTestResult | null>(null);`
- [452](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L452): `const [probing, setProbing] = useState(false);`
- [666](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L666): `{probe.error && (`
- [730](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpCatalogBrowser.tsx#L730): `label: string;`

### web/components/mcp/McpDeploymentList.tsx

- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpDeploymentList.tsx#L24): `if (names.length === 0) return null;`

### web/components/mcp/McpServerForm.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L3): `import { useCallback, useState } from "react";`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L52): `const [name, setName] = useState(initialName);`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L53): `const [type, setType] = useState<McpServerConfig["type"]>(initialConfig.type);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L54): `const [command, setCommand] = useState(initialConfig.command);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L55): `const [argsText, setArgsText] = useState(arrayToLines(initialConfig.args));`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L56): `const [envPairs, setEnvPairs] = useState<McpKvPair[]>(`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L59): `const [cwd, setCwd] = useState(initialConfig.cwd);`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L60): `const [url, setUrl] = useState(initialConfig.url);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L61): `const [allowPrivateNetwork, setAllowPrivateNetwork] = useState(initialConfig.allow_private_network ?? false);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L62): `const [headerPairs, setHeaderPairs] = useState<McpKvPair[]>(`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L65): `const [toolTimeout, setToolTimeout] = useState(initialConfig.tool_timeout);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L66): `const [enabledToolsText, setEnabledToolsText] = useState(`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L70): `const [testing, setTesting] = useState(false);`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L71): `const [testTools, setTestTools] = useState<McpTool[] | null>(null);`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L72): `const [testError, setTestError] = useState<string | null>(null);`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerForm.tsx#L73): `const [formError, setFormError] = useState<string | null>(null);`

### web/components/mcp/McpServerList.tsx

- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerList.tsx#L56): `if (names.length === 0) {`

### web/components/mcp/McpServerRow.tsx

- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerRow.tsx#L109): `{rowStatus === "error" && status?.error && (`
- [190](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerRow.tsx#L190): `label: string;`
- [224](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpServerRow.tsx#L224): `label: string;`

### web/components/mcp/McpStatusBadge.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpStatusBadge.tsx#L13): `error?: string;`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpStatusBadge.tsx#L33): `role={status === "error" && error ? "note" : undefined}`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpStatusBadge.tsx#L34): `tabIndex={status === "error" && error ? 0 : undefined}`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/mcp/McpStatusBadge.tsx#L44): `return status === "error" && error ? (`

### web/components/memory/MemoryArchivedBanner.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryArchivedBanner.tsx#L5): `import { useCallback, useState } from "react";`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryArchivedBanner.tsx#L21): `const [dismissed, setDismissed] = useState<string | null>(() => {`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryArchivedBanner.tsx#L25): `const [expanded, setExpanded] = useState(false);`

### web/components/memory/MemoryGraph.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L9): `useState,`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L72): `const [graph, setGraph] = useState<MemoryGraph | null>(null);`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L73): `const [loading, setLoading] = useState(true);`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L74): `const [layerOn, setLayerOn] = useState<Record<Layer, boolean>>({`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L79): `const [hover, setHover] = useState<HoverState | null>(null);`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L80): `const [selected, setSelected] = useState<string | null>(null);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L81): `const [view, setView] = useState<ViewState>(INITIAL_VIEW);`
- [266](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L266): `{loading && (`
- [275](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L275): `{graph && !loading && (`
- [288](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L288): `{graph && !loading && <Legend graph={graph} />}`
- [332](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L332): `className={loading ? "h-3.5 w-3.5 animate-spin" : "h-3.5 w-3.5"}`
- [810](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L810): `<IconButton onClick={() => zoomBy(1.25)} title={t("Zoom in")}>`
- [813](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L813): `<IconButton onClick={() => zoomBy(1 / 1.25)} title={t("Zoom out")}>`
- [816](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryGraph.tsx#L816): `<IconButton onClick={fit} title={t("Fit")}>`

### web/components/memory/MemoryHub.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L5): `import { useCallback, useEffect, useState } from "react";`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L54): `const [overview, setOverview] = useState<OverviewResponse | null>(null);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L55): `const [l1Total, setL1Total] = useState<number | null>(null);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L56): `const [loading, setLoading] = useState(true);`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L93): `title={t("Memory")}`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L103): `className={loading ? "h-3 w-3 animate-spin" : "h-3 w-3"}`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L121): `title={t("L1 · Workspace mirror")}`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L133): `title={t("L2 · Per-surface summaries")}`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryHub.tsx#L146): `title={t("L3 · Cross-surface knowledge")}`

### web/components/memory/MemoryL1Workbench.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L4): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L35): `label: string;`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L40): `{ key: "chat", icon: MessageSquare, label: "Chat" },`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L41): `{ key: "notebook", icon: NotebookPen, label: "Notebook" },`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L42): `{ key: "quiz", icon: ClipboardList, label: "Quiz" },`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L43): `{ key: "kb", icon: BookOpen, label: "Knowledge base" },`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L44): `{ key: "book", icon: Library, label: "Book" },`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L45): `{ key: "partner", icon: Bot, label: "Partner" },`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L46): `{ key: "cowriter", icon: PenLine, label: "Co-writer" },`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L68): `const [surface, setSurface] = useState<Surface>(initialSurface || "notebook");`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L69): `const [counts, setCounts] = useState<Record<Surface, number>>(`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L72): `const [pending, setPending] = useState<Record<Surface, number>>(`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L75): `const [focusRef, setFocusRef] = useState<string | null>(`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L78): `const [toast, setToast] = useState("");`
- [224](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L224): `label: string;`
- [226](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L226): `{ key: "L1", href: "/memory/l1", icon: Layers, label: t("L1") },`
- [227](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L227): `{ key: "L2", href: "/memory/l2", icon: Workflow, label: t("L2") },`
- [228](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L228): `{ key: "L3", href: "/memory/l3", icon: Network, label: t("L3") },`
- [260](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryL1Workbench.tsx#L260): `function Breadcrumb({ label, t }: { label: string; t: (k: string) => string }) {`

### web/components/memory/MemoryRunPanel.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L4): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L69): `const [mode, setMode] = useState<RunMode>("update");`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L73): `const [overrides, setOverrides] = useState<Record<RunMode, number | null>>({`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L88): `const [selection, setSelection] = useState<LLMSelection | null>(null);`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L89): `const [activeDefault, setActiveDefault] = useState<LLMSelection | null>(null);`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L90): `const [modelOptions, setModelOptions] = useState<LLMOption[]>([]);`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L91): `const [modelLoading, setModelLoading] = useState(true);`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L92): `const [modelError, setModelError] = useState(false);`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L93): `const [settings, setSettings] = useState<MemorySettingsDTO | null>(null);`
- [394](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L394): `{events.length === 0 && status === "idle" ? (`
- [407](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L407): `{error && (`
- [434](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L434): `label: string | null;`
- [458](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L458): `label: typeof p.label === "string" ? p.label : null,`
- [702](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L702): `const [systemOpen, setSystemOpen] = useState(false);`
- [703](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L703): `const [userOpen, setUserOpen] = useState(false);`
- [735](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L735): `) : turn.error ? (`
- [758](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L758): `label: string;`
- [799](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L799): `label: string;`
- [850](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L850): `const [open, setOpen] = useState(false);`
- [871](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryRunPanel.tsx#L871): `const inactive = disabled || loading || error || options.length === 0;`

### web/components/memory/MemorySection.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L8): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L66): `label: string;`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L84): `label: string;`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L146): `label: string;`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L150): `chat: { icon: MessageSquare, label: "Chat" },`
- [151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L151): `notebook: { icon: NotebookPen, label: "Notebook" },`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L152): `quiz: { icon: ClipboardList, label: "题库" },`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L153): `kb: { icon: BookOpen, label: "Knowledge base" },`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L154): `book: { icon: Library, label: "Book" },`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L155): `partner: { icon: Bot, label: "Partner" },`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L156): `cowriter: { icon: PenLine, label: "Co-writer" },`
- [269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L269): `const [tab, setTab] = useState<Tab>(forcedTab ?? "L2");`
- [270](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L270): `const [overview, setOverview] = useState<OverviewResponse | null>(null);`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L271): `const [selected, setSelected] = useState<{`
- [275](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L275): `const [content, setContent] = useState("");`
- [276](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L276): `const [editing, setEditing] = useState(false);`
- [277](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L277): `const [editorValue, setEditorValue] = useState("");`
- [278](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L278): `const [stream, setStream] = useState<StreamStage[]>([]);`
- [279](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L279): `const [loading, setLoading] = useState(true);`
- [280](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L280): `const [busy, setBusy] = useState(false);`
- [281](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L281): `const [toast, setToast] = useState("");`
- [282](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L282): `const [l1Surface, setL1Surface] = useState<Surface>("notebook");`
- [283](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L283): `const [l1FocusRef, setL1FocusRef] = useState<string | null>(null);`
- [284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L284): `const [dismissedBackup, setDismissedBackup] = useState<string | null>(null);`
- [453](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L453): `title={t("Memory")}`
- [520](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L520): `title={t(`
- [530](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L530): `{loading ? (`
- [585](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L585): `const tabs: Array<{ key: Tab; label: string; count?: number; hint: string }> =`
- [589](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L589): `label: t("L1 · Workspace"),`
- [596](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L596): `label: t("L2 · Per-surface"),`
- [602](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L602): `label: t("L3 · Cross-surface"),`
- [669](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L669): `const [mode, setMode] = useState<L1Mode>("snapshot");`
- [670](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L670): `const [snapshot, setSnapshot] = useState<SnapshotResponse | null>(null);`
- [671](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L671): `const [changes, setChanges] = useState<ChangeEntryDTO[]>([]);`
- [672](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L672): `const [kbQueries, setKbQueries] = useState<KbQueryDTO[]>([]);`
- [673](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L673): `const [loadingSnapshot, setLoadingSnapshot] = useState(false);`
- [674](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L674): `const [loadingChanges, setLoadingChanges] = useState(false);`
- [675](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L675): `const [loadingQueries, setLoadingQueries] = useState(false);`
- [676](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L676): `const [refreshing, setRefreshing] = useState(false);`
- [922](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L922): `label: string;`
- [951](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L951): `const tabs: Array<{ key: L1Mode; label: string; hidden?: boolean }> = [`
- [952](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L952): `{ key: "snapshot", label: t("Snapshot") },`
- [953](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L953): `{ key: "changes", label: t("Changes") },`
- [954](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L954): `{ key: "queries", label: t("Queries"), hidden: surface !== "kb" },`
- [1025](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1025): `{loading && entities.length === 0 ? (`
- [1029](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1029): `) : entities.length === 0 ? (`
- [1115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1115): `<Tooltip label={t("Open in {{label}}", { label: meta.label })} as="div" side="top">`
- [1138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1138): `label: t("new"),`
- [1142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1142): `label: t("modified"),`
- [1146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1146): `label: t("removed"),`
- [1174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1174): `if (loading && changes.length === 0 && pending.length === 0) {`
- [1261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1261): `if (loading && queries.length === 0) {`
- [1268](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemorySection.tsx#L1268): `if (queries.length === 0) {`

### web/components/memory/MemoryWorkbench.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L6): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L150): `label: string;`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L155): `{ key: "chat", icon: MessageSquare, label: "Chat" },`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L156): `{ key: "notebook", icon: NotebookPen, label: "Notebook" },`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L157): `{ key: "quiz", icon: ClipboardList, label: "Quiz" },`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L158): `{ key: "kb", icon: BookOpen, label: "Knowledge base" },`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L159): `{ key: "book", icon: Library, label: "Book" },`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L160): `{ key: "partner", icon: Bot, label: "Partner" },`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L161): `{ key: "cowriter", icon: PenLine, label: "Co-writer" },`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L165): `{ key: "recent", icon: Network, label: "Recent summary" },`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L166): `{ key: "profile", icon: Network, label: "User profile" },`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L167): `{ key: "scope", icon: Network, label: "Knowledge scope" },`
- [191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L191): `const [docKey, setDocKey] = useState<string>(initialKey || nav[0].key);`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L197): `const [overview, setOverview] = useState<Record<string, DocOverview>>({});`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L198): `const [content, setContent] = useState("");`
- [199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L199): `const [lines, setLines] = useState<LineRowDTO[]>([]);`
- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L200): `const [view, setView] = useState<ViewMode>("plain");`
- [201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L201): `const [editing, setEditing] = useState(false);`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L202): `const [editorValue, setEditorValue] = useState("");`
- [203](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L203): `const [saving, setSaving] = useState(false);`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L204): `const [toast, setToast] = useState("");`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L208): `const [pendingFocus, setPendingFocus] = useState<string | null>(`
- [304](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L304): `router.replace(`
- [452](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L452): `<EmptyState t={t} />`
- [484](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L484): `label: string;`
- [526](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L526): `label: string;`
- [528](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L528): `{ key: "L1", href: "/memory/l1", icon: Layers, label: t("L1") },`
- [529](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L529): `{ key: "L2", href: "/memory/l2", icon: Workflow, label: t("L2") },`
- [530](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L530): `{ key: "L3", href: "/memory/l3", icon: Network, label: t("L3") },`
- [571](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L571): `const items: { key: ViewMode; label: string; icon: LucideIcon }[] = [`
- [572](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L572): `{ key: "plain", label: t("Rendered"), icon: FileText },`
- [573](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L573): `{ key: "lines", label: t("Line numbers"), icon: Hash },`
- [604](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/MemoryWorkbench.tsx#L604): `if (lines.length === 0) return <EmptyState t={t} />;`

### web/components/memory/useMemoryRun.ts

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/useMemoryRun.ts#L5): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/memory/useMemoryRun.ts#L78): `const [state, setState] = useState<State>({`

### web/components/notebook/NotebookConsole.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L4): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L89): `const [banner, setBanner] = useState<string | null>(null);`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L106): `role="alert"`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L126): `title={t("Could not load your notebooks")}`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L149): `onOpen={(id) => router.push(notebookRoute(id))}`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L172): `const [peeks, setPeeks] = useState<Record<string, NotebookRecordItem[]>>({});`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L218): `const [query, setQuery] = useState("");`
- [219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L219): `const [creating, setCreating] = useState(startCreating);`
- [220](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L220): `const [editingId, setEditingId] = useState<string | null>(null);`
- [249](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L249): `title={t("Notebooks")}`
- [344](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L344): `if (createdId) router.push(notebookRoute(createdId));`
- [474](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L474): `const [recordQuery, setRecordQuery] = useState("");`
- [475](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L475): `const [recordKind, setRecordKind] = useState("");`
- [476](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L476): `const [recordError, setRecordError] = useState<string | null>(null);`
- [477](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L477): `const [editing, setEditing] = useState(false);`
- [478](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L478): `const [confirmingDelete, setConfirmingDelete] = useState(false);`
- [479](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L479): `const [deleting, setDeleting] = useState(false);`
- [521](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L521): `router.replace(notebookRoute(collectionId, initialRecordId));`
- [576](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L576): `label: notebook.name,`
- [588](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L588): `router.replace(notebookRoute());`
- [618](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L618): `router.push('/chat/${encodeURIComponent(sessionId)}'),`
- [632](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L632): `create={{ label: t("New notebook"), href: "/notebooks?create=1" }}`
- [633](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L633): `all={{ label: t("All notebooks"), href: notebookRoute() }}`
- [640](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L640): `role="alert"`
- [649](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L649): `title={t("This notebook could not be opened")}`
- [655](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L655): `title={`
- [773](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L773): `router.replace(route, { scroll: false });`
- [786](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L786): `title={`
- [803](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L803): `<ConfirmDialog`
- [805](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L805): `title={t("Delete this notebook?")}`
- [836](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L836): `label: string;`
- [847](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L847): `const [name, setName] = useState(initial?.name ?? "");`
- [848](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L848): `const [description, setDescription] = useState(initial?.description ?? "");`
- [849](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L849): `const [color, setColor] = useState(initial?.color ?? DEFAULT_COLOR);`
- [850](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L850): `const [busy, setBusy] = useState(false);`
- [940](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookConsole.tsx#L940): `label: string;`

### web/components/notebook/NotebookRecordActions.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx#L43): `const [open, setOpen] = useState(false);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx#L44): `const [panel, setPanel] = useState<Panel>("root");`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx#L102): `role="menu"`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx#L157): `role="menuitem"`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx#L197): `label: string;`
- [205](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordActions.tsx#L205): `role="menuitem"`

### web/components/notebook/NotebookRecordPicker.tsx

- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordPicker.tsx#L59): `title={t("Select Notebook Records")}`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordPicker.tsx#L60): `subtitle={t(`

### web/components/notebook/NotebookRecordRow.tsx

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L7): `import { useEffect, useState } from "react";`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L121): `const [editing, setEditing] = useState(false);`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L122): `const [previewing, setPreviewing] = useState(false);`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L123): `const [busy, setBusy] = useState(false);`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L124): `const [pending, setPending] = useState<Pending>(null);`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L125): `const [draftTitle, setDraftTitle] = useState(record.title);`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L126): `const [draftSummary, setDraftSummary] = useState(record.summary ?? "");`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L127): `const [draftOutput, setDraftOutput] = useState(record.output ?? "");`
- [128](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L128): `const [failure, setFailure] = useState<string | null>(null);`
- [274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L274): `<time title={timestamp}>`
- [314](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L314): `<p role="alert" className="dt-fav-record-error">`
- [321](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L321): `title={draftTitle}`
- [361](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L361): `title={record.title}`
- [377](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L377): `<ConfirmDialog`
- [379](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L379): `title={t("Delete this record?")}`
- [393](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L393): `<ConfirmDialog`
- [395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L395): `title={t("Discard your changes?")}`
- [477](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L477): `role="tablist"`
- [482](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L482): `{ key: "write", label: t("Source text"), active: !previewing },`
- [483](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L483): `{ key: "preview", label: t("Preview"), active: previewing },`
- [488](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookRecordRow.tsx#L488): `role="tab"`

### web/components/notebook/NotebookSelector.tsx

- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookSelector.tsx#L79): `) : notebooks.length === 0 ? (`
- [139](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/NotebookSelector.tsx#L139): `) : records.length === 0 ? (`

### web/components/notebook/SaveToNotebookModal.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L4): `import { useEffect, useMemo, useRef, useState } from "react";`
- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L134): `if (messages.length === 0 || turnCount <= 0) return [];`
- [139](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L139): `if (userPositions.length === 0) {`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L157): `const [notebooks, setNotebooks] = useState<RealNotebookSummary[]>([]);`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L158): `const [selectedIds, setSelectedIds] = useState<string[]>([]);`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L159): `const [title, setTitle] = useState("");`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L160): `const [titleEdited, setTitleEdited] = useState(false);`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L161): `const [summaryPreview, setSummaryPreview] = useState("");`
- [162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L162): `const [isLoading, setIsLoading] = useState(false);`
- [163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L163): `const [isLoadingNotebooks, setIsLoadingNotebooks] = useState(false);`
- [164](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L164): `const [error, setError] = useState("");`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L165): `const [selectedMessageIdx, setSelectedMessageIdx] = useState<Set<number>>(`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L170): `const [newNotebookName, setNewNotebookName] = useState("");`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L171): `const [isCreatingNotebook, setIsCreatingNotebook] = useState(false);`
- [459](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L459): `title={t("Save to Notebook")}`
- [460](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L460): `subtitle={`
- [473](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L473): `title={title}`
- [558](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L558): `const empty = preview.length === 0;`
- [621](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L621): `) : notebooks.length === 0 ? (`
- [718](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/SaveToNotebookModal.tsx#L718): `{error && (`

### web/components/notebook/useNotebookLibrary.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L66): `const [notebooks, setNotebooks] = useState<NotebookSummary[]>([]);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L67): `const [selectedId, setSelectedId] = useState<string | null>(`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L70): `const [selected, setSelected] = useState<NotebookDetailState | null>(null);`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L71): `const [loading, setLoading] = useState(true);`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L72): `const [detailLoading, setDetailLoading] = useState(false);`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L73): `const [error, setError] = useState<string | null>(null);`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookLibrary.ts#L74): `const [detailError, setDetailError] = useState<string | null>(null);`

### web/components/notebook/useNotebookSelection.ts

- [1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookSelection.ts#L1): `import { useState, useCallback } from "react";`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookSelection.ts#L17): `const [notebooks, setNotebooks] = useState<Notebook[]>([]);`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookSelection.ts#L18): `const [expandedNotebooks, setExpandedNotebooks] = useState<Set<string>>(`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookSelection.ts#L21): `const [notebookRecordsMap, setNotebookRecordsMap] = useState<`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookSelection.ts#L24): `const [selectedRecords, setSelectedRecords] = useState<`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookSelection.ts#L27): `const [loadingNotebooks, setLoadingNotebooks] = useState(true);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/notebook/useNotebookSelection.ts#L28): `const [loadingRecordsFor, setLoadingRecordsFor] = useState<Set<string>>(`

### web/components/partners/AssetPicker.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L9): `import { useEffect, useRef, useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L25): `label: string;`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L55): `{options.length === 0 ? (`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L99): `const [kbs, setKbs] = useState<Option[]>([]);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L100): `const [skills, setSkills] = useState<Option[]>([]);`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L101): `const [notebooks, setNotebooks] = useState<Option[]>([]);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L102): `const [loading, setLoading] = useState(true);`
- [128](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L128): `label: kb.name,`
- [135](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L135): `label: skill.name,`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L142): `label: nb.name,`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L146): `if (preselectAllSkills && latest.current.value.skills.length === 0) {`
- [188](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L188): `title={t("Knowledge bases")}`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L196): `title={t("Skills")}`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/AssetPicker.tsx#L204): `title={t("Notebooks")}`

### web/components/partners/ChannelIcon.tsx

- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelIcon.tsx#L57): `const LETTER_BADGES: Record<string, { label: string; hex: string }> = {`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelIcon.tsx#L58): `slack: { label: "S", hex: "#4A154B" },`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelIcon.tsx#L59): `mochat: { label: "M", hex: "#07C160" },`

### web/components/partners/ChannelOnboardingPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L38): `useState<PartnerChannelOnboardingSession | null>(null);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L39): `const [busy, setBusy] = useState(false);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L40): `const [error, setError] = useState<string | null>(null);`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L41): `const [nowMs, setNowMs] = useState(() => Date.now());`
- [225](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelOnboardingPanel.tsx#L225): `{error && (`

### web/components/partners/ChannelRuntimeStatus.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelRuntimeStatus.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/ChannelRuntimeStatus.tsx#L23): `const [entry, setEntry] = useState<PartnerChannelRuntimeEntry | null>(null);`

### web/components/partners/FaceEditor.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/FaceEditor.tsx#L10): `import { useRef, useState } from "react";`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/FaceEditor.tsx#L102): `const [uploadError, setUploadError] = useState("");`

### web/components/partners/PartnerArchives.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L162): `const [sessions, setSessions] = useState<PartnerSessionInfo[]>([]);`
- [163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L163): `const [selectedKey, setSelectedKey] = useState("");`
- [164](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L164): `const [messages, setMessages] = useState<HistoryMessage[]>([]);`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L165): `const [olderBefore, setOlderBefore] = useState<number | null>(null);`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L166): `const [loadingOlder, setLoadingOlder] = useState(false);`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L167): `const [loadingSessions, setLoadingSessions] = useState(true);`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L168): `const [loadingMessages, setLoadingMessages] = useState(false);`
- [390](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L390): `title={session.chat_id}`
- [403](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerArchives.tsx#L403): `{!loadingSessions && sessions.length === 0 ? (`

### web/components/partners/PartnerChannels.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L9): `import { useCallback, useEffect, useState } from "react";`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L52): `useState<ChannelsSchemaResponse | null>(null);`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L53): `const [catalogError, setCatalogError] = useState(false);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L54): `const [channels, setChannels] = useState<Record<string, unknown>>({});`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L55): `const [activeChannel, setActiveChannel] = useState<string | null>(null);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L56): `const [reloadError, setReloadError] = useState<string | null>(null);`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L57): `const [loadingDetail, setLoadingDetail] = useState(true);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L58): `const [detailError, setDetailError] = useState(false);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L59): `const [saving, setSaving] = useState(false);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L61): `const [revealed, setRevealed] = useState<Set<string>>(new Set());`
- [347](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChannels.tsx#L347): `activeValue.allow_from.length === 0 && (`

### web/components/partners/PartnerChat.tsx

- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L14): `import { useCallback, useEffect, useRef, useState } from "react";`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L64): `error?: boolean;`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L116): `if (!Array.isArray(value) || value.length === 0) return undefined;`
- [253](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L253): `title={attachment.filename}`
- [272](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L272): `title={attachment.filename}`
- [339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L339): `const [messages, setMessages] = useState<ChatMsg[]>([]);`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L340): `const [olderBefore, setOlderBefore] = useState<number | null>(null);`
- [341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L341): `const [loadingOlder, setLoadingOlder] = useState(false);`
- [342](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L342): `const [historyLoadedKey, setHistoryLoadedKey] = useState("");`
- [343](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L343): `const [historyLoadError, setHistoryLoadError] = useState(false);`
- [344](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L344): `const [historyRetry, setHistoryRetry] = useState(0);`
- [345](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L345): `const [reconciling, setReconciling] = useState(false);`
- [346](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L346): `const [commandBusy, setCommandBusy] = useState(false);`
- [348](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L348): `const [restoreDraft, setRestoreDraft] = useState<{`
- [363](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L363): `const [streaming, setStreaming] = useState(false);`
- [366](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L366): `const [connected, setConnected] = useState(false);`
- [370](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L370): `const [draft, setDraft] = useState<{`
- [374](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L374): `const [externalDrafts, setExternalDrafts] = useState<ExternalDraft[]>([]);`
- [943](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L943): `if (document.querySelector('[role="dialog"], [role="alertdialog"]')) {`
- [965](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L965): `if (messages.length === 0) {`
- [1102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L1102): `attachments.length === 0 ? parseClientCommand(content) : null;`
- [1190](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L1190): `{messages.length === 0 && !draft ? (`
- [1252](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerChat.tsx#L1252): `{msg.error ? (`

### web/components/partners/PartnerComposer.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L9): `import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L64): `const [input, setInput] = useState("");`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L65): `const [attachments, setAttachments] = useState<PartnerPendingAttachment[]>(`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L79): `const [dragging, setDragging] = useState(false);`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L80): `const [attachmentError, setAttachmentError] = useState<string | null>(null);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L81): `const [commands, setCommands] = useState<PartnerCommandInfo[]>([]);`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L82): `const [slashClosed, setSlashClosed] = useState(false);`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L83): `const [slashIndex, setSlashIndex] = useState(0);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L84): `const [showHelp, setShowHelp] = useState(false);`
- [261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerComposer.tsx#L261): `if ((!content && attachments.length === 0) || disabled) return;`

### web/components/partners/PartnerConfigure.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L9): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L80): `const [name, setName] = useState(partner.name);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L81): `const [description, setDescription] = useState(partner.description ?? "");`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L82): `const [face, setFace] = useState<FaceValue>({`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L87): `const [language, setLanguage] = useState(partner.language ?? "");`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L88): `const [savingIdentity, setSavingIdentity] = useState(false);`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L91): `const [soul, setSoul] = useState("");`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L92): `const [soulLoaded, setSoulLoaded] = useState(false);`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L93): `const [soulError, setSoulError] = useState<string | null>(null);`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L94): `const [savingSoul, setSavingSoul] = useState(false);`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L97): `const [llmOptions, setLLMOptions] = useState<LLMOption[]>([]);`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L98): `const [activeLLMDefault, setActiveLLMDefault] = useState<LLMSelection | null>(`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L101): `const [llmLoading, setLLMLoading] = useState(true);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L102): `const [llmError, setLLMError] = useState(false);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L103): `const [selection, setSelection] = useState<LLMSelection | null>(`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L106): `const [backupSelection, setBackupSelection] = useState<LLMSelection | null>(`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L111): `const [toolOptions, setToolOptions] = useState<ToolOptions | null>(null);`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L112): `const [enabledTools, setEnabledTools] = useState<string[]>([]);`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L113): `const [builtinTools, setBuiltinTools] = useState<string[]>([]);`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L114): `const [mcpTools, setMcpTools] = useState<string[]>([]);`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L115): `const [savingTools, setSavingTools] = useState(false);`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L117): `const [savingWorkspace, setSavingWorkspace] = useState(false);`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L120): `const [assets, setAssets] = useState<PartnerAssets | null>(null);`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L121): `const [showAssetPicker, setShowAssetPicker] = useState(false);`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L122): `const [pendingAssets, setPendingAssets] = useState<AssetSelection>({`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L127): `const [addingAssets, setAddingAssets] = useState(false);`
- [301](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L301): `label: kb.name,`
- [307](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L307): `label: skill.name,`
- [313](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L313): `label: nb.name || nb.id,`
- [327](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L327): `title={t("Identity")}`
- [385](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L385): `title={t("Soul")}`
- [417](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L417): `title={t("Model")}`
- [456](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L456): `title={t("Tools")}`
- [485](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L485): `<Section title={t("Workspace")}>`
- [496](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L496): `title={t("Library")}`
- [544](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerConfigure.tsx#L544): `{assetRows.length === 0 ? (`

### web/components/partners/PartnerLinkModal.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L13): `import { useCallback, useEffect, useState } from "react";`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L35): `const [links, setLinks] = useState<PartnerLink[]>([]);`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L36): `const [code, setCode] = useState<PartnerLinkCode | null>(null);`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L37): `const [loading, setLoading] = useState(true);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L38): `const [issuing, setIssuing] = useState(false);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L39): `const [copied, setCopied] = useState(false);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L40): `const [error, setError] = useState("");`
- [169](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L169): `{error ? (`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L177): `{loading ? (`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerLinkModal.tsx#L179): `) : links.length === 0 ? (`

### web/components/partners/PartnerModelPicker.tsx

- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelPicker.tsx#L120): `title={t("System default")}`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelPicker.tsx#L121): `subtitle={`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelPicker.tsx#L130): `title={option.model_name || option.model}`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelPicker.tsx#L131): `subtitle={'${option.provider_label || option.provider} · ${option.profile_name}'}`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelPicker.tsx#L142): `{options.length === 0 && (`

### web/components/partners/PartnerModelSelect.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelSelect.tsx#L10): `import { useEffect, useRef, useState } from "react";`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelSelect.tsx#L47): `const [open, setOpen] = useState(false);`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelSelect.tsx#L136): `title={noneLabel}`
- [137](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelSelect.tsx#L137): `subtitle={noneDetail}`
- [144](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelSelect.tsx#L144): `title={option.model_name || option.model}`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelSelect.tsx#L145): `subtitle={'${option.provider_label || option.provider} · ${option.profile_name}'}`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerModelSelect.tsx#L156): `{options.length === 0 && (`

### web/components/partners/PartnerWorkspacePicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L3): `import { useEffect, useId, useState } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L20): `onChange: (id: string, label: string) => void;`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L26): `const [rows, setRows] = useState<ChatWorkspaceRegistration[]>([]);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L27): `const [loading, setLoading] = useState(true);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L28): `const [error, setError] = useState("");`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L29): `const [attempt, setAttempt] = useState(0);`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L89): `{loading ? t("Loading…") : t("Assigned workspace unavailable")}`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L107): `{error && (`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/PartnerWorkspacePicker.tsx#L108): `<p role="alert" className="text-[12px] text-[var(--destructive)]">`

### web/components/partners/SoulEditor.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulEditor.tsx#L10): `import { useState } from "react";`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulEditor.tsx#L29): `const [mode, setMode] = useState<Mode>("edit");`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulEditor.tsx#L31): `const segments: { key: Mode; label: string; icon: typeof PencilLine }[] = [`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulEditor.tsx#L32): `{ key: "edit", label: t("Edit"), icon: PencilLine },`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulEditor.tsx#L33): `{ key: "preview", label: t("Preview"), icon: Eye },`

### web/components/partners/SoulPicker.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L11): `import { useEffect, useState } from "react";`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L57): `const [sources, setSources] = useState<SoulSources | null>(null);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L58): `const [tab, setTab] = useState<SourceTab>(`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L65): `const [saveName, setSaveName] = useState("");`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L66): `const [saving, setSaving] = useState(false);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L67): `const [savedId, setSavedId] = useState("");`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L68): `const [saveError, setSaveError] = useState("");`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L90): `const tabs: { key: SourceTab; label: string; icon: typeof Sparkles }[] = [`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L91): `{ key: "library", label: t("Soul library"), icon: BookHeart },`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L92): `{ key: "persona", label: t("Clone a persona"), icon: UserRound },`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L93): `{ key: "custom", label: t("Write your own"), icon: Sparkles },`
- [183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L183): `{sources && sources.library.length === 0 && (`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/SoulPicker.tsx#L208): `{sources && sources.personas.length === 0 && (`

### web/components/partners/WeixinQrLogin.tsx

- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx#L15): `import { useCallback, useEffect, useRef, useState } from "react";`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx#L35): `const [session, setSession] = useState<WeixinQrSession | null>(null);`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx#L36): `const [svg, setSvg] = useState("");`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx#L37): `const [busy, setBusy] = useState(false);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx#L38): `const [error, setError] = useState("");`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx#L130): `{error && (`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/WeixinQrLogin.tsx#L136): `{session && !error && (`

### web/components/partners/group/DiscussionModePicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx#L3): `import { useEffect, useState } from "react";`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx#L28): `): { label: string; hint: string; cost: string } => {`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx#L32): `label: t("Parallel answers"),`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx#L38): `label: t("One after another"),`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx#L46): `label: t("Cross-examination"),`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx#L53): `return { label: mode.label, hint: mode.description, cost: "" };`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/DiscussionModePicker.tsx#L72): `const [modes, setModes] = useState<DiscussionMode[]>([]);`

### web/components/partners/group/GroupComposer.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupComposer.tsx#L3): `import { useEffect, useMemo, useRef, useState } from "react";`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupComposer.tsx#L54): `const [input, setInput] = useState("");`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupComposer.tsx#L55): `const [highlight, setHighlight] = useState(0);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupComposer.tsx#L56): `const [dismissed, setDismissed] = useState(false);`

### web/components/partners/group/GroupRound.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupRound.tsx#L3): `import { useState } from "react";`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupRound.tsx#L117): `const [open, setOpen] = useState(true);`

### web/components/partners/group/GroupSessionPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSessionPicker.tsx#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSessionPicker.tsx#L36): `const [open, setOpen] = useState(false);`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSessionPicker.tsx#L37): `const [sessions, setSessions] = useState<PartnerGroupSession[]>([]);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSessionPicker.tsx#L38): `const [busy, setBusy] = useState("");`

### web/components/partners/group/GroupSidePanel.tsx

- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSidePanel.tsx#L123): `traced.length === 0 ? (`
- [181](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/GroupSidePanel.tsx#L181): `) : entries.length === 0 ? (`

### web/components/partners/group/PartnerGroupChat.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L57): `const [quote, setQuote] = useState<QuotedSpeech | null>(null);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L58): `const [board, setBoard] = useState<WhiteboardEntry[]>([]);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L59): `const [panelTab, setPanelTab] = useState<PanelTab>("reasoning");`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L60): `const [traceFocus, setTraceFocus] = useState<TraceFocus | null>(null);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L84): `onMessagesChange?.(loading ? [] : messages);`
- [216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L216): `{loading ? (`
- [220](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L220): `) : rounds.length === 0 ? (`
- [242](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerGroupChat.tsx#L242): `{error ? (`

### web/components/partners/group/PartnerSeat.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerSeat.tsx#L4): `import { useState } from "react";`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerSeat.tsx#L58): `const [copied, setCopied] = useState(false);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/PartnerSeat.tsx#L59): `const [askOpen, setAskOpen] = useState(false);`

### web/components/partners/group/RoundSummaryAction.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/RoundSummaryAction.tsx#L3): `import { useState } from "react";`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/RoundSummaryAction.tsx#L26): `const [open, setOpen] = useState(false);`

### web/components/partners/group/useGroupSession.ts

- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L16): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L103): `const [messages, setMessages] = useState<PartnerGroupMessage[]>([]);`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L104): `const [rawLive, setLive] = useState<LiveTurn | null>(null);`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L108): `const [stoppedTurns, setStoppedTurns] = useState<Set<string>>(new Set());`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L109): `const [connected, setConnected] = useState(false);`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L112): `const [loadedKey, setLoadedKey] = useState<string | null>(null);`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L113): `const [error, setError] = useState("");`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L115): `const [pendingActions, setPendingActions] = useState<Set<string>>(new Set());`
- [361](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/group/useGroupSession.ts#L361): `status: message.error ? "error" : "done",`

### web/components/partners/schema-form.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/schema-form.tsx#L9): `import { useState } from "react";`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/schema-form.tsx#L72): `label: string;`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/schema-form.tsx#L92): `label: string;`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/schema-form.tsx#L98): `const [draft, setDraft] = useState(() => {`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/partners/schema-form.tsx#L105): `const [invalid, setInvalid] = useState(false);`

### web/components/quiz/FollowupChatComposer.tsx

- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/FollowupChatComposer.tsx#L40): `label: "Chat",`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/FollowupChatComposer.tsx#L82): `const isFirstSend = !thread.sessionId && thread.messages.length === 0;`

### web/components/quiz/QuizConfigPanel.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L10): `useState,`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L112): `const [dragOver, setDragOver] = useState(false);`
- [385](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L385): `const [open, setOpen] = useState(false);`
- [395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L395): `const [menuPos, setMenuPos] = useState<{`
- [482](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L482): `if (value.length === 0) return t("Auto");`
- [492](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L492): `if (value.length === 0) return t("Auto");`
- [499](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L499): `if (value.length === 0) return;`
- [539](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L539): `active={value.length === 0}`
- [589](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizConfigPanel.tsx#L589): `label: string;`

### web/components/quiz/QuizFollowupTabBody.tsx

- [206](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizFollowupTabBody.tsx#L206): `) : context.answerImages.length === 0 ? (`
- [252](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizFollowupTabBody.tsx#L252): `{visibleMessages.length === 0 ? (`
- [308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizFollowupTabBody.tsx#L308): `{thread.error && (`
- [309](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizFollowupTabBody.tsx#L309): `<div role="alert" className="rounded-lg bg-red-50 px-2.5 py-1.5 text-[12px] text-red-700 dark:bg-red-950/20 dark:text-red-300">`
- [341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizFollowupTabBody.tsx#L341): `label: string;`

### web/components/quiz/QuizViewer.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L9): `useState,`
- [203](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L203): `const [idx, setIdx] = useState(0);`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L204): `const [answers, setAnswers] = useState<Record<number, AnswerState>>({});`
- [207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L207): `const [entryIds, setEntryIds] = useState<Record<string, number>>({});`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L208): `const [bookmarked, setBookmarked] = useState<Record<string, boolean>>({});`
- [211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L211): `const [followupSessionIds, setFollowupSessionIds] = useState<`
- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L214): `const [categories, setCategories] = useState<NotebookCategory[]>([]);`
- [216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L216): `const [judgments, setJudgments] = useState<Record<number, JudgmentState>>({});`
- [217](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L217): `const [answerViews, setAnswerViews] = useState<Record<number, AnswerView>>(`
- [223](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L223): `const [reviewCollapsed, setReviewCollapsed] = useState<`
- [575](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L575): `if (files.length === 0) return;`
- [594](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L594): `if (newImages.length === 0) return;`
- [628](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L628): `if (!userAnswer && answer.images.length === 0) return;`
- [1040](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L1040): `const renderTFButton = (key: "true" | "false", label: string) => {`
- [1190](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L1190): `{ans.images.length === 0`
- [1357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/quiz/QuizViewer.tsx#L1357): `{judgment.error ? (`

### web/components/reading/AnnotationList.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationList.tsx#L3): `import { useMemo, useState } from "react";`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationList.tsx#L45): `const [view, setView] = useState<"annotations" | "citations">("annotations");`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationList.tsx#L70): `role="tablist"`
- [216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationList.tsx#L216): `label: string;`
- [222](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationList.tsx#L222): `role="tab"`

### web/components/reading/AnnotationPopover.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L4): `import { useEffect, useLayoutEffect, useRef, useState } from 'react'`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L43): `label: string`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L89): `const [color, setColor] = useState<AnnotationColor>('yellow')`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L90): `const [noteOpen, setNoteOpen] = useState(false)`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L91): `const [note, setNote] = useState('')`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L92): `const [overflowOpen, setOverflowOpen] = useState(false)`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L95): `const [position, setPosition] = useState({ left: anchor.x, top: anchor.y })`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L103): `const [dragOffset, setDragOffset] = useState(0)`
- [213](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L213): `title={noteSource.title}`
- [305](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L305): `role="dialog"`
- [334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L334): `role="dialog"`
- [351](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/AnnotationPopover.tsx#L351): `label: string`

### web/components/reading/EpubDocumentView.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/EpubDocumentView.tsx#L4): `import { useCallback, useEffect, useRef, useState } from "react";`
- [201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/EpubDocumentView.tsx#L201): `const [preferences, setPreferences] = useState<ReaderDisplayPreferences>(`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/EpubDocumentView.tsx#L204): `const [loading, setLoading] = useState(true);`
- [205](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/EpubDocumentView.tsx#L205): `const [loadError, setLoadError] = useState("");`
- [664](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/EpubDocumentView.tsx#L664): `{loading && (`
- [673](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/EpubDocumentView.tsx#L673): `{!loading && loadError && (`
- [675](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/EpubDocumentView.tsx#L675): `role="alert"`

### web/components/reading/PdfDocumentView.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfDocumentView.tsx#L9): `useState,`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfDocumentView.tsx#L98): `const [loaded, setLoaded] = useState<{`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfDocumentView.tsx#L103): `const [loadError, setLoadError] = useState<{`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfDocumentView.tsx#L107): `const [pageWidth, setPageWidth] = useState(0);`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfDocumentView.tsx#L115): `const [visibleLocator, setVisibleLocator] = useState(1);`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfDocumentView.tsx#L118): `const [flash, setFlash] = useState<{`

### web/components/reading/PdfPage.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfPage.tsx#L3): `import { useEffect, useMemo, useRef, useState } from "react";`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfPage.tsx#L64): `const [ratio, setRatio] = useState<number | null>(null);`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/PdfPage.tsx#L65): `const [failed, setFailed] = useState(false);`

### web/components/reading/ReaderDisplayControls.tsx

- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderDisplayControls.tsx#L33): `label: string;`

### web/components/reading/ReaderPane.tsx

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L7): `import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode, type RefObject } from "react";`
- [211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L211): `const [activeAnnotationId, setActiveAnnotationId] = useState<string | null>(`
- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L214): `const [selection, setSelection] = useState<SelectionPayload | null>(null);`
- [224](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L224): `const [popoverOpen, setPopoverOpen] = useState(false);`
- [237](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L237): `const [jump, setJump] = useState<JumpRequest | null>(null);`
- [242](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L242): `const [annotationPanel, setAnnotationPanel] = useState<boolean | null>(null);`
- [243](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L243): `const [autoJump, setAutoJump] = useState(true);`
- [244](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L244): `const [exporting, setExporting] = useState(false);`
- [245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L245): `const [currentLocator, setCurrentLocator] = useState(1);`
- [246](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L246): `const [epubPosition, setEpubPosition] = useState<{`
- [256](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L256): `useState<ReadingLocationHistory>(EMPTY_READING_HISTORY);`
- [257](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L257): `const [historySessionId, setHistorySessionId] = useState<`
- [260](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L260): `const [showHistory, setShowHistory] = useState(false);`
- [261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L261): `const [showMoreTools, setShowMoreTools] = useState(false);`
- [264](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L264): `const [unavailableMaterials, setUnavailableMaterials] = useState<Set<string>>(`
- [844](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L844): `label: prompt.label,`
- [854](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L854): `label: entry.label,`
- [929](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L929): `label: t("History"),`
- [937](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L937): `label: t("Forward"),`
- [948](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L948): `label: t("Follow the assistant"),`
- [959](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L959): `label: t("Annotations"),`
- [967](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L967): `label: t("Export annotated file"),`
- [1008](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L1008): `title={material?.filename || material?.title}`
- [1105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L1105): `role="menu"`
- [1210](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L1210): `role="alert"`
- [1365](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L1365): `label: string;`
- [1410](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReaderPane.tsx#L1410): `label: string;`

### web/components/reading/ReadingActionsProvider.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingActionsProvider.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingActionsProvider.tsx#L53): `const [extensions, setExtensions] = useState<ReadingExtensionManifest[]>([]);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingActionsProvider.tsx#L54): `const [ageMode, setAgeMode] = useState<ReadingAgeMode>("default");`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingActionsProvider.tsx#L55): `const [cards, setCards] = useState<ReadingActionCard[]>([]);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingActionsProvider.tsx#L56): `const [busyKey, setBusyKey] = useState("");`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingActionsProvider.tsx#L125): `label: builtIn ? t(builtIn) : action.label,`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingActionsProvider.tsx#L150): `label: entry.label,`

### web/components/reading/ReadingExtensionBar.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L3): `import { useEffect, useMemo, useRef, useState } from "react";`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L99): `const [extensions, setExtensions] = useState<ReadingExtensionManifest[]>([]);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L100): `const [busy, setBusy] = useState("");`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L101): `const [result, setResult] = useState<ReadingExtensionResult | null>(null);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L102): `const [resultLocator, setResultLocator] = useState(locator);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L103): `const [ageMode, setAgeMode] = useState<ReadingAgeMode>("default");`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L202): `if (actions.length === 0) return null;`
- [479](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L479): `const [answers, setAnswers] = useState<Record<string, number>>({});`
- [480](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L480): `const [verdicts, setVerdicts] = useState<Record<string, boolean>>({});`
- [481](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L481): `const [reward, setReward] = useState<ReadingQuizReward | null>(null);`
- [482](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/ReadingExtensionBar.tsx#L482): `const [saving, setSaving] = useState<Record<string, boolean>>({});`

### web/components/reading/TextUnitView.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L9): `useState,`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L117): `const [locator, setLocator] = useState(1);`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L118): `const [text, setText] = useState("");`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L119): `const [media, setMedia] = useState<MaterialMediaItem[]>([]);`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L120): `const [loading, setLoading] = useState(true);`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L121): `const [error, setError] = useState<string | null>(null);`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L122): `const [fontSize, setFontSize] = useState(DEFAULT_FONT_SIZE);`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L123): `const [lineWidth, setLineWidth] = useState(DEFAULT_LINE_WIDTH);`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L124): `const [serif, setSerif] = useState(true);`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L125): `const [readerTheme, setReaderTheme] = useState<ReaderTheme>("auto");`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L126): `const [spreadMode, setSpreadMode] = useState<EpubSpreadMode>("none");`
- [396](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L396): `if (!container || pageHeadings.length === 0) return;`
- [531](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L531): `{loading ? (`
- [536](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/TextUnitView.tsx#L536): `) : error ? (`

### web/components/reading/library/AddMaterialsDialog.tsx

- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L18): `useState,`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L50): `label: string;`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L82): `const [title, setTitle] = useState("");`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L83): `const [items, setItems] = useState<PendingItem[]>([]);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L84): `const [linkDraft, setLinkDraft] = useState("");`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L85): `const [dragging, setDragging] = useState(false);`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L86): `const [checking, setChecking] = useState(false);`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L87): `const [working, setWorking] = useState(false);`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L88): `const [error, setError] = useState("");`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L89): `const [showPicker, setShowPicker] = useState(false);`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L90): `const [showInvidious, setShowInvidious] = useState(false);`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L106): `label: file.name,`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L125): `label: url.replace(/^https?:\/\//, ""),`
- [259](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L259): `label: material.title,`
- [499](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L499): `{error && (`
- [670](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L670): `label: string;`
- [703](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L703): `const [query, setQuery] = useState("");`
- [704](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L704): `const [rows, setRows] = useState<ReadingLibraryMaterial[]>([]);`
- [705](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L705): `const [loading, setLoading] = useState(true);`
- [744](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/AddMaterialsDialog.tsx#L744): `{loading ? (`

### web/components/reading/library/FolderDialog.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L4): `import { useEffect, useId, useState, type FormEvent } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L32): `const [title, setTitle] = useState(collection?.title ?? "");`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L33): `const [color, setColor] = useState(collection?.color ?? "");`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L34): `const [working, setWorking] = useState(false);`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L35): `const [error, setError] = useState("");`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L75): `role="dialog"`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L131): `{error && (`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderDialog.tsx#L132): `<p role="alert" className="mt-3 text-[11px] text-[var(--destructive)]">`

### web/components/reading/library/FolderGlyph.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L10): `{ key: "", label: "Default", tone: "var(--folder-default)" },`
- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L11): `{ key: "blue", label: "Blue", tone: "var(--folder-blue)" },`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L12): `{ key: "teal", label: "Teal", tone: "var(--folder-teal)" },`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L13): `{ key: "green", label: "Green", tone: "var(--folder-green)" },`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L14): `{ key: "amber", label: "Amber", tone: "var(--folder-amber)" },`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L15): `{ key: "orange", label: "Orange", tone: "var(--folder-orange)" },`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L16): `{ key: "rose", label: "Rose", tone: "var(--folder-rose)" },`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L17): `{ key: "violet", label: "Violet", tone: "var(--folder-violet)" },`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/FolderGlyph.tsx#L18): `{ key: "slate", label: "Slate", tone: "var(--folder-slate)" },`

### web/components/reading/library/InvidiousAccountFeedback.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/InvidiousAccountFeedback.tsx#L2): `import { useEffect, useState } from "react";`
- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/InvidiousAccountFeedback.tsx#L11): `const [dismissed, setDismissed] = useState(false);`

### web/components/reading/library/LibraryShell.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/LibraryShell.tsx#L10): `import { useEffect, useState, type ReactNode } from 'react'`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/LibraryShell.tsx#L39): `const [otherCount, setOtherCount] = useState<number | null>(null)`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/LibraryShell.tsx#L69): `title={t('Immersive Reading')}`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/LibraryShell.tsx#L70): `subtitle={t(`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/LibraryShell.tsx#L112): `label: string`

### web/components/reading/library/MaterialLibrary.tsx

- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L24): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L62): `const [materials, setMaterials] = useState<ReadingLibraryMaterial[]>([]);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L63): `const [counts, setCounts] = useState<ReadingLibraryCounts | null>(null);`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L64): `const [collections, setCollections] = useState<ReadingWorkspace[]>([]);`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L65): `const [filter, setFilter] = useState<ReadingLibraryFilter>("all");`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L66): `const [search, setSearch] = useState("");`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L67): `const [loading, setLoading] = useState(true);`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L68): `const [error, setError] = useState("");`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L70): `const [showUpload, setShowUpload] = useState(requestedLearningCreation);`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L72): `const [menuFor, setMenuFor] = useState<string | null>(null);`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L73): `const [assignFor, setAssignFor] = useState<ReadingLibraryMaterial | null>(`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L76): `const [deleteFor, setDeleteFor] = useState<ReadingLibraryMaterial | null>(`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L95): `router.replace('${window.location.pathname}${next.size ? '?${next}' : ''}', { scroll: false });`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L197): `{error && (`
- [212](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L212): `{loading ? (`
- [217](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L217): `error ? null : (`
- [219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L219): `title={`
- [298](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L298): `label: string;`
- [370](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L370): `if (target) router.push(readingCollectionRoute(target.workspace_id, material.content_workspace_id ?? ""));`
- [546](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L546): `const [working, setWorking] = useState("");`
- [547](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L547): `const [error, setError] = useState("");`
- [548](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L548): `const [creating, setCreating] = useState(false);`
- [572](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L572): `router.push(readingCollectionRoute(workspace.workspace_id))`
- [641](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L641): `{error && (`
- [677](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L677): `const [working, setWorking] = useState(false);`
- [678](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L678): `const [error, setError] = useState("");`
- [700](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/MaterialLibrary.tsx#L700): `{error && (`

### web/components/reading/library/ReadingFolder.tsx

- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L19): `import { useCallback, useEffect, useState } from "react";`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L54): `const [folder, setFolder] = useState<ReadingWorkspace | null>(null);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L55): `const [sessions, setSessions] = useState<ReadingConversation[]>([]);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L56): `const [error, setError] = useState("");`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L57): `const [loading, setLoading] = useState(true);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L58): `const [opening, setOpening] = useState<string | null>(null);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L59): `const [menuOpen, setMenuOpen] = useState(false);`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L60): `const [dialog, setDialog] = useState<"add" | "edit" | "delete" | null>(null);`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L112): `router.push(readerHref);`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L172): `title={folder.title}`
- [209](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L209): `role="menu"`
- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L214): `role="menuitem"`
- [226](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L226): `role="menuitem"`
- [244](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L244): `{error && (`
- [245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L245): `<p role="alert" className="mt-4 text-[12px] text-[var(--destructive)]">`
- [346](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L346): `router.push(scopedUrl(READING_HOME));`
- [358](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingFolder.tsx#L358): `function SectionHeading({ label, count }: { label: string; count: number }) {`

### web/components/reading/library/ReadingLibrary.tsx

- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L27): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L53): `const [collections, setCollections] = useState<ReadingWorkspace[]>([]);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L54): `const [materials, setMaterials] = useState<ReadingLibraryMaterial[]>([]);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L55): `const [loading, setLoading] = useState(true);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L56): `const [error, setError] = useState("");`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L57): `const [search, setSearch] = useState("");`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L58): `const [sort, setSort] = useState<SortMode>("recent");`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L59): `const [folderDialog, setFolderDialog] = useState<FolderDialogState | null>(`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L62): `const [menuFor, setMenuFor] = useState<string | null>(null);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L63): `const [deleteTarget, setDeleteTarget] = useState<ReadingWorkspace | null>(`
- [175](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L175): `{error && (`
- [187](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L187): `{loading ? (`
- [193](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L193): `error ? null : (`
- [236](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L236): `router.push(readingFolderRoute(collection.workspace_id));`
- [260](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L260): `label: string;`
- [345](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L345): `role="menu"`
- [349](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L349): `role="menuitem"`
- [358](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L358): `role="menuitem"`
- [367](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L367): `role="menuitem"`
- [389](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L389): `const [retrying, setRetrying] = useState(false);`
- [458](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L458): `title={searching ? t("Nothing matches that.") : t("No collections yet")}`
- [490](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L490): `const [working, setWorking] = useState(false);`
- [491](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L491): `const [error, setError] = useState("");`
- [508](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/library/ReadingLibrary.tsx#L508): `{error && (`

### web/components/reading/reading-actions-context.ts

- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/reading-actions-context.ts#L15): `label: string;`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/reading-actions-context.ts#L31): `label: string;`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/reading-actions-context.ts#L37): `error?: string;`

### web/components/reading/use-read-aloud-speech.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/use-read-aloud-speech.ts#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/use-read-aloud-speech.ts#L11): `const [speaking, setSpeaking] = useState(false);`

### web/components/reading/workspace/BilibiliReadingPlayer.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/BilibiliReadingPlayer.tsx#L3): `import { useEffect, useMemo, useRef, useState } from 'react'`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/BilibiliReadingPlayer.tsx#L40): `const [playerStart, setPlayerStart] = useState(startSeconds)`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/BilibiliReadingPlayer.tsx#L41): `const [loaded, setLoaded] = useState(false)`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/BilibiliReadingPlayer.tsx#L91): `title={title}`

### web/components/reading/workspace/LegacyWatchingSession.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L2): `import { useEffect, useState } from "react";`
- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L11): `const [error, setError] = useState("");`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L12): `const [retry, setRetry] = useState(0);`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L16): `if (!cancelled) router.replace(sessionRoute({ ...session, message_count: session.messages.length, last_message: session.messages.at(-1)?.content ?? "" }), { scroll: false });`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L22): `return <div className="p-6 text-sm" role={error ? "alert" : "status"}>`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/LegacyWatchingSession.tsx#L24): `{error && <button type="button" className="ml-3 underline" onClick={() => { setError(""); setRetry(value => value + 1); }}>{t("Retry")}</button>}`

### web/components/reading/workspace/MediaReadingStage.tsx

- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L18): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L97): `const [time, setTime] = useState(0);`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L98): `const [duration, setDuration] = useState(material.duration_seconds || 0);`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L99): `const [startSeconds, setStartSeconds] = useState(sourceEntryTime);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L100): `const [playerError, setPlayerError] = useState("");`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L101): `const [followTranscript, setFollowTranscript] = useState(true);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L102): `const [transcriptQuery, setTranscriptQuery] = useState("");`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L103): `const [selectedTranscriptMatch, setSelectedTranscriptMatch] = useState(-1);`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L104): `const [isFullscreen, setIsFullscreen] = useState(false);`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L105): `const [noteDraft, setNoteDraft] = useState("");`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L106): `const [noteSaving, setNoteSaving] = useState(false);`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L107): `const [noteError, setNoteError] = useState("");`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L110): `const [editingNoteId, setEditingNoteId] = useState("");`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L111): `const [noteEditorOpen, setNoteEditorOpen] = useState(false);`
- [323](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L323): `const [untrackedPlayback, setUntrackedPlayback] = useState(false);`
- [630](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L630): `title={title}`
- [796](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L796): `{noteError && <p role="alert" className="mt-2 text-xs text-destructive">{noteError}</p>}`
- [989](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L989): `) : normalizedTranscriptQuery && transcriptMatches.length === 0 ? (`
- [993](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/MediaReadingStage.tsx#L993): `) : transcript.length === 0 ? (`

### web/components/reading/workspace/ReadingActionCards.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingActionCards.tsx#L3): `import { useEffect, useRef, useState } from "react";`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingActionCards.tsx#L39): `if (!shared || shared.cards.length === 0) return null;`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingActionCards.tsx#L81): `const [innerError, setInnerError] = useState("");`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingActionCards.tsx#L173): `label: string;`

### web/components/reading/workspace/ReadingBar.tsx

- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingBar.tsx#L40): `label: string;`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingBar.tsx#L133): `label: collection.title || t("Untitled collection"),`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingBar.tsx#L142): `label: tab.material.title || tab.material.filename,`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingBar.tsx#L168): `all={{ label: t("Open folder"), href: backHref }}`
- [182](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingBar.tsx#L182): `create={{ label: t("Add material"), onSelect: onAdd }}`

### web/components/reading/workspace/ReadingCompanion.tsx

- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L31): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L122): `const [turnsOpen, setTurnsOpen] = useState(false);`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L123): `const [showSaveModal, setShowSaveModal] = useState(false);`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L124): `const [viewerOpen, setViewerOpen] = useState(false);`
- [231](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L231): `const [askHint, setAskHint] = useState("");`
- [308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L308): `label: t("Save to Notebook"),`
- [315](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L315): `label: t("Download Markdown"),`
- [322](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L322): `label: t("Activity"),`
- [328](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L328): `label: t("Link earlier reading conversations"),`
- [345](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingCompanion.tsx#L345): `label: t("Jump to a question"),`

### web/components/reading/workspace/ReadingPanelSeparator.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingPanelSeparator.tsx#L3): `import { useEffect, useRef, useState, type PointerEvent } from 'react'`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingPanelSeparator.tsx#L15): `label: string`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingPanelSeparator.tsx#L25): `const [resizing, setResizing] = useState(false)`

### web/components/reading/workspace/ReadingWorkspace.tsx

- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L20): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L177): `const [transcriptSearch, setTranscriptSearch] = useState("");`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L178): `const [selection, setSelection] = useState<{`
- [183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L183): `const [isDesktopWide, setIsDesktopWide] = useState(false);`
- [185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L185): `const [docSlot, setDocSlot] = useState<HTMLDivElement | null>(null);`
- [194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L194): `const [showSessions, setShowSessions] = useState(false);`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L195): `const [showLinker, setShowLinker] = useState(false);`
- [199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L199): `const [showNotebook, setShowNotebook] = useState(false);`
- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L200): `const [showAddSource, setShowAddSource] = useState(false);`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L202): `const [showRename, setShowRename] = useState(false);`
- [203](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L203): `const [showMastery, setShowMastery] = useState(false);`
- [209](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L209): `label: t("Organize notes"),`
- [215](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L215): `label: t("Send to Notebook"),`
- [221](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L221): `label: t("Build Mastery Path"),`
- [228](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L228): `useState<ReadingLibraryMaterial | null>(null);`
- [254](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L254): `const [documentJump, setDocumentJump] = useState<JumpRequest | null>(null);`
- [255](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L255): `const [pageHeadings, setPageHeadings] = useState<ReaderHeading[]>([]);`
- [256](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L256): `const [activeHeadingId, setActiveHeadingId] = useState<string | null>(null);`
- [257](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L257): `const [headingJump, setHeadingJump] = useState<{`
- [379](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L379): `if (error && !workspace) {`
- [452](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L452): `title={workspace.title}`
- [569](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L569): `title={activeTab.material.title}`
- [598](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L598): `onClose={() => router.push(scopedUrl(READING_HOME))}`
- [631](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L631): `title={activeConversation?.title}`
- [644](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L644): `title={t("Remove from collection")}`
- [660](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L660): `title={t("Rename collection")}`
- [674](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/ReadingWorkspace.tsx#L674): `title={t("Build Mastery Path")}`

### web/components/reading/workspace/SourceNavigator.tsx

- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L14): `import { useMemo, useState } from "react";`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L103): `const [view, setView] = useState<"contents" | "notes">("contents");`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L104): `const [activeAnnotationId, setActiveAnnotationId] = useState<string | null>(`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L113): `const [collapsedNodes, setCollapsedNodes] = useState<Set<string>>(new Set());`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L114): `const [collapsedMaterials, setCollapsedMaterials] = useState<Set<string>>(`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L122): `const pageFallback = isPdf && reliableOutline.length === 0 && unitCount > 0;`
- [220](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L220): `<div role="tablist" className="flex min-w-0 flex-1 items-center gap-0.5">`
- [327](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L327): `{visibleMaterials.length === 0 ? (`
- [544](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L544): `label: string;`
- [551](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/SourceNavigator.tsx#L551): `role="tab"`

### web/components/reading/workspace/WorkspaceChrome.tsx

- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceChrome.tsx#L14): `import { useState } from "react";`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceChrome.tsx#L38): `label: string;`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceChrome.tsx#L197): `const [retrying, setRetrying] = useState(false);`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceChrome.tsx#L198): `const [retryError, setRetryError] = useState("");`

### web/components/reading/workspace/WorkspaceMenu.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceMenu.tsx#L4): `import { useEffect, useMemo, useState } from "react";`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceMenu.tsx#L29): `const [sections, setSections] = useState<WorkspaceMenuSections>({});`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceMenu.tsx#L53): `const [open, setOpen] = useState(false);`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/WorkspaceMenu.tsx#L89): `role="menu"`

### web/components/reading/workspace/dialogs.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L11): `import { useEffect, useState } from "react";`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L68): `const [selected, setSelected] = useState<string[]>(`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L71): `const [saving, setSaving] = useState(false);`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L76): `<ModalShell title={t("Link reading conversations")} onClose={onClose}>`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L155): `const [notebooks, setNotebooks] = useState<NotebookSummary[]>([]);`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L156): `const [selected, setSelected] = useState<string[]>([]);`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L157): `const [loading, setLoading] = useState(true);`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L158): `const [saving, setSaving] = useState(false);`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L159): `const [error, setError] = useState("");`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L173): `<ModalShell title={t("Send reading notes to Notebook")} onClose={onClose}>`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L180): `{loading ? (`
- [221](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L221): `{error && <p className="mt-3 text-[10px] text-red-600">{error}</p>}`
- [263](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L263): `<ModalShell title={t("Organized reading notes")} onClose={onClose} wide>`
- [298](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L298): `label: string;`
- [305](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L305): `const [value, setValue] = useState(initialValue);`
- [306](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L306): `const [working, setWorking] = useState(false);`
- [307](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L307): `const [error, setError] = useState("");`
- [323](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L323): `<ModalShell title={title} onClose={onClose}>`
- [339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L339): `{error && <p className="mt-3 text-[11px] text-red-600">{error}</p>}`
- [376](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L376): `const [working, setWorking] = useState(false);`
- [377](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L377): `const [error, setError] = useState("");`
- [379](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L379): `<ModalShell title={title} onClose={onClose}>`
- [383](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/dialogs.tsx#L383): `{error && <p className="mt-3 text-[11px] text-red-600">{error}</p>}`

### web/components/reading/workspace/useLearningMode.ts

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useLearningMode.ts#L5): `import { useCallback, useEffect, useRef, useState } from 'react'`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useLearningMode.ts#L41): `const [learning, setLearning] = useState(`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useLearningMode.ts#L48): `const [learningSnapshot, setLearningSnapshot] = useState<ReadingPanelState | null>(() =>`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useLearningMode.ts#L51): `const [companionOpen, setCompanionOpen] = useState(() =>`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useLearningMode.ts#L56): `const [navigatorOpen, setNavigatorOpen] = useState(() =>`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useLearningMode.ts#L91): `document.querySelectorAll<HTMLElement>('[role="dialog"],[role="alertdialog"]')`

### web/components/reading/workspace/useReadingPanelLayout.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingPanelLayout.ts#L3): `import { useCallback, useEffect, useState } from 'react'`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingPanelLayout.ts#L58): `const [element, gridRef] = useState<HTMLDivElement | null>(null)`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingPanelLayout.ts#L59): `const [frame, setFrame] = useState(0)`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingPanelLayout.ts#L60): `const [navigatorWidth, setNavigatorWidth] = useState(() =>`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingPanelLayout.ts#L63): `const [companionWidth, setCompanionWidth] = useState(() =>`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingPanelLayout.ts#L66): `const [focus, setFocus] = useState<{ width?: number } | null>(null)`

### web/components/reading/workspace/useReadingWorkspace.ts

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L6): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L66): `const [workspace, setWorkspace] = useState<ReadingWorkspace | null>(null);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L67): `const [conversations, setConversations] = useState<ReadingConversation[]>([]);`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L68): `const [loading, setLoading] = useState(true);`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L69): `const [error, setError] = useState("");`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L70): `const [notice, setNotice] = useState("");`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L71): `const [activeLocator, setActiveLocator] = useState(1);`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L72): `const [transcript, setTranscript] = useState<TranscriptRow[]>([]);`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L74): `useState<OrganizedReadingNotes | null>(null);`
- [279](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L279): `const [loadedBookmarks, setLoadedBookmarks] = useState<{`
- [420](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L420): `router.push(readingCollectionRoute(workspace.workspace_id));`
- [433](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace/useReadingWorkspace.ts#L433): `// The URL is written with the native history API rather than 'router.replace'`

### web/components/reading/workspace-menu-context.ts

- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/reading/workspace-menu-context.ts#L17): `label: string;`

### web/components/research/ResearchConfigPanel.tsx

- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L31): `const MODE_OPTIONS: Array<{ value: Exclude<ResearchMode, "">; label: string }> =`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L33): `{ value: "notes", label: "Study Notes" },`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L34): `{ value: "report", label: "Report" },`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L35): `{ value: "comparison", label: "Comparison" },`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L36): `{ value: "learning_path", label: "Learning Path" },`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L41): `label: string;`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L43): `{ value: "quick", label: "Quick" },`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L44): `{ value: "standard", label: "Standard" },`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L45): `{ value: "deep", label: "Deep" },`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L46): `{ value: "manual", label: "Manual" },`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchConfigPanel.tsx#L56): `label: string;`

### web/components/research/ResearchOutlineEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L3): `import { useCallback, useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L32): `const [items, setItems] = useState<OutlineItem[]>(initialOutline);`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L33): `const [localConfirmed, setLocalConfirmed] = useState(false);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L38): `const [collapsed, setCollapsed] = useState(false);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L39): `const [userToggled, setUserToggled] = useState(false);`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/research/ResearchOutlineEditor.tsx#L76): `if (valid.length === 0) return;`

### web/components/sessions/OrganizedSessionList.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L4): `import { useEffect, useMemo, useRef, useState } from "react";`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L145): `const [workspaceMoveError, setWorkspaceMoveError] = useState("");`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L146): `const [movingWorkspace, setMovingWorkspace] = useState(false);`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L147): `const [groupLimits, setGroupLimits] = useState<Record<string, number>>({});`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L160): `const [editingId, setEditingId] = useState<string | null>(null);`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L161): `const [draftTitle, setDraftTitle] = useState("");`
- [162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L162): `const [openMenuId, setOpenMenuId] = useState<string | null>(null);`
- [163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L163): `const [menuPosition, setMenuPosition] = useState<FloatingMenuPosition | null>(`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L166): `const [collapsedParents, setCollapsedParents] = useState<Set<string>>(`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L218): `const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(`
- [295](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L295): `if (entries.length === 0) {`
- [483](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L483): `role="menu"`
- [678](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L678): `{workspaceMoveError && <p role="alert" className="px-2 py-1 text-xs text-[var(--destructive)]">{workspaceMoveError}</p>}`
- [684](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L684): `label: t("navigation.pinned"),`
- [702](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/OrganizedSessionList.tsx#L702): `{workspaceMoveError && <p role="alert" className="px-2 py-1 text-xs text-[var(--destructive)]">{workspaceMoveError}</p>}`

### web/components/sessions/SessionActionsMenu.tsx

- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/SessionActionsMenu.tsx#L46): `label: string;`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sessions/SessionActionsMenu.tsx#L55): `role="menuitem"`

### web/components/settings/AddProviderPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L3): `import { useId, useState } from 'react'`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L12): `export type ProviderCatalogOption = { value: string; label: string; services: ServiceName[] }`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L76): `const [filter, setFilter] = useState<string>('all')`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L77): `const [query, setQuery] = useState('')`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L78): `const [name, setName] = useState('')`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L79): `const [url, setUrl] = useState('')`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L80): `const [protocol, setProtocol] = useState<ApiFormat>('openai_chat')`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AddProviderPanel.tsx#L84): `label: formatProviderLabel(option.value, option.label, uiLanguage),`

### web/components/settings/AgentSetupHelp.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AgentSetupHelp.tsx#L3): `import { useState } from "react";`
- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AgentSetupHelp.tsx#L11): `const [open, setOpen] = useState(false);`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AgentSetupHelp.tsx#L12): `const [copyState, setCopyState] = useState<"idle" | "copying" | "copied" | "failed">("idle");`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AgentSetupHelp.tsx#L43): `<Modal`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/AgentSetupHelp.tsx#L46): `title={t("settings.agentSetup.title")}`

### web/components/settings/ChatResponseTimeoutSection.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ChatResponseTimeoutSection.tsx#L2): `import { useCallback, useEffect, useRef, useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ChatResponseTimeoutSection.tsx#L25): `const [seconds, setSeconds] = useState<number>(`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ChatResponseTimeoutSection.tsx#L28): `const [initial, setInitial] = useState<number>(`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ChatResponseTimeoutSection.tsx#L31): `const [message, setMessage] = useState("");`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ChatResponseTimeoutSection.tsx#L32): `const [loaded, setLoaded] = useState(false);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ChatResponseTimeoutSection.tsx#L102): `title={t("Chat response timeout")}`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ChatResponseTimeoutSection.tsx#L108): `title={t("Timeout (seconds)")}`

### web/components/settings/CodeBuddyAuthCard.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx#L13): `import { useCallback, useEffect, useState } from "react";`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx#L27): `const [status, setStatus] = useState<CodeBuddyAuthStatus | null>(null);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx#L28): `const [loading, setLoading] = useState(true);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx#L29): `const [working, setWorking] = useState(false);`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx#L30): `const [requestError, setRequestError] = useState("");`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx#L126): `<RefreshCw className={'h-4 w-4 ${loading ? "animate-spin" : ""}'} />`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodeBuddyAuthCard.tsx#L132): `{loading ? (`

### web/components/settings/CodexOAuthCard.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L4): `import { useCallback, useEffect, useRef, useState } from "react";`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L36): `const [liveEfforts, setLiveEfforts] = useState<Record<string, string | null>>({});`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L38): `const [status, setStatus] = useState<CodexOAuthStatus | null>(null);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L39): `const [pending, setPending] = useState(false);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L40): `const [errorKey, setErrorKey] = useState<string | null>(null);`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L41): `const [pollTick, setPollTick] = useState(0);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L42): `const [loginStart, setLoginStart] = useState<CodexLoginStart | null>(null);`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L45): `const [callbackUrl, setCallbackUrl] = useState("");`
- [375](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/CodexOAuthCard.tsx#L375): `if (options.length === 0) return null;`

### web/components/settings/ConnectionsEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L3): `import { useMemo, useState } from "react";`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L98): `const [adding, setAdding] = useState(false);`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L99): `const [editingId, setEditingId] = useState<string | null>(null);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L100): `const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);`
- [194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L194): `created.length === 0`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L196): `: kept.length === 0`
- [212](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L212): `{connections.length === 0 && !adding && (`
- [306](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L306): `label: (service: ServiceName) => string;`
- [314](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L314): `const [showKey, setShowKey] = useState(false);`
- [339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L339): `{/* Each service it supplies is a way in, not just a label: the link`
- [525](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L525): `const [provider, setProvider] = useState("");`
- [526](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L526): `const [apiKey, setApiKey] = useState("");`
- [527](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L527): `const [baseUrl, setBaseUrl] = useState("");`
- [528](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L528): `const [showKey, setShowKey] = useState(false);`
- [529](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L529): `const [selected, setSelected] = useState<Set<ServiceName>>(new Set());`
- [530](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ConnectionsEditor.tsx#L530): `const [llmModel, setLlmModel] = useState("");`

### web/components/settings/DimensionField.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/DimensionField.tsx#L3): `import { useState } from "react";`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/DimensionField.tsx#L28): `): { label: string; tone: "muted" | "ok" | "warn" } | null {`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/DimensionField.tsx#L30): `return { label: t("Source: detected from API probe"), tone: "ok" };`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/DimensionField.tsx#L66): `const [customRequested, setCustomRequested] = useState<boolean>(false);`

### web/components/settings/EmbeddingModelUsage.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L3): `import { useEffect, useState } from "react";`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L16): `const [usage, setUsage] = useState<EmbeddingUsage[] | null>(null);`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L17): `const [error, setError] = useState(false);`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L18): `const [attempt, setAttempt] = useState(0);`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L20): `const [resolvedKey, setResolvedKey] = useState(requestKey);`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L53): `{error ? (`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L55): `<p role="alert">{t("Failed to load embedding model usage")}</p>`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/EmbeddingModelUsage.tsx#L61): `) : usage.length === 0 ? (`

### web/components/settings/MemoryUsageItem.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MemoryUsageItem.tsx#L4): `import { Fragment, useCallback, useEffect, useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MemoryUsageItem.tsx#L32): `label: string;`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MemoryUsageItem.tsx#L64): `const [usage, setUsage] = useState<MemoryUsage | null>(null);`

### web/components/settings/MinerUEngineSettings.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L5): `import { useEffect, useRef, useState } from "react";`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L89): `const [payload, setPayload] = useState<MinerUPayload | null>(null);`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L90): `const [liveDraft, setLiveDraft] = useState<MinerUSettings | null>(null);`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L94): `const [showToken, setShowToken] = useState(false);`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L95): `const [loading, setLoading] = useState(true);`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L96): `const [testing, setTesting] = useState(false);`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L97): `const [testResult, setTestResult] = useState<{`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L101): `const [error, setError] = useState<string | null>(null);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L102): `const [download, setDownload] = useState<DownloadStatus | null>(null);`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L104): `useState<MinerUDownloadType>("pipeline");`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L105): `const [startingDownload, setStartingDownload] = useState(false);`
- [270](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L270): `function renderTestControl(label: string) {`
- [311](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L311): `if (error && !draft) {`
- [323](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L323): `{error && (`
- [330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L330): `title={t("Parsing backend")}`
- [334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L334): `title={t("Mode")}`
- [368](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L368): `title={t("Local install")}`
- [374](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L374): `title={`
- [391](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L391): `title={t("CLI path")}`
- [409](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L409): `title={t("Model weights")}`
- [415](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L415): `title={t("Allow automatic model download")}`
- [427](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L427): `title={t("Download source")}`
- [450](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L450): `title={t("Download address")}`
- [467](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L467): `title={t("Download models")}`
- [545](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L545): `title={t("Cloud API")}`
- [549](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L549): `title={t("API base URL")}`
- [563](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L563): `title={t("API token")}`
- [605](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L605): `title={t("Test connection")}`
- [615](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L615): `title={t("Parsing options")}`
- [619](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L619): `title={t("Model version")}`
- [640](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L640): `title={t("Language")}`
- [654](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L654): `title={t("Extract formulas")}`
- [663](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L663): `title={t("Extract tables")}`
- [672](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/MinerUEngineSettings.tsx#L672): `title={t("Force OCR")}`

### web/components/settings/ModelCapabilityFields.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCapabilityFields.tsx#L3): `import { useEffect, useState } from "react";`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCapabilityFields.tsx#L16): `const ROWS: { key: ModelCapabilityKey; label: string }[] = [`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCapabilityFields.tsx#L17): `{ key: "tools", label: "Tool calling" },`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCapabilityFields.tsx#L18): `{ key: "vision", label: "Image input" },`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCapabilityFields.tsx#L19): `{ key: "json_output", label: "JSON output" },`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCapabilityFields.tsx#L20): `{ key: "reasoning", label: "Reasoning controls" },`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCapabilityFields.tsx#L46): `const [fetched, setFetched] = useState<{`

### web/components/settings/ModelCards.tsx

- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelCards.tsx#L75): `label: string;`

### web/components/settings/ModelsWorkspace.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L6): `import { useEffect, useId, useRef, useState } from "react";`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L85): `const [selected, setSelected] = useState<string | null>(null);`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L86): `const [adding, setAdding] = useState(false);`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L87): `const [newService, setNewService] = useState<ServiceName>(`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L90): `const [newProvider, setNewProvider] = useState("");`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L91): `const [newModelId, setNewModelId] = useState("");`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L92): `const [query, setQuery] = useState("");`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L93): `const [filter, setFilter] = useState("all");`
- [389](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L389): `label: t(page === "search" ? "settings.serviceConfig.findSearch" : "Find model"),`
- [530](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L530): `title={t("Nothing selected")}`
- [608](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L608): `const [custom, setCustom] = useState(false);`
- [716](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L716): `const [custom, setCustom] = useState(false);`
- [734](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModelsWorkspace.tsx#L734): `const [listed, setListed] = useState<{`

### web/components/settings/ModulesPanel.tsx

- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModulesPanel.tsx#L15): `{error && <button onClick={reload}>{t("Retry")}</button>}`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ModulesPanel.tsx#L16): `{!modules && !error && <p aria-busy="true">{t("Loading...")}</p>}`

### web/components/settings/ProviderModelDiscovery.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L3): `import { useEffect, useId, useRef, useState } from "react";`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L58): `const [running, setRunning] = useState(false);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L59): `const [result, setResult] = useState<{`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L63): `const [error, setError] = useState("");`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L64): `const [picked, setPicked] = useState<string[]>([]);`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L65): `const [query, setQuery] = useState("");`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProviderModelDiscovery.tsx#L130): `{error && <p className="text-red-600 dark:text-red-400">{error}</p>}`

### web/components/settings/ProvidersWorkspace.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L6): `import { useEffect, useRef, useState } from "react";`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L66): `const [selected, setSelected] = useState<string | null>(null);`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L75): `const [adding, setAdding] = useState(false);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L81): `const [vendor, setVendor] = useState("");`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L82): `const [query, setQuery] = useState("");`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L83): `const [auth, setAuth] = useState("");`
- [217](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L217): `label: t("Find provider"),`
- [452](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ProvidersWorkspace.tsx#L452): `title={t("Nothing selected")}`

### web/components/settings/RegistryControls.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L4): `import { type KeyboardEvent, useEffect, useId, useRef, useState } from "react";`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L34): `label: string;`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L36): `const [editing, setEditing] = useState(false);`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L157): `const [result, setResult] = useState(discovery);`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L158): `const [pending, setPending] = useState(false);`
- [290](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L290): `label: string;`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L340): `label: string;`
- [353](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L353): `const [open, setOpen] = useState(false);`
- [354](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L354): `const [active, setActive] = useState(-1);`
- [510](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/RegistryControls.tsx#L510): `<p id={'${id}-error'} role="alert" className="text-[13px] text-red-600">`

### web/components/settings/ServiceConfigEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L3): `import { useCallback, useEffect, useId, useRef, useState } from "react";`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L142): `const [openProfileId, setOpenProfileId] = useState<string | null>(null);`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L143): `const [collapsedProfileId, setCollapsedProfileId] = useState<`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L146): `const [expandedModelId, setExpandedModelId] = useState<string | null>(`
- [307](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L307): `const [showApiKey, setShowApiKey] = useState(false);`
- [309](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L309): `useState<CatalogProfile | null>(null);`
- [310](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L310): `const [editingModelId, setEditingModelId] = useState<string | null>(null);`
- [311](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L311): `const [editingModelName, setEditingModelName] = useState("");`
- [312](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L312): `const [editingProfileId, setEditingProfileId] = useState<string | null>(`
- [315](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L315): `const [editingProfileName, setEditingProfileName] = useState("");`
- [316](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L316): `const [modelsSyncing, setModelsSyncing] = useState(false);`
- [323](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L323): `const [lastProfileKey, setLastProfileKey] = useState(profileKey);`
- [412](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L412): `if (fetched.length === 0) throw new Error(t("No models returned"));`
- [572](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L572): `title={t("Providers")}`
- [766](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L766): `title={t("Models from {{provider}}", {`
- [1301](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L1301): `<SectionHead title={t("Providers")} />`
- [1312](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L1312): `<ConfirmDialog`
- [1314](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L1314): `title={t("Delete this provider?")}`
- [1419](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L1419): `<span title={model.context_window_detected_at}>{updatedAt}</span>`
- [1651](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServiceConfigEditor.tsx#L1651): `? t("{{label}} (legacy)", { label: p.label })`

### web/components/settings/ServicePreviewPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServicePreviewPanel.tsx#L3): `import { useEffect, useRef, useState } from 'react'`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServicePreviewPanel.tsx#L55): `const [text, setText] = useState('')`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServicePreviewPanel.tsx#L56): `const [file, setFile] = useState<File | null>(null)`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServicePreviewPanel.tsx#L57): `const [audioUrl, setAudioUrl] = useState('')`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServicePreviewPanel.tsx#L58): `const [result, setResult] = useState<Result | null>(null)`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServicePreviewPanel.tsx#L59): `const [state, setState] = useState('idle')`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ServicePreviewPanel.tsx#L60): `const [phase, setPhase] = useState('requesting')`

### web/components/settings/SettingsLoadStatusBanner.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsLoadStatusBanner.tsx#L3): `import { useState } from "react";`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsLoadStatusBanner.tsx#L16): `const [retrying, setRetrying] = useState(false);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsLoadStatusBanner.tsx#L40): `role="alert"`

### web/components/settings/SettingsMain.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L4): `import { useEffect, useRef, useState } from 'react'`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L21): `const [mobileOpen, setMobileOpen] = useState(false)`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L22): `const [leaving, setLeaving] = useState(false)`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L23): `const [leaveFailed, setLeaveFailed] = useState(false)`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L45): `router.push(destination)`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L93): `<Modal`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L96): `title={t('Settings')}`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L103): `<Modal`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L108): `title={t('Keep your changes?')}`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsMain.tsx#L113): `<p role="alert" className="text-sm text-red-600 dark:text-red-400">`

### web/components/settings/SettingsNav.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsNav.tsx#L3): `import { useState } from 'react'`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsNav.tsx#L22): `const tr = (label: Lang) => (zh ? label.zh : t(label.en))`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsNav.tsx#L26): `const [query, setQuery] = useState('')`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsNav.tsx#L48): `? [{ label: { en: 'Search results', zh: '搜索结果' }, pages: matches }]`

### web/components/settings/SettingsOverview.tsx

- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L32): `label: string;`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L75): `title={t("General")}`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L80): `<SettingSection title={t("Language")}>`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L82): `title={t("Interface language")}`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L95): `title={t("Model output language")}`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L119): `<SettingSection title={t("Layout")}>`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L121): `title={t("Interface layout")}`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L142): `title={t("Set up chat first")}`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsOverview.tsx#L179): `title={t("Add more when you need it")}`

### web/components/settings/SettingsPageContent.tsx

- [230](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPageContent.tsx#L230): `router.replace(settingsAnchorHref(key) + window.location.search, {`

### web/components/settings/SettingsPresetsPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L3): `import { useCallback, useEffect, useState } from "react";`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L16): `const [presets, setPresets] = useState<SettingsPreset[] | null>(null);`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L17): `const [loading, setLoading] = useState(false);`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L18): `const [error, setError] = useState(false);`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L19): `const [activeId, setActiveId] = useState<string | null>(null);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L70): `{loading ? (`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L79): `{error && (`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L80): `<p role="alert" className="py-3 text-[12.5px] text-amber-600">`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L85): `{!presets && !error && (`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsPresetsPanel.tsx#L96): `{presets && presets.length === 0 && (`

### web/components/settings/SettingsReadinessPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L3): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L126): `const [snapshot, setSnapshot] = useState<SettingsReadinessSnapshot | null>(`
- [129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L129): `const [loading, setLoading] = useState(false);`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L130): `const [error, setError] = useState(false);`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L171): `label: string;`
- [181](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L181): `label: t(row.label),`
- [193](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L193): `label: t("readiness.attention.draft"),`
- [207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L207): `label: row ? t(row.label) : t('readiness.section.${notice.section}'),`
- [253](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L253): `{loading ? (`
- [263](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L263): `{error && (`
- [264](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L264): `<p role="alert" className="py-3 text-[12.5px] text-amber-600">`
- [269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L269): `{!snapshot && !error && (`
- [284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsReadinessPanel.tsx#L284): `{attention.length === 0 ? (`

### web/components/settings/SettingsRuntimePage.tsx

- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsRuntimePage.tsx#L16): `title={t("Runtime status")}`

### web/components/settings/SettingsTourOverlay.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsTourOverlay.tsx#L3): `import { useEffect, useState } from "react";`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsTourOverlay.tsx#L15): `// transition the controller pushes router.push to the step's route;`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsTourOverlay.tsx#L37): `const [rect, setRect] = useState<DOMRect | null>(null);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsTourOverlay.tsx#L54): `const [resolvedFor, setResolvedFor] = useState<string | null>(null);`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SettingsTourOverlay.tsx#L173): `role="dialog"`

### web/components/settings/SubagentSettingsEditor.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L5): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L240): `const PERMISSION_MODES: { value: string; label: Lang }[] = [`
- [243](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L243): `label: {`
- [250](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L250): `label: { zh: "自动接受编辑", en: "Accept edits automatically" },`
- [254](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L254): `label: { zh: "默认 · 可能等待确认", en: "Default · may wait for prompts" },`
- [258](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L258): `label: { zh: "计划模式 · 只读", en: "Plan mode · read-only" },`
- [262](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L262): `const GROK_PERMISSION_MODES: { value: string; label: Lang }[] = [`
- [265](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L265): `label: {`
- [272](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L272): `label: { zh: "Plan（兼容模式）", en: "Plan (compatibility mode)" },`
- [276](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L276): `label: { zh: "默认权限", en: "Default permissions" },`
- [280](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L280): `label: { zh: "自动接受编辑", en: "Accept edits automatically" },`
- [284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L284): `label: { zh: "自动评估权限", en: "Automatically evaluate permissions" },`
- [288](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L288): `label: { zh: "绕过权限", en: "Bypass permissions" },`
- [298](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L298): `const SANDBOXES: { value: string; label: Lang }[] = [`
- [299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L299): `{ value: "read-only", label: { zh: "只读", en: "Read-only" } },`
- [302](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L302): `label: { zh: "工作目录可写（推荐）", en: "Workspace write (recommended)" },`
- [304](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L304): `{ value: "danger-full-access", label: { zh: "完全访问", en: "Full access" } },`
- [307](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L307): `label: { zh: "绕过沙箱与审批", en: "Bypass sandbox & approvals" },`
- [311](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L311): `const APPROVALS: { value: string; label: Lang }[] = [`
- [314](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L314): `label: { zh: "从不询问（推荐）", en: "Never ask (recommended)" },`
- [316](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L316): `{ value: "on-failure", label: { zh: "失败时询问", en: "On failure" } },`
- [317](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L317): `{ value: "on-request", label: { zh: "按需询问", en: "On request" } },`
- [320](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L320): `label: { zh: "不可信命令时询问", en: "Untrusted commands" },`
- [329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L329): `const [options, setOptions] = useState<SubagentBackendOptions | null>(null);`
- [330](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L330): `const [liveConfig, setLiveConfig] = useState<SubagentBackendConfig>({`
- [334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L334): `const [customModel, setCustomModel] = useState(false);`
- [335](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L335): `const [loading, setLoading] = useState(true);`
- [336](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L336): `const [syncing, setSyncing] = useState(false);`
- [338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L338): `const [error, setError] = useState<string | null>(null);`
- [435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L435): `title={displayName}`
- [449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L449): `{loading && (`
- [456](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L456): `{!loading && error && (`
- [462](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L462): `{!loading && options && (`
- [467](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L467): `title={tr({ zh: "连接与同步", en: "Connection & sync" })}`
- [486](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L486): `title={`
- [525](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L525): `title={tr({ zh: "模型列表", en: "Model list" })}`
- [571](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L571): `title={tr({ zh: "远程网关", en: "Remote gateway" })}`
- [578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L578): `title={tr({ zh: "网关 URL", en: "Gateway URL" })}`
- [594](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L594): `title={tr({ zh: "密钥环境变量", en: "API key environment variable" })}`
- [606](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L606): `title={tr({ zh: "配置 profile", en: "Profile label" })}`
- [622](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L622): `title={tr({ zh: "空闲超时（秒）", en: "Idle timeout (seconds)" })}`
- [647](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L647): `title={tr({ zh: "模型", en: "Model" })}`
- [654](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L654): `title={tr({ zh: "启用", en: "Enabled" })}`
- [668](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L668): `title={tr({ zh: "模型", en: "Model" })}`
- [717](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L717): `title={tr({ zh: "推理强度", en: "Reasoning effort" })}`
- [742](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L742): `disabled={busy || effortChoices.length === 0}`
- [765](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L765): `title={tr({ zh: "系统提示", en: "System prompt" })}`
- [793](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L793): `title={tr({ zh: "运行参数", en: "Run parameters" })}`
- [801](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L801): `title={tr({ zh: "权限模式", en: "Permission mode" })}`
- [838](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L838): `title={tr({ zh: "自动批准", en: "Auto-approve" })}`
- [855](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L855): `title={tr({ zh: "思考过程", en: "Thinking" })}`
- [873](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L873): `title={tr({ zh: "沙箱", en: "Sandbox" })}`
- [890](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L890): `title={tr({ zh: "审批策略", en: "Approval policy" })}`
- [911](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L911): `title={tr({ zh: "命令联网", en: "Command network access" })}`
- [925](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L925): `title={tr({ zh: "临时会话", en: "Ephemeral session" })}`
- [943](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/SubagentSettingsEditor.tsx#L943): `title={tr({ zh: "转发图片", en: "Forward images" })}`

### web/components/settings/TaskModelsWorkspace.tsx

- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L43): `const TASK_TEXT: Record<string, { label: string; detail: string }> = {`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L45): `label: "Conversation titles",`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L49): `label: "Starter suggestions",`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L53): `label: "Composer hint",`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L57): `label: "Mastery goal names",`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L61): `label: "Study composer hint",`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L65): `label: "Reading composer hint",`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L69): `label: "Vocabulary help",`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L73): `label: "Translation",`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L77): `label: "Study guidance",`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L81): `label: "Reading questions",`
- [184](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L184): `label: string,`
- [186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L186): `leading: { value: string; label: string },`
- [227](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L227): `title={t("Global task model")}`
- [233](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L233): `title={t("Background task model")}`
- [240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L240): `{ value: INHERIT, label: t("Follow the chat model") },`
- [260](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L260): `title={t(GROUP_TEXT[entry.group] ?? entry.group)}`
- [268](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L268): `title={label}`
- [273](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/TaskModelsWorkspace.tsx#L273): `{ value: GLOBAL, label: t("Follow the global task model") },`

### web/components/settings/ThemePreviewCard.tsx

- [251](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/ThemePreviewCard.tsx#L251): `label: string;`

### web/components/settings/VoiceDiscoveryField.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L3): `import { useEffect, useRef, useState } from 'react'`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L85): `const [attempt, setAttempt] = useState(0)`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L86): `const [result, setResult] = useState<Result | null>(null)`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L87): `const [loading, setLoading] = useState(true)`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L88): `const [error, setError] = useState(false)`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L89): `const [manual, setManual] = useState(false)`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L148): `{loading ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoiceDiscoveryField.tsx#L149): `{t(loading ? 'settings.voiceDiscovery.loading' : 'Refresh')}`

### web/components/settings/VoicePreviewPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoicePreviewPanel.tsx#L3): `import { useEffect, useId, useRef, useState } from 'react'`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoicePreviewPanel.tsx#L45): `const [text, setText] = useState(() =>`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoicePreviewPanel.tsx#L50): `const [pending, setPending] = useState(false)`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoicePreviewPanel.tsx#L51): `const [url, setUrl] = useState<string | null>(null)`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoicePreviewPanel.tsx#L52): `const [error, setError] = useState('')`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoicePreviewPanel.tsx#L154): `{error && (`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/VoicePreviewPanel.tsx#L155): `<p role="alert" className="text-xs text-red-600">`

### web/components/settings/WorkspaceShell.tsx

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/WorkspaceShell.tsx#L7): `useState,`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/WorkspaceShell.tsx#L61): `const [edges, setEdges] = useState({ top: false, bottom: false });`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/WorkspaceShell.tsx#L100): `const [height, setHeight] = useState<number | null>(null);`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/WorkspaceShell.tsx#L176): `label: string;`

### web/components/settings/shared.tsx

- [219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/settings/shared.tsx#L219): `<PageHeader title={title} description={description} action={actions} headingTour="tour-page-heading" />`

### web/components/sidebar/CategoryNavigation.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L5): `import { useId, useState, startTransition, type ReactNode } from 'react'`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L47): `{ id: 'home', label: 'navigation.home', icon: HomeShelfIcon, href: '/chat', account: false },`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L48): `{ id: 'learning', label: 'navigation.learning', icon: LearningShelfIcon, href: '/learning', account: false },`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L49): `{ id: 'resources', label: 'navigation.resources', icon: ResourcesShelfIcon, href: '/space', account: false },`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L50): `{ id: 'partners', label: 'navigation.partners', icon: PartnersShelfIcon, href: '/partners', account: true },`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L53): `label: 'navigation.personalization',`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L66): `const [visited, setVisited] = useState<NavigationCategory[]>([])`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L67): `const [selection, setSelection] = useState<{`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L102): `const [peek, setPeek] = useState(false)`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L105): `if (collapsed) navigateTask(category.href, router.push)`
- [129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L129): `role="tab"`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L150): `.closest('[role="tablist"]')`
- [151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L151): `?.querySelectorAll<HTMLButtonElement>('[role="tab"]')`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L173): `role="tablist"`
- [226](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L226): `role="tabpanel"`
- [236](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L236): `<Section title={t('navigation.workspace')}>`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L238): `{ href: '/calendar', label: 'Calendar', icon: CalendarDays },`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L239): `{ href: '/kanban', label: 'Task Board', icon: Columns3 },`
- [240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CategoryNavigation.tsx#L240): `{ href: '/co-writer', label: 'Co-Writer', icon: PenLine },`

### web/components/sidebar/CommandPalette.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L6): `import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L24): `label: string`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L53): `categories: readonly { id: string; label: string; icon: LucideIcon; href: string }[]`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L65): `const [query, setQuery] = useState('')`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L66): `const [activeIndex, setActiveIndex] = useState(0)`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L80): `const go = (href: string) => () => navigateTask(href, router.push)`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L83): `{ id: 'new-chat', label: t('navigation.newChat'), icon: glyph(PenLine), run: onNewChat },`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L84): `...categories.map(item => ({ id: 'category:${item.id}', label: t(item.label), icon: glyph(item.icon), run: go(item.href) })),`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L86): `{ href: '/calendar', label: 'Calendar', icon: CalendarDays },`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L87): `{ href: '/kanban', label: 'Task Board', icon: Columns3 },`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L88): `{ href: '/co-writer', label: 'Co-Writer', icon: PenLine },`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L91): `.map(item => ({ id: item.href, label: t(item.label), icon: glyph(item.icon), run: go(item.href) })),`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L101): `label: zh ? row.title.zh : row.title.en,`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L108): `{ id: 'settings', label: t('Settings'), icon: glyph(Settings), run: go('/settings') },`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L119): `label: session.title || t('New conversation'),`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L127): `label: item.title,`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L136): `label: partner.name,`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L142): `label: group.name,`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L156): `}, [query, categories, allowedSurfaces, available, zh, sessions, sources, partnerData, onSelectSession, onNewChat, router.push, t])`
- [175](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/CommandPalette.tsx#L175): `<div role="dialog" aria-modal="true" aria-label={t('navigation.searchEverything')} className="dt-palette">`

### web/components/sidebar/LearningNavigation.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/LearningNavigation.tsx#L5): `import { useLayoutEffect, useState, type ReactNode } from 'react'`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/LearningNavigation.tsx#L55): `const [open, setOpen] = useState<Record<string, boolean>>({})`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/LearningNavigation.tsx#L98): `title={t('navigation.learningRecords')}`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/LearningNavigation.tsx#L133): `!loading &&`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/LearningNavigation.tsx#L202): `<span className="dt-record-chat-count" title={t('navigation.recordChats', { count: sessions.length })}>`

### web/components/sidebar/NavigationPrimitives.tsx

- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/NavigationPrimitives.tsx#L21): `label: string`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/NavigationPrimitives.tsx#L65): `label: string`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/NavigationPrimitives.tsx#L126): `return error ? (`
- [135](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/NavigationPrimitives.tsx#L135): `export const matches = (label: string, query: string) =>`

### web/components/sidebar/PartnerNavigation.tsx

- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/PartnerNavigation.tsx#L53): `{!loading && !partners.length && (`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/PartnerNavigation.tsx#L94): `{!loading && !groups.length && (`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/PartnerNavigation.tsx#L102): `title={t('navigation.partnerSessions')}`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/PartnerNavigation.tsx#L148): `!loading &&`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/PartnerNavigation.tsx#L149): `!error && (`

### web/components/sidebar/RecordList.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L3): `import { useLayoutEffect, useState, type ReactNode } from 'react'`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L25): `const [sort, setSortState] = useState<RecordSort>('updatedAt')`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L26): `const [query, setQueryState] = useState('')`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L27): `const [searching, setSearching] = useState(false)`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L28): `const [limit, setLimit] = useState(PAGE)`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L81): `const [open, setOpen] = useState(false)`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L107): `<div role="menu" aria-label={t('navigation.sortRecords')} className="dt-popover dt-record-sort-menu">`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L113): `role="menuitemradio"`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L174): `title={new Date(seconds * 1000).toLocaleString(i18n.language)}`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/RecordList.tsx#L195): `lead?: { label: string; rows: readonly T[] }`

### web/components/sidebar/ResourcesNavigation.tsx

- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/ResourcesNavigation.tsx#L23): `<Section key={group.label.en} title={zh ? group.label.zh : t(group.label.en)}>`

### web/components/sidebar/SidebarNav.tsx

- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L25): `useState,`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L99): `const [layout, setLayout] = useState<SidebarNavLayout | null>(null);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L100): `const [moreExpanded, setMoreExpanded] = useState(false);`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L101): `const [menu, setMenu] = useState<RowMenu | null>(null);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L102): `const [railMenu, setRailMenu] = useState<FloatingMenuPosition | null>(null);`
- [287](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L287): `role="menuitem"`
- [682](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L682): `label: string;`
- [688](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L688): `role="menu"`
- [710](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L710): `label: string;`
- [716](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarNav.tsx#L716): `role="menuitem"`

### web/components/sidebar/SidebarShell.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L13): `useState,`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L132): `const [paletteOpen, setPaletteOpen] = useState(false);`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L153): `navigateTask("/chat", router.push);`
- [184](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L184): `if (collapsed) navigateTask(target.href, router.push);`
- [262](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/SidebarShell.tsx#L262): `title={t("navigation.chatRecords")}`

### web/components/sidebar/UtilitySidebar.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/UtilitySidebar.tsx#L5): `import { useCallback, useEffect, useRef, useState } from "react";`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/UtilitySidebar.tsx#L36): `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/UtilitySidebar.tsx#L37): `const [masteryTopics, setMasteryTopics] = useState<MasteryTopicLabel[]>([]);`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/UtilitySidebar.tsx#L38): `const [readingCollections, setReadingCollections] = useState<`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/UtilitySidebar.tsx#L41): `const [loadingSessions, setLoadingSessions] = useState(false);`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/UtilitySidebar.tsx#L85): `navigateTask(session ? sessionRoute(session) : '/chat/${sessionId}', router.push);`

### web/components/sidebar/VersionBadge.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L4): `import { useEffect, useState, type MouseEventHandler } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L20): `const [status, setStatus] = useState<AppUpdateStatus | null>(null);`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L21): `const [error, setError] = useState("");`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L47): `? { dot: "bg-red-500", label: t("Status check failed") }`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L49): `? { dot: "bg-amber-500", label: t("Update available") }`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L53): `label: t("Up to date"),`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L58): `label: t("Version checks are disabled."),`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/VersionBadge.tsx#L62): `label: status ? t("Not checked yet") : t("Checking..."),`

### web/components/sidebar/WorkspaceMenu.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L5): `import { useId, useState, type ReactNode } from 'react'`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L48): `role="menuitem"`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L61): `<Link role="menuitem" href="/settings/workspace" prefetch={false} onClick={onChoose} className="dt-menu-item is-quiet">`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L85): `const [open, setOpen] = useState(false)`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L123): `<div id={menuId} role="menu" aria-label={t('Manage workspaces')} className="dt-popover dt-workspace-panel">`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L126): `<Link role="menuitem" href="/settings" prefetch={false} onClick={close} className="dt-menu-item">`
- [135](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceMenu.tsx#L135): `title={clientEditionLabel(process.env.NEXT_PUBLIC_APP_VERSION)}`

### web/components/sidebar/WorkspaceSidebar.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L5): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L46): `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L47): `const [masteryTopics, setMasteryTopics] = useState<MasteryTopicLabel[]>([]);`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L48): `const [readingCollections, setReadingCollections] = useState<`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L51): `const [loadingSessions, setLoadingSessions] = useState(false);`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L147): `navigateTask("/chat", router.push);`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L156): `navigateTask(session ? sessionRoute(session) : '/chat/${sessionId}', router.push);`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L197): `router.push,`
- [211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/WorkspaceSidebar.tsx#L211): `preferences: updated.preferences, content_workspace_id: updated.preferences?.workspace_id || "" }), router.push);`

### web/components/sidebar/nav-entries.ts

- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L19): `label: string`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L44): `label: 'Home',`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L52): `label: 'Partners',`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L59): `label: 'Personalized Learning',`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L64): `{ href: '/space', label: 'Learning Space', icon: LayoutGrid, tooltipKey: 'Space tooltip' },`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L66): `href: '/calendar', label: 'Calendar', icon: CalendarDays, surfaces: ['chat'],`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L70): `label: 'Task Board',`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L77): `label: 'Co-Writer',`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L85): `label: 'My Agents',`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/nav-entries.ts#L92): `export const SECONDARY_NAV: NavEntry[] = [{ href: '/settings', label: 'Settings', icon: Settings }]`

### web/components/sidebar/page-sections.ts

- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L22): `label: string`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L30): `label: string`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L60): `group.items.map(item => ({ href: item.href, label: zh ? item.title.zh : item.title.en, icon: item.icon }))`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L65): `label: t('navigation.home'),`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L68): `{ href: '/chat', label: t('Chat'), icon: MessageCircle },`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L69): `{ href: '/calendar', label: t('Calendar'), icon: CalendarDays, account: true },`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L70): `{ href: '/kanban', label: t('Task Board'), icon: Columns3 },`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L71): `{ href: '/co-writer', label: t('Co-Writer'), icon: PenLine },`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L76): `label: t('navigation.learning'),`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L79): `{ href: '/learning/new', label: t('navigation.createLearning'), icon: Plus },`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L80): `{ href: '/learning', label: t('navigation.allLearning'), icon: LayoutGrid },`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L83): `label: t(surface.title),`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L90): `label: t('navigation.resources'),`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L92): `pages: [{ href: '/space', label: t('navigation.allResources'), icon: ResourcesShelfIcon }, ...shelf(DASHBOARD_GROUPS)],`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L96): `label: t('navigation.partners'),`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L99): `pages: [{ href: '/partners', label: t('Partners'), icon: MessageCircle }],`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L103): `label: t('navigation.personalization'),`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/page-sections.ts#L107): `{ href: '/personalization', label: t('navigation.allPersonalization'), icon: PersonalizationShelfIcon },`

### web/components/sidebar/roster-lens.ts

- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/roster-lens.ts#L30): `label: number`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/roster-lens.ts#L59): `const flat: RosterLens = { dx: 0, scale: 1, opacity: 1, label: 1, depth: 0 }`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/sidebar/roster-lens.ts#L80): `label: 1 - clamp01((into / (zone * 0.5)) * strength),`

### web/components/space/ArchivedConversations.tsx

- [135](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ArchivedConversations.tsx#L135): `label: string,`

### web/components/space/ChatHistorySection.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L6): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L65): `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L66): `const [masteryTopics, setMasteryTopics] = useState<MasteryTopicLabel[]>([]);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L67): `const [readingCollections, setReadingCollections] = useState<`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L70): `const [loading, setLoading] = useState(true);`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L71): `const [restoringId, setRestoringId] = useState<string | null>(null);`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L72): `const [query, setQuery] = useState("");`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L73): `const [searchResults, setSearchResults] = useState<SessionSearchResult[]>([]);`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L74): `const [searchLoading, setSearchLoading] = useState(false);`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L75): `const [searchError, setSearchError] = useState(false);`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L76): `const [searchVersion, setSearchVersion] = useState(0);`
- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L78): `const [kindFilter, setKindFilter] = useState("all");`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L79): `const [archiveFilter, setArchiveFilter] = useState("active");`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L179): `navigateTask(session ? sessionRoute(session) : '${basePath}/${sessionId}', router.push);`
- [281](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L281): `title={headerTitle}`
- [358](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ChatHistorySection.tsx#L358): `<div role="alert" className="flex items-center justify-between gap-3 px-2 py-4 text-[12.5px] text-[var(--muted-foreground)]">`

### web/components/space/EduHubImportModal.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L4): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L66): `const [skills, setSkills] = useState<HubSkillListing[] | null>(null);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L67): `const [webUrl, setWebUrl] = useState<string>(EDUHUB_FALLBACK);`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L68): `const [loading, setLoading] = useState(true);`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L69): `const [error, setError] = useState<string | null>(null);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L70): `const [query, setQuery] = useState("");`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L72): `const [selected, setSelected] = useState<HubSkillListing | null>(null);`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L73): `const [detail, setDetail] = useState<HubSkillDetail | null>(null);`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L74): `const [detailLoading, setDetailLoading] = useState(false);`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L75): `const [detailError, setDetailError] = useState<string | null>(null);`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L77): `const [installState, setInstallState] = useState<`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L82): `const [installedLocal, setInstalledLocal] = useState<Set<string>>(`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L172): `role="dialog"`
- [293](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L293): `{loading ? (`
- [297](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L297): `) : error ? (`
- [312](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L312): `) : skills.length === 0 ? (`
- [527](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L527): `{loading ? (`
- [531](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/EduHubImportModal.tsx#L531): `) : error ? (`

### web/components/space/ImportWizard.tsx

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L7): `useState,`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L65): `const [phase, setPhase] = useState<Phase>("intro");`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L66): `const [scan, setScan] = useState<ScanResult | null>(null);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L67): `const [name, setName] = useState("");`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L68): `const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L69): `const [errorCode, setErrorCode] = useState<ImportScanErrorCode | "generic">(`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L72): `const [progress, setProgress] = useState({`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L77): `const [result, setResult] = useState<{ imported: number; skipped: number }>({`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L161): `if (!scan || selectedRefs.length === 0) return;`
- [205](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L205): `<Modal`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L208): `title={t("Import conversations")}`
- [241](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L241): `title={t("Reading your folder…")}`
- [242](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L242): `subtitle={t("Finding projects and conversations.")}`
- [247](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L247): `(groups.length === 0 ? (`
- [250](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L250): `title={t("No conversations found")}`
- [251](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L251): `subtitle={t(`
- [364](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L364): `title={`
- [369](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L369): `subtitle={`
- [399](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L399): `title={t("Imported {{count}} conversations", { count: result.imported })}`
- [400](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L400): `subtitle={`
- [432](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L432): `title={t("Couldn't import")}`
- [433](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ImportWizard.tsx#L433): `subtitle={message}`

### web/components/space/LearningJournalPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L3): `import { useEffect, useState } from "react";`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L12): `const [result, setResult] = useState<{ workspace: string; revision: number; journal?: LearningJournal; error?: boolean } | null>(null);`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L13): `const [revision, setRevision] = useState(0);`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L31): `<SpaceSectionHeader title={t("Learning journal")} description={t("Your tutor's mission, handoff and confirmed learning records.")}`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/LearningJournalPanel.tsx#L33): `{error ? <div role="alert" className={card}>{t("Could not read the learning journal. Its original data is preserved. Try refreshing.")}</div>`

### web/components/space/McpStoreSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L3): `import { useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L32): `const [tab, setTab] = useState<Tab>("installed");`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L41): `title={t("MCP Services")}`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/McpStoreSection.tsx#L271): `label: string;`

### web/components/space/MyAgentsSection.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L5): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L93): `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L94): `const [registry, setRegistry] = useState<ImportAgent[]>([]);`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L95): `const [loading, setLoading] = useState(true);`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L96): `const [selectedKey, setSelectedKey] = useState<string | null>(null);`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L97): `const [query, setQuery] = useState("");`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L98): `const [wizardOpen, setWizardOpen] = useState(false);`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L99): `const [refreshingId, setRefreshingId] = useState<string | null>(null);`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L100): `const [note, setNote] = useState("");`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L101): `const [renamingId, setRenamingId] = useState<string | null>(null);`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L102): `const [scopeAgent, setScopeAgent] = useState<ImportAgent | null>(null);`
- [181](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L181): `router.push('/chat/${sessionId}');`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L271): `const isEmpty = !loading && cards.length === 0;`
- [277](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L277): `title={t("Imported conversations")}`
- [296](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L296): `<EmptyState onAdd={() => setWizardOpen(true)} />`
- [418](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L418): `const [menuOpen, setMenuOpen] = useState(false);`
- [518](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L518): `role="menu"`
- [566](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L566): `const [draft, setDraft] = useState(initial);`
- [591](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L591): `label: string;`
- [598](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/MyAgentsSection.tsx#L598): `role="menuitem"`

### web/components/space/PersonalizationHub.tsx

- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonalizationHub.tsx#L16): `title={t("navigation.personalization")}`

### web/components/space/PersonasSection.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L5): `import { useCallback, useEffect, useState } from "react";`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L66): `const [personas, setPersonas] = useState<PersonaInfo[]>([]);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L67): `const [loading, setLoading] = useState(false);`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L68): `const [errorMsg, setErrorMsg] = useState<string | null>(null);`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L69): `const [editor, setEditor] = useState<PersonaEditorState | null>(null);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L70): `const [viewer, setViewer] = useState<PersonaViewerState | null>(null);`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L71): `const [deleting, setDeleting] = useState<string | null>(null);`
- [245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L245): `title={t("Personas")}`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L271): `{loading ? (`
- [275](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L275): `) : personas.length === 0 ? (`
- [393](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L393): `role="dialog"`
- [447](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L447): `{viewer.loading ? (`
- [451](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L451): `) : viewer.error ? (`
- [469](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L469): `role="dialog"`
- [558](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/PersonasSection.tsx#L558): `{editor.error && (`

### web/components/space/ScopeEditorModal.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L3): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L56): `const [phase, setPhase] = useState<Phase>("loading");`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L57): `const [groups, setGroups] = useState<SelectGroup[]>([]);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L58): `const [selected, setSelected] = useState<Set<string>>(new Set());`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L146): `<Modal`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L149): `title={t("Edit scope")}`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L180): `title={t("Reading your folder…")}`
- [188](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L188): `title={t("Couldn't read this folder")}`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopeEditorModal.tsx#L189): `subtitle={t("Refresh failed — try re-adding the agent.")}`

### web/components/space/ScopePicker.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopePicker.tsx#L5): `import { useState } from "react";`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/ScopePicker.tsx#L50): `const [expanded, setExpanded] = useState<Set<string>>(new Set());`

### web/components/space/SkillLibraryScope.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillLibraryScope.tsx#L3): `import { useEffect, useState } from 'react'`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillLibraryScope.tsx#L12): `const [workspaces, setWorkspaces] = useState<ChatWorkspaceRegistration[]>([])`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillLibraryScope.tsx#L13): `const [error, setError] = useState('')`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillLibraryScope.tsx#L59): `{error && (`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillLibraryScope.tsx#L60): `<p role="alert" className="text-xs text-[var(--destructive)]">`

### web/components/space/SkillsSection.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L6): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L81): `const [skills, setSkills] = useState<SkillInfo[]>([]);`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L82): `const [tagVocab, setTagVocab] = useState<string[]>([]);`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L83): `const [loading, setLoading] = useState(false);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L84): `const [errorMsg, setErrorMsg] = useState<string | null>(null);`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L85): `const [editor, setEditor] = useState<SkillEditorState | null>(null);`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L86): `const [viewer, setViewer] = useState<SkillViewerState | null>(null);`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L87): `const [deleting, setDeleting] = useState<string | null>(null);`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L88): `const [importOpen, setImportOpen] = useState(false);`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L90): `const [filterTag, setFilterTag] = useState<string | "all" | "untagged">(`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L93): `const [tagManagerOpen, setTagManagerOpen] = useState(false);`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L94): `const [newTagDraft, setNewTagDraft] = useState("");`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L95): `const [renamingTag, setRenamingTag] = useState<{`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L99): `const [editorTagDraft, setEditorTagDraft] = useState("");`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L125): `return skills.filter((s) => !s.tags || s.tags.length === 0);`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L141): `() => skills.filter((s) => !s.tags || s.tags.length === 0).length,`
- [403](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L403): `title={t("Skills")}`
- [587](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L587): `{loading ? (`
- [591](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L591): `) : skills.length === 0 ? (`
- [612](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L612): `) : filteredSkills.length === 0 ? (`
- [744](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L744): `role="dialog"`
- [798](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L798): `{viewer.loading ? (`
- [802](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L802): `) : viewer.error ? (`
- [820](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L820): `role="dialog"`
- [889](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L889): `{availableTagsForEditor.length === 0 && (`
- [962](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L962): `{editor.error && (`
- [1003](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SkillsSection.tsx#L1003): `label: string;`

### web/components/space/SpaceDashboard.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L4): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L54): `const [counts, setCounts] = useState<Partial<Record<DashKey, number>>>({});`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceDashboard.tsx#L86): `title={title ?? spaceLabel}`

### web/components/space/SpaceSectionHeader.tsx

- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/SpaceSectionHeader.tsx#L31): `<PageHeader title={title} description={description} action={action} meta={meta} level={level} icon={icon ?? hubIcon} />`

### web/components/space/dashboard-groups.ts

- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts#L78): `label: Lang;`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts#L84): `label: { zh: "对话与资料", en: "Conversations & Materials" },`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts#L152): `label: { zh: "更多项目", en: "More Projects" },`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/dashboard-groups.ts#L179): `label: { zh: "个性化", en: "Personalization" },`

### web/components/space/learning/ConfirmDialog.tsx

- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ConfirmDialog.tsx#L34): `role="alertdialog"`

### web/components/space/learning/CoverageNotice.tsx

- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CoverageNotice.tsx#L35): `if (missing.length === 0) {`

### web/components/space/learning/CreateTopicWizard.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L3): `import { useState, type RefObject } from "react";`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L55): `const [step, setStep] = useState(1);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L56): `const [goal, setGoal] = useState("");`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L57): `const [emoji, setEmoji] = useState("🧭");`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L65): `const [selected, setSelected] = useState<Set<string>>(new Set());`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L66): `const [busy, setBusy] = useState(false);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L67): `const [error, setError] = useState<string | null>(null);`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L85): `label: t("Learning goal"),`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L118): `role="dialog"`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/CreateTopicWizard.tsx#L202): `{error && (`

### web/components/space/learning/EditTopicRouteDialog.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L3): `import { useMemo, useState, type RefObject } from "react";`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L53): `const [draft, setDraft] = useState(original);`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L54): `const [busy, setBusy] = useState(false);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L55): `const [error, setError] = useState<string | null>(null);`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L75): `role="dialog"`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/EditTopicRouteDialog.tsx#L116): `{error && <p className="mt-4 text-xs text-red-600">{error}</p>}`

### web/components/space/learning/LearnerProfileCard.tsx

- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/LearnerProfileCard.tsx#L47): `{rows.length === 0 ? (`

### web/components/space/learning/LearningBoard.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/LearningBoard.tsx#L3): `import { useCallback, useEffect, useState } from "react";`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/LearningBoard.tsx#L56): `const [openId, setOpenId] = useState<string | null>(null);`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/LearningBoard.tsx#L57): `const [report, setReport] = useState<ObjectiveReport | null>(null);`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/LearningBoard.tsx#L58): `const [reportError, setReportError] = useState(false);`

### web/components/space/learning/MasteryStudy.tsx

- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L23): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L218): `const [viewerOpen, setViewerOpen] = useState(false);`
- [219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L219): `const [showSaveModal, setShowSaveModal] = useState(false);`
- [308](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L308): `const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);`
- [312](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L312): `const [outlineOpen, setOutlineOpen] = useState(true);`
- [357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L357): `const [askHint, setAskHint] = useState("");`
- [388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L388): `const [celebration, setCelebration] = useState<{`
- [512](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/MasteryStudy.tsx#L512): `const [modeBusy, setModeBusy] = useState(false);`

### web/components/space/learning/ModuleOutline.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L3): `import { useEffect, useState } from "react";`
- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L214): `const [report, setReport] = useState<ObjectiveReport | null>(null);`
- [215](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L215): `const [noteOpen, setNoteOpen] = useState(false);`
- [216](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L216): `const [note, setNote] = useState("");`
- [217](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L217): `const [busy, setBusy] = useState(false);`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L218): `const [error, setError] = useState<string | null>(null);`
- [248](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L248): `{error ? error : <Loader2 className="h-5 w-5 animate-spin" />}`
- [339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ModuleOutline.tsx#L339): `{error && <p className="mt-2 text-xs text-red-600">{error}</p>}`

### web/components/space/learning/ObjectiveDetail.tsx

- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ObjectiveDetail.tsx#L153): `{report.attempts.length === 0 && !report.explanation && (`
- [236](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ObjectiveDetail.tsx#L236): `label: string;`

### web/components/space/learning/PathTitle.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/PathTitle.tsx#L6): `import { useEffect, useRef, useState } from "react";`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/PathTitle.tsx#L46): `const [editing, setEditing] = useState(false);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/PathTitle.tsx#L47): `const [draft, setDraft] = useState(storedName);`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/PathTitle.tsx#L48): `const [saving, setSaving] = useState(false);`

### web/components/space/learning/ReviewTrail.tsx

- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L18): `import { useState } from "react";`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L124): `const [expanded, setExpanded] = useState(false);`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L125): `const [editorOpen, setEditorOpen] = useState(false);`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L126): `const [form, setForm] = useState<StrategyForm>(() =>`
- [129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L129): `const [formError, setFormError] = useState<string | null>(null);`
- [247](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L247): `role="alert"`
- [302](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L302): `role="alert"`
- [356](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L356): `role="alert"`
- [362](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/ReviewTrail.tsx#L362): `{reviews.length === 0 ? (`

### web/components/space/learning/RouteDraftEditor.tsx

- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/RouteDraftEditor.tsx#L132): `<p role="alert" className="mt-4 text-xs font-medium text-red-600">`
- [302](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/RouteDraftEditor.tsx#L302): `<p role="alert" className="text-[11px] text-red-600">`

### web/components/space/learning/SessionCamp.tsx

- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/SessionCamp.tsx#L32): `router.push(`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/SessionCamp.tsx#L69): `{loading ? (`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/SessionCamp.tsx#L73): `) : sessions.length === 0 ? (`

### web/components/space/learning/TopicAtlas.tsx

- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L52): `title={t('Mastery Path')}`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L53): `subtitle={t(`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L110): `{error && <LearningErrorState message={error} onRetry={onRetry} />}`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L111): `{loading ? (`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L122): `) : !error ? (`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicAtlas.tsx#L125): `title={t('Your atlas is still uncharted')}`

### web/components/space/learning/TopicMapCard.tsx

- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicMapCard.tsx#L34): `title={displayName}`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicMapCard.tsx#L35): `subtitle={metadata.description || metadata.goal}`

### web/components/space/learning/TopicWizardSteps.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L3): `import { useId, useState } from 'react'`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L132): `const [opened, setOpened] = useState<Set<string>>(new Set())`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L143): `{ key: 'knowledgeBases', label: 'Knowledge bases', icon: Database },`
- [144](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L144): `{ key: 'notebooks', label: 'Notebooks', icon: Notebook },`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L145): `{ key: 'books', label: 'Books', icon: BookOpen },`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L146): `{ key: 'questionSets', label: 'Question bank', icon: ListChecks },`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L147): `{ key: 'chats', label: 'Conversations', icon: MessagesSquare },`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L148): `{ key: 'drafts', label: 'Co-Writer drafts', icon: PenLine },`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L149): `{ key: 'partners', label: 'Partners', icon: Users },`
- [151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L151): `const [tab, setTab] = useState<string>('knowledgeBases')`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L153): `const [search, setSearch] = useState('')`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L177): `role="tablist"`
- [186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L186): `role="tab"`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L198): `'[role="tab"]'`
- [223](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L223): `<p role="alert" className="text-xs text-destructive">`
- [232](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L232): `role="tabpanel"`
- [237](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L237): `{loading ? (`
- [244](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L244): `title=""`
- [363](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L363): `if (state.candidates.length === 0) {`
- [428](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/TopicWizardSteps.tsx#L428): `{items.length === 0 ? (`

### web/components/space/learning/route-draft.ts

- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/route-draft.ts#L69): `if (draft.modules.length === 0) return [{ code: "no_regions" }];`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/route-draft.ts#L73): `if (module.knowledge_points.length === 0) {`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/learning/route-draft.ts#L90): `return routeDraftIssues(draft).length === 0;`

### web/components/space/question-bank/BankScopeRail.tsx

- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankScopeRail.tsx#L19): `label: string;`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankScopeRail.tsx#L23): `{ kind: "all", label: "All", icon: LayoutGrid, count: s => s.total },`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankScopeRail.tsx#L24): `{ kind: "wrong", label: "Wrong Only", icon: XCircle, count: s => s.wrong },`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankScopeRail.tsx#L27): `label: "Needs Review",`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankScopeRail.tsx#L33): `label: "Marked",`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankScopeRail.tsx#L39): `label: "Untagged",`

### web/components/space/question-bank/BankToolbar.tsx

- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/BankToolbar.tsx#L120): `disabled={materials.length === 0}`

### web/components/space/question-bank/CategoryManager.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L3): `import { useCallback, useState } from "react";`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L30): `const [newName, setNewName] = useState("");`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L31): `const [renaming, setRenaming] = useState<{ id: number; name: string } | null>(`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L34): `const [busy, setBusy] = useState(false);`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryManager.tsx#L148): `{categories.length === 0 && (`

### web/components/space/question-bank/CategoryMenu.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L51): `const [open, setOpen] = useState(false);`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L52): `const [name, setName] = useState("");`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L53): `const [busy, setBusy] = useState(false);`
- [140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L140): `{categories.length === 0 && (`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/CategoryMenu.tsx#L179): `autoFocus={categories.length === 0}`

### web/components/space/question-bank/QuestionBankSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L3): `import { useEffect, useState } from "react";`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L59): `const [managerOpen, setManagerOpen] = useState(false);`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L68): `title={t("Question Bank")}`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L136): `{bank.loading ? (`
- [140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L140): `) : bank.error ? (`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L157): `) : bank.items.length === 0 ? (`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L159): `<EmptyState`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L161): `title={t("No matching questions")}`
- [165](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L165): `<EmptyState`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L167): `title={t("Everything is filed")}`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L171): `<EmptyState`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L173): `title={t("No entries yet")}`
- [178](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L178): `<EmptyState`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionBankSection.tsx#L180): `title={t("Nothing in this view")}`

### web/components/space/question-bank/QuestionCard.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionCard.tsx#L3): `import { useState } from "react";`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionCard.tsx#L87): `label: string;`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/QuestionCard.tsx#L152): `const [answersVisible, setAnswersVisible] = useState(!collapseAnswers);`

### web/components/space/question-bank/useQuestionBank.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L146): `const [page, setPage] = useState(0);`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L147): `const [items, setItems] = useState<NotebookEntry[]>([]);`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L148): `const [total, setTotal] = useState(0);`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L149): `const [categories, setCategories] = useState<NotebookCategory[]>([]);`
- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L150): `const [stats, setStats] = useState<QuestionBankStats>(EMPTY_STATS);`
- [151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L151): `const [materials, setMaterials] = useState<QuestionBankMaterial[]>([]);`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L152): `const [scope, setScopeState] = useState<BankScope>(DEFAULT_SCOPE);`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L153): `const [reviewFilters, setReviewFiltersState] = useState<ReviewFilters>(EMPTY_FILTERS);`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L154): `const [sort, setSort] = useState<BankSort>("recent");`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L155): `const [searchInput, setSearchInput] = useState("");`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L156): `const [search, setSearch] = useState("");`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L157): `const [loading, setLoading] = useState(true);`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L158): `const [refreshing, setRefreshing] = useState(false);`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L159): `const [error, setError] = useState<string | null>(null);`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L160): `const [pendingIds, setPendingIds] = useState<ReadonlySet<number>>(new Set());`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L161): `const [selectedIds, setSelectedIds] = useState<ReadonlySet<number>>(new Set());`
- [187](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/space/question-bank/useQuestionBank.ts#L187): `if (response.items.length === 0 && page > 0 && response.total > 0) {`

### web/components/tasks/TaskColorPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L3): `import { useRef, useState, type RefObject } from 'react'`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L38): `error?: string`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L42): `const [open, setOpen] = useState(false)`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L95): `error?: string`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L101): `const [draft, setDraft] = useState(colors)`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L102): `const [status, setStatus] = useState<TaskStatus>('todo')`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L103): `const [hex, setHex] = useState(colors.todo)`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L116): `role="dialog"`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L218): `{error && (`
- [219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskColorPicker.tsx#L219): `<p role="alert" className="mt-3 text-xs text-destructive">`

### web/components/tasks/TaskLinkSelector.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskLinkSelector.tsx#L3): `import { useState } from 'react'`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskLinkSelector.tsx#L23): `const [query, setQuery] = useState('')`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskLinkSelector.tsx#L24): `const [busy, setBusy] = useState(false)`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskLinkSelector.tsx#L25): `const [saveError, setSaveError] = useState(false)`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskLinkSelector.tsx#L64): `<p role="alert" className="text-xs text-[var(--destructive)]">`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskLinkSelector.tsx#L68): `{!board && !error && (`

### web/components/tasks/TaskPanelSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskPanelSection.tsx#L3): `import { useState } from 'react'`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskPanelSection.tsx#L28): `const [busy, setBusy] = useState(false)`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskPanelSection.tsx#L29): `const [error, setError] = useState(false)`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskPanelSection.tsx#L106): `{error && (`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/tasks/TaskPanelSection.tsx#L107): `<p role="alert" className="text-xs text-[var(--destructive)]">`

### web/components/ui/ConfirmDialog.tsx

- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/ui/ConfirmDialog.tsx#L58): `role="alertdialog"`

### web/components/video-lesson/VideoLessonViewer.tsx

- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/video-lesson/VideoLessonViewer.tsx#L41): `title={result.title || t("Video Lesson")}`

### web/components/visualize/VisualizationViewer.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L4): `import { useEffect, useMemo, useRef, useState, type MouseEvent } from "react";`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L53): `const [error, setError] = useState<string | null>(null);`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L121): `const [height, setHeight] = useState(560);`
- [186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L186): `title={t("HTML visualization")}`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L198): `const [height, setHeight] = useState(560);`
- [245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L245): `title={result.presentation.title || result.renderer.id}`
- [482](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L482): `title={result.presentation.title}`
- [522](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L522): `const [showCode, setShowCode] = useState(false);`
- [523](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L523): `const [copied, setCopied] = useState(false);`
- [524](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizationViewer.tsx#L524): `const [fullscreen, setFullscreen] = useState(false);`

### web/components/visualize/VisualizeConfigPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizeConfigPanel.tsx#L3): `import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizeConfigPanel.tsx#L42): `const [catalog, setCatalog] = useState<VisualizerCatalogItem[]>([]);`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizeConfigPanel.tsx#L43): `const [catalogError, setCatalogError] = useState("");`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/visualize/VisualizeConfigPanel.tsx#L44): `const [busy, setBusy] = useState("");`

### web/components/watching/WatchingBrowser.tsx

- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L14): `import { useEffect, useRef, useState } from 'react'`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L41): `const [account, setAccount] = useState<InvidiousAccountStatus | null>(null)`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L42): `const [view, setView] = useState<BrowserView>('search')`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L43): `const [input, setInput] = useState('')`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L44): `const [query, setQuery] = useState('')`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L45): `const [playlist, setPlaylist] = useState('')`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L46): `const [page, setPage] = useState(1)`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L47): `const [items, setItems] = useState<(InvidiousVideo | InvidiousPlaylist)[]>([])`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L48): `const [busy, setBusy] = useState(false)`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L49): `const [accountBusy, setAccountBusy] = useState(false)`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L50): `const [error, setError] = useState('')`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L51): `const [reload, setReload] = useState(0)`
- [183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L183): `title={t('Browse Invidious')}`
- [184](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L184): `subtitle={t('Choose a video to add to this collection.')}`
- [265](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L265): `{error && (`
- [348](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L348): `title={item.title}`
- [350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L350): `subtitle={isPlaylist ? '${item.videoCount} ${t('videos')}' : item.author}`
- [357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L357): `{!items.length && !error && (`
- [360](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingBrowser.tsx#L360): `title={`

### web/components/watching/WatchingMarksPanel.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingMarksPanel.tsx#L3): `import { useState } from "react";`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingMarksPanel.tsx#L41): `error?: string | null;`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingMarksPanel.tsx#L50): `const [filter, setFilter] = useState<VideoMarkKind | "all">("all");`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingMarksPanel.tsx#L55): `{error && (`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/watching/WatchingMarksPanel.tsx#L57): `role="alert"`

### web/components/whisper/WhisperMessageList.tsx

- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/whisper/WhisperMessageList.tsx#L46): `if (messages.length === 0) {`

### web/components/whisper/WhisperRoomChip.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/whisper/WhisperRoomChip.tsx#L3): `import { useState } from "react";`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/whisper/WhisperRoomChip.tsx#L13): `const [copied, setCopied] = useState(false);`

### web/components/workspaces/ServerFolderPicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L3): `import { useEffect, useState } from 'react'`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L23): `const [path, setPath] = useState('')`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L24): `const [listing, setListing] = useState<ServerFolderListing | null>(null)`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L25): `const [loading, setLoading] = useState(true)`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L26): `const [saving, setSaving] = useState(false)`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L27): `const [error, setError] = useState('')`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L28): `const [filter, setFilter] = useState('')`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L29): `const [attempt, setAttempt] = useState(0)`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L81): `<Dialog`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L83): `title={t('Choose a server folder')}`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L154): `{error && (`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L156): `<p role="alert" className="text-sm text-[var(--destructive)]">`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L176): `{loading ? (`
- [202](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/ServerFolderPicker.tsx#L202): `!error && (`

### web/components/workspaces/SystemWorkspaceSnapshot.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/SystemWorkspaceSnapshot.tsx#L3): `import { useState } from 'react'`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/SystemWorkspaceSnapshot.tsx#L14): `const [snapshot, setSnapshot] = useState<Snapshot | null>(null)`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/SystemWorkspaceSnapshot.tsx#L15): `const [busy, setBusy] = useState(false)`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/SystemWorkspaceSnapshot.tsx#L16): `const [error, setError] = useState('')`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/SystemWorkspaceSnapshot.tsx#L47): `{error && (`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/SystemWorkspaceSnapshot.tsx#L48): `<p role="alert" className="mt-2 text-xs text-[var(--destructive)]">`

### web/components/workspaces/WorkspaceNavigation.tsx

- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceNavigation.tsx#L30): `router.replace(scopedUrl('${window.location.pathname}${window.location.search}${window.location.hash}'))`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceNavigation.tsx#L51): `useEffect(() => registerWorkspaceNavigator(router.push), [router])`

### web/components/workspaces/WorkspacePill.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L4): `import { useEffect, useRef, useState } from "react";`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L36): `label: pickerLabel = "Conversation workspace",`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L43): `/** Freeze the binding as a label: this conversation already has messages. */`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L45): `error?: string;`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L49): `const [creating, setCreating] = useState(false);`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L50): `const [browsing, setBrowsing] = useState(false);`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L51): `const [name, setName] = useState("");`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L52): `const [saving, setSaving] = useState(false);`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L53): `const [createError, setCreateError] = useState("");`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L54): `const [created, setCreated] = useState<ChatWorkspaceRegistration[]>([]);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L55): `const [open, setOpen] = useState(false);`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L155): `{error ? (`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L158): `role="alert"`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L170): `role="menu"`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L174): `{selectable.length === 0 ? (`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L189): `role="menuitemradio"`
- [228](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L228): `<button type="button" role="menuitem" onClick={() => { setOpen(false); setBrowsing(true); }}`
- [254](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspacePill.tsx#L254): `{createError && <p role="alert" className="text-xs text-[var(--destructive)]">{createError}</p>}`

### web/components/workspaces/WorkspaceResourcePicker.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L3): `import { useEffect, useState } from 'react'`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L22): `const [catalog, setCatalog] = useState<WorkspaceResourceCatalog | null>(null)`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L23): `const [error, setError] = useState('')`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L24): `const [attempt, setAttempt] = useState(0)`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L42): `{ key: 'skills' as const, label: 'Skills', href: '/space/skills' },`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L43): `{ key: 'mcp' as const, label: 'MCP services', href: '/space/mcp' },`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L44): `{ key: 'knowledge_bases' as const, label: 'Knowledge bases', href: '/knowledge-bases' },`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L56): `{error && (`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L57): `<p role="alert" className="text-xs text-[var(--destructive)]">`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/components/workspaces/WorkspaceResourcePicker.tsx#L106): `{!catalog && !error && (`

### web/features/calendar/components/AnchoredPopover.tsx

- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/AnchoredPopover.tsx#L35): `label: string`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/AnchoredPopover.tsx#L68): `if (target?.closest?.('[role="dialog"], [role="menu"], [data-calendar-keep-popover]')) return`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/AnchoredPopover.tsx#L91): `role="dialog"`

### web/features/calendar/components/CalendarPage.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L4): `import { useEffect, useMemo, useRef, useState } from 'react'`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L86): `const [cursor, setCursor] = useState(() => new Date())`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L87): `const [view, setView] = useState<View>('month')`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L88): `const [now, setNow] = useState(() => new Date())`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L89): `const [toggles, setToggles] = useState<LayerToggles>(DEFAULT_LAYERS)`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L90): `const [rail, setRail] = useState(true)`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L91): `const [panel, setPanel] = useState<Panel | null>(null)`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L92): `const [scope, setScope] = useState<api.EditScope>('this')`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L93): `const [error, setError] = useState('')`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L94): `const [busy, setBusy] = useState(false)`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L96): `const [undo, setUndo] = useState<string | null>(null)`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L97): `const [query, setQuery] = useState('')`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L98): `const [hits, setHits] = useState<api.SearchHit[] | null>(null)`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L99): `const [searching, setSearching] = useState(false)`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L101): `const [searchOpen, setSearchOpen] = useState(false)`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L102): `const [permission, setPermission] = useState<NotificationPermission | 'unsupported'>(`
- [412](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L412): `title={'${t('Search calendar')}  /'}`
- [417](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L417): `<div className="dt-cal-views" role="tablist" aria-label={t('Calendar view')}>`
- [421](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L421): `role="tab"`
- [449](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L449): `<PageHeader title={t('Calendar')} icon={CalendarDays} />`
- [467](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L467): `<div role="alert" className="dt-cal-alert is-error">`
- [480](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L480): `{error && !editing && (`
- [481](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarPage.tsx#L481): `<div role="alert" className="dt-cal-alert is-error">`

### web/features/calendar/components/CalendarRail.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L3): `import { useState, type CSSProperties, type FormEvent } from 'react'`
- [234](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L234): `label: string`
- [269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L269): `const [open, setOpen] = useState(false)`
- [270](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L270): `const [renaming, setRenaming] = useState(false)`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L271): `const [name, setName] = useState('')`
- [327](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L327): `<div role="menu" aria-label={label} className="dt-popover dt-cal-calendar-menu">`
- [333](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L333): `role="menuitemradio"`
- [349](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L349): `role="menuitem"`
- [361](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L361): `role="menuitem"`
- [374](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L374): `role="menuitem"`
- [399](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L399): `const [editing, setEditing] = useState(false)`
- [400](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRail.tsx#L400): `const [name, setName] = useState('')`

### web/features/calendar/components/CalendarRuntime.tsx

- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/CalendarRuntime.tsx#L20): `!loading &&`

### web/features/calendar/components/EventEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L3): `import { useState, type CSSProperties } from 'react'`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L44): `const [draft, setDraft] = useState(initial)`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L45): `const [scope, setScope] = useState<EditScope>('this')`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L46): `const [preset, setPreset] = useState<RepeatPreset>(detectPreset(initial.rrule, initial.start))`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L47): `const [rule, setRule] = useState(parseRule(initial.rrule) ?? defaultRule('WEEKLY', initial.start))`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L48): `const [customReminder, setCustomReminder] = useState(10)`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L56): `const [addingReminder, setAddingReminder] = useState(false)`
- [414](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L414): `<p role="alert" className="dt-cal-editor-error">`
- [418](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L418): `{error && (`
- [419](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/EventEditor.tsx#L419): `<p role="alert" className="dt-cal-editor-error">`

### web/features/calendar/components/ItemDetails.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx#L3): `import { useState, type CSSProperties, type ReactNode } from 'react'`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx#L102): `title={itemTitle(item, t)}`
- [190](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx#L190): `title={card.title}`
- [240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx#L240): `title={itemTitle(item, t)}`
- [282](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx#L282): `const [confirming, setConfirming] = useState(false)`
- [294](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx#L294): `title={itemTitle(item, t)}`
- [338](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/ItemDetails.tsx#L338): `title={t('Footprints')}`

### web/features/calendar/components/MiniMonth.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/MiniMonth.tsx#L3): `import { useState } from 'react'`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/MiniMonth.tsx#L35): `const [shown, setShown] = useState(() => startOfMonth(cursor))`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/MiniMonth.tsx#L36): `const [followed, setFollowed] = useState(dateKey(startOfMonth(cursor)))`

### web/features/calendar/components/MonthView.tsx

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/MonthView.tsx#L7): `useState,`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/MonthView.tsx#L83): `const [lanes, setLanes] = useState(4)`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/MonthView.tsx#L84): `const [drag, setDrag] = useState<Drag | null>(null)`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/MonthView.tsx#L86): `const [dropDay, setDropDay] = useState<DateKey | null>(null)`

### web/features/calendar/components/TimeGrid.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/TimeGrid.tsx#L9): `useState,`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/TimeGrid.tsx#L103): `const [drag, setDrag] = useState<Drag | null>(null)`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/TimeGrid.tsx#L105): `const [taskDrop, setTaskDrop] = useState<`

### web/features/calendar/components/calendar.css

- [484](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/calendar.css#L484): `.dt-cal-day-label:hover {`
- [1053](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/components/calendar.css#L1053): `.dt-cal-editor [role='alert'] {`

### web/features/calendar/store/calendar-store.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L3): `import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'`
- [163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L163): `const [state, setState] = useState<{`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L168): `const [error, setError] = useState(false)`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L170): `const [nonce, setNonce] = useState(0)`
- [203](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L203): `const [error, setError] = useState(false)`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L204): `const [layers, setLayers] = useState<CalendarLayers | null>(null)`
- [205](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L205): `const [nonce, setNonce] = useState(0)`
- [243](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/calendar/store/calendar-store.ts#L243): `const [state, setState] = useState<{`

### web/features/capabilities/presentation.tsx

- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L34): `label: string;`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L39): `{ name: "brainstorm", label: "Brainstorm", icon: Lightbulb },`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L40): `{ name: "geogebra_analysis", label: "GeoGebra", icon: Compass },`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L41): `{ name: "web_search", label: "Web Search", icon: Globe },`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L42): `{ name: "exec", label: "Execute", icon: Code2 },`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L43): `{ name: "reason", label: "Reason", icon: Sparkles },`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L44): `{ name: "paper_search", label: "Arxiv Search", icon: FileSearch },`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L45): `{ name: "imagegen", label: "Image Gen", icon: ImageIcon },`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L46): `{ name: "videogen", label: "Video Gen", icon: Clapperboard },`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L51): `label: string;`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L70): `label: "Chat",`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L87): `label: "Solve",`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L96): `label: "Ask Questions",`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L113): `label: "Quiz",`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L121): `label: "Research",`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L130): `label: "Visualize",`
- [139](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L139): `label: "Video Lesson",`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/presentation.tsx#L147): `label: "Mastery Path",`

### web/features/capabilities/useCapabilityCatalog.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/useCapabilityCatalog.ts#L3): `import { useEffect, useMemo, useState } from "react";`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/useCapabilityCatalog.ts#L26): `useState<CapabilityDescriptor[]>(fallbackDescriptors);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/useCapabilityCatalog.ts#L27): `const [isLoading, setIsLoading] = useState(true);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/capabilities/useCapabilityCatalog.ts#L28): `const [error, setError] = useState<Error | null>(null);`

### web/features/chat/ChatStateAdapter.tsx

- [1003](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/ChatStateAdapter.tsx#L1003): `if (!session || session.messages.length === 0) return state;`
- [4114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/ChatStateAdapter.tsx#L4114): `if (Object.keys(nextSelections).length === 0) return;`

### web/features/chat/components/ChatLocation.tsx

- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatLocation.tsx#L41): `label: displaySessionTitle(session.title, t("New conversation")),`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatLocation.tsx#L64): `create={{ label: t("New chat"), onSelect: onNewChat }}`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatLocation.tsx#L65): `all={{ label: t("All conversations"), href: "/space/chat-history" }}`

### web/features/chat/components/ChatSessionMenu.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatSessionMenu.tsx#L11): `import { useCallback, useEffect, useRef, useState } from "react";`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatSessionMenu.tsx#L80): `const [position, setPosition] = useState<FloatingMenuPosition | null>(null);`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatSessionMenu.tsx#L81): `const [moving, setMoving] = useState(false);`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatSessionMenu.tsx#L122): `const [menuSessionId, setMenuSessionId] = useState(sessionId);`
- [199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatSessionMenu.tsx#L199): `title={sessionId ? t("Conversation actions") : t("Start a conversation first")}`
- [206](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatSessionMenu.tsx#L206): `role="menu"`

### web/features/chat/components/ChatWorkspace.tsx

- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L21): `useState,`
- [319](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L319): `const [replyLanguageSavingKey, setReplyLanguageSavingKey] = useState<string | null>(null);`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L340): `const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBase[]>([]);`
- [341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L341): `const [knowledgeBasesLoaded, setKnowledgeBasesLoaded] = useState(false);`
- [371](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L371): `const [draftTaskSelections, setDraftTaskSelections] = useState<Record<string, string[]>>({});`
- [388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L388): `const [userEnabledTools, setUserEnabledTools] = useState<string[] | null>(`
- [391](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L391): `const [attachments, setAttachments] = useState<PendingAttachment[]>([]);`
- [393](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L393): `const [dragging, setDragging] = useState(false);`
- [394](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L394): `const [attachmentError, setAttachmentError] = useState<string | null>(null);`
- [395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L395): `const [previewSource, setPreviewSource] = useState<FilePreviewSource | null>(`
- [407](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L407): `const [viewerPanelOpen, setViewerPanelOpen] = useState(false);`
- [411](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L411): `const [selectedPassage, setSelectedPassage] = useState<{`
- [460](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L460): `const [capMenuOpen, setCapMenuOpen] = useState(false);`
- [461](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L461): `const [quizConfig, setQuizConfig] = useState<DeepQuestionFormConfig>({`
- [464](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L464): `const [quizValidationErrors, setQuizValidationErrors] = useState<string[]>(`
- [467](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L467): `const [quizPdf, setQuizPdf] = useState<File | null>(null);`
- [468](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L468): `const [visualizeConfig, setVisualizeConfig] = useState<VisualizeFormConfig>({`
- [471](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L471): `const [researchConfig, setResearchConfig] = useState<DeepResearchFormConfig>(`
- [482](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L482): `useState(false);`
- [542](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L542): `const [showSaveModal, setShowSaveModal] = useState(false);`
- [543](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L543): `const [showNotebookPicker, setShowNotebookPicker] = useState(false);`
- [544](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L544): `const [showBookPicker, setShowBookPicker] = useState(false);`
- [545](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L545): `const [showReadingPicker, setShowReadingPicker] = useState(false);`
- [546](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L546): `const [showHistoryPicker, setShowHistoryPicker] = useState(false);`
- [547](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L547): `const [showAgentsPicker, setShowAgentsPicker] = useState(false);`
- [548](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L548): `const [showQuestionBankPicker, setShowQuestionBankPicker] = useState(false);`
- [552](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L552): `const [personaSelectorOpen, setPersonaSelectorOpen] = useState(false);`
- [553](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L553): `const [showMemoryPicker, setShowMemoryPicker] = useState(false);`
- [554](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L554): `const [spaceMenuOpen, setSpaceMenuOpen] = useState(false);`
- [555](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L555): `const [selectedNotebookRecords, setSelectedNotebookRecords] = useState<`
- [558](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L558): `const [selectedBookReferences, setSelectedBookReferences] = useState<`
- [561](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L561): `const [selectedReadingReferences, setSelectedReadingReferences] = useState<`
- [564](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L564): `const [selectedHistorySessions, setSelectedHistorySessions] = useState<`
- [571](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L571): `const [selectedAgentSessions, setSelectedAgentSessions] = useState<`
- [574](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L574): `const [selectedQuestionEntries, setSelectedQuestionEntries] = useState<`
- [577](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L577): `const [selectedMemoryFiles, setSelectedMemoryFiles] = useState<`
- [588](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L588): `const [sessionLoading, setSessionLoading] = useState(false);`
- [592](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L592): `const [sessionLoadFailed, setSessionLoadFailed] = useState(false);`
- [677](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L677): `router.replace(watchingRoute(sessionIdParam, state.workspaceId || ""), { scroll: false });`
- [779](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L779): `const [askHint, setAskHint] = useState("");`
- [796](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L796): `const [welcomeGreeting, setWelcomeGreeting] = useState<string>(`
- [846](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L846): `useState(displaySessionTitle);`
- [847](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L847): `const [sessionTitleEditing, setSessionTitleEditing] = useState(false);`
- [851](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L851): `const [sessionTitleSaving, setSessionTitleSaving] = useState(false);`
- [852](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L852): `const [sessionTitleError, setSessionTitleError] = useState<string | null>(`
- [900](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L900): `router.push,`
- [907](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L907): `navigateTask("/chat", router.push);`
- [912](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L912): `navigateTask("/chat", router.push);`
- [1232](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1232): `router.replace(scopedUrl("/chat"), { scroll: false });`
- [1383](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1383): `router.replace(scopedUrl('/chat/${encodeURIComponent(state.sessionId)}', state.workspaceId || ""), {`
- [1672](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1672): `canConfirm={quizValidationErrors.length === 0}`
- [1708](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1708): `canConfirm={researchErrorMessages.length === 0}`
- [1955](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1955): `const [subagentBudget, setSubagentBudget] = useState<number | null>(null);`
- [1956](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1956): `const [selectedPartner, setSelectedPartner] = useState<string | null>(null);`
- [1957](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1957): `const [selectedPartnerGroup, setSelectedPartnerGroup] = useState<string | null>(null);`
- [1973](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L1973): `const [retryingTurn, setRetryingTurn] = useState<{`
- [2158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L2158): `extraAttachments.length === 0 &&`
- [2601](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L2601): `title={displaySessionTitle}`
- [2679](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L2679): `title={t("Write Markdown in chat")}`
- [2686](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L2686): `title={t("Session activity, attachments & previews")}`
- [2692](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L2692): `title={displaySessionTitle}`
- [2860](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L2860): `role="alert"`
- [3189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/ChatWorkspace.tsx#L3189): `const groups = new Map<string, { label: string; events: StreamEvent[] }>();`

### web/features/chat/components/HeaderActionButton.tsx

- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/HeaderActionButton.tsx#L27): `label: string;`

### web/features/chat/components/SelectionActions.tsx

- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/SelectionActions.tsx#L14): `import { useEffect, useState } from "react";`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/SelectionActions.tsx#L62): `const [menuOpen, setMenuOpen] = useState(false);`
- [131](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/SelectionActions.tsx#L131): `role="menu"`

### web/features/chat/components/turn/ProtocolMismatchNotice.tsx

- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/turn/ProtocolMismatchNotice.tsx#L19): `<InlineAlert`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/components/turn/ProtocolMismatchNotice.tsx#L21): `title={t("Frontend update required")}`

### web/features/chat/messages/ChatMessageList.tsx

- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L12): `useState,`
- [372](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L372): `const [userOpen, setUserOpen] = useState<boolean | null>(null);`
- [1347](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1347): `label: string;`
- [1382](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1382): `const [outcome, setOutcome] = useState<"idle" | "copied" | "failed">("idle");`
- [1475](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1475): `const [state, setState] = useState<"idle" | "loading" | "playing">("idle");`
- [1673](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1673): `const [confirm, setConfirm] = useState(false);`
- [1746](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1746): `const [editing, setEditing] = useState(false);`
- [1747](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1747): `const [draft, setDraft] = useState(msg.content);`
- [1748](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1748): `const [discarding, setDiscarding] = useState(false);`
- [1749](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1749): `const [discardFailed, setDiscardFailed] = useState(false);`
- [1750](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1750): `const [submittingEdit, setSubmittingEdit] = useState(false);`
- [1751](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1751): `const [editFailed, setEditFailed] = useState(false);`
- [1752](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1752): `const [retrying, setRetrying] = useState(false);`
- [1765](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1765): `const [replacementAvailable, setReplacementAvailable] = useState(false);`
- [1829](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1829): `label: consultation.name,`
- [1840](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1840): `label: filename,`
- [1859](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1859): `label: name,`
- [1867](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1867): `label: kbDisplayNames?.[name] ?? name,`
- [1874](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1874): `label: '${ref.page_ids.length} ${t("chapters")}',`
- [1880](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1880): `label: '${ref.locators.length} ${t("reading sections")}',`
- [1886](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1886): `label: '${ref.record_ids.length} ${t("records")}',`
- [1897](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1897): `label: "",`
- [1905](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1905): `label: "",`
- [1913](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1913): `label: '${snap.questionNotebookReferences.length} ${t("items")}',`
- [1923](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1923): `label: snap.persona,`
- [1931](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L1931): `label: file === "summary" ? t("Summary") : t("Profile"),`
- [2001](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2001): `{editFailed && <p role="alert" className="text-xs text-[var(--destructive)]">{t("The edit could not be sent. Your draft is still here; please retry.")}</p>}`
- [2057](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2057): `{discardFailed && <p role="alert" className="max-w-full text-right text-xs text-[var(--destructive)]">`
- [2110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2110): `* A link, not a label: it is written in the reader's citation form, so the`
- [2439](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2439): `const [prevStreaming, setPrevStreaming] = useState(isStreaming);`
- [2440](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2440): `const [prevSession, setPrevSession] = useState(sessionId);`
- [2441](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2441): `const [freshlyCompletedIndex, setFreshlyCompletedIndex] = useState<`
- [2497](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2497): `role="alert"`
- [2635](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/ChatMessageList.tsx#L2635): `<div role="alert" className="mt-3 flex w-full max-w-[min(520px,90%)] items-center gap-2 rounded-xl border border-[var(--destructive)]/30 bg-[var(--destructive)]/5 px-3 py-2">`

### web/features/chat/messages/MessageThreadMarker.tsx

- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L20): `useState,`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L58): `const [open, setOpen] = useState(false);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L59): `const [position, setPosition] = useState<PopoverPosition | null>(null);`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L60): `const [confirming, setConfirming] = useState<string | null>(null);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L61): `const [deleting, setDeleting] = useState<string | null>(null);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L62): `const [detaching, setDetaching] = useState<string | null>(null);`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L97): `if (open && threads.length === 0) close();`
- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L134): `if (threads.length === 0) return null;`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/MessageThreadMarker.tsx#L189): `role="dialog"`

### web/features/chat/messages/UsageFooter.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/UsageFooter.tsx#L3): `import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react'`
- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/UsageFooter.tsx#L11): `const [open, setOpen] = useState(false)`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/UsageFooter.tsx#L12): `const [scope, setScope] = useState<'turn' | 'session'>('turn')`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/UsageFooter.tsx#L16): `const [position, setPosition] = useState({ top: 0, left: 0 })`
- [140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/messages/UsageFooter.tsx#L140): `role="dialog"`

### web/features/chat/trace/TracePresentation.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L8): `useState,`
- [439](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L439): `label: label.replace(/^generate\s+/i, ""),`
- [443](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L443): `label: label.replace(/^write\s+/i, ""),`
- [529](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L529): `if (questions.length === 0) return null;`
- [646](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L646): `!niceArgs && entries.length === 0 && rawArgs && typeof rawArgs !== "object"`
- [804](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L804): `<TraceSection title={t("Thought")}>`
- [809](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L809): `<TraceSection title={t("Tool")}>`
- [824](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L824): `<TraceSection title={t("Observe")}>`
- [987](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L987): `const [userOpen, setUserOpen] = useState<boolean | null>(null);`
- [1134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L1134): `title={headline}`
- [1540](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L1540): `const [nowSeconds, setNowSeconds] = useState(() => Date.now() / 1000);`
- [1853](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L1853): `const [userOpen, setUserOpen] = useState<boolean | null>(null);`
- [2008](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/TracePresentation.tsx#L2008): `title={card.title}`

### web/features/chat/trace/memory.ts

- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/chat/trace/memory.ts#L124): `if (result.length === 0 && size > maxBytes) {`

### web/features/co-writer/components/CoWriterWorkspace.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L5): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L116): `const TOOL_OPTIONS: Array<{ name: ToolName; label: string }> = [`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L117): `{ name: "rag", label: "Knowledge Base" },`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L118): `{ name: "web", label: "Web Search" },`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L121): `const MODE_OPTIONS: Array<{ value: SelectionMode; label: string }> = [`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L122): `{ value: "none", label: "None" },`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L123): `{ value: "shorten", label: "Shorten" },`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L124): `{ value: "expand", label: "Expand" },`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L125): `{ value: "rewrite", label: "Rewrite" },`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L189): `const [docTitle, setDocTitle] = useState<string>("");`
- [190](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L190): `const [isEditingTitle, setIsEditingTitle] = useState(false);`
- [191](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L191): `const [titleDraft, setTitleDraft] = useState<string>("");`
- [193](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L193): `const [docNotFound, setDocNotFound] = useState(false);`
- [194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L194): `const [isLoadingDoc, setIsLoadingDoc] = useState(true);`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L195): `const [isSavingDoc, setIsSavingDoc] = useState(false);`
- [196](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L196): `const [isExportingDocx, setIsExportingDocx] = useState(false);`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L197): `const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);`
- [230](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L230): `const [markdown, setMarkdown] = useState("");`
- [236](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L236): `const [instruction, setInstruction] = useState("");`
- [237](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L237): `const [action, setAction] = useState<EditAction>("rewrite");`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L238): `const [source, setSource] = useState<SourceOption>("none");`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L239): `const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBase[]>([]);`
- [240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L240): `const [kbName, setKbName] = useState("");`
- [241](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L241): `const [isEditing, setIsEditing] = useState(false);`
- [242](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L242): `const [isAutoMarking, setIsAutoMarking] = useState(false);`
- [243](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L243): `const [error, setError] = useState("");`
- [244](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L244): `const [status, setStatus] = useState("");`
- [245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L245): `const [isEditModalOpen, setIsEditModalOpen] = useState(false);`
- [247](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L247): `useState<ConfirmAction | null>(null);`
- [249](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L249): `useState<NotebookSavePayload | null>(null);`
- [250](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L250): `const [selectedRange, setSelectedRange] = useState<SelectedRange | null>(`
- [254](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L254): `useState<SelectionPopoverState>({`
- [259](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L259): `const [selectionInstruction, setSelectionInstruction] = useState("");`
- [260](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L260): `const [selectionMode, setSelectionMode] = useState<SelectionMode>("rewrite");`
- [261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L261): `const [selectionTools, setSelectionTools] = useState<ToolName[]>([]);`
- [262](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L262): `const [llmSelection, setLLMSelection] = useState<LLMSelection | null>(null);`
- [263](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L263): `const [isToolMenuOpen, setIsToolMenuOpen] = useState(false);`
- [264](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L264): `const [isModeMenuOpen, setIsModeMenuOpen] = useState(false);`
- [266](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L266): `useState<SelectionTraceData | null>(null);`
- [267](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L267): `const [selectionPopoverPinned, setSelectionPopoverPinned] = useState(false);`
- [269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L269): `useState(false);`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L271): `const [undoStack, setUndoStack] = useState<string[]>([]);`
- [272](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L272): `const [redoStack, setRedoStack] = useState<string[]>([]);`
- [275](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L275): `const [hasLoadedDraft, setHasLoadedDraft] = useState(false);`
- [470](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L470): `if (undoStack.length === 0) return;`
- [478](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L478): `if (redoStack.length === 0) return;`
- [1037](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1037): `if (dataLines.length === 0) return;`
- [1364](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1364): `if (sourceLines.length === 0) return new Map();`
- [1451](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1451): `if (nodes.length === 0) return new Map();`
- [1494](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1494): `markers.length === 0 ||`
- [1545](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1545): `if (markers.length === 0) return;`
- [1587](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1587): `if (markers.length === 0) return;`
- [1682](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1682): `onClick={() => onBack ? onBack() : router.push("/co-writer")}`
- [1711](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1711): `onClick={() => onBack ? onBack() : router.push("/co-writer")}`
- [1779](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1779): `title={t("Clear")}`
- [1785](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1785): `<ToolbarIconBtn title={t("Export Markdown")} onClick={handleDownload}>`
- [1789](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1789): `title={t("Export Word")}`
- [1802](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1802): `title={t("Save to Notebook")}`
- [1808](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L1808): `title={t("Load Example Template")}`
- [2117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L2117): `{selectionTools.length === 0`
- [2269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L2269): `title={label}`
- [2282](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L2282): `title={t("Response")}`
- [2299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L2299): `title={t("Running tools and preparing the final edit...")}`
- [2458](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/components/CoWriterWorkspace.tsx#L2458): `role="alertdialog"`

### web/features/co-writer/hooks/useSplitPane.ts

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/hooks/useSplitPane.ts#L7): `useState,`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/hooks/useSplitPane.ts#L16): `const [editorCollapsed, setEditorCollapsed] = useState(false);`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/hooks/useSplitPane.ts#L17): `const [previewCollapsed, setPreviewCollapsed] = useState(false);`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/hooks/useSplitPane.ts#L18): `const [editorRatio, setEditorRatio] = useState(0.5);`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/hooks/useSplitPane.ts#L19): `const [isResizingSplit, setIsResizingSplit] = useState(false);`

### web/features/co-writer/hooks/useSynchronizedScroll.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/hooks/useSynchronizedScroll.ts#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/hooks/useSynchronizedScroll.ts#L13): `const [enabled, setEnabled] = useState(true);`

### web/features/co-writer/model/editor-state.ts

- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/co-writer/model/editor-state.ts#L97): `if (markers.length === 0 || !Number.isFinite(sourcePosition)) return 0;`

### web/features/knowledge/api/client.ts

- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/api/client.ts#L173): `label: string;`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/api/client.ts#L189): `label: string;`
- [1719](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/api/client.ts#L1719): `error?: string | null;`

### web/features/knowledge/components/engines/EngineDetail.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L3): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L200): `label: string;`
- [217](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L217): `const [outcome, setOutcome] = useState<"idle" | "copied" | "failed">("idle");`
- [263](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L263): `label: string;`
- [301](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L301): `label: string;`
- [339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L339): `const [selected, setSelected] = useState(`
- [342](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L342): `const [pending, setPending] = useState<string | null>(null);`
- [407](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L407): `const [loaded, setLoaded] = useState<LlamaIndexConfig | null>(null);`
- [408](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L408): `const [form, setForm] = useState<LlamaIndexConfig | null>(null);`
- [409](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L409): `const [saving, setSaving] = useState(false);`
- [750](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L750): `const [config, setConfig] = useState<ImaAccountConfig | null>(null);`
- [751](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L751): `const [clientId, setClientId] = useState("");`
- [752](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L752): `const [apiKey, setApiKey] = useState("");`
- [753](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L753): `const [saving, setSaving] = useState(false);`
- [907](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L907): `label: string;`
- [975](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L975): `const [loaded, setLoaded] = useState<T | null>(null);`
- [976](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L976): `const [form, setForm] = useState<T | null>(null);`
- [977](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L977): `const [saving, setSaving] = useState(false);`
- [1112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1112): `{!auth.loading && !canEdit && (`
- [1241](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1241): `{!auth.loading && !canEdit && (`
- [1283](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1283): `const [loaded, setLoaded] = useState<LightRagServerConfig | null>(null);`
- [1284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1284): `const [serverUrl, setServerUrl] = useState("");`
- [1285](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1285): `const [apiKey, setApiKey] = useState("");`
- [1286](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1286): `const [probe, setProbe] = useState<LightRagServerProbe | null>(null);`
- [1287](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1287): `const [probing, setProbing] = useState(false);`
- [1288](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1288): `const [saving, setSaving] = useState(false);`
- [1468](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1468): `const [data, setData] = useState<ModelOptionsByKind | null>(null);`
- [1469](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1469): `const [failed, setFailed] = useState(false);`
- [1470](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1470): `const [busyKind, setBusyKind] = useState<string | null>(null);`
- [1471](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1471): `const [testingKind, setTestingKind] = useState<string | null>(null);`
- [1472](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1472): `const [draftSelections, setDraftSelections] = useState<`
- [1475](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1475): `const [compatibility, setCompatibility] = useState<{`
- [1481](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1481): `if (kinds.length === 0) return;`
- [1526](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1526): `if (kinds.length === 0) return null;`
- [1723](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1723): `label: string;`
- [1765](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1765): `const [open, setOpen] = useState(defaultOpen);`
- [1766](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1766): `const [report, setReport] = useState<EnginePreflight | null>(null);`
- [1767](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1767): `const [checking, setChecking] = useState(false);`
- [1979](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/knowledge/components/engines/EngineDetail.tsx#L1979): `{engineKbs.length === 0 ? (`

### web/features/multi-user/components/BookPermissionEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L23): `const [books, setBooks] = useState<AdminBook[]>([]);`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L24): `const [permission, setPermission] = useState<BookPermission>(EMPTY);`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L25): `const [saved, setSaved] = useState("");`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L26): `const [loading, setLoading] = useState(true);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L27): `const [saving, setSaving] = useState(false);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L28): `const [error, setError] = useState("");`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L29): `const [savedNow, setSavedNow] = useState(false);`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L149): `{books.length === 0 ? (`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L159): `<span className="min-w-0 truncate" title={book.title}>`
- [181](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/BookPermissionEditor.tsx#L181): `{error ? (`

### web/features/multi-user/components/GrantEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L82): `label: string;`
- [169](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L169): `const [resources, setResources] = useState<MultiUserResources | null>(null);`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L170): `const [grant, setGrant] = useState<GrantPayload>(() => emptyGrant(userId));`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L171): `const [loading, setLoading] = useState(true);`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L172): `const [savedFingerprint, setSavedFingerprint] = useState("");`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L173): `const [saveState, setSaveState] = useState<SaveState>("idle");`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L174): `const [message, setMessage] = useState("");`
- [427](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L427): `if (loading && !resources) {`
- [563](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L563): `{(resources?.reading_materials ?? []).length === 0 ? (`
- [682](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GrantEditor.tsx#L682): `{(resources?.partners || []).length === 0 ? (`

### web/features/multi-user/components/GuardianRelationshipsEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L3): `import { useEffect, useMemo, useState } from "react";`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L43): `const [relationships, setRelationships] = useState<GuardianRelationship[]>(`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L46): `const [report, setReport] = useState<GuardianReport | null>(null);`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L47): `const [guardianId, setGuardianId] = useState("");`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L48): `const [permissions, setPermissions] = useState<string[]>([...PERMISSIONS]);`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L49): `const [newPassword, setNewPassword] = useState("");`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L50): `const [loading, setLoading] = useState(true);`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L51): `const [busy, setBusy] = useState(false);`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L52): `const [error, setError] = useState("");`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L53): `const [message, setMessage] = useState("");`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L54): `const [confirm, setConfirm] = useState<`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L99): `if (!guardianId || permissions.length === 0) return;`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L167): `{loading ? (`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L174): `{relationships.length === 0 ? (`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L218): `disabled={busy || candidates.length === 0}`
- [231](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L231): `disabled={busy || !guardianId || permissions.length === 0}`
- [305](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L305): `{error ? <p className="mt-3 text-xs text-red-600">{error}</p> : null}`
- [310](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L310): `<ConfirmDialog`
- [312](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/GuardianRelationshipsEditor.tsx#L312): `title={`

### web/features/multi-user/components/LearnerProfileEditor.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/LearnerProfileEditor.tsx#L3): `import { useEffect, useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/LearnerProfileEditor.tsx#L32): `const [profile, setProfile] = useState<LearnerProfile>({});`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/LearnerProfileEditor.tsx#L33): `const [loading, setLoading] = useState(true);`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/LearnerProfileEditor.tsx#L34): `const [saving, setSaving] = useState(false);`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/multi-user/components/LearnerProfileEditor.tsx#L35): `const [message, setMessage] = useState("");`

### web/features/notes/components/AddToNote.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/AddToNote.tsx#L4): `import { useState } from 'react'`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/AddToNote.tsx#L35): `const [pages, setPages] = useState<NoteSummary[] | null>(null)`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/AddToNote.tsx#L36): `const [target, setTarget] = useState('')`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/AddToNote.tsx#L37): `const [busy, setBusy] = useState(false)`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/AddToNote.tsx#L38): `const [error, setError] = useState('')`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/AddToNote.tsx#L39): `const [saved, setSaved] = useState(false)`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/AddToNote.tsx#L126): `{error && <p role="alert">{error}</p>}`

### web/features/notes/components/NoteCompanion.tsx

- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L19): `import { useCallback, useEffect, useMemo, useRef, useState } from 'react'`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L77): `{ label: 'Explain this', prompt: 'Explain this passage in plain words.', Icon: Lightbulb },`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L79): `label: 'Rewrite',`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L84): `label: 'Make shorter',`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L88): `{ label: 'Give an example', prompt: 'Give a concrete example of this.', Icon: MessageSquareText },`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L90): `label: 'Translate',`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L95): `label: 'Quiz me on this',`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L102): `label: 'Continue writing here',`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L106): `{ label: 'Explain this part', prompt: 'Explain this part of my notes.', Icon: Lightbulb },`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L108): `label: 'Check the facts',`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L112): `{ label: 'Summarize this page', prompt: 'Summarize this page.', Icon: AlignLeft },`
- [118](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L118): `label: 'Walk me through this',`
- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L123): `label: 'Quiz me on this',`
- [128](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L128): `label: 'Improve this block',`
- [133](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L133): `label: 'Check the facts',`
- [236](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L236): `const [error, setError] = useState('')`
- [237](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L237): `const [savedPage, setSavedPage] = useState('')`
- [238](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L238): `const [viewerOpen, setViewerOpen] = useState(false)`
- [346](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L346): `? { label: focusText || t('Empty line'), kind: blockKind(focus) }`
- [349](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L349): `const [make, setMake] = useState<string | null>(thread.regenerate?.kind ?? null)`
- [350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L350): `const [again, setAgain] = useState(Boolean(thread.regenerate))`
- [479](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L479): `{error && (`
- [480](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L480): `<p role="alert" className="dt-note-companion-error">`
- [540](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L540): `const [open, setOpen] = useState(false)`
- [541](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L541): `const [query, setQuery] = useState('')`
- [575](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L575): `role="dialog"`
- [650](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L650): `focus: { label: string; kind: string | null } | null`
- [664](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L664): `const [text, setText] = useState('')`
- [666](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L666): `const [menuOpen, setMenuOpen] = useState(false)`
- [668](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L668): `const [options, setOptions] = useState<LLMOption[]>([])`
- [669](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L669): `const [activeDefault, setActiveDefault] = useState<LLMSelection | null>(null)`
- [670](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L670): `const [optionsState, setOptionsState] = useState<'loading' | 'error' | 'ready'>('loading')`
- [686](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L686): `const [prefilled, setPrefilled] = useState<number | null>(null)`
- [788](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L788): `<div className="dt-popover dt-note-kind-menu is-up" role="menu">`
- [793](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteCompanion.tsx#L793): `role="menuitemradio"`

### web/features/notes/components/NoteEditor.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L8): `useState,`
- [129](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L129): `const [editing, setEditing] = useState(!block.props.formula)`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L180): `title={block.props.title}`
- [259](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L259): `const [edit, setEdit] = useState(false)`
- [391](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L391): `const [open, setOpen] = useState(false)`
- [741](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L741): `const [containerEl, setContainerEl] = useState<HTMLDivElement | null>(null)`
- [945](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L945): `current.type === 'paragraph' && (!current.content || current.content.length === 0)`
- [1255](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1255): `const [panel, setPanel] = useState<'link' | 'ai' | 'color' | null>(null)`
- [1256](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1256): `const [linkUrl, setLinkUrl] = useState('')`
- [1257](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1257): `const [linkError, setLinkError] = useState('')`
- [1327](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1327): `<div className="dt-note-toolbar-panel" role="menu">`
- [1339](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1339): `role="menuitem"`
- [1352](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1352): `role="menuitem"`
- [1365](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1365): `<div className="dt-note-toolbar-panel is-colors" role="menu">`
- [1378](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1378): `role="menuitemradio"`
- [1423](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1423): `{linkError && <p role="alert">{linkError}</p>}`
- [1472](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1472): `if (Array.isArray(content) && content.length === 0) {`
- [1585](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteEditor.tsx#L1585): `(trigger !== '、' || parent.textContent.length === 0)`

### web/features/notes/components/NoteFavoriteBlock.tsx

- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoriteBlock.tsx#L12): `import { useLayoutEffect, useRef, useState } from 'react'`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoriteBlock.tsx#L56): `const [showAll, setShowAll] = useState(false)`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoriteBlock.tsx#L57): `const [overflows, setOverflows] = useState(false)`

### web/features/notes/components/NoteFavoritesPicker.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L13): `import { useEffect, useMemo, useRef, useState } from 'react'`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L45): `const [collections, setCollections] = useState<NotebookSummary[]>([])`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L46): `const [items, setItems] = useState<Item[]>([])`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L47): `const [collection, setCollection] = useState(ALL)`
- [48](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L48): `const [kind, setKind] = useState('')`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L49): `const [query, setQuery] = useState('')`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L50): `const [picked, setPicked] = useState<string[]>([])`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L51): `const [preview, setPreview] = useState('')`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L52): `const [loading, setLoading] = useState(true)`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L53): `const [error, setError] = useState('')`
- [257](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L257): `{loading && (`
- [264](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L264): `{!loading && !visible.length && !error && <p className="dt-fav-empty">{empty}</p>}`
- [265](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L265): `{error && (`
- [266](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteFavoritesPicker.tsx#L266): `<p role="alert" className="dt-fav-empty is-error">`

### web/features/notes/components/NoteGeometry.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteGeometry.tsx#L4): `import { useEffect, useMemo, useRef, useState } from 'react'`
- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteGeometry.tsx#L10): `const [width, setWidth] = useState(0)`

### web/features/notes/components/NoteInlineReviews.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInlineReviews.tsx#L3): `import { useCallback, useEffect, useState, useSyncExternalStore } from 'react'`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInlineReviews.tsx#L46): `const [snapshot, setSnapshot] = useState(() => ({`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInlineReviews.tsx#L156): `<p role="alert" className="dt-note-review-error">`

### web/features/notes/components/NoteInsertMenu.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInsertMenu.tsx#L2): `import { useEffect, useRef, useState } from 'react'`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInsertMenu.tsx#L29): `const [hover, setHover] = useState<{ index: number; signature: string } | null>(null)`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInsertMenu.tsx#L30): `const [previewSide, setPreviewSide] = useState('inline')`
- [139](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteInsertMenu.tsx#L139): `<NoteBlockPreview kind={selected.preview} title={selected.previewTitle} />`

### web/features/notes/components/NoteLearningContent.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L3): `import { useEffect, useRef, useState, useSyncExternalStore } from 'react'`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L56): `const [visible, setVisible] = useState(false)`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L57): `const [error, setError] = useState('')`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L170): `{preview?.error && (`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L171): `<p role="alert" className="text-sm text-red-600">`
- [273](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L273): `{error && (`
- [274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L274): `<p role="alert" className="text-sm text-red-600">`
- [298](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L298): `const [open, setOpen] = useState(false)`
- [315](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L315): `<div className="dt-popover dt-note-kind-menu" role="menu">`
- [319](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteLearningContent.tsx#L319): `role="menuitemradio"`

### web/features/notes/components/NoteOutline.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteOutline.tsx#L10): `import { useEffect, useMemo, useState } from 'react'`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteOutline.tsx#L57): `const [current, setCurrent] = useState<string | null>(null)`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteOutline.tsx#L58): `const [peek, setPeek] = useState(false)`

### web/features/notes/components/NotePageHead.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L3): `import { useLayoutEffect, useRef, useState } from 'react'`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L68): `const [iconOpen, setIconOpen] = useState(false)`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L69): `const [coverOpen, setCoverOpen] = useState(false)`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L70): `const [customIcon, setCustomIcon] = useState('')`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L93): `role="menuitemradio"`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L108): `role="menuitem"`
- [128](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L128): `role="menuitemradio"`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageHead.tsx#L155): `<button role="menuitem" className="dt-menu-item is-quiet" onClick={() => pickIcon('')}>`

### web/features/notes/components/NotePageTree.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageTree.tsx#L3): `import { useState, type MouseEvent } from 'react'`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NotePageTree.tsx#L27): `const [collapsed, setCollapsed] = useState<Set<string>>(() => new Set())`

### web/features/notes/components/NoteReview.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L2): `import { useEffect, useState } from 'react'`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L19): `const [cards, setCards] = useState<Card[]>([])`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L20): `const [open, setOpen] = useState(false)`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L21): `const [revealed, setRevealed] = useState(false)`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L22): `const [error, setError] = useState('')`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L23): `const [busy, setBusy] = useState(false)`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L124): `{error && (`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteReview.tsx#L125): `<p role="alert" className="dt-notes-review-error">`

### web/features/notes/components/NoteRichBlocks.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L3): `import { useEffect, useState } from 'react'`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L106): `const [headings, setHeadings] = useState<NoteBlock[]>([])`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L170): `const [edit, setEdit] = useState(!block.props.url)`
- [171](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L171): `const [url, setUrl] = useState(block.props.url)`
- [172](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L172): `const [title, setTitle] = useState(block.props.title)`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L173): `const [description, setDescription] = useState(block.props.description)`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L174): `const [error, setError] = useState('')`
- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L214): `{error && <p role="alert">{error}</p>}`
- [244](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L244): `title={block.props.title || host}`
- [267](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L267): `const [editing, setEditing] = useState(!block.props.source)`
- [293](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteRichBlocks.tsx#L293): `title={t('HTML preview')}`

### web/features/notes/components/NoteSourcePicker.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L2): `import { useCallback, useState } from 'react'`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L28): `const [query, setQuery] = useState('')`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L29): `const [busy, setBusy] = useState(false)`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L30): `const [error, setError] = useState('')`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L89): `{loading ? (`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L114): `{error && (`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteSourcePicker.tsx#L115): `<p role="alert" className="text-sm text-red-600">`

### web/features/notes/components/NoteTaskBlock.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskBlock.tsx#L2): `import { useEffect, useState } from 'react'`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskBlock.tsx#L23): `const [card, setCard] = useState<TaskCard | null>(null)`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskBlock.tsx#L24): `const [error, setError] = useState('')`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskBlock.tsx#L25): `const [busy, setBusy] = useState(false)`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskBlock.tsx#L105): `{error && <p role="alert">{error}</p>}`

### web/features/notes/components/NoteTaskView.tsx

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L2): `import { useEffect, useState } from 'react'`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L25): `const [cards, setCards] = useState<TaskCard[]>([])`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L26): `const [query, setQuery] = useState('')`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L27): `const [title, setTitle] = useState('')`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L28): `const [busy, setBusy] = useState(false)`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L29): `const [error, setError] = useState('')`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L77): `<div role="tablist" aria-label={t('Task view')}>`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L87): `role="tab"`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTaskView.tsx#L198): `{error && <p role="alert">{error}</p>}`

### web/features/notes/components/NoteThreadMarkers.tsx

- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L15): `import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L66): `const [placements, setPlacements] = useState<Placement[]>([])`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L67): `const [hoverBlock, setHoverBlock] = useState<{ blockId: string; top: number } | null>(null)`
- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L200): `const [anchor, setAnchor] = useState<HTMLDivElement | null>(null)`
- [201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L201): `const [hover, setHover] = useState(false)`
- [283](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L283): `const [confirming, setConfirming] = useState<string | null>(null)`
- [284](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L284): `const [deleting, setDeleting] = useState<string | null>(null)`
- [294](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteThreadMarkers.tsx#L294): `role="dialog"`

### web/features/notes/components/NoteTopBar.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L3): `import { useState, type MouseEvent } from 'react'`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L87): `const [open, setOpenState] = useState(false)`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L88): `const [moving, setMoving] = useState(false)`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L89): `const [query, setQuery] = useState('')`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L168): `label: '${entry.icon ? '${entry.icon} ' : ''}${entry.title || t('Untitled')}',`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L173): `create={{ label: t('New page'), onSelect: onCreatePage }}`
- [174](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L174): `all={embedded ? undefined : { label: t('All pages'), href: '/co-writer' }}`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L208): `<div className="dt-popover dt-note-page-menu" role="menu">`
- [211](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L211): `<button role="menuitem" className="dt-menu-item is-quiet" onClick={() => setMoving(false)}>`
- [226](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L226): `role="menuitem"`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L239): `role="menuitem"`
- [259](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L259): `role="menuitem"`
- [271](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L271): `role="menuitem"`
- [281](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L281): `role="menuitem"`
- [293](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L293): `role="menuitem"`
- [304](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L304): `role="menuitem"`
- [316](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteTopBar.tsx#L316): `role="menuitem"`

### web/features/notes/components/NoteUpload.tsx

- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteUpload.tsx#L27): `role={block.props.error ? 'alert' : 'status'}`

### web/features/notes/components/NoteWorkspace.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L4): `import { useCallback, useEffect, useRef, useState, type ComponentType } from 'react'`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L59): `auth.statusAvailable && !auth.loading ? (auth.enabled ? auth.userId : 'local') : null`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L60): `const [mutating, setMutating] = useState(false)`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L61): `const [page, setPage] = useState<NotePage | null>(null)`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L62): `const [pages, setPages] = useState<NoteSummary[]>([])`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L63): `const [error, setError] = useState('')`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L64): `const [reviewErrors, setReviewErrors] = useState<Record<string, string>>({})`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L65): `const [status, setStatus] = useState<NoteSaveStatus>('Saved')`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L66): `const [tree, setTreeOpen] = useState(false)`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L67): `const [outlineOpen, setOutlineOpenState] = useState(true)`
- [72](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L72): `const [mainEl, setMainEl] = useState<HTMLElement | null>(null)`
- [75](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L75): `const [margin, setMargin] = useState<'wide' | 'rail' | 'none'>('none')`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L81): `const [sources, setSources] = useState(false)`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L82): `const [favorites, setFavorites] = useState(false)`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L83): `const [suggestions, setSuggestions] = useState<NoteSuggestion[]>([])`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L84): `const [backlinks, setBacklinks] = useState<NoteSummary[]>([])`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L85): `const [recovery, setRecovery] = useState<{ title: string; blocks: NoteBlock[] } | null>(null)`
- [302](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L302): `router.push(`
- [325](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L325): `const [focus, setFocus] = useState<{ key: string; blockId: string } | null>(null)`
- [513](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L513): `router.push('/co-writer/${doc.id}')`
- [524](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L524): `router.push('/co-writer/${id}')`
- [536](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L536): `router.push('/co-writer/${id}')`
- [565](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L565): `router.push('${url.pathname}${url.search}${url.hash}')`
- [591](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L591): `{error && (`
- [592](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L592): `<div role="alert" className="dt-note-banner is-error">`
- [626](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/NoteWorkspace.tsx#L626): `router.push('/co-writer/${doc.id}')`

### web/features/notes/components/notes.css

- [676](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/notes.css#L676): `.dt-note-data-view [role='tablist'] {`
- [681](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/notes.css#L681): `.dt-note-data-view [role='tab'] {`
- [885](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/notes.css#L885): `.dt-note-preview-example label:has(input:checked) {`
- [1957](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/notes.css#L1957): `.dt-note-upload p[role='alert'] {`

### web/features/notes/components/useNoteBlockDrag.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteBlockDrag.tsx#L3): `import { useEffect, useRef, useState, type PointerEvent } from 'react'`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteBlockDrag.tsx#L16): `const [drop, setDrop] = useState<Drop | null>(null)`

### web/features/notes/components/useNoteThreads.ts

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L11): `import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L94): `const [threads, setThreads] = useState<NoteThread[]>([])`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L95): `const [loaded, setLoaded] = useState(false)`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L96): `const [opened, setOpen] = useState<OpenThread | null>(null)`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L97): `const [prefill, setPrefill] = useState<{ id: number; text: string } | null>(null)`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L100): `const [seen, setSeen] = useState<Record<string, number>>({})`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L101): `const [seenFrom, setSeenFrom] = useState<string | null>(null)`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/components/useNoteThreads.ts#L110): `const [tick, setTick] = useState(0)`

### web/features/notes/model/generation-previews.ts

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/generation-previews.ts#L11): `error?: string`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/generation-previews.ts#L29): `current.error === preview.error &&`

### web/features/notes/model/learning-kinds.ts

- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L22): `label: string`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L32): `label: 'Diagram',`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L39): `label: 'Timeline',`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L46): `label: 'Concept map',`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L53): `label: 'Quiz me',`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L60): `label: 'Flash Cards',`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L67): `label: 'Generate image',`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L74): `label: 'Animation',`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L81): `label: 'Geometry',`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L88): `label: 'Podcast',`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L95): `label: 'Research',`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L102): `label: 'Linked task',`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L110): `const LEGACY: Record<string, { label: string; Icon: LucideIcon }> = {`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L111): `visualization: { label: 'Visualization', Icon: Shapes },`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L112): `media: { label: 'Media', Icon: ImageIcon },`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L113): `code: { label: 'Code', Icon: Sigma },`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/learning-kinds.ts#L122): `...(LEGACY[kind] ?? { label: kind, Icon: Shapes }),`

### web/features/notes/model/threads.ts

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/threads.ts#L10): `label: string`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/notes/model/threads.ts#L57): `label: title || thread.quote.trim() || untitled,`

### web/features/runtime-status/RuntimeHealthCard.tsx

- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/RuntimeHealthCard.tsx#L42): `if (snapshot.loading && !snapshot.data) {`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/RuntimeHealthCard.tsx#L44): `<Skeleton className="h-6 w-28" />`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/RuntimeHealthCard.tsx#L46): `<Skeleton className="h-36 w-full" />`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/RuntimeHealthCard.tsx#L100): `{snapshot.error ? (`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/RuntimeHealthCard.tsx#L101): `<InlineAlert tone={status ? "warning" : "danger"} className="mt-4">`
- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/RuntimeHealthCard.tsx#L145): `function Metric({ label, value }: { label: string; value: string }) {`
- [151](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/RuntimeHealthCard.tsx#L151): `title={value}`

### web/features/runtime-status/TurnCoordinationSettings.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/TurnCoordinationSettings.tsx#L3): `import { useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/TurnCoordinationSettings.tsx#L25): `const [redisUrl, setRedisUrl] = useState("");`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/TurnCoordinationSettings.tsx#L26): `const [savingSecret, setSavingSecret] = useState(false);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/TurnCoordinationSettings.tsx#L27): `const [secretError, setSecretError] = useState("");`
- [160](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/TurnCoordinationSettings.tsx#L160): `<InlineAlert`
- [162](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/runtime-status/TurnCoordinationSettings.tsx#L162): `title={t("Check runtime settings")}`

### web/features/settings/components/UsageActivity.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/components/UsageActivity.tsx#L4): `import { useMemo, useRef, useState } from 'react'`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/components/UsageActivity.tsx#L28): `const [selected, setSelected] = useState<DailyUsage | null>(null)`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/components/UsageActivity.tsx#L29): `const [focused, setFocused] = useState(0)`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/components/UsageActivity.tsx#L44): `label: new Date('${day.date}T12:00:00Z').toLocaleDateString(i18n.language, {`

### web/features/settings/navigation/SettingsAccessProvider.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/SettingsAccessProvider.tsx#L3): `import { createContext, useContext, useEffect, useMemo, useState } from "react";`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/SettingsAccessProvider.tsx#L20): `const [access, setAccess] = useState<SettingsAccess>(PENDING_SETTINGS_ACCESS);`

### web/features/settings/navigation/settings-nav.ts

- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L61): `label: Lang;`
- [74](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L74): `label: Lang;`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L121): `label: { en: "Voice", zh: "语音" },`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L132): `label: { en: "Multimodal generation", zh: "多模态生成" },`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L143): `label: { zh: "提供方", en: "Providers" },`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L154): `label: { zh: "语言模型", en: "Language models" },`
- [166](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L166): `label: { zh: "后台任务模型", en: "Task models" },`
- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L177): `label: { zh: "嵌入模型", en: "Embedding models" },`
- [189](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L189): `label: { zh: "搜索", en: "Search" },`
- [198](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L198): `label: { zh: "语音合成", en: "Text-to-Speech" },`
- [210](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L210): `label: { zh: "语音识别", en: "Speech-to-Text" },`
- [222](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L222): `label: { zh: "文生图", en: "Image Generation" },`
- [234](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L234): `label: { zh: "文生视频", en: "Video Generation" },`
- [249](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L249): `label: { zh: "视频学习", en: "Video Learning" },`
- [261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L261): `label: { zh: "工具", en: "Tools" },`
- [272](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L272): `label: { zh: "能力", en: "Capabilities" },`
- [283](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L283): `label: { zh: "起始建议", en: "Starting points" },`
- [294](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L294): `label: { zh: "附件", en: "Attachments" },`
- [309](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L309): `label: { zh: "Claude Code", en: "Claude Code" },`
- [322](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L322): `label: { zh: "Codex", en: "Codex" },`
- [334](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L334): `label: { zh: "Grok CLI", en: "Grok CLI" },`
- [347](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L347): `label: { zh: "Antigravity CLI", en: "Antigravity CLI" },`
- [359](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L359): `label: { zh: "Kimi CLI", en: "Kimi CLI" },`
- [371](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L371): `label: { zh: "opencode", en: "opencode" },`
- [383](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L383): `label: { zh: "MiMo Code", en: "MiMo Code" },`
- [395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L395): `label: { zh: "Hermes Agent", en: "Hermes Agent" },`
- [407](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L407): `label: { zh: "Hermes Agent（远程）", en: "Hermes Agent (remote)" },`
- [419](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L419): `label: { zh: "OpenClaw", en: "OpenClaw" },`
- [431](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L431): `label: { zh: "DeepSeek Harness", en: "DeepSeek Harness" },`
- [445](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L445): `label: { zh: "外观", en: "Appearance" },`
- [452](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L452): `label: { zh: "网络", en: "Network" },`
- [462](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L462): `label: { zh: "工作区", en: "Workspace" },`
- [472](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L472): `label: { zh: "模型", en: "Models" },`
- [483](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L483): `label: { zh: "知识库", en: "Knowledge Base" },`
- [490](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L490): `label: { zh: "聊天", en: "Chat" },`
- [501](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L501): `label: { zh: "伙伴和智能体", en: "Partners & Agents" },`
- [512](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L512): `label: { zh: "学习进度", en: "Learning progress" },`
- [520](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L520): `label: { zh: "学习档案", en: "Learner profile" },`
- [531](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L531): `label: { zh: "监护管理", en: "Guardian" },`
- [541](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L541): `label: { zh: "记忆", en: "Memory" },`
- [551](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-nav.ts#L551): `label: { zh: "关于", en: "About" },`

### web/features/settings/navigation/settings-pages.ts

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L13): `export const SETTINGS_PAGE_GROUPS: { label: Lang; keys: string[] }[] = [`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L14): `{ label: { en: 'Personal', zh: '个人' }, keys: ['general', 'workspace', 'data-migration', 'appearance', 'usage'] },`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L16): `label: { en: 'Models & services', zh: '模型与服务' },`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L20): `label: { en: 'Learning & conversation', zh: '学习与对话' },`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L24): `label: { en: 'Features & integrations', zh: '功能与集成' },`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L28): `label: { en: 'System', zh: '系统' },`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L31): `{ label: { en: 'Archived', zh: '已归档' }, keys: ['archive'] },`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L65): `label: { en: 'Learning progress', zh: '学习进度' },`
- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L73): `label: { en: 'Data migration', zh: '数据迁移' },`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L81): `label: { en: 'Usage statistics', zh: '用量统计' },`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L89): `label: { en: 'Archived chats', zh: '已归档的聊天' },`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L100): `label: { en: 'General', zh: '常规' },`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/navigation/settings-pages.ts#L111): `label: { en: 'Runtime status', zh: '运行状态' },`

### web/features/settings/sections/AboutSettingsSection.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L5): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L61): `const [status, setStatus] = useState<AppUpdateStatus | null>(null);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L62): `const [job, setJob] = useState<UpdateJob | null>(null);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L63): `const [loading, setLoading] = useState(true);`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L64): `const [checking, setChecking] = useState(false);`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L66): `const [liveChecks, setLiveChecks] = useState({ enabled: false });`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L68): `const [requesting, setRequesting] = useState(false);`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L69): `const [confirmOpen, setConfirmOpen] = useState(false);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L70): `const [error, setError] = useState("");`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L176): `const [edition, setEdition] = useState<ClientEdition>(() =>`
- [204](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L204): `title={t("About")}`
- [267](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L267): `{error && (`
- [274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L274): `<SettingSection title={t("Software")}>`
- [276](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L276): `title={t("Current version")}`
- [280](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L280): `title={t("Installation")}`
- [291](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L291): `title={t("Release channel")}`
- [304](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L304): `title={t("Updates")}`
- [310](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L310): `title={t("Check for updates")}`
- [329](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L329): `title={t("Latest stable release")}`
- [397](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L397): `{job.error && (`
- [406](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L406): `<SettingSection title={t("Project")}>`
- [408](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L408): `title={t("GitHub")}`
- [414](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L414): `title={t("Documentation")}`
- [421](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L421): `<ConfirmDialog`
- [423](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AboutSettingsSection.tsx#L423): `title={t("Update and restart DeepTutor?")}`

### web/features/settings/sections/AppearanceSettingsSection.tsx

- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L78): `title={t("Appearance")}`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L85): `title={t("Theme")}`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L98): `{ id: "system", label: t("System") },`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L99): `{ id: "snow", label: t("Default") },`
- [100](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L100): `{ id: "light", label: t("Cream") },`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L101): `{ id: "dark", label: t("Dark") },`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L102): `{ id: "glass", label: t("Glass") },`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L124): `title={t("Learning text")}`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L130): `title={t("Text size")}`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L154): `title={t("Line spacing")}`
- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L214): `title={t("Code blocks")}`
- [233](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L233): `title={t("Syntax theme")}`
- [261](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L261): `title={t("Show line numbers")}`
- [274](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AppearanceSettingsSection.tsx#L274): `title={t("Wrap long lines")}`

### web/features/settings/sections/ArchivedChatsSettingsSection.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L6): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L40): `const [sessions, setSessions] = useState<SessionSummary[]>([]);`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L41): `const [topics, setTopics] = useState<MasteryTopicLabel[]>([]);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L42): `const [collections, setCollections] = useState<ReadingCollectionLabel[]>([]);`
- [43](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L43): `const [loading, setLoading] = useState(true);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L44): `const [error, setError] = useState("");`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L45): `const [busy, setBusy] = useState<string | null>(null);`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L46): `const [query, setQuery] = useState("");`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L47): `const [kind, setKind] = useState<ArchiveKind | "all">("all");`
- [128](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L128): `<SettingsPageHeader title={t("Archived chats")} />`
- [207](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L207): `{error && (`
- [208](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L208): `<p role="alert" className="mb-4 text-sm text-red-600 dark:text-red-400">`
- [212](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L212): `{loading ? (`
- [234](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ArchivedChatsSettingsSection.tsx#L234): `navigateTask(sessionRoute(session), router.push);`

### web/features/settings/sections/AttachmentsSettingsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L51): `const [payload, setPayload] = useState<AttachmentSettingsPayload | null>(`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L54): `const [draft, setDraft] = useState<AttachmentSettings | null>(null);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L55): `const [loading, setLoading] = useState(true);`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L56): `const [error, setError] = useState<string | null>(null);`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L157): `title={t("Attachments")}`
- [163](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L163): `{loading && (`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L170): `{!loading && error && (`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L176): `{!loading && payload && draft && (`
- [179](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L179): `title={t("Size limits")}`
- [185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L185): `title={t("Max file size (MB)")}`
- [201](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L201): `title={t("Max total per message (MB)")}`
- [221](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L221): `title={t("Extraction budgets")}`
- [227](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L227): `title={t("Max characters per document")}`
- [246](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/AttachmentsSettingsSection.tsx#L246): `title={t("Max characters per message")}`

### web/features/settings/sections/CapabilitiesSettingsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L92): `const [settings, setSettings] = useState<CapabilitiesSettingsDTO | null>(`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L96): `useState<CapabilitiesSettingsDTO | null>(null);`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L97): `const [loadError, setLoadError] = useState<string | null>(null);`
- [299](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L299): `title={t("Capabilities")}`
- [304](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L304): `title={t("Chat")}`
- [350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L350): `title={t("Solve")}`
- [395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L395): `title={t("Question")}`
- [440](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L440): `title={t("Research")}`
- [488](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L488): `title={t("Math animator")}`
- [511](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L511): `title={t("Visualize")}`
- [537](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L537): `title={t("Co-writer")}`
- [565](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L565): `label: string;`
- [587](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L587): `title={label}`
- [610](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L610): `label: string;`
- [619](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/CapabilitiesSettingsSection.tsx#L619): `title={label}`

### web/features/settings/sections/DataMigrationSettingsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L3): `import { useEffect, useState } from 'react'`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L12): `label: string`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L32): `error?: string`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L79): `const [source, setSource] = useState(activeWorkspaceId)`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L80): `const [target, setTarget] = useState('')`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L81): `const [discovery, setDiscovery] = useState<Discovery | null>(null)`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L82): `const [selected, setSelected] = useState<string[]>([])`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L83): `const [preview, setPreview] = useState<Preview | null>(null)`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L84): `const [operations, setOperations] = useState<Operation[]>([])`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L85): `const [busy, setBusy] = useState(false)`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L86): `const [error, setError] = useState('')`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L87): `const [historical, setHistorical] = useState(false)`
- [357](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L357): `{error ? (`
- [358](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L358): `<p role="alert" className="text-sm text-[var(--destructive)]">`
- [373](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DataMigrationSettingsSection.tsx#L373): `{row.error ? <p className="text-[var(--destructive)]">{row.error}</p> : null}`

### web/features/settings/sections/DocumentParsingSettingsSection.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L5): `import { useCallback, useEffect, useRef, useState } from "react";`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L68): `const [liveData, setLiveData] = useState<DocumentParsingPayload | null>(null);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L70): `const [loading, setLoading] = useState(true);`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L71): `const [error, setError] = useState<string | null>(null);`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L121): `title={t("Document Parsing")}`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L127): `{loading && (`
- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L134): `{!loading && error && (`
- [135](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L135): `<div role="alert" className="mb-5 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-[13px] text-red-600 dark:text-red-300">`
- [140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L140): `{!loading && data && (`
- [291](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L291): `title={t("Text-only")}`
- [297](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L297): `title={t("Model status")}`
- [390](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L390): `const [testing, setTesting] = useState(false);`
- [391](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L391): `const [testResult, setTestResult] = useState<{`
- [445](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L445): `title={t("Docling backend")}`
- [451](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L451): `title={t("Mode")}`
- [490](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L490): `title={t("Remote server")}`
- [496](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L496): `title={t("Server base URL")}`
- [510](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L510): `title={t("API key")}`
- [533](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L533): `title={t("Test connection")}`
- [578](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L578): `title={t("Parsing options")}`
- [582](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L582): `title={t("Recognize tables")}`
- [592](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L592): `title={t("OCR scanned pages")}`
- [608](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L608): `title={t("Docling (local)")}`
- [615](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L615): `title={t("Docling (local)")}`
- [624](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L624): `title={t("Docling")}`
- [629](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L629): `title={t("Allow automatic model download")}`
- [642](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L642): `title={t("Recognize tables")}`
- [652](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L652): `title={t("OCR scanned pages")}`
- [684](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L684): `const [testing, setTesting] = useState(false);`
- [685](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L685): `const [testResult, setTestResult] = useState<{`
- [734](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L734): `title={t("Tika")}`
- [741](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L741): `title={t("Server base URL")}`
- [755](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L755): `title={t("Test connection")}`
- [819](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L819): `title={t("markitdown")}`
- [827](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L827): `title={t("markitdown")}`
- [833](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L833): `title={t("Describe images with the vision model")}`
- [874](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L874): `title={t("PyMuPDF4LLM")}`
- [882](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L882): `title={t("PyMuPDF4LLM")}`
- [888](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L888): `title={t("Extract images")}`
- [903](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L903): `title={t("Image format")}`
- [920](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L920): `title={t("Image resolution (DPI)")}`
- [968](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L968): `title={t("LiteParse")}`
- [976](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L976): `title={t("LiteParse")}`
- [982](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L982): `title={t("Image mode")}`
- [1000](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1000): `title={t("Extract links")}`
- [1011](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1011): `title={t("Extract images")}`
- [1022](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1022): `title={t("Max pages")}`
- [1064](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1064): `const [job, setJob] = useState<JobStatus | null>(null);`
- [1065](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1065): `const [starting, setStarting] = useState(false);`
- [1206](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1206): `label: string;`
- [1250](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1250): `const [checking, setChecking] = useState(false);`
- [1251](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1251): `const [checked, setChecked] = useState(false);`
- [1267](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1267): `title={title}`
- [1289](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1289): `title={t("Recheck availability")}`
- [1333](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/DocumentParsingSettingsSection.tsx#L1333): `title={t("Download models")}`

### web/features/settings/sections/GuardianSettingsSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L4): `import { useEffect, useState } from "react";`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L46): `const [relationships, setRelationships] = useState<GuardianRelationship[]>(`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L50): `useState<GuardianRelationship | null>(null);`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L51): `const [report, setReport] = useState<GuardianReport | null>(null);`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L52): `const [materials, setMaterials] = useState<GuardianMaterial[]>([]);`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L53): `const [liveMaterialIds, setLiveMaterialIds] = useState<string[]>([]);`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L55): `const [liveRestrictions, setLiveRestrictions] = useState<GuardianRestrictions | null>(`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L59): `const [extensions, setExtensions] = useState<GuardianExtension[]>([]);`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L60): `const [newPassword, setNewPassword] = useState("");`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L61): `const [loading, setLoading] = useState(true);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L62): `const [busy, setBusy] = useState<BusyAction>(null);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L63): `const [confirmAction, setConfirmAction] = useState<ConfirmAction>(null);`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L64): `const [message, setMessage] = useState<string | null>(null);`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L65): `const [error, setError] = useState<string | null>(null);`
- [184](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L184): `{error && (`
- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L195): `{loading ? (`
- [199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L199): `) : relationships.length === 0 ? (`
- [287](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L287): `{materials.length === 0 ? (`
- [439](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L439): `<ConfirmDialog`
- [441](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/GuardianSettingsSection.tsx#L441): `title={`

### web/features/settings/sections/ImageDescriptionModelSetting.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ImageDescriptionModelSetting.tsx#L3): `import { useEffect, useState } from 'react'`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ImageDescriptionModelSetting.tsx#L20): `const [models, setModels] = useState<LLMOption[]>([])`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ImageDescriptionModelSetting.tsx#L21): `const [failed, setFailed] = useState(false)`
- [77](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ImageDescriptionModelSetting.tsx#L77): `<p role="alert" className="mt-2 text-xs text-red-600">`

### web/features/settings/sections/LearnerProfileSettingsSection.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L5): `import { useEffect, useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L25): `const [live, setLive] = useState<LearnerProfile>({});`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/LearnerProfileSettingsSection.tsx#L27): `const [status, setStatus] = useState<"idle" | "loading" | "saved" | "error">(`

### web/features/settings/sections/MemorySettingsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L41): `const [error, setError] = useState<string | null>(null);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L42): `const [settings, setSettings] = useState<MemorySettingsDTO | null>(null);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L44): `useState<MemorySettingsDTO | null>(null);`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L112): `<p role="alert" className="text-sm text-red-600 dark:text-red-400">`
- [128](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L128): `title={t("Memory")}`
- [134](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L134): `title={t("Update mode")}`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L158): `title={t("Audit mode")}`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L180): `title={t("Dedup")}`
- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L200): `title={t("Merge footnotes")}`
- [223](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L223): `title={t("Chunking")}`
- [241](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L241): `{ value: "paragraph", label: t("Paragraph") },`
- [242](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L242): `{ value: "sentence", label: t("Sentence") },`
- [269](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L269): `title={t("References")}`
- [296](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L296): `label: string;`
- [318](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L318): `title={label}`
- [341](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L341): `label: string;`
- [350](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L350): `title={label}`
- [376](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L376): `label: string;`
- [379](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L379): `options: { value: string; label: string }[];`
- [386](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/MemorySettingsSection.tsx#L386): `title={label}`

### web/features/settings/sections/NetworkSettingsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L69): `label: string;`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L87): `title={value}`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L102): `const [payload, setPayload] = useState<NetworkSettingsPayload | null>(null);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L103): `const [draft, setDraft] = useState<NetworkSettings | null>(null);`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L104): `const [corsText, setCorsText] = useState("");`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L105): `const [loading, setLoading] = useState(true);`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L106): `const [error, setError] = useState<string | null>(null);`
- [210](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L210): `title={t("Network")}`
- [240](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L240): `{loading && (`
- [247](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L247): `{!loading && error && (`
- [253](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L253): `{!loading && payload && draft && (`
- [291](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L291): `title={t("Runtime ports")}`
- [297](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L297): `title={t("Backend port")}`
- [320](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L320): `title={t("Frontend port")}`
- [345](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L345): `title={t("Browser API base")}`
- [351](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L351): `title={t("Public API base")}`
- [373](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/NetworkSettingsSection.tsx#L373): `title={t("CORS origins")}`

### web/features/settings/sections/StartersSettingsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L3): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L31): `const [payload, setPayload] = useState<StarterSettingsPayload | null>(null);`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L32): `const [draft, setDraft] = useState<StarterSettings | null>(null);`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L33): `const [loading, setLoading] = useState(true);`
- [34](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L34): `const [error, setError] = useState<string | null>(null);`
- [132](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L132): `title={t("Conversation")}`
- [140](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L140): `{loading && (`
- [147](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L147): `{!loading && error && (`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L153): `{!loading && payload && draft && (`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L155): `title={t("Starting points")}`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L161): `title={t("Recent activities")}`
- [185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L185): `{!loading && payload && draft && (`
- [186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L186): `<SettingSection title={t("Composer")}>`
- [188](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L188): `title={t("Suggest my next message")}`
- [206](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/StartersSettingsSection.tsx#L206): `{!loading && payload && (`

### web/features/settings/sections/ToolsSettingsSection.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L5): `import { useEffect, useMemo, useState } from "react";`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L66): `label: string;`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L82): `const [tools, setTools] = useState<BuiltinTool[] | null>(null);`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L83): `const [error, setError] = useState<string | null>(null);`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L84): `const [expanded, setExpanded] = useState<Set<string>>(new Set());`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L85): `const [liveTools, setLiveTools] = useState({ enabled_tools: [] as string[] });`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L90): `const [query, setQuery] = useState("");`
- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L149): `label: zh ? "体验增强" : "Experience Enhancement",`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L159): `label: zh ? "内置工具" : "Built-in Tools",`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L170): `label: zh ? '${label} · 能力工具' : '${label} · Capability Tools',`
- [239](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L239): `title={t("Tools")}`
- [277](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L277): `{error && (`
- [285](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L285): `{!tools && !error && (`
- [292](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L292): `{filteredSections && query.trim() && filteredSections.length === 0 && (`
- [302](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L302): `if (list.length === 0) return null;`
- [546](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L546): `label: string;`
- [576](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/ToolsSettingsSection.tsx#L576): `label: string;`

### web/features/settings/sections/UsageSettingsSection.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L3): `import { useEffect, useState } from 'react'`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L18): `const [snapshot, setSnapshot] = useState<{`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L23): `const [revision, setRevision] = useState(0)`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L27): `const error = !loading && Boolean(snapshot?.error)`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L49): `router.push('/settings/usage?${query}', { scroll: false })`
- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L60): `title={t('Usage statistics')}`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L92): `<RefreshCw size={15} className={loading ? 'animate-spin' : ''} />`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L95): `{error && (`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L97): `role="alert"`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L102): `{snapshot?.error && <span className="mt-1 block break-words">{t(snapshot.error)}</span>}`
- [113](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/UsageSettingsSection.tsx#L113): `{loading && !visible && (`

### web/features/settings/sections/VideoLearningSettingsSection.tsx

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L5): `import { useEffect, useState } from "react";`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L26): `const [live, setLive] = useState(DEFAULTS);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L28): `const [loading, setLoading] = useState(true);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L29): `const [message, setMessage] = useState("");`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L63): `title={t("Video Learning")}`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/VideoLearningSettingsSection.tsx#L68): `{loading ? (`

### web/features/settings/sections/WorkspaceSettingsSection.tsx

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L4): `import { useCallback, useEffect, useState } from 'react'`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L25): `const [resourcesOpen, setResourcesOpen] = useState(false)`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L26): `const [instructionsOpen, setInstructionsOpen] = useState(false)`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L27): `const [instructions, setInstructions] = useState(row.instructions ?? '')`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L28): `const [resources, setResources] = useState(row.resources ?? inheritedWorkspaceResources())`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L29): `const [editing, setEditing] = useState(false)`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L30): `const [name, setName] = useState(row.display_name)`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L31): `const [moving, setMoving] = useState(false)`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L32): `const [destination, setDestination] = useState('')`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L93): `{row.error && <p role="alert" className="mt-2 text-xs text-[var(--destructive)]">{row.error}</p>}`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L102): `const [catalog, setCatalog] = useState<WorkspaceCatalog | null>(null)`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L103): `const [root, setRoot] = useState('')`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L104): `const [busy, setBusy] = useState(false)`
- [105](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L105): `const [creating, setCreating] = useState(false)`
- [106](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L106): `const [browsing, setBrowsing] = useState(false)`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L107): `const [resources, setResources] = useState(inheritedWorkspaceResources)`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L108): `const [instructions, setInstructions] = useState('')`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L109): `const [name, setName] = useState('')`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L110): `const [path, setPath] = useState('')`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L111): `const [error, setError] = useState('')`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L112): `const [notice, setNotice] = useState('')`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L136): `<SettingsPageHeader title={t('Workspaces')} description={t('Keep conversations, learning materials and progress together in one workspace.')} actions={`
- [139](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L139): `{error && <div role="alert" className="mb-4 rounded-lg border border-[var(--destructive)] p-3 text-sm text-[var(--destructive)]">{error}{!catalog && <button className="ml-3 underline" onClick={() => void refresh().catch(err => setError(String(err.message)))}>{t('Retry')}</button>}</div>}`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L141): `{!catalog ? (!error && <div aria-busy="true" className="h-44 animate-pulse rounded-xl bg-[var(--muted)]" />) : (`
- [143](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L143): `<SettingSection title={t('Custom workspaces')} description={t('Books, Mastery Path, Reading, Watching and conversations are isolated by workspace.')}>`
- [161](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L161): `<SettingSection title={t('Built-in workspaces')}>`
- [164](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/WorkspaceSettingsSection.tsx#L164): `<SettingSection title={t('Storage location')} description={t('Workspaces default to root / workspace ID. Changing root migrates folders that follow it; custom locations stay in place. Remote deployments use server folders.')}>`

### web/features/settings/sections/models/ConnectionsSettingsSection.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/ConnectionsSettingsSection.tsx#L13): `title={t("Providers")}`

### web/features/settings/sections/models/EmbeddingSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/EmbeddingSettingsSection.tsx#L10): `title={t("Embedding models")}`

### web/features/settings/sections/models/ImageSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/ImageSettingsSection.tsx#L10): `title={t("Multimodal generation")}`

### web/features/settings/sections/models/LlmSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/LlmSettingsSection.tsx#L10): `title={t("Language models")}`

### web/features/settings/sections/models/MultimodalSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/MultimodalSettingsSection.tsx#L10): `title={t("Multimodal generation")}`

### web/features/settings/sections/models/SearchSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/SearchSettingsSection.tsx#L10): `title={t("Search")}`

### web/features/settings/sections/models/SttSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/SttSettingsSection.tsx#L10): `title={t("settings.serviceConfig.voiceServices")}`

### web/features/settings/sections/models/TaskModelsSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/TaskModelsSettingsSection.tsx#L10): `title={t("Task models")}`

### web/features/settings/sections/models/TtsSettingsSection.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/TtsSettingsSection.tsx#L11): `title={t("settings.serviceConfig.voiceServices")}`

### web/features/settings/sections/models/VideoSettingsSection.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/VideoSettingsSection.tsx#L10): `title={t("Multimodal generation")}`

### web/features/settings/sections/models/VoicePlaybackPrefs.tsx

- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/VoicePlaybackPrefs.tsx#L15): `label: string;`

### web/features/settings/sections/models/VoiceSettingsSection.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/sections/models/VoiceSettingsSection.tsx#L11): `title={t("settings.serviceConfig.voiceServices")}`

### web/features/settings/store/SettingsStore.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L10): `useState,`
- [168](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L168): `llm: { status: string; model?: string; error?: string };`
- [169](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L169): `embeddings: { status: string; model?: string; error?: string };`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L170): `search: { status: string; provider?: string; error?: string };`
- [656](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L656): `const [status, setStatus] = useState<SystemStatus | null>(null);`
- [657](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L657): `const [theme, setTheme] = useState<UiSettings["theme"]>("system");`
- [674](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L674): `const [learningDisplay, setLearningDisplay] = useState(`
- [681](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L681): `const [language, setLanguage] = useState<UiSettings["language"]>("en");`
- [683](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L683): `useState<UiSettings["response_language"]>("en");`
- [684](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L684): `const [catalog, setCatalog] = useState<Catalog>(defaultCatalog());`
- [685](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L685): `const [draft, setDraft] = useState<Catalog>(defaultCatalog());`
- [686](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L686): `const [catalogEditable, setCatalogEditable] = useState<boolean | null>(null);`
- [687](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L687): `const [providers, setProviders] = useState<`
- [699](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L699): `const [connectionTargets, setConnectionTargets] = useState<`
- [702](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L702): `const [taskKinds, setTaskKinds] = useState<TaskKindInfo[]>([]);`
- [703](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L703): `const [storedDraft, setStoredDraft] = useState<StoredDraft | null>(null);`
- [705](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L705): `const [savedSignature, setSavedSignature] = useState<string | null>(null);`
- [706](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L706): `const [draftRevision, setDraftRevision] = useState(0);`
- [707](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L707): `const [toast, setToast] = useState("");`
- [708](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L708): `const [saving, setSaving] = useState(false);`
- [709](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L709): `const [applying, setApplying] = useState(false);`
- [710](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L710): `const [focusModel, setFocusModel] = useState<IncompleteModel | null>(null);`
- [715](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L715): `const [logs, setLogs] = useState<string>("");`
- [716](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L716): `const [modelTests, setModelTests] = useState<Record<string, ModelTestState>>(`
- [720](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L720): `const [testRunning, setTestRunning] = useState<ServiceName | null>(null);`
- [721](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L721): `const [diagnosticsResults, setDiagnosticsResults] = useState<`
- [725](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L725): `useState<LlmContextWindowDetection | null>(null);`
- [727](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L727): `useState<EmbeddingCapabilities | null>(null);`
- [728](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L728): `const [tourStepIndex, setTourStepIndex] = useState(-1);`
- [729](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L729): `const [activeSection, setActiveSection] = useState<string | null>(null);`
- [742](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L742): `const [pendingSignature, setPendingSignature] = useState("{}");`
- [796](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L796): `const [settingsError, setSettingsError] = useState<string | null>(null);`
- [1407](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L1407): `activate: draft.services[request.service].profiles.length === 0,`
- [1618](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L1618): `if (Object.keys(capabilities).length === 0) delete model.capabilities;`
- [1947](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L1947): `router.push(`
- [2364](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L2364): `if (TOUR_STEPS.length === 0) return;`
- [2366](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L2366): `// No router.push here — the route-sync effect below handles it,`
- [2370](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L2370): `// Pure state updaters — DO NOT call router.push inside these. React`
- [2395](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/SettingsStore.tsx#L2395): `router.push(step.route);`

### web/features/settings/store/response-language-options.ts

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L5): `label: string;`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L13): `{ value: "en", label: "English" },`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L14): `{ value: "zh", label: "简体中文" },`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L15): `{ value: "zh-tw", label: "繁體中文" },`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L16): `{ value: "ja", label: "日本語" },`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L17): `{ value: "ko", label: "한국어" },`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L18): `{ value: "es", label: "Español" },`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L19): `{ value: "fr", label: "Français" },`
- [20](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L20): `{ value: "de", label: "Deutsch" },`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L21): `{ value: "ru", label: "Русский" },`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L22): `{ value: "pt", label: "Português" },`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L23): `{ value: "it", label: "Italiano" },`
- [24](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L24): `{ value: "ar", label: "العربية" },`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L25): `{ value: "pl", label: "Polski" },`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L26): `{ value: "uk", label: "Українська" },`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L27): `{ value: "ms", label: "Bahasa Melayu" },`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L28): `{ value: "vi", label: "Tiếng Việt" },`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/settings/store/response-language-options.ts#L29): `{ value: "tr", label: "Türkçe" },`

### web/features/tasks/components/KanbanBoard.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L8): `import { useRef, useState } from 'react'`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L49): `const [title, setTitle] = useState('')`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L50): `const [editing, setEditing] = useState<string | null>(null)`
- [51](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L51): `const [draftTitle, setDraftTitle] = useState('')`
- [52](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L52): `const [draftNote, setDraftNote] = useState('')`
- [53](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L53): `const [dueDate, setDueDate] = useState('')`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L54): `const [dateFilter, setDateFilter] = useState('all')`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L55): `const [busy, setBusy] = useState(false)`
- [56](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L56): `const [error, setError] = useState('')`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L57): `const [dragged, setDragged] = useState<string | null>(null)`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L58): `const [dropTarget, setDropTarget] = useState<TaskStatus | null>(null)`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L61): `const [showArchived, setShowArchived] = useState(false)`
- [104](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L104): `title={t('Task Board')}`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L112): `error={error ? t(error) : undefined}`
- [181](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L181): `{!board && !error && !loadError && (`
- [187](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/tasks/components/KanbanBoard.tsx#L187): `<p role="alert" className="mb-5 rounded-xl bg-secondary p-3 text-sm text-destructive">`

### web/features/ui-layout/classic/ClassicLearningDashboard.tsx

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L8): `import { useEffect, useState } from 'react'`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L38): `const [sources, setSources] = useState<LearningSources>({`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L44): `const [failed, setFailed] = useState<LearningKind[]>([])`
- [45](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L45): `const [loading, setLoading] = useState(true)`
- [46](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L46): `const [reload, setReload] = useState(0)`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L94): `title={t('Personalized Learning')}`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L95): `subtitle={t('One tutor, your own way to learn.')}`
- [110](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L110): `{loading ? (`
- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L124): `title={topic.name || topic.metadata.goal}`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L126): `subtitle={t('{{count}} reviews due', {`
- [146](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L146): `title={book.title}`
- [148](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L148): `subtitle={`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L173): `title={item.title}`
- [176](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L176): `subtitle={t(surface.title)}`
- [184](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L184): `{!recent.length && failed.length === 0 && (`
- [186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicLearningDashboard.tsx#L186): `title={t('Your next learning journey starts here')}`

### web/features/ui-layout/classic/ClassicSidebarShell.tsx

- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicSidebarShell.tsx#L16): `useState,`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicSidebarShell.tsx#L136): `const [sessionOrder, setSessionOrder] = useState<string[]>([]);`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/classic/ClassicSidebarShell.tsx#L170): `navigateTask("/chat", router.push);`

### web/features/ui-layout/modern/modern.css

- [78](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L78): `--dt-nav-label: 12px;`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L82): `.dt-category-bar [role="tablist"] { display: flex; flex: 1; align-items: center; min-width: 0; gap: 1px; }`
- [85](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L85): `.dt-category-bar [role="tab"] { position: relative; display: flex; align-items: center; justify-content: center; flex: 1; min-width: 34px; height: 34px; gap: 6px; padding: 0 clamp(5px, (100cqi - 180px) / 10, 10px); color: var(--muted-foreground); border-radius: var(--dt-nav-radius); transition: color 140ms, background-color 140ms; }`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L86): `.dt-category-bar [role="tab"] > svg, .dt-category-bar [role="tab"] > span:not(.dt-category-pill) { position: relative; z-index: 1; flex-shrink: 0; }`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L87): `.dt-category-bar [role="tab"] > span:not(.dt-category-pill) { display: none; font-size: 13.5px; font-weight: 500; white-space: nowrap; }`
- [88](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L88): `.dt-category-bar [role="tab"].is-active { flex: 1.9; color: var(--foreground); }`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L89): `.dt-category-bar [role="tab"].is-active > span:not(.dt-category-pill) { display: inline; }`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L92): `.dt-category-bar:not(.is-collapsed) :has(> [role="tab"].is-active) { min-width: 0; }`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L93): `.dt-category-bar [role="tab"].is-active > span:not(.dt-category-pill) { flex-shrink: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; }`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L103): `.dt-category-bar [role="tab"].is-active .dt-shelf-fill { fill: color-mix(in srgb, currentColor 16%, transparent); }`
- [108](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L108): `.dt-account-tabs [role="tab"] { transition: padding 240ms var(--dt-ease), margin 240ms var(--dt-ease), opacity 200ms, color 140ms, background-color 140ms; }`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L109): `.dt-account-tabs [role="tab"] > svg { transition: transform 240ms var(--dt-ease); }`
- [112](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L112): `.dt-account-tabs.is-tucked [role="tab"] { min-width: 0; padding: 0 6px; }`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L114): `.dt-account-tabs.is-tucked > :first-child [role="tab"] > svg { filter: drop-shadow(1.5px 0 0 var(--secondary)) drop-shadow(1.5px 1px 0 var(--secondary)); }`
- [115](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L115): `.dt-account-tabs.is-tucked > :last-child [role="tab"] { margin-left: -23px; padding-left: 0; opacity: .5; }`
- [116](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L116): `.dt-account-tabs.is-tucked > :last-child [role="tab"] > svg { transform: translateX(10px) scale(.86); }`
- [117](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L117): `.dt-account-tabs.is-tucked:hover [role="tab"] { opacity: 1; }`
- [120](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L120): `@media (prefers-reduced-motion: reduce) { .dt-account-tabs [role="tab"], .dt-account-tabs [role="tab"] > svg { transition: none; } }`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L121): `.dt-category-bar [role="tab"]:not(.is-active):hover, .dt-nav-icon:hover { background: var(--accent); color: var(--foreground); }`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L125): `.dt-category-bar.is-collapsed [role="tablist"] { flex-direction: column; gap: 5px; }`
- [126](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L126): `.dt-category-bar.is-collapsed [role="tab"] { width: 36px; height: 36px; flex: none; }`
- [127](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L127): `.dt-category-bar.is-collapsed [role="tab"] > span:not(.dt-category-pill) { display: none; }`
- [186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L186): `@container (max-width: 240px) { .dt-category-bar [role="tab"] { padding: 0 5px; gap: 4px; } .dt-category-bar [role="tab"] > span:not(.dt-category-pill) { font-size: 12px; } }`
- [706](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L706): `.dt-page-bar .dt-page-bar-actions :is(a, button, summary):not(.absolute *, .dt-popover *, [role="menu"] *, [role="tablist"] *, [role="dialog"] *, .dt-cal-toolbar *) {`
- [714](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L714): `.dt-page-bar .dt-page-bar-actions :is(a, button, summary):not(.absolute *, .dt-popover *, [role="menu"] *, [role="tablist"] *, [role="dialog"] *, .dt-cal-toolbar *):is(:hover, [aria-expanded="true"], [aria-pressed="true"]) {`
- [717](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L717): `.dt-page-bar .dt-page-bar-actions :is(a, button):not(.absolute *, .dt-popover *, [role="menu"] *, [role="tablist"] *, [role="dialog"] *, .dt-cal-toolbar *):is([class*="bg-[var(--primary)]"], [class~="bg-primary"]) {`
- [720](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L720): `.dt-page-bar .dt-page-bar-actions :is(a, button):not(.absolute *, .dt-popover *, [role="menu"] *, [role="tablist"] *, [role="dialog"] *, .dt-cal-toolbar *):is([class*="bg-[var(--primary)]"], [class~="bg-primary"]):hover {`
- [723](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/modern/modern.css#L723): `.dt-page-bar .dt-page-bar-actions :is(a, button, summary):not(.absolute *, .dt-popover *, [role="menu"] *, [role="tablist"] *, [role="dialog"] *, .dt-cal-toolbar *) > svg { width: 15px; height: 15px; flex-shrink: 0; }`

### web/features/ui-layout/tokens.ts

- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/features/ui-layout/tokens.ts#L25): `export function useCapabilityLabel(): (capability: { value: string; label: string }) => string {`

### web/hooks/use-card-submission.ts

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-card-submission.ts#L2): `import { useCallback, useState } from "react";`
- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-card-submission.ts#L26): `const [sending, setSending] = useState(false);`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-card-submission.ts#L27): `const [failed, setFailed] = useState(false);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-card-submission.ts#L28): `const [failureMessage, setFailureMessage] = useState<string | null>(null);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-card-submission.ts#L29): `const [submittedAfterRejection, setSubmittedAfterRejection] = useState<string>();`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-card-submission.ts#L30): `const [submittedAfterAcknowledgement, setSubmittedAfterAcknowledgement] = useState<string>();`

### web/hooks/use-linger-expand.ts

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-linger-expand.ts#L7): `useState,`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-linger-expand.ts#L27): `const [hovered, setHovered] = useState(false);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-linger-expand.ts#L28): `const [keyboardFocused, setKeyboardFocused] = useState(false);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/use-linger-expand.ts#L29): `const [lingering, setLingering] = useState(false);`

### web/hooks/useAuthStatus.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useAuthStatus.ts#L3): `import { useEffect, useState } from "react";`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useAuthStatus.ts#L79): `const [state, setState] = useState<AuthStatusState>(INITIAL);`

### web/hooks/useChatWorkspaces.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useChatWorkspaces.ts#L3): `import { useEffect, useState } from "react";`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useChatWorkspaces.ts#L22): `const [workspaces, setWorkspaces] = useState<ChatWorkspaceRegistration[]>([]);`
- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useChatWorkspaces.ts#L23): `const [error, setError] = useState("");`

### web/hooks/useCollapsiblePanel.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useCollapsiblePanel.ts#L3): `import { useCallback, useEffect, useState } from "react";`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useCollapsiblePanel.ts#L16): `const [collapsed, setCollapsedState] = useState(defaultCollapsed);`

### web/hooks/useComposerResources.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useComposerResources.ts#L3): `import { useEffect, useState } from "react";`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useComposerResources.ts#L35): `const [catalog, setCatalog] = useState<ComposerResourceCatalog>(EMPTY);`

### web/hooks/useConnectedAgentKinds.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useConnectedAgentKinds.ts#L3): `import { useEffect, useState } from "react";`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useConnectedAgentKinds.ts#L35): `const [map, setMap] = useState<Record<string, string>>(() => cache ?? {});`

### web/hooks/useConsultationReference.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useConsultationReference.ts#L3): `import { useEffect, useState } from "react";`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useConsultationReference.ts#L15): `const [resolved, setResolved] = useState({ key: "", name: "" });`

### web/hooks/useDragSort.ts

- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useDragSort.ts#L22): `import { useCallback, useEffect, useRef, useState } from "react";`
- [83](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useDragSort.ts#L83): `const [view, setView] = useState<DragView | null>(null);`

### web/hooks/useEmbeddingModels.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useEmbeddingModels.ts#L3): `import { useEffect, useState } from "react";`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useEmbeddingModels.ts#L14): `const [options, setOptions] = useState<ModelOption[]>([]);`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useEmbeddingModels.ts#L15): `const [selection, setSelection] = useState<EmbeddingModelSelection | null>(`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useEmbeddingModels.ts#L18): `const [loading, setLoading] = useState(enabled);`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useEmbeddingModels.ts#L19): `const [error, setError] = useState<string | null>(null);`

### web/hooks/useImaConnection.ts

- [1](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L1): `import { useCallback, useEffect, useRef, useState } from "react";`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L63): `const [accountConfigured, setAccountConfigured] = useState(false);`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L64): `const [useOwnCredentials, setUseOwnCredentials] = useState(false);`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L65): `const [clientId, setClientId] = useState("");`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L66): `const [apiKey, setApiKey] = useState("");`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L67): `const [mode, setMode] = useState<ImaConnectionMode>("automatic");`
- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L68): `const [manualKnowledgeBaseId, setManualKnowledgeBaseId] = useState("");`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L69): `const [lookup, setLookup] = useState(emptyImaLookupState);`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useImaConnection.ts#L70): `const [manualProbe, setManualProbe] = useState<ImaProbe | null>(null);`

### web/hooks/useKnowledgeBases.ts

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L6): `import { useCallback, useEffect, useMemo, useRef, useState } from "react";`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L61): `const [kbs, setKbs] = useState<KnowledgeBase[]>([]);`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L62): `const [providers, setProviders] = useState<RagProviderSummary[]>([]);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L63): `const [uploadPolicy, setUploadPolicy] = useState<KnowledgeUploadPolicy>(`
- [66](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L66): `const [loading, setLoading] = useState(true);`
- [67](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L67): `const [error, setError] = useState<string | null>(null);`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L86): `label: final.label,`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L87): `status: final.error ? "error" : "completed",`
- [212](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L212): `label: 'Create ${params.name}',`
- [247](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L247): `label: 'Upload to ${kbName}',`
- [297](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L297): `label: 'Re-index ${kbName}',`
- [318](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L318): `label: 'Retry ${kbName}',`
- [388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeBases.ts#L388): `label: "Sync linked folder",`

### web/hooks/useKnowledgeHistory.ts

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeHistory.ts#L5): `import { useCallback, useEffect, useState } from "react";`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeHistory.ts#L12): `label: string;`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeHistory.ts#L17): `error?: string | null;`
- [70](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeHistory.ts#L70): `const [store, setStore] = useState<HistoryStore>({ byKb: {} });`

### web/hooks/useKnowledgeProgress.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeProgress.ts#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeProgress.ts#L17): `label: string;`
- [84](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeProgress.ts#L84): `const [progressByKb, setProgressByKb] = useState<`
- [87](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeProgress.ts#L87): `const [tasksByKb, setTasksByKb] = useState<Record<string, TaskState>>({});`
- [224](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeProgress.ts#L224): `status: finalState.error ? "error" : "completed",`
- [278](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeProgress.ts#L278): `label: string,`
- [452](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useKnowledgeProgress.ts#L452): `label: string;`

### web/hooks/useLLMOptions.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useLLMOptions.ts#L3): `import { useCallback, useEffect, useReducer, useRef, useState } from "react";`
- [25](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useLLMOptions.ts#L25): `const [loadOptions] = useState(() => createSingleFlight(loader));`

### web/hooks/useLearningIndex.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useLearningIndex.ts#L3): `import { useCallback, useEffect, useState } from 'react'`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useLearningIndex.ts#L15): `const [sources, setSources] = useState<LearningSources>(`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useLearningIndex.ts#L18): `const [failed, setFailed] = useState<LearningKind[]>(`
- [21](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useLearningIndex.ts#L21): `const [loading, setLoading] = useState(() => !readClientCache<LearningIndex>(CACHE_KEY))`
- [22](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useLearningIndex.ts#L22): `const [revision, setRevision] = useState(0)`

### web/hooks/useMasteryPathActivity.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryPathActivity.ts#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryPathActivity.ts#L65): `if (batch.length === 0 && headRevision === undefined) return previous;`
- [141](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryPathActivity.ts#L141): `const [feed, setFeed] = useState<ActivityFeed>(EMPTY_FEED);`
- [142](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryPathActivity.ts#L142): `const [socketStatus, setSocketStatus] = useState<SocketStatus>({`

### web/hooks/useMasteryStudySession.ts

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryStudySession.ts#L6): `import { useEffect, useMemo, useRef, useState } from "react";`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryStudySession.ts#L58): `const [topic, setTopic] = useState<MasteryTopic | null>(null);`
- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryStudySession.ts#L59): `const [topicError, setTopicError] = useState<string | null>(null);`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryStudySession.ts#L61): `const [sessionResolution, setSessionResolution] = useState<{`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryStudySession.ts#L65): `const [draftBinding, setDraftBinding] = useState<{`
- [250](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMasteryStudySession.ts#L250): `router.replace(`

### web/hooks/useMcpServers.ts

- [4](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L4): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L33): `const [servers, setServers] = useState<Record<`
- [37](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L37): `const [statusRows, setStatusRows] = useState<McpStatusRow[]>([]);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L39): `const [userView, setUserView] = useState<McpUserView | null>(null);`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L40): `const [loadError, setLoadError] = useState<string | null>(null);`
- [41](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L41): `const [saveError, setSaveError] = useState<string | null>(null);`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L42): `const [saving, setSaving] = useState(false);`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L44): `const [expanded, setExpanded] = useState<Set<string>>(new Set());`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMcpServers.ts#L47): `const [editingKey, setEditingKey] = useState<string | null>(null);`

### web/hooks/useMeasuredHeight.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMeasuredHeight.ts#L3): `import { useEffect, useRef, useState } from "react";`
- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useMeasuredHeight.ts#L7): `const [height, setHeight] = useState(0);`

### web/hooks/useModalDialog.ts

- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useModalDialog.ts#L61): `if (focusable.length === 0) {`

### web/hooks/useModules.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useModules.ts#L3): `import { useEffect, useState, useCallback } from 'react'`
- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useModules.ts#L19): `return owners.length === 0 || owners.every(module => module.installed && module.enabled)`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useModules.ts#L38): `const [modules, setModules] = useState<ModuleStatus[] | null>(null)`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useModules.ts#L39): `const [error, setError] = useState(false)`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useModules.ts#L40): `const [revision, setRevision] = useState(0)`

### web/hooks/usePartnerNavigation.ts

- [2](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/usePartnerNavigation.ts#L2): `import { useCallback, useEffect, useState } from 'react'`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/usePartnerNavigation.ts#L29): `const [data, setData] = useState<PartnerNavigationData>(`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/usePartnerNavigation.ts#L38): `const [loading, setLoading] = useState(() => !readClientCache<PartnerNavigationData>(CACHE_KEY))`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/usePartnerNavigation.ts#L39): `const [error, setError] = useState(false)`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/usePartnerNavigation.ts#L40): `const [revision, setRevision] = useState(0)`

### web/hooks/usePickerOpen.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/usePickerOpen.ts#L3): `import { useEffect, useState } from "react";`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/usePickerOpen.ts#L17): `const [open, setOpen] = useState(false);`

### web/hooks/useSessionOrganization.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSessionOrganization.ts#L3): `import { useCallback, useEffect, useState } from "react";`
- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSessionOrganization.ts#L31): `const [state, setState] = useState<{`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSessionOrganization.ts#L35): `const [revision, setRevision] = useState(0);`

### web/hooks/useSessionThreads.ts

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSessionThreads.ts#L9): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSessionThreads.ts#L32): `const [state, setState] = useState<{`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSessionThreads.ts#L36): `const [revision, setRevision] = useState(0);`

### web/hooks/useSetupSync.ts

- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSetupSync.ts#L69): `if (fresh.length === 0) return;`

### web/hooks/useSidebarResize.ts

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSidebarResize.ts#L7): `useState,`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSidebarResize.ts#L27): `const [preferredWidth, setPreferredWidth] = useState(defaultWidth);`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSidebarResize.ts#L28): `const [max, setMax] = useState(MAX_WIDTH);`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSidebarResize.ts#L29): `const [resizing, setResizing] = useState(false);`

### web/hooks/useSmoothStreamText.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSmoothStreamText.ts#L3): `import { useEffect, useRef, useState } from "react";`
- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useSmoothStreamText.ts#L121): `const [shown, setShown] = useState<string>(content);`

### web/hooks/useTopicSourceLibrary.ts

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L6): `import { useCallback, useEffect, useMemo, useState } from 'react'`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L27): `label: string`
- [98](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L98): `const [library, setLibrary] = useState<SourceLibrary>(EMPTY_LIBRARY)`
- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L99): `const [loading, setLoading] = useState(true)`
- [130](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L130): `label: unknown,`
- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L136): `label: String(label || tr('Untitled', 'Untitled')),`
- [170](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L170): `label: row.name,`
- [180](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L180): `label: row.name,`
- [199](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L199): `const [childLists, setChildLists] = useState<Record<string, SourceChildren>>({})`
- [277](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L277): `label: entry.name,`
- [297](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L297): `label: entry.question.slice(0, 80) || tr('未命名题目', 'Untitled question'),`
- [313](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L313): `label: session.title || tr('未命名对话', 'Untitled conversation'),`
- [326](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L326): `label: session.title || tr('未命名讨论', 'Untitled discussion'),`
- [385](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L385): `label: candidate.label,`
- [407](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L407): `label: candidate.label,`
- [427](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L427): `label: candidate.label,`
- [448](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L448): `label: candidate.label,`
- [456](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L456): `label: candidate.label,`
- [466](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useTopicSourceLibrary.ts#L466): `label: candidate.label,`

### web/hooks/useVoiceAutoplay.ts

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceAutoplay.ts#L5): `import { useCallback, useEffect, useState } from "react";`
- [79](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceAutoplay.ts#L79): `const [value, setVal] = useState<boolean>(cachedGlobal ?? false);`
- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceAutoplay.ts#L80): `const [loading, setLoading] = useState<boolean>(cachedGlobal === null);`
- [119](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceAutoplay.ts#L119): `const [globalDefault, setGlobalDefault] = useState<boolean>(`
- [122](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceAutoplay.ts#L122): `const [stateScopeKey, setStateScopeKey] = useState<string | undefined>(`
- [125](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceAutoplay.ts#L125): `const [sessionOverride, setSessionOverride] = useState<boolean | null>(() =>`

### web/hooks/useVoiceMathSpeak.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceMathSpeak.ts#L3): `import { useCallback, useEffect, useState } from "react";`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceMathSpeak.ts#L38): `const [value, setVal] = useState<boolean>(cached ?? true);`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceMathSpeak.ts#L39): `const [loading, setLoading] = useState<boolean>(cached === null);`

### web/hooks/useVoiceRecorder.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceRecorder.ts#L3): `import { useCallback, useEffect, useRef, useState } from "react";`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceRecorder.ts#L16): `const [state, setState] = useState<RecorderState>("idle");`
- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useVoiceRecorder.ts#L17): `const [error, setError] = useState<string | null>(null);`

### web/hooks/useWorkspaceBinding.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useWorkspaceBinding.ts#L3): `import { useCallback, useLayoutEffect, useRef, useState } from 'react'`
- [15](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useWorkspaceBinding.ts#L15): `const [failure, setFailure] = useState<{ key: string; message: string } | null>(null)`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useWorkspaceBinding.ts#L16): `const [pendingKey, setPendingKey] = useState<string | null>(null)`

### web/hooks/useWorkspaceChatActions.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useWorkspaceChatActions.ts#L3): `import { useCallback, useEffect, useMemo, useState } from "react";`
- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/hooks/useWorkspaceChatActions.ts#L36): `const [enabledOptionalTools, setEnabledOptionalTools] = useState<`

### web/lib/admin-api.ts

- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/admin-api.ts#L89): `error?: string | null;`

### web/lib/attachment-limits.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/attachment-limits.ts#L3): `import { useEffect, useState } from "react";`
- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/attachment-limits.ts#L76): `const [limits, setLimits] = useState<AttachmentLimits>(`

### web/lib/auth.ts

- [121](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/auth.ts#L121): `): Promise<{ ok: boolean; error?: string; mustChangePassword?: boolean }> {`
- [173](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/auth.ts#L173): `error?: string;`

### web/lib/book-activity.ts

- [73](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/book-activity.ts#L73): `label: string;`
- [82](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/book-activity.ts#L82): `label: string;`
- [340](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/book-activity.ts#L340): `label: blockLabel(type, t),`
- [420](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/book-activity.ts#L420): `let label: string;`

### web/lib/book-types.ts

- [60](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/book-types.ts#L60): `label: string;`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/book-types.ts#L111): `links: Array<{ target_page_id: string; relation: string; label: string }>;`

### web/lib/chat-import/claude-code.ts

- [124](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/chat-import/claude-code.ts#L124): `label: projectLabel(groupCwd),`

### web/lib/chat-import/codex.ts

- [200](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/chat-import/codex.ts#L200): `groups.push({ cwd, label: projectLabel(cwd), sessions });`

### web/lib/chat-import/index.ts

- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/chat-import/index.ts#L86): `.map(([key, sessions]) => ({ key, label: key, sessions }));`
- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/chat-import/index.ts#L90): `label: p.label || projectLabel(p.cwd),`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/chat-import/index.ts#L91): `sublabel: p.cwd,`

### web/lib/chat-import/types.ts

- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/chat-import/types.ts#L33): `label: string;`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/chat-import/types.ts#L55): `label: string;`

### web/lib/codebuddy-auth.ts

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/codebuddy-auth.ts#L7): `user_label: string | null;`

### web/lib/concept-graph.ts

- [17](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/concept-graph.ts#L17): `function safeLabel(label: string): string {`
- [29](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/concept-graph.ts#L29): `if (graph.nodes.length === 0) {`

### web/lib/doc-attachments.ts

- [264](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/doc-attachments.ts#L264): `label: string; // e.g. "PDF"`
- [386](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/doc-attachments.ts#L386): `return { Icon: FileType2, tint: "text-red-500/80", label: "PDF" };`
- [388](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/doc-attachments.ts#L388): `return { Icon: FileText, tint: "text-blue-500/80", label: "DOCX" };`
- [393](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/doc-attachments.ts#L393): `label: "XLSX",`
- [396](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/doc-attachments.ts#L396): `return { Icon: Presentation, tint: "text-orange-500/80", label: "PPTX" };`
- [398](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/doc-attachments.ts#L398): `return { Icon: FileImage, tint: "text-teal-500/80", label: "SVG" };`

### web/lib/imports-api.ts

- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/imports-api.ts#L27): `if (sessions.length === 0) {`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/imports-api.ts#L61): `if (sessions.length === 0) throw new Error("No sessions to import");`

### web/lib/kb-name.ts

- [31](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/kb-name.ts#L31): `return forbiddenKbNameChars(trimmed).length === 0;`

### web/lib/knowledge-helpers.ts

- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/knowledge-helpers.ts#L64): `error?: string;`
- [401](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/knowledge-helpers.ts#L401): `progress?.error?.trim() ||`
- [402](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/knowledge-helpers.ts#L402): `storedProgress?.error?.trim() ||`

### web/lib/latex-normalize.ts

- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex-normalize.ts#L71): `function maskSpans(content: string, regex: RegExp, label: string): Mask {`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex-normalize.ts#L109): `if (prose.length === 0) return;`

### web/lib/latex.ts

- [219](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex.ts#L219): `if (headings.length === 0) return "";`
- [231](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex.ts#L231): `if (headings.length === 0) {`
- [245](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex.ts#L245): `if (lines.length === 0) return null;`
- [250](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex.ts#L250): `const renderNode = (id: string, type: string, label: string): string => {`
- [305](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex.ts#L305): `if (nodeDefs.length === 0 || edges.length === 0) return null;`
- [315](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/latex.ts#L315): `if (lines.length === 0) return null;`

### web/lib/learning-api.ts

- [435](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/learning-api.ts#L435): `label: string;`
- [448](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/learning-api.ts#L448): `label: string;`
- [529](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/learning-api.ts#L529): `label: string;`

### web/lib/markdown-display.ts

- [337](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/markdown-display.ts#L337): `(cell) => stripDisplaySyntax(cell).length === 0,`
- [558](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/markdown-display.ts#L558): `label: string,`

### web/lib/mastery-handoff.ts

- [123](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mastery-handoff.ts#L123): `if (!events || events.length === 0) return [];`

### web/lib/mastery-question.ts

- [36](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mastery-question.ts#L36): `label: string;`
- [114](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mastery-question.ts#L114): `label: text(entry.label),`

### web/lib/math-animator-types.ts

- [80](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/math-animator-types.ts#L80): `Object.keys(timings).length === 0 &&`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/math-animator-types.ts#L81): `Object.keys(render).length === 0`

### web/lib/mcp-api.ts

- [331](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mcp-api.ts#L331): `error?: unknown;`
- [348](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mcp-api.ts#L348): `error: String(item.error ?? ""),`
- [416](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mcp-api.ts#L416): `error: String(data.error ?? ""),`

### web/lib/mcp-store.ts

- [145](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mcp-store.ts#L145): `return missingRequiredFields(fields, values).length === 0;`
- [218](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/mcp-store.ts#L218): `if (words.length === 0) return "?";`

### web/lib/memory-graph.ts

- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L33): `label: string;`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L61): `label: string; // tooltip header`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L93): `label: string;`
- [403](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L403): `label: L3_LABEL[slot],`
- [451](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L451): `label: SURFACE_LABEL[surf],`
- [464](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L464): `label: SURFACE_LABEL[surf],`
- [494](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L494): `label: '${cluster.label} · ${entry.section || ""}'.trim(),`
- [525](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L525): `label: '${cluster.label} · ${entry.section || ""}'.trim(),`
- [553](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L553): `label: entity.label || entity.id,`
- [609](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/memory-graph.ts#L609): `label: cluster.label,`

### web/lib/message-branches.ts

- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/message-branches.ts#L69): `if (seeds.length === 0) return ROOT_KEY`
- [167](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/message-branches.ts#L167): `if (!children || children.length === 0) break`

### web/lib/model-catalog-types.ts

- [195](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/model-catalog-types.ts#L195): `label: string;`
- [226](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/model-catalog-types.ts#L226): `export type VoiceChoice = { id: string; label: string; languages?: string[] };`
- [229](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/model-catalog-types.ts#L229): `label: string;`
- [250](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/model-catalog-types.ts#L250): `label: string;`

### web/lib/page-customization.ts

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/page-customization.ts#L6): `label: string`
- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/page-customization.ts#L47): `label: t('starters.${group}.${n}'),`

### web/lib/partner-groups-api.ts

- [259](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/partner-groups-api.ts#L259): `label: string;`

### web/lib/partners-api.ts

- [47](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/partners-api.ts#L47): `last_reload_error?: string | null;`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/partners-api.ts#L49): `start_error?: string;`

### web/lib/provider-branding.ts

- [136](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/provider-branding.ts#L136): `export function formatProviderLabel(provider: string, label: string, language: string): string {`

### web/lib/provider-registry.ts

- [337](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/provider-registry.ts#L337): `if (!saved && now.models.length === 0)`

### web/lib/question-bank-answers.ts

- [7](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/question-bank-answers.ts#L7): `label: string;`
- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/question-bank-answers.ts#L12): `return { label: "Partially Correct", className: "bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400" };`
- [14](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/question-bank-answers.ts#L14): `return { label: "Not Graded", className: "bg-[var(--muted)] text-[var(--muted-foreground)]" };`
- [16](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/question-bank-answers.ts#L16): `return { label: "Correct", className: "bg-green-100 text-green-700 dark:bg-green-950/30 dark:text-green-400" };`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/question-bank-answers.ts#L18): `return { label: "Incorrect", className: "bg-red-100 text-red-700 dark:bg-red-950/30 dark:text-red-400" };`

### web/lib/quiz-judge.ts

- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/quiz-judge.ts#L154): `reject(reader.error ?? new Error("Failed to read file"));`

### web/lib/quiz-types.ts

- [138](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/quiz-types.ts#L138): `if (!Array.isArray(events) || events.length === 0) return null;`
- [197](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/quiz-types.ts#L197): `if (!Array.isArray(results) || results.length === 0) return null;`
- [283](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/quiz-types.ts#L283): `cfg.question_types.length === 0`

### web/lib/reading-api.ts

- [177](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-api.ts#L177): `label: string;`
- [190](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-api.ts#L190): `label: string;`

### web/lib/reading-citations.ts

- [149](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-citations.ts#L149): `label: string;`
- [194](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-citations.ts#L194): `best = { start, end, label: match[0] };`
- [321](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-citations.ts#L321): `const label = parts.length === 0 ? 'p.${piece}' : piece;`

### web/lib/reading-passage-prompts.ts

- [23](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-passage-prompts.ts#L23): `label: string;`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-passage-prompts.ts#L97): `label: t("Explain"),`
- [102](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-passage-prompts.ts#L102): `label: t("Translate"),`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reading-passage-prompts.ts#L109): `label: t("Guide me"),`

### web/lib/reasoning-effort.ts

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reasoning-effort.ts#L3): `label: string;`
- [58](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reasoning-effort.ts#L58): `if (resolved.length === 0) return [];`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reasoning-effort.ts#L61): `label: LABELS[value] ?? value,`
- [89](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/reasoning-effort.ts#L89): `if (declaredReasoning === true && fromTables.length === 0) {`

### web/lib/research-types.ts

- [68](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/research-types.ts#L68): `return { valid: Object.keys(errors).length === 0, errors };`

### web/lib/selection-text.ts

- [59](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/selection-text.ts#L59): `if (roots.length === 0) return range.toString();`

### web/lib/session-activity.ts

- [150](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L150): `tools.length === 0 &&`
- [152](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L152): `attachments.length === 0 &&`
- [153](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L153): `artifacts.length === 0 &&`
- [154](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L154): `space.historySessionIds.length === 0 &&`
- [155](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L155): `space.bookIds.length === 0 &&`
- [156](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L156): `space.notebookIds.length === 0 &&`
- [157](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L157): `space.questionEntryIds.length === 0 &&`
- [158](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L158): `space.personas.length === 0 &&`
- [159](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/session-activity.ts#L159): `space.memoryKinds.length === 0;`

### web/lib/settings-presets.ts

- [5](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/settings-presets.ts#L5): `label: string;`

### web/lib/settings-readiness.ts

- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/settings-readiness.ts#L38): `label: string;`

### web/lib/setup-signals.ts

- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/setup-signals.ts#L18): `label: string;`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/setup-signals.ts#L38): `if (!events || events.length === 0) return null;`
- [50](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/setup-signals.ts#L50): `label: String(payload.label ?? ""),`
- [69](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/setup-signals.ts#L69): `if (!messages || messages.length === 0) return [];`

### web/lib/sidebar-entries.ts

- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/sidebar-entries.ts#L40): `label: string;`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/sidebar-entries.ts#L63): `label: string;`
- [81](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/sidebar-entries.ts#L81): `return { id: "recent:unassigned", group: "recent", label: "Recent" };`
- [86](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/sidebar-entries.ts#L86): `return topic ? { id: topicId, group: "mastery", label: topic.name } : null;`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/sidebar-entries.ts#L92): `? { id: collectionId, group: "reading", label: collection.title }`

### web/lib/sidebar-layout.ts

- [214](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/sidebar-layout.ts#L214): `if (order.length === 0) return [...items];`

### web/lib/space-items.ts

- [26](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/space-items.ts#L26): `label: string;`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/space-items.ts#L35): `label: "Chat History",`
- [42](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/space-items.ts#L42): `label: "My Agents",`
- [49](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/space-items.ts#L49): `label: "Notebooks",`
- [57](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/space-items.ts#L57): `label: "Question Bank",`
- [64](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/space-items.ts#L64): `label: "Personas",`
- [71](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/space-items.ts#L71): `label: "Skills",`

### web/lib/think-segments.ts

- [90](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/think-segments.ts#L90): `if (blocks.length === 0) return input;`

### web/lib/youtube-iframe-api.ts

- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/lib/youtube-iframe-api.ts#L38): `const finish = (namespace?: YouTubeNamespace, error?: Error) => {`

### web/shared/ui/Button.tsx

- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Button.tsx#L13): `loading?: boolean;`
- [65](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Button.tsx#L65): `{loading ? (`

### web/shared/ui/Dialog.tsx

- [99](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Dialog.tsx#L99): `if (focusable.length === 0) {`

### web/shared/ui/Field.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Field.tsx#L6): `label: string;`
- [13](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Field.tsx#L13): `error?: ReactNode;`
- [33](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Field.tsx#L33): `error ? errorId : undefined,`
- [54](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Field.tsx#L54): `"aria-invalid": error ? true : children.props["aria-invalid"],`
- [61](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Field.tsx#L61): `{error ? (`

### web/shared/ui/IconButton.tsx

- [11](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/IconButton.tsx#L11): `label: string;`

### web/shared/ui/Tooltip.tsx

- [12](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Tooltip.tsx#L12): `useState,`
- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Tooltip.tsx#L27): `label: string;`
- [62](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Tooltip.tsx#L62): `const [visible, setVisible] = useState(false);`
- [63](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/Tooltip.tsx#L63): `const [layerMounted, setLayerMounted] = useState(false);`

### web/shared/ui/TooltipLayer.tsx

- [6](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/TooltipLayer.tsx#L6): `useState,`
- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/TooltipLayer.tsx#L28): `label: string;`
- [35](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/TooltipLayer.tsx#L35): `const [position, setPosition] = useState<TooltipPosition | null>(null);`

### web/shared/ui/useMenuPopover.ts

- [8](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/useMenuPopover.ts#L8): `* move between '[role="menuitem"]'s with the arrow keys.`
- [18](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/useMenuPopover.ts#L18): `root?.querySelector<HTMLElement>('[role="menuitem"][aria-current="page"], [role="menuitem"]')?.focus();`
- [30](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/shared/ui/useMenuPopover.ts#L30): `const items = [...(root?.querySelectorAll<HTMLElement>('[role="menuitem"]') ?? [])];`

### web/context/AppShellContext.tsx

- [9](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L9): `useState,`
- [91](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L91): `const [theme, setThemeState] = useState<Theme>(() => {`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L95): `const [language, setLanguageState] = useState<AppLanguage>("en");`
- [96](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L96): `const [languageReady, setLanguageReady] = useState(false);`
- [97](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L97): `const [activeSessionId, setActiveSessionIdState] = useState<string | null>(`
- [101](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L101): `const [sidebarCollapsed, setSidebarCollapsedState] = useState<boolean>(false);`
- [103](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L103): `const [codeBlockTheme, setCodeBlockThemeState] = useState<string>(`
- [107](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L107): `useState<boolean>(DEFAULT_CODE_BLOCK_SHOW_LINE_NUMBERS);`
- [109](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L109): `useState<boolean>(DEFAULT_CODE_BLOCK_WRAP_LONG_LINES);`
- [111](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/AppShellContext.tsx#L111): `const [learningDisplay, setLearningDisplay] = useState(`

### web/context/PageCustomizationContext.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/PageCustomizationContext.tsx#L10): `useState,`
- [38](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/PageCustomizationContext.tsx#L38): `const [value, setValue] = useState(DEFAULT_PAGE_CUSTOMIZATION)`
- [39](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/PageCustomizationContext.tsx#L39): `const [loading, setLoading] = useState(true)`
- [40](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/PageCustomizationContext.tsx#L40): `const [error, setError] = useState(false)`

### web/context/QuizFollowupContext.tsx

- [27](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/QuizFollowupContext.tsx#L27): `useState,`
- [243](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/QuizFollowupContext.tsx#L243): `const [threads, setThreads] = useState<Record<string, FollowupThreadState>>(`
- [479](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/QuizFollowupContext.tsx#L479): `if (!content && input.attachments.length === 0) return;`

### web/context/ReadingContext.tsx

- [10](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/ReadingContext.tsx#L10): `useState,`
- [92](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/ReadingContext.tsx#L92): `const [material, setMaterial] = useState<MaterialDetail | null>(null);`
- [93](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/ReadingContext.tsx#L93): `const [annotations, setAnnotations] = useState<AnnotationItem[]>([]);`
- [94](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/ReadingContext.tsx#L94): `const [loading, setLoading] = useState(false);`
- [95](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/context/ReadingContext.tsx#L95): `const [error, setErrorState] = useState<string | null>(null);`

### web/i18n/I18nProvider.tsx

- [3](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/i18n/I18nProvider.tsx#L3): `import { useEffect, useState } from "react";`
- [32](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/web/i18n/I18nProvider.tsx#L32): `const [readyLanguage, setReadyLanguage] = useState<AppLanguage | null>(() =>`

### packages/chat-engine/src/native/model-round.ts

- [28](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/native/model-round.ts#L28): `label: settling`

### packages/chat-engine/src/tools/ask-user.ts

- [19](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/tools/ask-user.ts#L19): `const key = (label: string) => label.replace(/\s/g, "").toLowerCase();`
- [44](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/tools/ask-user.ts#L44): `const options: { label: string; description: string | null }[] = [];`
- [55](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/tools/ask-user.ts#L55): `? { label: rawOption }`

### packages/chat-engine/src/tools/dispatcher.ts

- [76](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/tools/dispatcher.ts#L76): `label: this.input.copy.tool_call || "Tool call",`

### packages/chat-engine/src/transport/stdio.ts

- [183](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/transport/stdio.ts#L183): `String(error?.message ?? "Host operation failed"),`
- [185](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/transport/stdio.ts#L185): `error?.partialResponse === true,`
- [186](https://github.com/HKUDS/DeepTutor/blob/f7aed0744c36c5afef16a4261c31ebee1208cac2/packages/chat-engine/src/transport/stdio.ts#L186): `error?.fatal === true,`
